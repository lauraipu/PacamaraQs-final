import {
  ETIQUETAS_HEDONICAS,
  RUEDA_SABORES
} from "./chunk-ECLBRM7C.js";
import {
  FormatoCva,
  checkmarkCircleOutline,
  closeOutline,
  documentTextOutline,
  downloadOutline,
  getFormatoById,
  hourglassOutline,
  lockClosedOutline,
  medalOutline,
  ribbonOutline,
  sesionDtoToDomain,
  trophyOutline
} from "./chunk-IN4O4X7H.js";
import {
  codigoDeError,
  mensajeDeError
} from "./chunk-OFWJO6PD.js";
import {
  addIcons
} from "./chunk-4JFQPQWK.js";
import {
  ActivatedRoute,
  CommonModule,
  Component,
  DOCUMENT,
  DatePipe,
  DecimalPipe,
  Injectable,
  Injector,
  Input,
  IonAccordion,
  IonAccordionGroup,
  IonBackButton,
  IonBadge,
  IonButton,
  IonButtons,
  IonCard,
  IonCardContent,
  IonCheckbox,
  IonCol,
  IonContent,
  IonGrid,
  IonHeader,
  IonIcon,
  IonItem,
  IonLabel,
  IonList,
  IonModal,
  IonRow,
  IonSegment,
  IonSegmentButton,
  IonSelect,
  IonSelectOption,
  IonSpinner,
  IonTitle,
  IonToolbar,
  NavController,
  NgClass,
  NgTemplateOutlet,
  SupabaseService,
  ToastController,
  ViewChild,
  afterNextRender,
  computed,
  inject,
  setClassMetadata,
  signal,
  viewChild,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵattribute,
  ɵɵclassMap,
  ɵɵclassProp,
  ɵɵconditional,
  ɵɵconditionalCreate,
  ɵɵdefineComponent,
  ɵɵdefineInjectable,
  ɵɵelement,
  ɵɵelementContainer,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵinterpolate1,
  ɵɵlistener,
  ɵɵnamespaceHTML,
  ɵɵnamespaceSVG,
  ɵɵnextContext,
  ɵɵpipe,
  ɵɵpipeBind2,
  ɵɵproperty,
  ɵɵpureFunction0,
  ɵɵpureFunction1,
  ɵɵpureFunction2,
  ɵɵpureFunction3,
  ɵɵqueryAdvance,
  ɵɵreference,
  ɵɵrepeater,
  ɵɵrepeaterCreate,
  ɵɵrepeaterTrackByIdentity,
  ɵɵrepeaterTrackByIndex,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵstyleProp,
  ɵɵtemplate,
  ɵɵtemplateRefExtractor,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1,
  ɵɵtextInterpolate2,
  ɵɵtextInterpolate3,
  ɵɵviewQuerySignal
} from "./chunk-DEQWXDMW.js";
import "./chunk-BMQUG2PJ.js";
import "./chunk-3OZZMUVI.js";
import "./chunk-3GAB7GSC.js";
import "./chunk-B7Y4FMY7.js";
import "./chunk-NQCL7WZ3.js";
import "./chunk-4BTEZGN2.js";
import "./chunk-XTVSKRH4.js";
import "./chunk-ETZFPO3Y.js";
import "./chunk-LLS636HS.js";
import "./chunk-KQQH3YTO.js";
import "./chunk-DI3VEDFV.js";
import {
  __spreadProps,
  __spreadValues
} from "./chunk-PAXKX5KU.js";

// src/app/core/cva/hoja-sca.ts
var ATRIBUTOS_HOJA = [
  "fragancia",
  "aroma",
  "sabor",
  "sabor_residual",
  "acidez",
  "dulzor",
  "sensacion_boca"
];
var CLAVE_FORMULARIO = {
  fragancia: "fragancia",
  aroma: "aroma",
  sabor: "sabor",
  sabor_residual: "saborResidual",
  acidez: "acidez",
  dulzor: "dulzor",
  sensacion_boca: "sensacionEnBoca"
};
var DESCRIPTORES_SCA = [
  [{ clave: "floral", etiqueta: "Floral", principal: true }],
  [
    { clave: "afrutado", etiqueta: "Afrutado", principal: true },
    { clave: "afrutado.bayas", etiqueta: "Bayas", principal: false },
    { clave: "afrutado.deshidratadas", etiqueta: "Frutas deshidratadas", principal: false },
    { clave: "afrutado.citricos", etiqueta: "C\xEDtricos", principal: false }
  ],
  [
    { clave: "acido_fermentado", etiqueta: "\xC1cido/Fermentado", principal: true },
    { clave: "acido_fermentado.acido", etiqueta: "\xC1cido", principal: false },
    { clave: "acido_fermentado.fermentado", etiqueta: "Fermentado", principal: false }
  ],
  [{ clave: "verde", etiqueta: "Verde/Vegetal", principal: true }],
  [
    { clave: "otra", etiqueta: "Otra", principal: true },
    { clave: "otra.quimico", etiqueta: "Qu\xEDmico", principal: false },
    { clave: "otra.humedad", etiqueta: "Humedad/Tierra", principal: false },
    { clave: "otra.madera", etiqueta: "Madera", principal: false }
  ],
  [
    { clave: "tostado", etiqueta: "Tostado", principal: true },
    { clave: "tostado.cereal", etiqueta: "Cereal", principal: false },
    { clave: "tostado.quemado", etiqueta: "Quemado", principal: false },
    { clave: "tostado.tabaco", etiqueta: "Tabaco", principal: false }
  ],
  [
    { clave: "nueces_cacao", etiqueta: "Nueces/Cacao", principal: true },
    { clave: "nueces_cacao.nueces", etiqueta: "Nueces", principal: false },
    { clave: "nueces_cacao.cacao", etiqueta: "Cacao", principal: false }
  ],
  [{ clave: "especias", etiqueta: "Especias", principal: true }],
  [
    { clave: "dulce", etiqueta: "Dulce", principal: true },
    { clave: "dulce.vainilla", etiqueta: "Vainilla", principal: false },
    { clave: "dulce.azucar_morena", etiqueta: "Az\xFAcar morena", principal: false }
  ]
];
var GUSTOS_SCA = [
  { clave: "salado", etiqueta: "Salado", principal: true },
  { clave: "acido", etiqueta: "\xC1cido", principal: true },
  { clave: "dulce", etiqueta: "Dulce", principal: true },
  { clave: "amargo", etiqueta: "Amargo", principal: true },
  { clave: "umami", etiqueta: "Umami", principal: true }
];
var BOCA_SCA = [
  { clave: "aspero", etiqueta: "\xC1spero", detalle: "(Arenoso, Rugoso, Rasposo)", principal: true },
  { clave: "aceitoso", etiqueta: "Aceitoso", detalle: "", principal: true },
  { clave: "suave", etiqueta: "Suave", detalle: "(Aterciopelado, Sedoso, Almibarado)", principal: true },
  { clave: "astringente", etiqueta: "Deja seca la boca", detalle: "(astringente)", principal: true },
  { clave: "metalico", etiqueta: "Met\xE1lico", detalle: "", principal: true }
];
var DEFECTOS_SCA = [
  { clave: "mohoso", etiqueta: "Mohoso", principal: true },
  { clave: "fenolico", etiqueta: "Fen\xF3lico", principal: true },
  { clave: "papa", etiqueta: "Papa", principal: true }
];
var normalizar = (texto) => texto.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().replace(/\s+/g, " ").trim();
var CATEGORIA_APP_A_SCA = {
  [normalizar("Floral")]: "floral",
  [normalizar("Afrutado")]: "afrutado",
  [normalizar("\xC1cido / Fermentado")]: "acido_fermentado",
  [normalizar("Verde / Vegetal")]: "verde",
  [normalizar("Otro")]: "otra",
  [normalizar("Tostado")]: "tostado",
  [normalizar("Nueces / Cacao")]: "nueces_cacao",
  [normalizar("Especias")]: "especias",
  [normalizar("Dulce")]: "dulce"
};
var SUB_APP_A_SCA = {
  [normalizar("Bayas")]: "afrutado.bayas",
  [normalizar("Frutas deshidratadas")]: "afrutado.deshidratadas",
  [normalizar("C\xEDtricos")]: "afrutado.citricos",
  [normalizar("\xC1cido ac\xE9tico")]: "acido_fermentado.acido",
  [normalizar("Agrio")]: "acido_fermentado.acido",
  [normalizar("Fermentado")]: "acido_fermentado.fermentado",
  [normalizar("Madera")]: "otra.madera",
  [normalizar("Tinta")]: "otra.quimico",
  [normalizar("Caucho")]: "otra.quimico",
  [normalizar("Cereal")]: "tostado.cereal",
  [normalizar("Quemado")]: "tostado.quemado",
  [normalizar("Tabaco")]: "tostado.tabaco",
  [normalizar("Pipa")]: "tostado.tabaco",
  [normalizar("Nueces")]: "nueces_cacao.nueces",
  [normalizar("Almendra")]: "nueces_cacao.nueces",
  [normalizar("Cacao")]: "nueces_cacao.cacao",
  [normalizar("Chocolate")]: "nueces_cacao.cacao",
  [normalizar("Vainilla")]: "dulce.vainilla",
  [normalizar("Az\xFAcar morena")]: "dulce.azucar_morena",
  [normalizar("Miel")]: "dulce.azucar_morena",
  [normalizar("Caramelo")]: "dulce.azucar_morena"
};
var CATEGORIA_DE_SUB = new Map(Object.entries(RUEDA_SABORES).flatMap(([categoria, { subdescriptores }]) => subdescriptores.map((sub) => [normalizar(sub), normalizar(categoria)])));
function casillasDeDescriptores(descriptores) {
  const casillas = /* @__PURE__ */ new Set();
  for (const descriptor of descriptores) {
    const n = normalizar(descriptor);
    const categoriaDirecta = CATEGORIA_APP_A_SCA[n];
    if (categoriaDirecta) {
      casillas.add(categoriaDirecta);
      continue;
    }
    const sub = SUB_APP_A_SCA[n];
    if (sub) {
      casillas.add(sub);
      casillas.add(sub.split(".")[0]);
      continue;
    }
    const categoria = CATEGORIA_DE_SUB.get(n);
    const clave = categoria ? CATEGORIA_APP_A_SCA[categoria] : void 0;
    if (clave)
      casillas.add(clave);
  }
  return casillas;
}
function casillasDeBoca(valores) {
  const casillas = /* @__PURE__ */ new Set();
  for (const valor of valores) {
    const n = normalizar(valor);
    if (n.startsWith("aspero"))
      casillas.add("aspero");
    else if (n.startsWith("aceitoso"))
      casillas.add("aceitoso");
    else if (n.startsWith("suave"))
      casillas.add("suave");
    else if (n.startsWith("astringente") || n.includes("seca la boca"))
      casillas.add("astringente");
    else if (n.startsWith("metalico"))
      casillas.add("metalico");
  }
  return casillas;
}
function casillasDeDefectos(valores) {
  const casillas = /* @__PURE__ */ new Set();
  for (const valor of valores) {
    const n = normalizar(valor);
    if (n.includes("mohoso"))
      casillas.add("mohoso");
    if (n.includes("fenolico"))
      casillas.add("fenolico");
    if (n.startsWith("papa"))
      casillas.add("papa");
  }
  return casillas;
}
var comoRegistro = (v) => v && typeof v === "object" && !Array.isArray(v) ? v : {};
var comoTextos = (v) => Array.isArray(v) ? v.filter((x) => typeof x === "string" && x.trim() !== "") : [];
var comoTexto = (v) => typeof v === "string" ? v.trim() : "";
var numeroEn = (v, min, max) => {
  const n = typeof v === "number" ? v : typeof v === "string" && v.trim() ? Number(v) : NaN;
  return Number.isFinite(n) && n >= min && n <= max ? n : null;
};
var unir = (...partes) => partes.filter(Boolean).join(" \xB7 ");
function leerFichaSca(ficha) {
  const formulario = comoRegistro(ficha.formulario);
  const bloque = (a) => comoRegistro(comoRegistro(formulario["atributos"])[CLAVE_FORMULARIO[a]] ?? formulario[CLAVE_FORMULARIO[a]]);
  const intensidad = {};
  const calidad = {};
  for (const a of ATRIBUTOS_HOJA) {
    const db = ficha.atributos[a];
    const json = bloque(a);
    intensidad[a] = db?.intensidad ?? numeroEn(json["intensidad"], 0, 15);
    calidad[a] = db?.calidad ?? numeroEn(json["calidad"], 1, 9);
  }
  const descriptores = (atributos) => atributos.flatMap((a) => comoTextos(bloque(a)["descriptores"]));
  const extras = (atributos) => atributos.map((a) => comoTexto(bloque(a)["extra"])).filter(Boolean);
  const listar = (nombres) => nombres.length ? `Descriptores: ${[...new Set(nombres)].join(", ")}` : "";
  const olfativos = descriptores(["fragancia", "aroma"]);
  const gustativos = descriptores(["sabor", "sabor_residual"]);
  const boca = [...comoTextos(formulario["mouthfeel"]), ...comoTextos(bloque("sensacion_boca")["textura"])];
  const defectos = comoTextos(formulario["tiposDefecto"]);
  const defectosSinCasilla = defectos.filter((d) => casillasDeDefectos([d]).size === 0);
  const tazas = comoRegistro(formulario["defectos"]);
  return {
    intensidad,
    calidad,
    impresionGlobal: ficha.impresionGlobal ?? numeroEn(formulario["impresionGlobal"], 1, 9),
    olfativo: casillasDeDescriptores(olfativos),
    gustativo: casillasDeDescriptores(gustativos),
    gustos: /* @__PURE__ */ new Set(),
    boca: casillasDeBoca(boca),
    defectos: casillasDeDefectos(defectos),
    tazasNoUniformes: numeroEn(ficha.tazasNoUniformes ?? tazas["tazasNoUniformes"], 0, 5),
    tazasDefectuosas: numeroEn(ficha.tazasDefectuosas ?? tazas["tazasDefectuosas"], 0, 5),
    puntaje: ficha.puntaje > 0 ? ficha.puntaje : null,
    notas: {
      olfativo: unir(listar(olfativos), ...extras(["fragancia", "aroma"])),
      gustativo: unir(listar(gustativos), ...extras(["sabor", "sabor_residual"])),
      acidez: comoTexto(bloque("acidez")["nota"]),
      dulzor: comoTexto(bloque("dulzor")["nota"]),
      boca: comoTexto(formulario["notasMouthfeel"]),
      otras: unir(comoTexto(formulario["notas"]), defectosSinCasilla.length ? `Otros defectos: ${defectosSinCasilla.join(", ")}` : "")
    }
  };
}
var promedio = (valores) => {
  const v = valores.filter((x) => x !== null);
  return v.length ? Math.round(v.reduce((t, x) => t + x, 0) / v.length * 100) / 100 : null;
};
function mayoria(conjuntos) {
  const conteo = /* @__PURE__ */ new Map();
  for (const c of conjuntos)
    for (const clave of c)
      conteo.set(clave, (conteo.get(clave) ?? 0) + 1);
  return new Set([...conteo].filter(([, n]) => n / conjuntos.length > 0.5).map(([clave]) => clave));
}
var NOTA_PANEL = "Ver reporte individual de cada catador.";
function consolidarFichas(fichas, resumenNotas) {
  const intensidad = {};
  const calidad = {};
  for (const a of ATRIBUTOS_HOJA) {
    intensidad[a] = promedio(fichas.map((f) => f.intensidad[a]));
    calidad[a] = promedio(fichas.map((f) => f.calidad[a]));
  }
  return {
    intensidad,
    calidad,
    impresionGlobal: promedio(fichas.map((f) => f.impresionGlobal)),
    olfativo: mayoria(fichas.map((f) => f.olfativo)),
    gustativo: mayoria(fichas.map((f) => f.gustativo)),
    gustos: mayoria(fichas.map((f) => f.gustos)),
    boca: mayoria(fichas.map((f) => f.boca)),
    defectos: mayoria(fichas.map((f) => f.defectos)),
    tazasNoUniformes: promedio(fichas.map((f) => f.tazasNoUniformes)),
    tazasDefectuosas: promedio(fichas.map((f) => f.tazasDefectuosas)),
    puntaje: promedio(fichas.map((f) => f.puntaje)),
    notas: {
      olfativo: NOTA_PANEL,
      gustativo: NOTA_PANEL,
      acidez: NOTA_PANEL,
      dulzor: NOTA_PANEL,
      boca: NOTA_PANEL,
      otras: resumenNotas
    }
  };
}
function circuloMarcado(valor) {
  return valor === null ? null : Math.min(9, Math.max(1, Math.round(valor)));
}
function etiquetaCalidad(valor) {
  const n = circuloMarcado(valor);
  return n === null ? "" : `${n} \xB7 ${ETIQUETAS_HEDONICAS[n] ?? ""}`;
}
function puntajePanel(puntajes) {
  if (puntajes.length === 0)
    return null;
  const orden = [...puntajes].sort((a, b) => a - b);
  const usados = orden.length >= 5 ? orden.slice(1, -1) : orden;
  return Math.round(usados.reduce((t, x) => t + x, 0) / usados.length * 100) / 100;
}

// src/app/core/services/estilos-hoja-sca.ts
var ESTILOS_HOJA_SCA = `
  @page sca { size: A4 portrait; margin: 8mm 8mm 7mm; }
  .sca-page {
    page: sca;
    --sca-ink: #2b2f35;
    --sca-slate: #3a3f47;
    --sca-line: 0.3mm solid #3a3f47;
    color: var(--sca-ink);
    font: 500 7pt/1.25 "Helvetica Neue", Helvetica, Arial, sans-serif;
    break-after: page;
    page-break-after: always;
  }
  .sca-page:last-child { break-after: auto; page-break-after: auto; }
  .sca-page p { margin: 0; }

  /* \u2500\u2500 Cabecera \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 */
  .sca-head { display: grid; grid-template-columns: 1fr; gap: 4mm; align-items: end; margin-bottom: 2.5mm; }
  .sca-page--combinado .sca-head { grid-template-columns: 1fr 74mm; }
  .sca-head__brand { font-size: 8pt; font-weight: 600; color: #555b63; }
  .sca-head h1 { margin: 0.4mm 0 2mm; color: var(--sca-slate); font-size: 21pt; font-weight: 700; letter-spacing: -0.01em; line-height: 1.05; }
  .sca-fields { display: grid; grid-template-columns: 1.55fr 1fr; gap: 2.2mm 6mm; }
  .sca-field { display: flex; align-items: baseline; gap: 1.8mm; font-size: 9pt; }
  .sca-field span { color: var(--sca-slate); font-weight: 700; white-space: nowrap; }
  .sca-field b {
    flex: 1; min-height: 4mm; padding: 0 1mm 0.3mm;
    border-bottom: 0.3mm dotted var(--sca-slate);
    font-size: 8.5pt; font-weight: 500; overflow: hidden; white-space: nowrap; text-overflow: ellipsis;
  }
  .sca-legend { padding: 1.4mm 2mm; border: var(--sca-line); }
  .sca-legend > p { margin-bottom: 1mm; font-size: 6pt; font-weight: 800; }
  .sca-legend ol {
    display: grid; grid-auto-flow: column; grid-template-rows: repeat(3, auto);
    gap: 0.5mm 1.6mm; margin: 0; padding: 0; list-style: none; font-size: 4.3pt; white-space: nowrap;
  }
  .sca-legend i {
    display: inline-grid; place-items: center; width: 2.5mm; height: 2.5mm; margin-right: 0.6mm;
    border: 0.2mm solid var(--sca-ink); border-radius: 50%; font-size: 4pt; font-style: normal; vertical-align: middle;
  }

  /* \u2500\u2500 Consolidado del panel \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 */
  .sca-kpis { display: flex; flex-wrap: wrap; gap: 1.2mm 2mm; margin-bottom: 2mm; }
  .sca-kpi { flex: 0 1 44mm; padding: 1mm 2.2mm; border: var(--sca-line); border-radius: 1.5mm; }
  .sca-kpi strong { display: block; color: #c2410c; font-size: 11pt; font-weight: 800; }
  .sca-kpi span { color: #555b63; font-size: 5.5pt; font-weight: 700; text-transform: uppercase; letter-spacing: 0.04em; }
  .sca-kpis__note { flex-basis: 100%; color: #555b63; font-size: 5.6pt; }

  /* \u2500\u2500 Barras de secci\xF3n \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 */
  .sca-bars { display: grid; grid-template-columns: 1fr 3mm 33%; align-items: center; }
  .sca-bars__left { display: flex; align-items: center; gap: 1.4mm; grid-column: 1; }
  .sca-bars__right { grid-column: 3; }
  .sca-bars--desc { display: flex; gap: 1.4mm; }
  .sca-bar {
    display: inline-block; padding: 1.2mm 2.4mm; background: var(--sca-slate); color: #fff;
    font-size: 8pt; font-weight: 700; letter-spacing: 0.01em; white-space: nowrap;
  }
  .sca-bar--block { display: block; }
  .sca-bar--muestra em { margin-left: 2mm; padding: 0 2mm; background: #fff; color: var(--sca-slate); font-style: normal; }
  .sca-roast { position: relative; flex: 1; height: 3.2mm; background: linear-gradient(90deg, #f3f3f5, var(--sca-slate)); }
  .sca-roast em { position: absolute; top: 50%; left: 2mm; transform: translateY(-50%); color: var(--sca-slate); font-size: 6pt; font-style: normal; font-weight: 800; }

  /* \u2500\u2500 Rejilla del Formato Combinado (Parte 1 | Parte 2) \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 */
  .sca-comb { display: grid; grid-template-columns: 1fr 3mm 33%; }
  .sca-comb > .sca-l { grid-column: 1; }
  .sca-comb > .sca-r { grid-column: 3; }
  .sca-l, .sca-r { border: var(--sca-line); border-top: none; overflow: hidden; }
  .sca-comb > :nth-child(-n + 2) { border-top: var(--sca-line); }
  .sca-l--sliders { height: 18.5mm; display: flex; flex-direction: column; justify-content: center; gap: 0.6mm; }
  .sca-l--one { height: 8.6mm; display: flex; align-items: center; }
  .sca-l--one > .sca-attr { flex: 1; }
  .sca-h-desc { height: 35mm; }
  .sca-h-desc2 { height: 43mm; }
  .sca-h-note { height: 11mm; }
  .sca-h-boca { height: 19mm; }
  .sca-otras { height: 31mm; }
  .sca-r--circles { display: flex; flex-direction: column; justify-content: space-around; }

  /* \u2500\u2500 Rejilla del Formato Descriptivo (atributos | notas) \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 */
  .sca-desc-grid { display: grid; grid-template-columns: minmax(0, 1fr) 27%; border-top: var(--sca-line); }
  .sca-desc-grid > .sca-l { grid-column: 1; }
  .sca-desc-grid > .sca-r { grid-column: 2; border-left: none; }
  .sca-desc-grid > .sca-full { grid-column: 1 / -1; height: 42mm; }
  .sca-desc-grid .sca-l--sliders { height: auto; padding: 1mm 0; }
  .sca-span2 { grid-row: span 2; }
  .sca-h-attr { height: 11mm; }
  .sca-desc-gustos { display: grid; grid-template-columns: minmax(0, 1fr) 24mm; }
  .sca-desc-gustos .sca-desc { padding-right: 1.5mm; column-gap: 2mm; }
  .sca-desc-gustos .sca-desc .sca-cb { margin-right: 0.9mm; font-size: 5.8pt; }
  .sca-desc-gustos > .sca-gustos { margin: 0; padding: 1.4mm 2mm; border-left: var(--sca-line); }

  /* \u2500\u2500 Slider de intensidad 0\u201315 \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 */
  .sca-attr { display: grid; grid-template-columns: 31mm minmax(0, 1fr); align-items: end; gap: 2mm; padding: 0.3mm 3mm 0.3mm 2.5mm; }
  .sca-attr__name b { display: block; color: var(--sca-slate); font-size: 9pt; font-weight: 800; line-height: 1.05; }
  .sca-attr__name small { display: block; margin-top: 0.3mm; font-size: 5.6pt; font-weight: 700; white-space: nowrap; }
  .sca-attr__val { display: inline-block; margin-left: 0.8mm; padding: 0 0.9mm; border-radius: 0.6mm; background: #000; color: #fff; font-size: 5.8pt; font-weight: 800; }
  .sca-slider { position: relative; padding-top: 2.3mm; }
  .sca-slider__zones span {
    position: absolute; top: 0; transform: translateX(-50%);
    font-size: 4.6pt; font-weight: 800; letter-spacing: 0.08em; color: var(--sca-slate);
  }
  .sca-slider__zones span:nth-child(1) { left: 17%; }
  .sca-slider__zones span:nth-child(2) { left: 50%; }
  .sca-slider__zones span:nth-child(3) { left: 83%; }
  .sca-slider__bar { position: relative; height: 2.3mm; background: linear-gradient(90deg, #ececef 0%, #9a9ea6 50%, var(--sca-slate) 100%); }
  .sca-slider__ticks {
    height: 1.3mm;
    border-right: 0.25mm solid var(--sca-slate);
    background:
      repeating-linear-gradient(90deg, var(--sca-slate) 0 0.25mm, transparent 0.25mm 33.3333%) top left / 100% 100% no-repeat,
      repeating-linear-gradient(90deg, var(--sca-slate) 0 0.18mm, transparent 0.18mm 6.6667%) top left / 100% 55% no-repeat;
  }
  .sca-slider__nums { position: relative; height: 2.1mm; font-size: 4.6pt; font-weight: 700; }
  .sca-slider__nums span { position: absolute; top: 0.1mm; transform: translateX(-50%); }
  .sca-slider__nums span:first-child { transform: none; }
  .sca-slider__nums span:last-child { transform: translateX(-100%); }
  /* Marca del catador: l\xEDnea vertical con punta, como el trazo a mano. */
  .sca-slider__mark {
    position: absolute; top: -0.9mm; bottom: -1.6mm; width: 0.6mm;
    background: #000; transform: translateX(-50%);
  }
  .sca-slider__mark::before {
    content: ''; position: absolute; top: -1mm; left: 50%; transform: translateX(-50%);
    border: 0.9mm solid transparent; border-top: 1.1mm solid #000; border-bottom: 0;
  }

  /* \u2500\u2500 C\xEDrculos 1\u20139 + FINAL \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 */
  .sca-circles { display: flex; align-items: center; gap: 0.45mm; padding: 0.6mm 2.4mm; }
  .sca-c {
    display: grid; place-items: center; width: 4.4mm; height: 4.4mm; flex: none;
    border: 0.25mm solid var(--sca-slate); border-radius: 50%;
    color: var(--sca-slate); font-size: 7pt; font-weight: 500;
  }
  .sca-c--on { background: var(--sca-ink); border-color: var(--sca-ink); color: #fff; font-weight: 800; }
  .sca-final {
    display: grid; place-items: center; min-width: 10.5mm; height: 4.4mm; margin-left: 1.4mm; padding: 0 1.2mm;
    border: 0.25mm solid #a3a8b0; border-radius: 3mm;
    color: #b4b9c0; font-size: 5.5pt; font-weight: 800; letter-spacing: 0.05em;
  }
  .sca-final--on { border-color: var(--sca-ink); color: var(--sca-ink); font-size: 6.5pt; letter-spacing: 0; }

  /* \u2500\u2500 Casillas \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 */
  .sca-desc { padding: 1.3mm 2.5mm; }
  .sca-desc--2col { columns: 2; column-gap: 3mm; }
  .sca-desc--boca { columns: 2; column-gap: 3mm; padding-top: 0.6mm; }
  .sca-desc__row { margin-bottom: 0.3mm; break-inside: avoid; white-space: nowrap; }
  .sca-cb { display: inline-flex; align-items: center; gap: 0.6mm; margin-right: 1.3mm; font-size: 6.1pt; line-height: 1.2; vertical-align: middle; }
  .sca-cb b { font-weight: 800; }
  .sca-cb small { font-size: 5.6pt; }
  .sca-cb i { position: relative; display: inline-block; flex: none; width: 2.3mm; height: 2.3mm; border: 0.25mm solid var(--sca-ink); }
  .sca-cb--on i { background: var(--sca-ink); }
  .sca-cb--on i::after {
    content: ''; position: absolute; left: 0.62mm; top: 0.12mm; width: 0.6mm; height: 1.3mm;
    border: solid #fff; border-width: 0 0.35mm 0.35mm 0; transform: rotate(45deg);
  }
  .sca-gustos { margin-top: 0.8mm; }
  /* En el Combinado los 5 gustos van en una fila para que la hoja quepa en un A4. */
  .sca-page--combinado .sca-gustos .sca-desc__row { display: inline-block; margin-right: 0.4mm; }
  .sca-label { margin-bottom: 0.6mm !important; color: var(--sca-slate); font-size: 6.6pt; font-weight: 800; }

  /* \u2500\u2500 Notas \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 */
  .sca-split { display: grid; grid-template-columns: 54% minmax(0, 1fr); }
  .sca-split--boca { grid-template-columns: 40% minmax(0, 1fr); }
  .sca-split > .sca-notes { border-left: var(--sca-line); }
  .sca-notes { padding: 1.4mm 2.5mm; overflow: hidden; }
  .sca-notes__text { color: #111; font-size: 6.3pt; line-height: 1.35; white-space: pre-line; }
  .sca-otras .sca-notes__text { padding: 2mm 2.5mm; }

  /* \u2500\u2500 Impresi\xF3n global, tazas y defectos \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 */
  .sca-global { display: flex; flex-direction: column; }
  .sca-global__head { padding-top: 1.2mm; border-bottom: var(--sca-line); }
  .sca-global__title { display: block; padding: 0 2.5mm; color: var(--sca-slate); font-size: 9.5pt; font-weight: 800; }
  .sca-global > .sca-notes { flex: 1; border-bottom: var(--sca-line); }
  .sca-cups { display: grid; grid-template-columns: 1.2fr 1fr; font-size: 5.6pt; }
  .sca-cups b { font-weight: 800; }
  .sca-cups__left { display: flex; flex-direction: column; justify-content: center; gap: 1mm; padding: 1.4mm 2mm; }
  .sca-cups__left > div { display: flex; align-items: center; justify-content: space-between; white-space: nowrap; }
  .sca-cups__right { padding: 1.4mm 2mm; border-left: var(--sca-line); }
  .sca-cups__right .sca-cb { margin-top: 0.6mm; font-size: 5.8pt; }
  .sca-boxes { display: inline-flex; gap: 0.3mm; margin-left: 1mm; }
  .sca-boxes i { display: inline-block; width: 2.3mm; height: 2.3mm; border: 0.25mm solid var(--sca-ink); }
  .sca-boxes i.on { background: var(--sca-ink); }

  /* \u2500\u2500 Pie legal \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 */
  .sca-legal { margin-top: 1.8mm; color: #555b63; font-size: 5.6pt; line-height: 1.3; }
`;

// src/app/core/services/impresion.ts
var ESTILOS_REPORTE = `
  @page { size: A4; margin: 14mm 14mm 16mm; }
  * { box-sizing: border-box; }
  html, body { margin: 0; padding: 0; }
  body {
    color: #0f172b;
    font: 11px/1.45 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
    -webkit-print-color-adjust: exact;
    print-color-adjust: exact;
  }
  .rp-head { display: flex; justify-content: space-between; align-items: flex-end; gap: 16px;
    padding-bottom: 10px; margin-bottom: 14px; border-bottom: 2px solid #2f3e46; }
  .rp-brand { margin: 0; color: #62748e; font-size: 9px; font-weight: 700; letter-spacing: .08em; text-transform: uppercase; }
  .rp-title { margin: 2px 0 0; font-size: 18px; font-weight: 700; }
  .rp-sub { margin: 2px 0 0; color: #62748e; font-size: 11px; }
  .rp-meta { margin: 0; color: #62748e; font-size: 10px; text-align: right; white-space: nowrap; }
  .rp-section { margin: 0 0 14px; break-inside: avoid; page-break-inside: avoid; }
  .rp-section h2 { margin: 0 0 6px; color: #62748e; font-size: 9px; font-weight: 700; letter-spacing: .06em; text-transform: uppercase; }
  .rp-kpis { display: flex; gap: 8px; margin: 0 0 14px; }
  .rp-kpi { flex: 1; padding: 8px 10px; border: 1px solid #e2e8f0; border-radius: 6px; }
  .rp-kpi strong { display: block; color: #c2410c; font-size: 16px; }
  .rp-kpi span { color: #62748e; font-size: 9px; text-transform: uppercase; }
  table { width: 100%; border-collapse: collapse; }
  th, td { padding: 5px 6px; border-bottom: 1px solid #e2e8f0; text-align: left; vertical-align: top; }
  th { color: #62748e; font-size: 9px; font-weight: 600; text-transform: uppercase; }
  td.num, th.num { text-align: right; font-variant-numeric: tabular-nums; }
  .rp-score { color: #c2410c; font-weight: 700; }
  .rp-badge { display: inline-block; padding: 1px 6px; border-radius: 4px; font-size: 9px; font-weight: 600; }
  .rp-bar { position: relative; height: 8px; border-radius: 4px; background: #f1f5f9; overflow: hidden; }
  .rp-bar > i { position: absolute; inset: 0 auto 0 0; border-radius: 4px; background: #2f3e46; }
  .rp-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 0 18px; }
  .rp-dl { display: grid; grid-template-columns: 40% 60%; margin: 0; }
  .rp-dl dt, .rp-dl dd { margin: 0; padding: 4px 0; border-bottom: 1px solid #e2e8f0; }
  .rp-dl dt { color: #62748e; }
  .rp-chips span { display: inline-block; margin: 0 4px 4px 0; padding: 2px 8px; border: 1px solid #e2e8f0; border-radius: 10px; }
  .rp-muted { color: #62748e; }
  .rp-formula { margin-top: 10px; padding: 8px 10px; border-radius: 6px; background: #f1f5f9; font-family: ui-monospace, Menlo, monospace; }
  .rp-foot { margin-top: 18px; padding-top: 6px; border-top: 1px solid #e2e8f0; color: #94a3b8; font-size: 9px; }
  .rp-page-break { break-before: page; page-break-before: always; }
`;
var escaparHtml = (texto) => texto.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
var _ImpresionService = class _ImpresionService {
  constructor() {
    this.document = inject(DOCUMENT);
  }
  imprimir(titulo, contenidoHtml) {
    const doc = this.document;
    const iframe = doc.createElement("iframe");
    iframe.setAttribute("aria-hidden", "true");
    iframe.setAttribute("tabindex", "-1");
    Object.assign(iframe.style, {
      position: "fixed",
      right: "0",
      bottom: "0",
      width: "0",
      height: "0",
      border: "0",
      visibility: "hidden"
    });
    return new Promise((resolve, reject) => {
      let terminado = false;
      const limpiar = () => {
        if (terminado)
          return;
        terminado = true;
        iframe.remove();
        resolve();
      };
      iframe.onload = () => {
        const ventana = iframe.contentWindow;
        if (!ventana || typeof ventana.print !== "function") {
          iframe.remove();
          reject(new Error("Este dispositivo no permite imprimir desde la app. Abre PacamaraQs en un navegador de escritorio."));
          return;
        }
        ventana.addEventListener("afterprint", () => setTimeout(limpiar, 0), { once: true });
        ventana.focus();
        ventana.print();
        setTimeout(limpiar, 6e4);
      };
      iframe.srcdoc = `<!doctype html><html lang="es"><head><meta charset="utf-8"><title>${escaparHtml(titulo)}</title><style>${ESTILOS_REPORTE}${ESTILOS_HOJA_SCA}</style></head><body>${contenidoHtml}</body></html>`;
      doc.body.appendChild(iframe);
    });
  }
};
_ImpresionService.\u0275fac = function ImpresionService_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _ImpresionService)();
};
_ImpresionService.\u0275prov = /* @__PURE__ */ \u0275\u0275defineInjectable({ token: _ImpresionService, factory: _ImpresionService.\u0275fac, providedIn: "root" });
var ImpresionService = _ImpresionService;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ImpresionService, [{
    type: Injectable,
    args: [{ providedIn: "root" }]
  }], null, null);
})();

// src/app/core/mappers/ficha-tecnica.mapper.ts
var SIN_DATO = "\u2014";
var CERTIFICACIONES_FORMULARIO = {
  c4: "4C",
  fairTrade: "Fair Trade",
  organic: "Org\xE1nico",
  rainforest: "Rainforest Alliance"
};
var comoRegistro2 = (valor) => valor !== null && typeof valor === "object" && !Array.isArray(valor) ? valor : {};
function textoDeCampo(valor) {
  if (valor === null || valor === void 0)
    return "";
  if (typeof valor === "boolean")
    return valor ? "S\xED" : "No";
  if (typeof valor === "number")
    return Number.isFinite(valor) ? String(valor) : "";
  if (typeof valor === "string")
    return valor.trim();
  return "";
}
var capitalizar = (texto) => texto ? texto.charAt(0).toUpperCase() + texto.slice(1) : texto;
function construirFichasTecnicas(fichas, registradas) {
  const pendientes = [...registradas];
  const tomarRegistro = (numeroMuestra) => {
    const indice = pendientes.findIndex((r) => Number(r.numero_muestra) === numeroMuestra);
    return indice >= 0 ? pendientes.splice(indice, 1)[0] : null;
  };
  const resultado = fichas.map((ficha) => {
    const numeroMuestra = Number(ficha.numero_muestra);
    return construirFicha(numeroMuestra, ficha, tomarRegistro(numeroMuestra));
  });
  for (const registro of pendientes) {
    resultado.push(construirFicha(Number(registro.numero_muestra), null, registro));
  }
  return resultado.sort((a, b) => a.numeroMuestra - b.numeroMuestra);
}
function construirFicha(numeroMuestra, ficha, registro) {
  const formulario = comoRegistro2(ficha?.formulario);
  const cultivo = comoRegistro2(formulario["farming"]);
  const proceso = comoRegistro2(formulario["processing"]);
  const comercio = comoRegistro2(formulario["trading"]);
  const certForm = comoRegistro2(formulario["certifications"]);
  const tabla = comoRegistro2(registro?.datos);
  const valor = (claveTabla, valorFormulario) => (claveTabla ? textoDeCampo(tabla[claveTabla]) : "") || textoDeCampo(valorFormulario) || SIN_DATO;
  const precio = textoDeCampo(tabla["precio_finca"]);
  const secciones = [
    {
      titulo: "Origen y cultivo",
      campos: [
        { etiqueta: "Pa\xEDs", valor: valor("pais", cultivo["country"]) },
        { etiqueta: "Regi\xF3n", valor: valor("region", cultivo["region"]) },
        { etiqueta: "Finca / Cooperativa", valor: valor("finca_o_coop", cultivo["farmName"]) },
        { etiqueta: "Productores", valor: valor("productores", cultivo["producers"]) },
        { etiqueta: "Especie", valor: valor("especie", cultivo["species"]) },
        { etiqueta: "Variedad", valor: valor("variedad", cultivo["variety"]) },
        { etiqueta: "Fecha de cosecha", valor: valor("fecha_cosecha", cultivo["harvestDate"]) },
        { etiqueta: "Otros (cultivo)", valor: valor("otro_cultivo", cultivo["other"]) }
      ]
    },
    {
      titulo: "Procesamiento",
      campos: [
        { etiqueta: "Procesador", valor: valor("nombre_procesador", proceso["processorName"]) },
        { etiqueta: "Beneficio h\xFAmedo", valor: valor("beneficio_humedo", proceso["wetMill"]) },
        { etiqueta: "Beneficio seco", valor: valor("beneficio_seco", proceso["dryMill"]) },
        { etiqueta: "Tipo de proceso", valor: capitalizar(valor("tipo_proceso", proceso["processType"])) },
        { etiqueta: "Descafeinado", valor: valor("descafeinado") },
        { etiqueta: "Descripci\xF3n del proceso", valor: valor("descripcion_proceso") },
        { etiqueta: "Otros (proceso)", valor: valor("otro_procesamiento", proceso["other"]) }
      ]
    },
    {
      titulo: "Comercializaci\xF3n",
      campos: [
        { etiqueta: "Grado", valor: valor("grado", comercio["grade"]) },
        { etiqueta: "N\xFAmero ICO", valor: valor("numero_ico", comercio["icoNumber"]) },
        { etiqueta: "Importador", valor: valor("importador") },
        { etiqueta: "Exportador", valor: valor("exportador") },
        { etiqueta: "Precio en finca", valor: precio || SIN_DATO },
        { etiqueta: "Tama\xF1o de lote", valor: valor("tamano_lote") },
        { etiqueta: "Otros (comercial)", valor: valor("otro_comercial", comercio["other"]) }
      ]
    }
  ];
  const otros = [
    { etiqueta: "Premios", valor: textoDeCampo(tabla["premios"]) },
    { etiqueta: "Otra informaci\xF3n", valor: textoDeCampo(tabla["otra_info"]) }
  ].filter((c) => c.valor !== "");
  if (otros.length > 0)
    secciones.push({ titulo: "Informaci\xF3n adicional", campos: otros });
  const certificaciones = new Set((registro?.certificaciones ?? []).map(textoDeCampo).filter(Boolean));
  for (const [clave, etiqueta] of Object.entries(CERTIFICACIONES_FORMULARIO)) {
    if (certForm[clave] === true)
      certificaciones.add(etiqueta);
  }
  const otraCert = textoDeCampo(certForm["other"]);
  if (otraCert)
    certificaciones.add(otraCert);
  return {
    numeroMuestra,
    registradaPor: ficha?.nombre ?? null,
    registradaEn: ficha?.registrado_en ?? (textoDeCampo(tabla["creado_en"]) || null),
    secciones,
    certificaciones: [...certificaciones].sort((a, b) => a.localeCompare(b, "es")),
    notas: textoDeCampo(formulario["notes"])
  };
}

// src/app/core/services/results.ts
var num = (valor) => {
  const n = typeof valor === "number" ? valor : Number(valor);
  return Number.isFinite(n) ? n : 0;
};
var numONulo = (valor) => {
  if (valor === null || valor === void 0 || valor === "")
    return null;
  const n = typeof valor === "number" ? valor : Number(valor);
  return Number.isFinite(n) ? n : null;
};
var _ResultsService = class _ResultsService {
  constructor() {
    this.supabase = inject(SupabaseService);
  }
  async obtenerResultadosSesion(sesionId) {
    const { data: sesionData, error: sesionError } = await this.supabase.client.from("sesiones").select("*").eq("id", sesionId).maybeSingle();
    if (sesionError)
      throw sesionError;
    if (!sesionData)
      return null;
    const sesion = sesionDtoToDomain(sesionData);
    const { data, error } = await this.supabase.client.rpc("get_resumen_panel", { p_sesion_id: sesionId });
    if (error)
      throw error;
    if (!data)
      return null;
    const resumen = data;
    const muestras = (resumen.por_muestra ?? []).map((m) => this.mapearMuestra(m));
    const catadores = (resumen.por_catador ?? []).map((c) => this.mapearCatador(c));
    return {
      sesionId,
      nombreSesion: sesion.nombre,
      formatoCva: sesion.formato,
      fechaCierre: (/* @__PURE__ */ new Date()).toISOString(),
      totalMuestras: sesion.numeroMuestras,
      totalCatadores: catadores.length,
      muestras,
      catadores,
      atributosPorMuestra: (resumen.por_atributo ?? []).map((a) => this.mapearPromedioAtributo(a)),
      votosHedonicos: (resumen.votos_hedonicos ?? []).map((v) => this.mapearVoto(v)),
      fichasTecnicas: construirFichasTecnicas(resumen.fichas_extrinsecas ?? [], resumen.extrinseca_registrada ?? [])
    };
  }
  /**
   * Antes el objeto snake_case de la RPC se asignaba directo a un modelo
   * camelCase: todas las tarjetas mostraban `undefined` y el `@for` hacía
   * track por `muestra.numeroMuestra` (undefined) → claves duplicadas.
   */
  mapearMuestra(m) {
    return {
      numeroMuestra: num(m.numero_muestra),
      nivelTueste: m.nivel_tueste,
      puntajePromedioPanel: num(m.puntaje_promedio_panel),
      puntajeMin: num(m.puntaje_min),
      puntajeMax: num(m.puntaje_max),
      desviacionEstandar: num(m.desviacion_estandar),
      evaluacionesRecibidas: num(m.evaluaciones_recibidas),
      evaluacionesEsperadas: num(m.evaluaciones_esperadas),
      recortado: m.recortado === true,
      puntajePromedioSimple: num(m.puntaje_promedio_simple),
      cerradaForzada: m.cerrada_forzada === true
    };
  }
  mapearCatador(c) {
    return {
      cupperId: c.cupper_id,
      nombre: c.nombre,
      esOrganizador: c.es_organizador,
      muestrasEvaluadas: num(c.muestras_evaluadas),
      muestrasAsignadas: num(c.muestras_asignadas),
      estado: c.estado,
      submittedAt: c.submitted_at,
      puntajePromedio: num(c.puntaje_promedio),
      desviacionRespectoPanel: num(c.desviacion_respecto_panel),
      puntajesPorMuestra: (c.puntajes_por_muestra ?? []).map((p) => ({
        numeroMuestra: num(p.numero_muestra),
        puntaje: num(p.puntaje),
        defectos: [],
        tazasNoUniformes: num(p.tazas_no_uniformes),
        tazasDefectuosas: num(p.tazas_defectuosas),
        impresionGlobal: numONulo(p.impresion_global),
        atributos: this.mapearAtributos(p.atributos),
        formulario: p.formulario && typeof p.formulario === "object" && !Array.isArray(p.formulario) ? p.formulario : null
      }))
    };
  }
  mapearAtributos(atributos) {
    const resultado = {};
    for (const [clave, valor] of Object.entries(atributos ?? {})) {
      resultado[clave] = { intensidad: numONulo(valor?.intensidad), calidad: numONulo(valor?.calidad) };
    }
    return resultado;
  }
  mapearPromedioAtributo(a) {
    return {
      numeroMuestra: num(a.numero_muestra),
      atributo: a.atributo,
      respuestas: num(a.respuestas),
      intensidadPromedio: numONulo(a.intensidad_promedio),
      calidadPromedio: numONulo(a.calidad_promedio)
    };
  }
  mapearVoto(v) {
    return { numeroMuestra: num(v.numero_muestra), valor: num(v.valor), votos: num(v.votos) };
  }
};
_ResultsService.\u0275fac = function ResultsService_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _ResultsService)();
};
_ResultsService.\u0275prov = /* @__PURE__ */ \u0275\u0275defineInjectable({ token: _ResultsService, factory: _ResultsService.\u0275fac, providedIn: "root" });
var ResultsService = _ResultsService;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ResultsService, [{
    type: Injectable,
    args: [{ providedIn: "root" }]
  }], null, null);
})();

// src/app/shared/components/cupper-result-card/cupper-result-card.component.ts
var _c0 = (a0, a1, a2) => ({ "generoso": a0, "estricto": a1, "calibrado": a2 });
function CupperResultCardComponent_Conditional_17_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span");
    \u0275\u0275text(1);
    \u0275\u0275pipe(2, "number");
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1("\u2191 +", \u0275\u0275pipeBind2(2, 1, ctx_r0.catador.desviacionRespectoPanel, "1.2-2"), " (Generoso)");
  }
}
function CupperResultCardComponent_Conditional_18_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span");
    \u0275\u0275text(1);
    \u0275\u0275pipe(2, "number");
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1("\u2193 ", \u0275\u0275pipeBind2(2, 1, ctx_r0.catador.desviacionRespectoPanel, "1.2-2"), " (Estricto)");
  }
}
function CupperResultCardComponent_Conditional_19_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span");
    \u0275\u0275text(1, "\u2713 Calibrado con el panel");
    \u0275\u0275elementEnd();
  }
}
var _CupperResultCardComponent = class _CupperResultCardComponent {
  get esGeneroso() {
    return this.catador.desviacionRespectoPanel > 0.5;
  }
  get esEstricto() {
    return this.catador.desviacionRespectoPanel < -0.5;
  }
  get estaCalibrado() {
    return Math.abs(this.catador.desviacionRespectoPanel) <= 0.5;
  }
};
_CupperResultCardComponent.\u0275fac = function CupperResultCardComponent_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _CupperResultCardComponent)();
};
_CupperResultCardComponent.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _CupperResultCardComponent, selectors: [["app-cupper-result-card"]], inputs: { catador: "catador" }, decls: 31, vars: 20, consts: [[1, "cupper-card"], [1, "cupper-header"], [1, "cupper-info"], [1, "avatar"], [1, "cupper-name"], [1, "cupper-role"], [1, "cupper-score"], [1, "score-value"], [1, "score-label"], [1, "calibration-badge", 3, "ngClass"], [1, "cupper-stats"], [1, "stat"], [1, "stat-label"], [1, "stat-value"]], template: function CupperResultCardComponent_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "div", 3);
    \u0275\u0275text(4);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "div")(6, "h4", 4);
    \u0275\u0275text(7);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "span", 5);
    \u0275\u0275text(9);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(10, "div", 6)(11, "span", 7);
    \u0275\u0275text(12);
    \u0275\u0275pipe(13, "number");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(14, "span", 8);
    \u0275\u0275text(15, "Promedio");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(16, "div", 9);
    \u0275\u0275conditionalCreate(17, CupperResultCardComponent_Conditional_17_Template, 3, 4, "span");
    \u0275\u0275conditionalCreate(18, CupperResultCardComponent_Conditional_18_Template, 3, 4, "span");
    \u0275\u0275conditionalCreate(19, CupperResultCardComponent_Conditional_19_Template, 2, 0, "span");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(20, "div", 10)(21, "div", 11)(22, "span", 12);
    \u0275\u0275text(23, "Muestras Evaluadas");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(24, "span", 13);
    \u0275\u0275text(25);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(26, "div", 11)(27, "span", 12);
    \u0275\u0275text(28, "Estado");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(29, "span", 13);
    \u0275\u0275text(30);
    \u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(ctx.catador.nombre.charAt(0).toUpperCase());
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(ctx.catador.nombre);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(ctx.catador.esOrganizador ? "Organizador" : "Catador");
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind2(13, 13, ctx.catador.puntajePromedio, "1.2-2"));
    \u0275\u0275advance(4);
    \u0275\u0275property("ngClass", \u0275\u0275pureFunction3(16, _c0, ctx.esGeneroso, ctx.esEstricto, ctx.estaCalibrado));
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx.esGeneroso ? 17 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx.esEstricto ? 18 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx.estaCalibrado ? 19 : -1);
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate2("", ctx.catador.muestrasEvaluadas, " / ", ctx.catador.muestrasAsignadas);
    \u0275\u0275advance(4);
    \u0275\u0275classProp("success", ctx.catador.estado === "enviado");
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", ctx.catador.estado === "enviado" ? "Enviado" : "Pendiente", " ");
  }
}, dependencies: [CommonModule, NgClass, DecimalPipe], styles: ["\n.cupper-card[_ngcontent-%COMP%] {\n  background: #FFFFFF;\n  border: 1px solid #E2E8F0;\n  border-radius: 12px;\n  padding: 16px;\n  margin-bottom: 12px;\n}\n.cupper-header[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  margin-bottom: 12px;\n}\n.cupper-info[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 12px;\n}\n.avatar[_ngcontent-%COMP%] {\n  width: 40px;\n  height: 40px;\n  border-radius: 50%;\n  background: #F1F5F9;\n  color: #0F172B;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-weight: 700;\n  font-size: 16px;\n}\n.cupper-name[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 14px;\n  font-weight: 700;\n  color: #0F172B;\n}\n.cupper-role[_ngcontent-%COMP%] {\n  font-size: 11px;\n  color: #62748E;\n}\n.cupper-score[_ngcontent-%COMP%] {\n  text-align: right;\n}\n.score-value[_ngcontent-%COMP%] {\n  display: block;\n  font-size: 20px;\n  font-weight: 800;\n  color: #0F172B;\n}\n.score-label[_ngcontent-%COMP%] {\n  font-size: 10px;\n  color: #62748E;\n  text-transform: uppercase;\n}\n.calibration-badge[_ngcontent-%COMP%] {\n  padding: 6px 12px;\n  border-radius: 6px;\n  font-size: 11px;\n  font-weight: 600;\n  text-align: center;\n  margin-bottom: 12px;\n}\n.calibration-badge.generoso[_ngcontent-%COMP%] {\n  background: #FEFCE8;\n  color: #A16207;\n}\n.calibration-badge.estricto[_ngcontent-%COMP%] {\n  background: #FFF7ED;\n  color: #C2410C;\n}\n.calibration-badge.calibrado[_ngcontent-%COMP%] {\n  background: #F0FDF4;\n  color: #15803D;\n}\n.cupper-stats[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  border-top: 1px solid #F1F5F9;\n  padding-top: 12px;\n}\n.stat[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 4px;\n}\n.stat-label[_ngcontent-%COMP%] {\n  font-size: 10px;\n  color: #62748E;\n  text-transform: uppercase;\n}\n.stat-value[_ngcontent-%COMP%] {\n  font-size: 13px;\n  font-weight: 600;\n  color: #0F172B;\n}\n.stat-value.success[_ngcontent-%COMP%] {\n  color: #15803D;\n}\n/*# sourceMappingURL=cupper-result-card.component.css.map */"] });
var CupperResultCardComponent = _CupperResultCardComponent;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(CupperResultCardComponent, [{
    type: Component,
    args: [{ selector: "app-cupper-result-card", standalone: true, imports: [CommonModule], template: `<div class="cupper-card">
  <div class="cupper-header">
    <div class="cupper-info">
      <div class="avatar">{{ catador.nombre.charAt(0).toUpperCase() }}</div>
      <div>
        <h4 class="cupper-name">{{ catador.nombre }}</h4>
        <span class="cupper-role">{{ catador.esOrganizador ? 'Organizador' : 'Catador' }}</span>
      </div>
    </div>
    <div class="cupper-score">
      <span class="score-value">{{ catador.puntajePromedio | number:'1.2-2' }}</span>
      <span class="score-label">Promedio</span>
    </div>
  </div>

   <div class="calibration-badge" 
       [ngClass]="{'generoso': esGeneroso, 'estricto': esEstricto, 'calibrado': estaCalibrado}">
    @if (esGeneroso) {
      <span>\u2191 +{{ catador.desviacionRespectoPanel | number:'1.2-2' }} (Generoso)</span>
    }
    @if (esEstricto) {
      <span>\u2193 {{ catador.desviacionRespectoPanel | number:'1.2-2' }} (Estricto)</span>
    }
    @if (estaCalibrado) {
      <span>\u2713 Calibrado con el panel</span>
    }
  
  </div>

  <div class="cupper-stats">
    <div class="stat">
      <span class="stat-label">Muestras Evaluadas</span>
      <span class="stat-value">{{ catador.muestrasEvaluadas }} / {{ catador.muestrasAsignadas }}</span>
    </div>
    <div class="stat">
      <span class="stat-label">Estado</span>
      <span class="stat-value" [class.success]="catador.estado === 'enviado'">
        {{ catador.estado === 'enviado' ? 'Enviado' : 'Pendiente' }}
      </span>
    </div>
  </div>
</div>`, styles: ["/* src/app/shared/components/cupper-result-card/cupper-result-card.component.scss */\n.cupper-card {\n  background: #FFFFFF;\n  border: 1px solid #E2E8F0;\n  border-radius: 12px;\n  padding: 16px;\n  margin-bottom: 12px;\n}\n.cupper-header {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  margin-bottom: 12px;\n}\n.cupper-info {\n  display: flex;\n  align-items: center;\n  gap: 12px;\n}\n.avatar {\n  width: 40px;\n  height: 40px;\n  border-radius: 50%;\n  background: #F1F5F9;\n  color: #0F172B;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-weight: 700;\n  font-size: 16px;\n}\n.cupper-name {\n  margin: 0;\n  font-size: 14px;\n  font-weight: 700;\n  color: #0F172B;\n}\n.cupper-role {\n  font-size: 11px;\n  color: #62748E;\n}\n.cupper-score {\n  text-align: right;\n}\n.score-value {\n  display: block;\n  font-size: 20px;\n  font-weight: 800;\n  color: #0F172B;\n}\n.score-label {\n  font-size: 10px;\n  color: #62748E;\n  text-transform: uppercase;\n}\n.calibration-badge {\n  padding: 6px 12px;\n  border-radius: 6px;\n  font-size: 11px;\n  font-weight: 600;\n  text-align: center;\n  margin-bottom: 12px;\n}\n.calibration-badge.generoso {\n  background: #FEFCE8;\n  color: #A16207;\n}\n.calibration-badge.estricto {\n  background: #FFF7ED;\n  color: #C2410C;\n}\n.calibration-badge.calibrado {\n  background: #F0FDF4;\n  color: #15803D;\n}\n.cupper-stats {\n  display: flex;\n  justify-content: space-between;\n  border-top: 1px solid #F1F5F9;\n  padding-top: 12px;\n}\n.stat {\n  display: flex;\n  flex-direction: column;\n  gap: 4px;\n}\n.stat-label {\n  font-size: 10px;\n  color: #62748E;\n  text-transform: uppercase;\n}\n.stat-value {\n  font-size: 13px;\n  font-weight: 600;\n  color: #0F172B;\n}\n.stat-value.success {\n  color: #15803D;\n}\n/*# sourceMappingURL=cupper-result-card.component.css.map */\n"] }]
  }], null, { catador: [{
    type: Input
  }] });
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(CupperResultCardComponent, { className: "CupperResultCardComponent", filePath: "src/app/shared/components/cupper-result-card/cupper-result-card.component.ts", lineNumber: 12 });
})();

// src/app/pages/session/results/results.page.ts
var _c02 = ["reporteImprimible"];
var _c1 = (a0, a1) => ({ valor: a0, aguja: a1, etiqueta: "Promedio puntaje del panel" });
var _c2 = (a0, a1, a2) => ({ valor: a0, aguja: a1, etiqueta: a2 });
var _c3 = (a0, a1) => ({ r: a0, detalle: a1 });
var _c4 = (a0) => ({ r: a0, detalle: "Escala hed\xF3nica de 9 puntos: 1 = extremadamente baja \xB7 5 = neutral \xB7 9 = extremadamente alta." });
var _c5 = (a0) => ({ r: a0 });
var _c6 = (a0) => ({ actual: a0 });
var _c7 = (a0) => ({ r: a0, detalle: "Perfil sensorial objetivo: intensidad f\xEDsica de 0 (ausente) a 15 (muy intensa), sin juicio de calidad." });
var _c8 = (a0, a1, a2) => ({ on: a0, etiqueta: a1, principal: a2 });
var _c9 = (a0, a1) => ({ on: a0, etiqueta: a1, principal: true });
var _c10 = (a0, a1, a2) => ({ on: a0, etiqueta: a1, principal: true, detalle: a2 });
var _c11 = () => [1, 2, 3, 4, 5];
var _c12 = (a0) => ({ titulo: "Fragancia", v: a0 });
var _c13 = (a0) => ({ titulo: "Aroma", v: a0 });
var _c14 = (a0) => ({ v: a0 });
var _c15 = (a0) => ({ marcadas: a0 });
var _c16 = (a0) => ({ texto: a0 });
var _c17 = () => ["fragancia", "aroma"];
var _c18 = (a0) => ({ titulo: "Sabor", v: a0 });
var _c19 = (a0) => ({ titulo: "Sabor Residual", v: a0 });
var _c20 = () => ["sabor", "sabor_residual"];
var _c21 = (a0) => ({ titulo: "Acidez", v: a0 });
var _c22 = () => ["acidez"];
var _c23 = (a0) => ({ titulo: "Dulzor", v: a0 });
var _c24 = () => ["dulzor"];
var _c25 = (a0) => ({ titulo: "Sensaci\xF3n en boca", v: a0 });
var _c26 = () => ["sensacion_boca"];
var _c27 = (a0) => ({ n: a0 });
var _forTrack0 = ($index, $item) => $item.clase;
var _forTrack1 = ($index, $item) => $item.cupperId;
var _forTrack2 = ($index, $item) => $item.numeroMuestra;
var _forTrack3 = ($index, $item) => $item.clave;
var _forTrack4 = ($index, $item) => $item.valor;
var _forTrack5 = ($index, $item) => $item.numeroMuestra + "-" + $index;
var _forTrack6 = ($index, $item) => $item.titulo;
var _forTrack7 = ($index, $item) => $item.etiqueta;
var _forTrack8 = ($index, $item) => $item.id;
var _forTrack9 = ($index, $item) => $item.n;
function ResultsPage_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 18);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275textInterpolate2("", ctx.nombreSesion, " \xB7 ", ctx_r0.tituloFormato());
  }
}
function ResultsPage_ng_template_12_For_5_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275namespaceSVG();
    \u0275\u0275element(0, "path");
  }
  if (rf & 2) {
    const a_r2 = ctx.$implicit;
    \u0275\u0275attribute("d", a_r2.d)("class", "rc-gauge__arc " + a_r2.clase);
  }
}
function ResultsPage_ng_template_12_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-card", 28)(1, "ion-card-content");
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(2, "svg", 29);
    \u0275\u0275pipe(3, "number");
    \u0275\u0275repeaterCreate(4, ResultsPage_ng_template_12_For_5_Template, 1, 2, ":svg:path", null, _forTrack0);
    \u0275\u0275elementStart(6, "text", 30);
    \u0275\u0275text(7, "50");
    \u0275\u0275elementEnd();
    \u0275\u0275element(8, "line", 31)(9, "circle", 32);
    \u0275\u0275elementEnd();
    \u0275\u0275namespaceHTML();
    \u0275\u0275elementStart(10, "p", 33);
    \u0275\u0275text(11);
    \u0275\u0275pipe(12, "number");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(13, "p", 34);
    \u0275\u0275text(14);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const valor_r3 = ctx.valor;
    const aguja_r4 = ctx.aguja;
    const etiqueta_r5 = ctx.etiqueta;
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance(2);
    \u0275\u0275attribute("aria-label", etiqueta_r5 + ": " + \u0275\u0275pipeBind2(3, 9, valor_r3, "1.2-2"));
    \u0275\u0275advance(2);
    \u0275\u0275repeater(ctx_r0.arcosMedidor);
    \u0275\u0275advance(4);
    \u0275\u0275attribute("x1", ctx_r0.centroMedidor.x)("y1", ctx_r0.centroMedidor.y)("x2", aguja_r4.x)("y2", aguja_r4.y);
    \u0275\u0275advance();
    \u0275\u0275attribute("cx", ctx_r0.centroMedidor.x)("cy", ctx_r0.centroMedidor.y);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind2(12, 12, valor_r3, "1.2-2"));
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(etiqueta_r5);
  }
}
function ResultsPage_ng_template_14_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-card", 35)(1, "ion-card-content", 36)(2, "div", 37)(3, "p", 38);
    \u0275\u0275element(4, "ion-icon", 39);
    \u0275\u0275text(5);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "p", 40);
    \u0275\u0275text(7);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(8, "div", 41)(9, "div")(10, "strong");
    \u0275\u0275text(11);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(12, "span");
    \u0275\u0275text(13, "Muestras");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(14, "div")(15, "strong");
    \u0275\u0275text(16);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(17, "span");
    \u0275\u0275text(18, "Catadores");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(19, "div")(20, "strong");
    \u0275\u0275text(21);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(22, "span");
    \u0275\u0275text(23, "Formato");
    \u0275\u0275elementEnd()()()()();
  }
  if (rf & 2) {
    const r_r6 = ctx.r;
    const detalle_r7 = ctx.detalle;
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate1(" Sesi\xF3n cerrada \xB7 ", ctx_r0.porcentajeCompletado(), "% completada ");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(detalle_r7);
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(r_r6.totalMuestras);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(r_r6.catadores.length);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(ctx_r0.tituloFormato());
  }
}
function ResultsPage_ng_template_16_For_8_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-item")(1, "span", 45);
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "ion-label")(4, "h3", 46);
    \u0275\u0275text(5);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "p");
    \u0275\u0275text(7);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(8, "ion-badge", 47);
    \u0275\u0275text(9);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const c_r8 = ctx.$implicit;
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(c_r8.nombre.charAt(0).toUpperCase());
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(c_r8.nombre);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate3("", c_r8.esOrganizador ? "Organizador" : "Catador", " \xB7 ", c_r8.muestrasEvaluadas, " / ", c_r8.muestrasAsignadas, " muestras");
    \u0275\u0275advance();
    \u0275\u0275classProp("rx-chip--ok", c_r8.estado === "enviado")("rx-chip--pending", c_r8.estado !== "enviado");
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", c_r8.estado === "enviado" ? "Enviado" : "Pendiente", " ");
  }
}
function ResultsPage_ng_template_16_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-card", 35)(1, "ion-card-content")(2, "h2", 42);
    \u0275\u0275text(3, "Participaci\xF3n del panel");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "p", 43);
    \u0275\u0275text(5, "Fichas enviadas por cada catador.");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "ion-list", 44);
    \u0275\u0275repeaterCreate(7, ResultsPage_ng_template_16_For_8_Template, 10, 10, "ion-item", null, _forTrack1);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const r_r9 = ctx.r;
    \u0275\u0275advance(7);
    \u0275\u0275repeater(r_r9.catadores);
  }
}
function ResultsPage_ng_template_18_For_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-segment-button", 49)(1, "ion-label");
    \u0275\u0275text(2);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const n_r11 = ctx.$implicit;
    \u0275\u0275property("value", n_r11);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1("Muestra ", n_r11);
  }
}
function ResultsPage_ng_template_18_Template(rf, ctx) {
  if (rf & 1) {
    const _r10 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "ion-segment", 48);
    \u0275\u0275listener("ionChange", function ResultsPage_ng_template_18_Template_ion_segment_ionChange_0_listener($event) {
      \u0275\u0275restoreView(_r10);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.seleccionarMuestraDetalle($event.detail.value));
    });
    \u0275\u0275repeaterCreate(1, ResultsPage_ng_template_18_For_2_Template, 3, 2, "ion-segment-button", 49, \u0275\u0275repeaterTrackByIdentity);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const actual_r12 = ctx.actual;
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275property("value", actual_r12);
    \u0275\u0275advance();
    \u0275\u0275repeater(ctx_r0.numerosMuestra());
  }
}
function ResultsPage_Conditional_22_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 24);
    \u0275\u0275element(1, "ion-spinner", 50);
    \u0275\u0275elementEnd();
  }
}
function ResultsPage_Conditional_23_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-icon", 54);
    \u0275\u0275elementStart(1, "h2");
    \u0275\u0275text(2, "Resultados reservados al organizador");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "p");
    \u0275\u0275text(4);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const mensaje_r14 = \u0275\u0275nextContext();
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(mensaje_r14);
  }
}
function ResultsPage_Conditional_23_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-icon", 55);
    \u0275\u0275elementStart(1, "h2");
    \u0275\u0275text(2, "El panel sigue abierto");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "p", 56);
    \u0275\u0275text(4, " Los resultados se consolidan cuando todos los catadores env\xEDan sus fichas. Desde el monitoreo puedes ver qui\xE9n falta, cerrar muestras o finalizar el panel. ");
    \u0275\u0275elementEnd();
  }
}
function ResultsPage_Conditional_23_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p");
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const mensaje_r14 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(mensaje_r14);
  }
}
function ResultsPage_Conditional_23_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r15 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "ion-button", 57);
    \u0275\u0275listener("click", function ResultsPage_Conditional_23_Conditional_5_Template_ion_button_click_0_listener() {
      \u0275\u0275restoreView(_r15);
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.irAMonitoreo());
    });
    \u0275\u0275text(1, "Monitorear y finalizar panel");
    \u0275\u0275elementEnd();
  }
}
function ResultsPage_Conditional_23_Template(rf, ctx) {
  if (rf & 1) {
    const _r13 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "section", 25);
    \u0275\u0275conditionalCreate(1, ResultsPage_Conditional_23_Conditional_1_Template, 5, 1)(2, ResultsPage_Conditional_23_Conditional_2_Template, 5, 0)(3, ResultsPage_Conditional_23_Conditional_3_Template, 2, 1, "p");
    \u0275\u0275elementStart(4, "div", 51);
    \u0275\u0275conditionalCreate(5, ResultsPage_Conditional_23_Conditional_5_Template, 2, 0, "ion-button", 52);
    \u0275\u0275elementStart(6, "ion-button", 53);
    \u0275\u0275listener("click", function ResultsPage_Conditional_23_Template_ion_button_click_6_listener() {
      \u0275\u0275restoreView(_r13);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.volverAlPanel());
    });
    \u0275\u0275text(7, "Volver al panel");
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r0.accesoDenegado() ? 1 : ctx_r0.panelAbierto() ? 2 : 3);
    \u0275\u0275advance(4);
    \u0275\u0275conditional(ctx_r0.panelAbierto() ? 5 : -1);
  }
}
function ResultsPage_Conditional_24_Conditional_0_ng_container_3_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_Conditional_24_Conditional_0_ng_container_5_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_Conditional_24_Conditional_0_ng_container_6_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_Conditional_24_Conditional_0_For_31_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-badge", 76);
    \u0275\u0275text(1, "en el medidor");
    \u0275\u0275elementEnd();
  }
}
function ResultsPage_Conditional_24_Conditional_0_For_31_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 77);
    \u0275\u0275text(1, "cerrada");
    \u0275\u0275elementEnd();
  }
}
function ResultsPage_Conditional_24_Conditional_0_For_31_Conditional_18_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 79);
    \u0275\u0275pipe(1, "number");
    \u0275\u0275text(2, "recortado");
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const fila_r18 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275property("title", \u0275\u0275interpolate1("Promedio simple: ", \u0275\u0275pipeBind2(1, 2, fila_r18.puntajePromedioSimple, "1.2-2")));
  }
}
function ResultsPage_Conditional_24_Conditional_0_For_31_Template(rf, ctx) {
  if (rf & 1) {
    const _r17 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "tr", 72);
    \u0275\u0275listener("click", function ResultsPage_Conditional_24_Conditional_0_For_31_Template_tr_click_0_listener() {
      const fila_r18 = \u0275\u0275restoreView(_r17).$implicit;
      const ctx_r0 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r0.seleccionarMuestraMedidor(fila_r18.numeroMuestra));
    })("keydown.enter", function ResultsPage_Conditional_24_Conditional_0_For_31_Template_tr_keydown_enter_0_listener() {
      const fila_r18 = \u0275\u0275restoreView(_r17).$implicit;
      const ctx_r0 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r0.seleccionarMuestraMedidor(fila_r18.numeroMuestra));
    })("keydown.space", function ResultsPage_Conditional_24_Conditional_0_For_31_Template_tr_keydown_space_0_listener($event) {
      const fila_r18 = \u0275\u0275restoreView(_r17).$implicit;
      const ctx_r0 = \u0275\u0275nextContext(3);
      $event.preventDefault();
      return \u0275\u0275resetView(ctx_r0.seleccionarMuestraMedidor(fila_r18.numeroMuestra));
    });
    \u0275\u0275elementStart(1, "td", 73);
    \u0275\u0275element(2, "ion-icon", 74);
    \u0275\u0275text(3);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "td")(5, "span", 75);
    \u0275\u0275text(6);
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(7, ResultsPage_Conditional_24_Conditional_0_For_31_Conditional_7_Template, 2, 0, "ion-badge", 76);
    \u0275\u0275conditionalCreate(8, ResultsPage_Conditional_24_Conditional_0_For_31_Conditional_8_Template, 2, 0, "span", 77);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(9, "td");
    \u0275\u0275text(10);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(11, "td", 56);
    \u0275\u0275text(12);
    \u0275\u0275pipe(13, "number");
    \u0275\u0275pipe(14, "number");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(15, "td", 78);
    \u0275\u0275text(16);
    \u0275\u0275pipe(17, "number");
    \u0275\u0275conditionalCreate(18, ResultsPage_Conditional_24_Conditional_0_For_31_Conditional_18_Template, 3, 5, "span", 79);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(19, "td")(20, "ion-badge", 80);
    \u0275\u0275text(21);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const fila_r18 = ctx.$implicit;
    const activa_r19 = fila_r18.numeroMuestra === \u0275\u0275nextContext(3).muestraEnMedidor()?.numeroMuestra;
    \u0275\u0275classProp("rc-ranking__row--active", activa_r19);
    \u0275\u0275attribute("aria-selected", activa_r19);
    \u0275\u0275advance(2);
    \u0275\u0275classMap("rc-medal rc-medal--" + (fila_r18.posicion <= 3 ? fila_r18.posicion : "n"));
    \u0275\u0275property("name", fila_r18.posicion === 1 ? "trophy-outline" : "medal-outline");
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" #", fila_r18.posicion, " ");
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate1("Muestra ", fila_r18.numeroMuestra);
    \u0275\u0275advance();
    \u0275\u0275conditional(activa_r19 ? 7 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(fila_r18.cerradaForzada ? 8 : -1);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate2("", fila_r18.evaluacionesRecibidas, " / ", fila_r18.evaluacionesEsperadas);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate2("", \u0275\u0275pipeBind2(13, 21, fila_r18.puntajeMin, "1.2-2"), " \u2013 ", \u0275\u0275pipeBind2(14, 24, fila_r18.puntajeMax, "1.2-2"));
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate1(" ", \u0275\u0275pipeBind2(17, 27, fila_r18.puntajePromedioPanel, "1.2-2"), " ");
    \u0275\u0275advance(2);
    \u0275\u0275conditional(fila_r18.recortado ? 18 : -1);
    \u0275\u0275advance(2);
    \u0275\u0275styleProp("--%NS%background", fila_r18.clasificacion.fondo)("--%NS%color", fila_r18.clasificacion.color);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", fila_r18.clasificacion.etiqueta, " ");
  }
}
function ResultsPage_Conditional_24_Conditional_0_ForEmpty_32_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "tr")(1, "td", 81);
    \u0275\u0275text(2, "Ninguna muestra recibi\xF3 fichas.");
    \u0275\u0275elementEnd()();
  }
}
function ResultsPage_Conditional_24_Conditional_0_Conditional_33_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 65);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext(3);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" Sin fichas: ", ctx_r0.muestrasSinFichas().length, " muestra(s) cerradas sin evaluaciones. ");
  }
}
function ResultsPage_Conditional_24_Conditional_0_For_42_Template(rf, ctx) {
  if (rf & 1) {
    const _r20 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "ion-col", 67)(1, "button", 82);
    \u0275\u0275listener("click", function ResultsPage_Conditional_24_Conditional_0_For_42_Template_button_click_1_listener() {
      const catador_r21 = \u0275\u0275restoreView(_r20).$implicit;
      const ctx_r0 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r0.seleccionarCatadorReporte(catador_r21.cupperId));
    });
    \u0275\u0275element(2, "app-cupper-result-card", 83);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const catador_r21 = ctx.$implicit;
    const ctx_r0 = \u0275\u0275nextContext(3);
    \u0275\u0275advance();
    \u0275\u0275classProp("rc-cupper-select--active", catador_r21.cupperId === ctx_r0.catadorReporte()?.cupperId);
    \u0275\u0275attribute("aria-pressed", catador_r21.cupperId === ctx_r0.catadorReporte()?.cupperId);
    \u0275\u0275advance();
    \u0275\u0275property("catador", catador_r21);
  }
}
function ResultsPage_Conditional_24_Conditional_0_Conditional_43_Conditional_19_For_4_Conditional_10_For_9_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 95)(1, "span");
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "span", 100)(4, "strong");
    \u0275\u0275text(5);
    \u0275\u0275pipe(6, "number");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "strong");
    \u0275\u0275text(8);
    \u0275\u0275pipe(9, "number");
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const a_r23 = ctx.$implicit;
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(a_r23.etiqueta);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(a_r23.intensidad === null ? "\u2014" : \u0275\u0275pipeBind2(6, 3, a_r23.intensidad, "1.0-2"));
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(a_r23.calidad === null ? "\u2014" : \u0275\u0275pipeBind2(9, 6, a_r23.calidad, "1.0-2"));
  }
}
function ResultsPage_Conditional_24_Conditional_0_Conditional_43_Conditional_19_For_4_Conditional_10_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 99)(1, "span");
    \u0275\u0275text(2, "Atributo");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "span", 100)(4, "em");
    \u0275\u0275text(5, "Intensidad");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "em");
    \u0275\u0275text(7, "Calidad");
    \u0275\u0275elementEnd()()();
    \u0275\u0275repeaterCreate(8, ResultsPage_Conditional_24_Conditional_0_Conditional_43_Conditional_19_For_4_Conditional_10_For_9_Template, 10, 9, "div", 95, _forTrack3);
  }
  if (rf & 2) {
    const ficha_r24 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275advance(8);
    \u0275\u0275repeater(ficha_r24.atributos);
  }
}
function ResultsPage_Conditional_24_Conditional_0_Conditional_43_Conditional_19_For_4_Conditional_11_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 95)(1, "span");
    \u0275\u0275text(2, "Impresi\xF3n global");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "strong");
    \u0275\u0275text(4);
    \u0275\u0275pipe(5, "number");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ficha_r24 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind2(5, 1, ficha_r24.impresionGlobal, "1.0-2"));
  }
}
function ResultsPage_Conditional_24_Conditional_0_Conditional_43_Conditional_19_For_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r22 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "ion-accordion", 91)(1, "ion-item", 92)(2, "ion-label");
    \u0275\u0275text(3);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "ion-badge", 47);
    \u0275\u0275text(5);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "span", 93);
    \u0275\u0275text(7);
    \u0275\u0275pipe(8, "number");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(9, "div", 94);
    \u0275\u0275conditionalCreate(10, ResultsPage_Conditional_24_Conditional_0_Conditional_43_Conditional_19_For_4_Conditional_10_Template, 10, 0);
    \u0275\u0275conditionalCreate(11, ResultsPage_Conditional_24_Conditional_0_Conditional_43_Conditional_19_For_4_Conditional_11_Template, 6, 4, "div", 95);
    \u0275\u0275elementStart(12, "div", 95)(13, "span");
    \u0275\u0275text(14, "Tazas no uniformes");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(15, "strong");
    \u0275\u0275text(16);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(17, "div", 95)(18, "span");
    \u0275\u0275text(19, "Tazas defectuosas");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(20, "strong");
    \u0275\u0275text(21);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(22, "div", 96)(23, "span");
    \u0275\u0275text(24, "Puntaje final");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(25, "strong");
    \u0275\u0275text(26);
    \u0275\u0275pipe(27, "number");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(28, "div", 97)(29, "ion-button", 98);
    \u0275\u0275listener("click", function ResultsPage_Conditional_24_Conditional_0_Conditional_43_Conditional_19_For_4_Template_ion_button_click_29_listener() {
      const ficha_r24 = \u0275\u0275restoreView(_r22).$implicit;
      const cat_r25 = \u0275\u0275nextContext(2);
      const ctx_r0 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r0.abrirExportar({ numeroMuestra: ficha_r24.numeroMuestra, cupperId: cat_r25.cupperId }));
    });
    \u0275\u0275text(30, " Exportar PDF ");
    \u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    const ficha_r24 = ctx.$implicit;
    const cat_r25 = \u0275\u0275nextContext(2);
    \u0275\u0275property("value", cat_r25.cupperId + "-" + ficha_r24.numeroMuestra);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate1("Muestra ", ficha_r24.numeroMuestra);
    \u0275\u0275advance();
    \u0275\u0275styleProp("--%NS%background", ficha_r24.clasificacion.fondo)("--%NS%color", ficha_r24.clasificacion.color);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", ficha_r24.clasificacion.etiqueta, " ");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind2(8, 13, ficha_r24.puntaje, "1.2-2"));
    \u0275\u0275advance(3);
    \u0275\u0275conditional(ficha_r24.atributos.length > 0 ? 10 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(ficha_r24.impresionGlobal !== null ? 11 : -1);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(ficha_r24.tazasNoUniformes);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(ficha_r24.tazasDefectuosas);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind2(27, 16, ficha_r24.puntaje, "1.2-2"));
  }
}
function ResultsPage_Conditional_24_Conditional_0_Conditional_43_Conditional_19_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 43);
    \u0275\u0275text(1, "Haz clic en una ficha para ver su detalle.");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(2, "ion-accordion-group", 90);
    \u0275\u0275repeaterCreate(3, ResultsPage_Conditional_24_Conditional_0_Conditional_43_Conditional_19_For_4_Template, 31, 19, "ion-accordion", 91, _forTrack2);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext(4);
    \u0275\u0275advance(2);
    \u0275\u0275property("multiple", false);
    \u0275\u0275advance();
    \u0275\u0275repeater(ctx_r0.fichasReporte());
  }
}
function ResultsPage_Conditional_24_Conditional_0_Conditional_43_Conditional_20_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 43);
    \u0275\u0275text(1, "Este catador a\xFAn no tiene fichas enviadas.");
    \u0275\u0275elementEnd();
  }
}
function ResultsPage_Conditional_24_Conditional_0_Conditional_43_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-card", 35)(1, "ion-card-content")(2, "h2", 42);
    \u0275\u0275text(3, "Reporte de sesi\xF3n individual");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "div", 84)(5, "div", 85)(6, "span", 86);
    \u0275\u0275text(7);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "div")(9, "p", 87);
    \u0275\u0275text(10);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(11, "p", 88);
    \u0275\u0275text(12);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(13, "div", 89)(14, "strong");
    \u0275\u0275text(15);
    \u0275\u0275pipe(16, "number");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(17, "span");
    \u0275\u0275text(18, "Promedio");
    \u0275\u0275elementEnd()()();
    \u0275\u0275conditionalCreate(19, ResultsPage_Conditional_24_Conditional_0_Conditional_43_Conditional_19_Template, 5, 1)(20, ResultsPage_Conditional_24_Conditional_0_Conditional_43_Conditional_20_Template, 2, 0, "p", 43);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const cat_r25 = ctx;
    const ctx_r0 = \u0275\u0275nextContext(3);
    \u0275\u0275advance(7);
    \u0275\u0275textInterpolate(cat_r25.nombre.charAt(0).toUpperCase());
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(cat_r25.nombre);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate3(" ", cat_r25.muestrasEvaluadas, " de ", cat_r25.muestrasAsignadas, " muestras evaluadas \xB7 estado ", cat_r25.estado, " ");
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind2(16, 7, cat_r25.puntajePromedio, "1.2-2"));
    \u0275\u0275advance(4);
    \u0275\u0275conditional(ctx_r0.fichasReporte().length > 0 ? 19 : 20);
  }
}
function ResultsPage_Conditional_24_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r16 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "ion-grid", 58)(1, "ion-row")(2, "ion-col", 59);
    \u0275\u0275template(3, ResultsPage_Conditional_24_Conditional_0_ng_container_3_Template, 1, 0, "ng-container", 60);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "ion-col", 59);
    \u0275\u0275template(5, ResultsPage_Conditional_24_Conditional_0_ng_container_5_Template, 1, 0, "ng-container", 60);
    \u0275\u0275elementEnd()()();
    \u0275\u0275template(6, ResultsPage_Conditional_24_Conditional_0_ng_container_6_Template, 1, 0, "ng-container", 60);
    \u0275\u0275elementStart(7, "ion-card", 35)(8, "ion-card-content")(9, "h2", 42);
    \u0275\u0275text(10, "Ranking \u2014 promedio del panel");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(11, "p", 43);
    \u0275\u0275text(12, "Haz clic en una muestra para ver su promedio del panel en el medidor.");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(13, "div", 61)(14, "table", 62)(15, "thead")(16, "tr")(17, "th", 63);
    \u0275\u0275text(18, "#");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(19, "th", 63);
    \u0275\u0275text(20, "Muestra");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(21, "th", 63);
    \u0275\u0275text(22, "Fichas");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(23, "th", 63);
    \u0275\u0275text(24, "M\xEDn \u2013 M\xE1x");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(25, "th", 63);
    \u0275\u0275text(26, "Puntaje panel");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(27, "th", 63);
    \u0275\u0275text(28, "Clasificaci\xF3n");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(29, "tbody");
    \u0275\u0275repeaterCreate(30, ResultsPage_Conditional_24_Conditional_0_For_31_Template, 22, 30, "tr", 64, _forTrack2, false, ResultsPage_Conditional_24_Conditional_0_ForEmpty_32_Template, 3, 0, "tr");
    \u0275\u0275elementEnd()()();
    \u0275\u0275conditionalCreate(33, ResultsPage_Conditional_24_Conditional_0_Conditional_33_Template, 2, 1, "p", 65);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(34, "section", 66)(35, "h2", 42);
    \u0275\u0275text(36, "An\xE1lisis de catadores");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(37, "p", 43);
    \u0275\u0275text(38, "Participaci\xF3n y consistencia individual dentro del panel. Selecciona un catador para ver su reporte.");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(39, "ion-grid", 58)(40, "ion-row");
    \u0275\u0275repeaterCreate(41, ResultsPage_Conditional_24_Conditional_0_For_42_Template, 3, 4, "ion-col", 67, _forTrack1);
    \u0275\u0275elementEnd()()();
    \u0275\u0275conditionalCreate(43, ResultsPage_Conditional_24_Conditional_0_Conditional_43_Template, 21, 10, "ion-card", 35);
    \u0275\u0275elementStart(44, "section", 68)(45, "h2", 69);
    \u0275\u0275text(46, "F\xF3rmula CVA aplicada");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(47, "p", 70);
    \u0275\u0275text(48, "S = 0.65625 \xD7 \u03A3h\u1D62 + 52.75 \u2212 2u \u2212 4d");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(49, "p", 56);
    \u0275\u0275text(50, " El consolidado descarta el valor m\xE1s alto y el m\xE1s bajo por muestra cuando hay 5 o m\xE1s fichas. ");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(51, "div", 51)(52, "ion-button", 53);
    \u0275\u0275listener("click", function ResultsPage_Conditional_24_Conditional_0_Template_ion_button_click_52_listener() {
      \u0275\u0275restoreView(_r16);
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.volverAlPanel());
    });
    \u0275\u0275text(53, "Volver al panel");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(54, "ion-button", 71);
    \u0275\u0275listener("click", function ResultsPage_Conditional_24_Conditional_0_Template_ion_button_click_54_listener() {
      \u0275\u0275restoreView(_r16);
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.abrirExportar());
    });
    \u0275\u0275element(55, "ion-icon", 21);
    \u0275\u0275text(56, " Exportar a PDF (Formato SCA) ");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    let tmp_24_0;
    const r_r26 = \u0275\u0275nextContext();
    const ctx_r0 = \u0275\u0275nextContext();
    const medidor_r27 = \u0275\u0275reference(13);
    const metaSesion_r28 = \u0275\u0275reference(15);
    \u0275\u0275advance(3);
    \u0275\u0275property("ngTemplateOutlet", medidor_r27)("ngTemplateOutletContext", \u0275\u0275pureFunction2(10, _c1, ctx_r0.promedioPanel(), ctx_r0.agujaPanel()));
    \u0275\u0275advance(2);
    \u0275\u0275property("ngTemplateOutlet", medidor_r27)("ngTemplateOutletContext", \u0275\u0275pureFunction3(13, _c2, ctx_r0.muestraEnMedidor()?.puntajePromedioPanel ?? 0, ctx_r0.agujaMuestra(), "Promedio del panel por muestra \xB7 Muestra " + (ctx_r0.muestraEnMedidor()?.numeroMuestra ?? "\u2014")));
    \u0275\u0275advance();
    \u0275\u0275property("ngTemplateOutlet", metaSesion_r28)("ngTemplateOutletContext", \u0275\u0275pureFunction2(17, _c3, r_r26, ctx_r0.hayRecorte() ? "Consolidaci\xF3n mediante promedio recortado SCA (se descartan m\xE1ximo y m\xEDnimo con 5 o m\xE1s catadores)." : "Consolidaci\xF3n mediante promedio simple (menos de 5 fichas por muestra)."));
    \u0275\u0275advance(24);
    \u0275\u0275repeater(ctx_r0.ranking());
    \u0275\u0275advance(3);
    \u0275\u0275conditional(ctx_r0.muestrasSinFichas().length > 0 ? 33 : -1);
    \u0275\u0275advance(8);
    \u0275\u0275repeater(r_r26.catadores);
    \u0275\u0275advance(2);
    \u0275\u0275conditional((tmp_24_0 = ctx_r0.catadorReporte()) ? 43 : -1, tmp_24_0);
    \u0275\u0275advance(11);
    \u0275\u0275property("disabled", ctx_r0.imprimiendo());
  }
}
function ResultsPage_Conditional_24_Conditional_1_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_Conditional_24_Conditional_1_For_23_Template(rf, ctx) {
  if (rf & 1) {
    const _r30 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "tr", 72);
    \u0275\u0275listener("click", function ResultsPage_Conditional_24_Conditional_1_For_23_Template_tr_click_0_listener() {
      const fila_r31 = \u0275\u0275restoreView(_r30).$implicit;
      const ctx_r0 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r0.seleccionarMuestraDetalle(fila_r31.numeroMuestra));
    })("keydown.enter", function ResultsPage_Conditional_24_Conditional_1_For_23_Template_tr_keydown_enter_0_listener() {
      const fila_r31 = \u0275\u0275restoreView(_r30).$implicit;
      const ctx_r0 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r0.seleccionarMuestraDetalle(fila_r31.numeroMuestra));
    })("keydown.space", function ResultsPage_Conditional_24_Conditional_1_For_23_Template_tr_keydown_space_0_listener($event) {
      const fila_r31 = \u0275\u0275restoreView(_r30).$implicit;
      const ctx_r0 = \u0275\u0275nextContext(3);
      $event.preventDefault();
      return \u0275\u0275resetView(ctx_r0.seleccionarMuestraDetalle(fila_r31.numeroMuestra));
    });
    \u0275\u0275elementStart(1, "td", 73);
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "td")(4, "span", 75);
    \u0275\u0275text(5);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(6, "td");
    \u0275\u0275text(7);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "td", 102)(9, "div", 103)(10, "div", 104);
    \u0275\u0275element(11, "i");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(12, "strong", 78);
    \u0275\u0275text(13);
    \u0275\u0275pipe(14, "number");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(15, "td")(16, "ion-badge", 105);
    \u0275\u0275text(17);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const fila_r31 = ctx.$implicit;
    const activa_r32 = fila_r31.numeroMuestra === \u0275\u0275nextContext(3).hedonicoSeleccionado()?.numeroMuestra;
    \u0275\u0275classProp("rc-ranking__row--active", activa_r32);
    \u0275\u0275attribute("aria-selected", activa_r32);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(fila_r31.posicion ? "#" + fila_r31.posicion : "\u2014");
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate1("Muestra ", fila_r31.numeroMuestra);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(fila_r31.totalVotos);
    \u0275\u0275advance(4);
    \u0275\u0275styleProp("width", (fila_r31.promedio ?? 0) / 9 * 100, "%");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(fila_r31.promedio === null ? "\u2014" : \u0275\u0275pipeBind2(14, 10, fila_r31.promedio, "1.2-2"));
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(fila_r31.etiqueta);
  }
}
function ResultsPage_Conditional_24_Conditional_1_ForEmpty_24_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "tr")(1, "td", 106);
    \u0275\u0275text(2, "La sesi\xF3n no tiene muestras.");
    \u0275\u0275elementEnd()();
  }
}
function ResultsPage_Conditional_24_Conditional_1_Conditional_25_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_Conditional_24_Conditional_1_Conditional_25_Conditional_10_For_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "li", 112)(1, "span", 113);
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "span", 114);
    \u0275\u0275text(4);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "div", 104);
    \u0275\u0275element(6, "i");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "strong", 115);
    \u0275\u0275text(8);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const d_r33 = ctx.$implicit;
    \u0275\u0275classProp("ra-dist__row--empty", d_r33.votos === 0);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(d_r33.valor);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(d_r33.etiqueta);
    \u0275\u0275advance(2);
    \u0275\u0275styleProp("width", d_r33.porcentaje, "%");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(d_r33.votos);
  }
}
function ResultsPage_Conditional_24_Conditional_1_Conditional_25_Conditional_10_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ul", 109);
    \u0275\u0275repeaterCreate(1, ResultsPage_Conditional_24_Conditional_1_Conditional_25_Conditional_10_For_2_Template, 9, 7, "li", 110, _forTrack4);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "p", 111);
    \u0275\u0275text(4);
    \u0275\u0275elementStart(5, "strong");
    \u0275\u0275text(6);
    \u0275\u0275pipe(7, "number");
    \u0275\u0275elementEnd();
    \u0275\u0275text(8);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const sel_r34 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275repeater(sel_r34.distribucion);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate1(" ", sel_r34.totalVotos, " voto(s) \xB7 promedio ");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind2(7, 3, sel_r34.promedio, "1.2-2"));
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1(" (", sel_r34.etiqueta, ") ");
  }
}
function ResultsPage_Conditional_24_Conditional_1_Conditional_25_Conditional_11_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 43);
    \u0275\u0275text(1, "Esta muestra no recibi\xF3 votos de Impresi\xF3n Global.");
    \u0275\u0275elementEnd();
  }
}
function ResultsPage_Conditional_24_Conditional_1_Conditional_25_For_21_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "li", 108)(1, "span", 116);
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "div", 104);
    \u0275\u0275element(4, "i");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "strong", 117);
    \u0275\u0275text(6);
    \u0275\u0275pipe(7, "number");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const a_r35 = ctx.$implicit;
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(a_r35.etiqueta);
    \u0275\u0275advance(2);
    \u0275\u0275styleProp("width", a_r35.porcentaje, "%");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(a_r35.valor === null ? "\u2014" : \u0275\u0275pipeBind2(7, 4, a_r35.valor, "1.1-1"));
  }
}
function ResultsPage_Conditional_24_Conditional_1_Conditional_25_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275template(0, ResultsPage_Conditional_24_Conditional_1_Conditional_25_ng_container_0_Template, 1, 0, "ng-container", 60);
    \u0275\u0275elementStart(1, "ion-grid", 58)(2, "ion-row")(3, "ion-col", 59)(4, "ion-card", 35)(5, "ion-card-content")(6, "h2", 42);
    \u0275\u0275text(7);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "p", 43);
    \u0275\u0275text(9, "Cu\xE1ntos catadores eligieron cada punto de la escala (Impresi\xF3n Global).");
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(10, ResultsPage_Conditional_24_Conditional_1_Conditional_25_Conditional_10_Template, 9, 6)(11, ResultsPage_Conditional_24_Conditional_1_Conditional_25_Conditional_11_Template, 2, 0, "p", 43);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(12, "ion-col", 59)(13, "ion-card", 35)(14, "ion-card-content")(15, "h2", 42);
    \u0275\u0275text(16);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(17, "p", 43);
    \u0275\u0275text(18, "Promedio del panel en la escala hed\xF3nica (1 a 9).");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(19, "ul", 107);
    \u0275\u0275repeaterCreate(20, ResultsPage_Conditional_24_Conditional_1_Conditional_25_For_21_Template, 8, 7, "li", 108, _forTrack3);
    \u0275\u0275elementEnd()()()()()();
  }
  if (rf & 2) {
    const sel_r34 = ctx;
    \u0275\u0275nextContext(3);
    const selectorMuestra_r36 = \u0275\u0275reference(19);
    \u0275\u0275property("ngTemplateOutlet", selectorMuestra_r36)("ngTemplateOutletContext", \u0275\u0275pureFunction1(5, _c6, sel_r34.numeroMuestra));
    \u0275\u0275advance(7);
    \u0275\u0275textInterpolate1("Distribuci\xF3n de votos \xB7 Muestra ", sel_r34.numeroMuestra);
    \u0275\u0275advance(3);
    \u0275\u0275conditional(sel_r34.totalVotos > 0 ? 10 : 11);
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate1("Calidad por atributo \xB7 Muestra ", sel_r34.numeroMuestra);
    \u0275\u0275advance(4);
    \u0275\u0275repeater(sel_r34.atributos);
  }
}
function ResultsPage_Conditional_24_Conditional_1_ng_container_26_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_Conditional_24_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r29 = \u0275\u0275getCurrentView();
    \u0275\u0275template(0, ResultsPage_Conditional_24_Conditional_1_ng_container_0_Template, 1, 0, "ng-container", 60);
    \u0275\u0275elementStart(1, "ion-card", 35)(2, "ion-card-content")(3, "h2", 42);
    \u0275\u0275text(4, "Agrado del panel \u2014 escala hed\xF3nica (1 a 9)");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "p", 43);
    \u0275\u0275text(6, "Promedio de la Impresi\xF3n Global por muestra. Haz clic en una muestra para ver sus votos.");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "div", 61)(8, "table", 62)(9, "thead")(10, "tr")(11, "th", 63);
    \u0275\u0275text(12, "#");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(13, "th", 63);
    \u0275\u0275text(14, "Muestra");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(15, "th", 63);
    \u0275\u0275text(16, "Votos");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(17, "th", 101);
    \u0275\u0275text(18, "Promedio hed\xF3nico");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(19, "th", 63);
    \u0275\u0275text(20, "Valoraci\xF3n");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(21, "tbody");
    \u0275\u0275repeaterCreate(22, ResultsPage_Conditional_24_Conditional_1_For_23_Template, 18, 13, "tr", 64, _forTrack2, false, ResultsPage_Conditional_24_Conditional_1_ForEmpty_24_Template, 3, 0, "tr");
    \u0275\u0275elementEnd()()()()();
    \u0275\u0275conditionalCreate(25, ResultsPage_Conditional_24_Conditional_1_Conditional_25_Template, 22, 7);
    \u0275\u0275template(26, ResultsPage_Conditional_24_Conditional_1_ng_container_26_Template, 1, 0, "ng-container", 60);
    \u0275\u0275elementStart(27, "div", 51)(28, "ion-button", 53);
    \u0275\u0275listener("click", function ResultsPage_Conditional_24_Conditional_1_Template_ion_button_click_28_listener() {
      \u0275\u0275restoreView(_r29);
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.volverAlPanel());
    });
    \u0275\u0275text(29, "Volver al panel");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(30, "ion-button", 71);
    \u0275\u0275listener("click", function ResultsPage_Conditional_24_Conditional_1_Template_ion_button_click_30_listener() {
      \u0275\u0275restoreView(_r29);
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.exportarPDF());
    });
    \u0275\u0275element(31, "ion-icon", 21);
    \u0275\u0275text(32, " Exportar a PDF (Formato SCA) ");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    let tmp_18_0;
    const r_r26 = \u0275\u0275nextContext();
    const ctx_r0 = \u0275\u0275nextContext();
    const metaSesion_r28 = \u0275\u0275reference(15);
    const participacion_r37 = \u0275\u0275reference(17);
    \u0275\u0275property("ngTemplateOutlet", metaSesion_r28)("ngTemplateOutletContext", \u0275\u0275pureFunction1(7, _c4, r_r26));
    \u0275\u0275advance(22);
    \u0275\u0275repeater(ctx_r0.resultadosHedonicos());
    \u0275\u0275advance(3);
    \u0275\u0275conditional((tmp_18_0 = ctx_r0.hedonicoSeleccionado()) ? 25 : -1, tmp_18_0);
    \u0275\u0275advance();
    \u0275\u0275property("ngTemplateOutlet", participacion_r37)("ngTemplateOutletContext", \u0275\u0275pureFunction1(9, _c5, r_r26));
    \u0275\u0275advance(4);
    \u0275\u0275property("disabled", ctx_r0.imprimiendo());
  }
}
function ResultsPage_Conditional_24_Conditional_2_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_Conditional_24_Conditional_2_Conditional_1_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_Conditional_24_Conditional_2_Conditional_1_For_23_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "li", 108)(1, "span", 116);
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "div", 124);
    \u0275\u0275element(4, "i");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "strong", 117);
    \u0275\u0275text(6);
    \u0275\u0275pipe(7, "number");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const a_r39 = ctx.$implicit;
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(a_r39.etiqueta);
    \u0275\u0275advance(2);
    \u0275\u0275styleProp("width", a_r39.porcentaje, "%");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(a_r39.valor === null ? "\u2014" : \u0275\u0275pipeBind2(7, 4, a_r39.valor, "1.1-1"));
  }
}
function ResultsPage_Conditional_24_Conditional_2_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275template(0, ResultsPage_Conditional_24_Conditional_2_Conditional_1_ng_container_0_Template, 1, 0, "ng-container", 60);
    \u0275\u0275elementStart(1, "ion-card", 35)(2, "ion-card-content")(3, "div", 120)(4, "div")(5, "h2", 42);
    \u0275\u0275text(6);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "p", 43);
    \u0275\u0275text(8);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(9, "div", 121);
    \u0275\u0275element(10, "span");
    \u0275\u0275elementStart(11, "span", 122)(12, "em");
    \u0275\u0275text(13, "0");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(14, "em");
    \u0275\u0275text(15, "5");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(16, "em");
    \u0275\u0275text(17, "10");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(18, "em");
    \u0275\u0275text(19, "15");
    \u0275\u0275elementEnd()();
    \u0275\u0275element(20, "span");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(21, "ul", 123);
    \u0275\u0275repeaterCreate(22, ResultsPage_Conditional_24_Conditional_2_Conditional_1_For_23_Template, 8, 7, "li", 108, _forTrack3);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const perfil_r40 = ctx;
    \u0275\u0275nextContext(3);
    const selectorMuestra_r36 = \u0275\u0275reference(19);
    \u0275\u0275property("ngTemplateOutlet", selectorMuestra_r36)("ngTemplateOutletContext", \u0275\u0275pureFunction1(4, _c6, perfil_r40.numeroMuestra));
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate1("Perfil de intensidad \xB7 Muestra ", perfil_r40.numeroMuestra);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1("Promedio del panel por atributo (", perfil_r40.fichas, " ficha(s)).");
    \u0275\u0275advance(14);
    \u0275\u0275repeater(perfil_r40.atributos);
  }
}
function ResultsPage_Conditional_24_Conditional_2_For_15_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "th", 119);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const p_r41 = ctx.$implicit;
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1("M", p_r41.numeroMuestra);
  }
}
function ResultsPage_Conditional_24_Conditional_2_For_18_For_4_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "td", 126)(1, "span", 127);
    \u0275\u0275text(2);
    \u0275\u0275pipe(3, "number");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const p_r42 = ctx.$implicit;
    const \u0275$index_719_r43 = \u0275\u0275nextContext().$index;
    \u0275\u0275advance();
    \u0275\u0275styleProp("--%NS%rd-alpha", p_r42.atributos[\u0275$index_719_r43].porcentaje / 100);
    \u0275\u0275classProp("rd-cell--dark", p_r42.atributos[\u0275$index_719_r43].porcentaje > 55);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", p_r42.atributos[\u0275$index_719_r43].valor === null ? "\u2014" : \u0275\u0275pipeBind2(3, 5, p_r42.atributos[\u0275$index_719_r43].valor, "1.1-1"), " ");
  }
}
function ResultsPage_Conditional_24_Conditional_2_For_18_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "tr")(1, "th", 125);
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
    \u0275\u0275repeaterCreate(3, ResultsPage_Conditional_24_Conditional_2_For_18_For_4_Template, 4, 8, "td", 126, _forTrack2);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const atr_r44 = ctx.$implicit;
    const ctx_r0 = \u0275\u0275nextContext(3);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(atr_r44.etiqueta);
    \u0275\u0275advance();
    \u0275\u0275repeater(ctx_r0.perfilesDescriptivos());
  }
}
function ResultsPage_Conditional_24_Conditional_2_ng_container_19_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_Conditional_24_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r38 = \u0275\u0275getCurrentView();
    \u0275\u0275template(0, ResultsPage_Conditional_24_Conditional_2_ng_container_0_Template, 1, 0, "ng-container", 60);
    \u0275\u0275conditionalCreate(1, ResultsPage_Conditional_24_Conditional_2_Conditional_1_Template, 24, 6);
    \u0275\u0275elementStart(2, "ion-card", 35)(3, "ion-card-content")(4, "h2", 42);
    \u0275\u0275text(5, "Comparativa de intensidades");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "p", 43);
    \u0275\u0275text(7, "Promedio del panel (0\u201315). El tono de cada celda es proporcional a la intensidad.");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "div", 61)(9, "table", 118)(10, "thead")(11, "tr")(12, "th", 63);
    \u0275\u0275text(13, "Atributo");
    \u0275\u0275elementEnd();
    \u0275\u0275repeaterCreate(14, ResultsPage_Conditional_24_Conditional_2_For_15_Template, 2, 1, "th", 119, _forTrack2);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(16, "tbody");
    \u0275\u0275repeaterCreate(17, ResultsPage_Conditional_24_Conditional_2_For_18_Template, 5, 1, "tr", null, _forTrack3);
    \u0275\u0275elementEnd()()()()();
    \u0275\u0275template(19, ResultsPage_Conditional_24_Conditional_2_ng_container_19_Template, 1, 0, "ng-container", 60);
    \u0275\u0275elementStart(20, "div", 51)(21, "ion-button", 53);
    \u0275\u0275listener("click", function ResultsPage_Conditional_24_Conditional_2_Template_ion_button_click_21_listener() {
      \u0275\u0275restoreView(_r38);
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.volverAlPanel());
    });
    \u0275\u0275text(22, "Volver al panel");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(23, "ion-button", 71);
    \u0275\u0275listener("click", function ResultsPage_Conditional_24_Conditional_2_Template_ion_button_click_23_listener() {
      \u0275\u0275restoreView(_r38);
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.abrirExportar());
    });
    \u0275\u0275element(24, "ion-icon", 21);
    \u0275\u0275text(25, " Exportar a PDF (Formato SCA) ");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    let tmp_17_0;
    const r_r26 = \u0275\u0275nextContext();
    const ctx_r0 = \u0275\u0275nextContext();
    const metaSesion_r28 = \u0275\u0275reference(15);
    const participacion_r37 = \u0275\u0275reference(17);
    \u0275\u0275property("ngTemplateOutlet", metaSesion_r28)("ngTemplateOutletContext", \u0275\u0275pureFunction1(6, _c7, r_r26));
    \u0275\u0275advance();
    \u0275\u0275conditional((tmp_17_0 = ctx_r0.perfilSeleccionado()) ? 1 : -1, tmp_17_0);
    \u0275\u0275advance(13);
    \u0275\u0275repeater(ctx_r0.perfilesDescriptivos());
    \u0275\u0275advance(3);
    \u0275\u0275repeater(ctx_r0.atributosCva);
    \u0275\u0275advance(2);
    \u0275\u0275property("ngTemplateOutlet", participacion_r37)("ngTemplateOutletContext", \u0275\u0275pureFunction1(8, _c5, r_r26));
    \u0275\u0275advance(4);
    \u0275\u0275property("disabled", ctx_r0.imprimiendo());
  }
}
function ResultsPage_Conditional_24_Conditional_3_For_1_Conditional_9_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275text(0);
  }
  if (rf & 2) {
    const ficha_r46 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275textInterpolate1(" Registrada por ", ficha_r46.registradaPor, " ");
  }
}
function ResultsPage_Conditional_24_Conditional_3_For_1_Conditional_10_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275text(0);
    \u0275\u0275pipe(1, "date");
  }
  if (rf & 2) {
    const ficha_r46 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275textInterpolate1(" \xB7 ", \u0275\u0275pipeBind2(1, 1, ficha_r46.registradaEn, "mediumDate"), " ");
  }
}
function ResultsPage_Conditional_24_Conditional_3_For_1_For_14_For_6_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "dt");
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(2, "dd");
    \u0275\u0275text(3);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const campo_r47 = ctx.$implicit;
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(campo_r47.etiqueta);
    \u0275\u0275advance();
    \u0275\u0275classProp("re-dl__empty", campo_r47.valor === "\u2014");
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(campo_r47.valor);
  }
}
function ResultsPage_Conditional_24_Conditional_3_For_1_For_14_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-col", 132)(1, "section", 133)(2, "h3", 69);
    \u0275\u0275text(3);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "dl", 135);
    \u0275\u0275repeaterCreate(5, ResultsPage_Conditional_24_Conditional_3_For_1_For_14_For_6_Template, 4, 4, null, null, _forTrack7);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const seccion_r48 = ctx.$implicit;
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(seccion_r48.titulo);
    \u0275\u0275advance(2);
    \u0275\u0275repeater(seccion_r48.campos);
  }
}
function ResultsPage_Conditional_24_Conditional_3_For_1_Conditional_18_For_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-badge", 136);
    \u0275\u0275element(1, "ion-icon", 137);
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const c_r49 = ctx.$implicit;
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1(" ", c_r49);
  }
}
function ResultsPage_Conditional_24_Conditional_3_For_1_Conditional_18_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 134);
    \u0275\u0275repeaterCreate(1, ResultsPage_Conditional_24_Conditional_3_For_1_Conditional_18_For_2_Template, 3, 1, "ion-badge", 136, \u0275\u0275repeaterTrackByIdentity);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ficha_r46 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275advance();
    \u0275\u0275repeater(ficha_r46.certificaciones);
  }
}
function ResultsPage_Conditional_24_Conditional_3_For_1_Conditional_19_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 43);
    \u0275\u0275text(1, "Sin certificaciones registradas.");
    \u0275\u0275elementEnd();
  }
}
function ResultsPage_Conditional_24_Conditional_3_For_1_Conditional_20_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "section", 133)(1, "h3", 69);
    \u0275\u0275text(2, "Notas");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "p", 138);
    \u0275\u0275text(4);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ficha_r46 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(ficha_r46.notas);
  }
}
function ResultsPage_Conditional_24_Conditional_3_For_1_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-card", 128)(1, "ion-card-content")(2, "div", 129)(3, "div", 130);
    \u0275\u0275element(4, "ion-icon", 131);
    \u0275\u0275elementStart(5, "div")(6, "h2");
    \u0275\u0275text(7);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "p", 56);
    \u0275\u0275conditionalCreate(9, ResultsPage_Conditional_24_Conditional_3_For_1_Conditional_9_Template, 1, 1);
    \u0275\u0275conditionalCreate(10, ResultsPage_Conditional_24_Conditional_3_For_1_Conditional_10_Template, 2, 4);
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(11, "ion-grid", 58)(12, "ion-row");
    \u0275\u0275repeaterCreate(13, ResultsPage_Conditional_24_Conditional_3_For_1_For_14_Template, 7, 1, "ion-col", 132, _forTrack6);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(15, "section", 133)(16, "h3", 69);
    \u0275\u0275text(17, "Certificaciones");
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(18, ResultsPage_Conditional_24_Conditional_3_For_1_Conditional_18_Template, 3, 0, "div", 134)(19, ResultsPage_Conditional_24_Conditional_3_For_1_Conditional_19_Template, 2, 0, "p", 43);
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(20, ResultsPage_Conditional_24_Conditional_3_For_1_Conditional_20_Template, 5, 1, "section", 133);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ficha_r46 = ctx.$implicit;
    \u0275\u0275advance(7);
    \u0275\u0275textInterpolate1("Ficha t\xE9cnica del caf\xE9 \xB7 Muestra ", ficha_r46.numeroMuestra);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ficha_r46.registradaPor ? 9 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(ficha_r46.registradaEn ? 10 : -1);
    \u0275\u0275advance(3);
    \u0275\u0275repeater(ficha_r46.secciones);
    \u0275\u0275advance(5);
    \u0275\u0275conditional(ficha_r46.certificaciones.length > 0 ? 18 : 19);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ficha_r46.notas ? 20 : -1);
  }
}
function ResultsPage_Conditional_24_Conditional_3_ForEmpty_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-card", 35)(1, "ion-card-content", 139);
    \u0275\u0275element(2, "ion-icon", 140);
    \u0275\u0275elementStart(3, "p");
    \u0275\u0275text(4, "Esta sesi\xF3n no tiene fichas t\xE9cnicas registradas.");
    \u0275\u0275elementEnd()()();
  }
}
function ResultsPage_Conditional_24_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r45 = \u0275\u0275getCurrentView();
    \u0275\u0275repeaterCreate(0, ResultsPage_Conditional_24_Conditional_3_For_1_Template, 21, 5, "ion-card", 128, _forTrack5, false, ResultsPage_Conditional_24_Conditional_3_ForEmpty_2_Template, 5, 0, "ion-card", 35);
    \u0275\u0275elementStart(3, "div", 51)(4, "ion-button", 53);
    \u0275\u0275listener("click", function ResultsPage_Conditional_24_Conditional_3_Template_ion_button_click_4_listener() {
      \u0275\u0275restoreView(_r45);
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.volverAlPanel());
    });
    \u0275\u0275text(5, "Volver al panel");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "ion-button", 71);
    \u0275\u0275listener("click", function ResultsPage_Conditional_24_Conditional_3_Template_ion_button_click_6_listener() {
      \u0275\u0275restoreView(_r45);
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.exportarPDF());
    });
    \u0275\u0275element(7, "ion-icon", 21);
    \u0275\u0275text(8, " Exportar Ficha T\xE9cnica a PDF ");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext(2);
    \u0275\u0275repeater(ctx_r0.fichasTecnicas());
    \u0275\u0275advance(6);
    \u0275\u0275property("disabled", ctx_r0.imprimiendo() || ctx_r0.fichasTecnicas().length === 0);
  }
}
function ResultsPage_Conditional_24_Conditional_4_For_44_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-icon", 145);
  }
}
function ResultsPage_Conditional_24_Conditional_4_For_44_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 77);
    \u0275\u0275text(1, "cerrada");
    \u0275\u0275elementEnd();
  }
}
function ResultsPage_Conditional_24_Conditional_4_For_44_Conditional_16_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 79);
    \u0275\u0275pipe(1, "number");
    \u0275\u0275text(2, "recortado");
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const fila_r51 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275property("title", \u0275\u0275interpolate1("Promedio simple: ", \u0275\u0275pipeBind2(1, 2, fila_r51.puntajePromedioSimple, "1.2-2")));
  }
}
function ResultsPage_Conditional_24_Conditional_4_For_44_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "tr")(1, "td", 73);
    \u0275\u0275conditionalCreate(2, ResultsPage_Conditional_24_Conditional_4_For_44_Conditional_2_Template, 1, 0, "ion-icon", 145);
    \u0275\u0275text(3);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "td");
    \u0275\u0275text(5);
    \u0275\u0275conditionalCreate(6, ResultsPage_Conditional_24_Conditional_4_For_44_Conditional_6_Template, 2, 0, "span", 77);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "td");
    \u0275\u0275text(8);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(9, "td", 56);
    \u0275\u0275text(10);
    \u0275\u0275pipe(11, "number");
    \u0275\u0275pipe(12, "number");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(13, "td", 78);
    \u0275\u0275text(14);
    \u0275\u0275pipe(15, "number");
    \u0275\u0275conditionalCreate(16, ResultsPage_Conditional_24_Conditional_4_For_44_Conditional_16_Template, 3, 5, "span", 79);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(17, "td")(18, "span", 146);
    \u0275\u0275text(19);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const fila_r51 = ctx.$implicit;
    \u0275\u0275advance(2);
    \u0275\u0275conditional(fila_r51.posicion === 1 ? 2 : -1);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" #", fila_r51.posicion, " ");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1(" Muestra ", fila_r51.numeroMuestra, " ");
    \u0275\u0275advance();
    \u0275\u0275conditional(fila_r51.cerradaForzada ? 6 : -1);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate2("", fila_r51.evaluacionesRecibidas, " / ", fila_r51.evaluacionesEsperadas);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate2("", \u0275\u0275pipeBind2(11, 15, fila_r51.puntajeMin, "1.2-2"), " \u2013 ", \u0275\u0275pipeBind2(12, 18, fila_r51.puntajeMax, "1.2-2"));
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate1(" ", \u0275\u0275pipeBind2(15, 21, fila_r51.puntajePromedioPanel, "1.2-2"), " ");
    \u0275\u0275advance(2);
    \u0275\u0275conditional(fila_r51.recortado ? 16 : -1);
    \u0275\u0275advance(2);
    \u0275\u0275styleProp("color", fila_r51.clasificacion.color)("background", fila_r51.clasificacion.fondo);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", fila_r51.clasificacion.etiqueta, " ");
  }
}
function ResultsPage_Conditional_24_Conditional_4_ForEmpty_45_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "tr")(1, "td", 81);
    \u0275\u0275text(2, "Ninguna muestra recibi\xF3 fichas.");
    \u0275\u0275elementEnd()();
  }
}
function ResultsPage_Conditional_24_Conditional_4_Conditional_46_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "tfoot")(1, "tr")(2, "td", 147);
    \u0275\u0275text(3, "Promedio del panel");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "td", 78);
    \u0275\u0275text(5);
    \u0275\u0275pipe(6, "number");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "td")(8, "span", 146);
    \u0275\u0275text(9);
    \u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext(3);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind2(6, 6, ctx_r0.promedioPanel(), "1.2-2"));
    \u0275\u0275advance(3);
    \u0275\u0275styleProp("color", ctx_r0.clasificacionPanel().color)("background", ctx_r0.clasificacionPanel().fondo);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", ctx_r0.clasificacionPanel().etiqueta, " ");
  }
}
function ResultsPage_Conditional_24_Conditional_4_Conditional_47_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 43);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext(3);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" Sin fichas: ", ctx_r0.muestrasSinFichas().length, " muestra(s) cerradas sin evaluaciones. ");
  }
}
function ResultsPage_Conditional_24_Conditional_4_For_55_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "app-cupper-result-card", 83);
  }
  if (rf & 2) {
    const catador_r52 = ctx.$implicit;
    \u0275\u0275property("catador", catador_r52);
  }
}
function ResultsPage_Conditional_24_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r50 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "section", 141)(1, "div", 37)(2, "p", 38);
    \u0275\u0275element(3, "ion-icon", 39);
    \u0275\u0275text(4);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "p", 40);
    \u0275\u0275text(6);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(7, "div", 41)(8, "div")(9, "strong");
    \u0275\u0275text(10);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(11, "span");
    \u0275\u0275text(12, "Muestras");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(13, "div")(14, "strong");
    \u0275\u0275text(15);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(16, "span");
    \u0275\u0275text(17, "Catadores");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(18, "div")(19, "strong");
    \u0275\u0275text(20);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(21, "span");
    \u0275\u0275text(22, "Formato");
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(23, "section", 142)(24, "h2", 69);
    \u0275\u0275text(25, "Ranking \u2014 promedio del panel");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(26, "div", 61)(27, "table", 143)(28, "thead")(29, "tr")(30, "th", 63);
    \u0275\u0275text(31, "#");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(32, "th", 63);
    \u0275\u0275text(33, "Muestra");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(34, "th", 63);
    \u0275\u0275text(35, "Fichas");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(36, "th", 63);
    \u0275\u0275text(37, "M\xEDn \u2013 M\xE1x");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(38, "th", 63);
    \u0275\u0275text(39, "Puntaje panel");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(40, "th", 63);
    \u0275\u0275text(41, "Clasificaci\xF3n");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(42, "tbody");
    \u0275\u0275repeaterCreate(43, ResultsPage_Conditional_24_Conditional_4_For_44_Template, 20, 24, "tr", null, _forTrack2, false, ResultsPage_Conditional_24_Conditional_4_ForEmpty_45_Template, 3, 0, "tr");
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(46, ResultsPage_Conditional_24_Conditional_4_Conditional_46_Template, 10, 9, "tfoot");
    \u0275\u0275elementEnd()();
    \u0275\u0275conditionalCreate(47, ResultsPage_Conditional_24_Conditional_4_Conditional_47_Template, 2, 1, "p", 43);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(48, "section")(49, "h2", 69);
    \u0275\u0275text(50, "An\xE1lisis de catadores");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(51, "p", 43);
    \u0275\u0275text(52, "Participaci\xF3n y consistencia individual dentro del panel.");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(53, "div", 144);
    \u0275\u0275repeaterCreate(54, ResultsPage_Conditional_24_Conditional_4_For_55_Template, 1, 1, "app-cupper-result-card", 83, _forTrack1);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(56, "section", 68)(57, "h2", 69);
    \u0275\u0275text(58, "F\xF3rmula CVA aplicada");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(59, "p", 70);
    \u0275\u0275text(60, "S = 0.65625 \xD7 \u03A3h\u1D62 + 52.75 \u2212 2u \u2212 4d");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(61, "p", 56);
    \u0275\u0275text(62, " El consolidado descarta el valor m\xE1s alto y el m\xE1s bajo por muestra cuando hay 5 o m\xE1s fichas. ");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(63, "div", 51)(64, "ion-button", 53);
    \u0275\u0275listener("click", function ResultsPage_Conditional_24_Conditional_4_Template_ion_button_click_64_listener() {
      \u0275\u0275restoreView(_r50);
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.volverAlPanel());
    });
    \u0275\u0275text(65, "Volver al panel");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(66, "ion-button", 57);
    \u0275\u0275listener("click", function ResultsPage_Conditional_24_Conditional_4_Template_ion_button_click_66_listener() {
      \u0275\u0275restoreView(_r50);
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.exportarPDF());
    });
    \u0275\u0275element(67, "ion-icon", 21);
    \u0275\u0275text(68, " Exportar a PDF (Formato SCA) ");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const r_r26 = \u0275\u0275nextContext();
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate1(" Sesi\xF3n cerrada \xB7 ", ctx_r0.porcentajeCompletado(), "% completada ");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1(" ", ctx_r0.hayRecorte() ? "Consolidaci\xF3n mediante promedio recortado SCA (se descartan m\xE1ximo y m\xEDnimo con 5 o m\xE1s catadores)." : "Consolidaci\xF3n mediante promedio simple (menos de 5 fichas por muestra).", " ");
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(r_r26.totalMuestras);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(r_r26.catadores.length);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(ctx_r0.tituloFormato());
    \u0275\u0275advance(23);
    \u0275\u0275repeater(ctx_r0.ranking());
    \u0275\u0275advance(3);
    \u0275\u0275conditional(ctx_r0.ranking().length > 0 ? 46 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r0.muestrasSinFichas().length > 0 ? 47 : -1);
    \u0275\u0275advance(7);
    \u0275\u0275repeater(r_r26.catadores);
  }
}
function ResultsPage_Conditional_24_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275conditionalCreate(0, ResultsPage_Conditional_24_Conditional_0_Template, 57, 20)(1, ResultsPage_Conditional_24_Conditional_1_Template, 33, 11)(2, ResultsPage_Conditional_24_Conditional_2_Template, 26, 10)(3, ResultsPage_Conditional_24_Conditional_3_Template, 9, 2)(4, ResultsPage_Conditional_24_Conditional_4_Template, 69, 8);
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275conditional(ctx_r0.esCombinado() ? 0 : ctx_r0.esAfectivo() ? 1 : ctx_r0.esDescriptivo() ? 2 : ctx_r0.esExtrinseco() ? 3 : 4);
  }
}
function ResultsPage_Conditional_25_ng_template_1_For_10_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-select-option", 49);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const n_r55 = ctx.$implicit;
    \u0275\u0275property("value", n_r55);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1("Muestra ", n_r55);
  }
}
function ResultsPage_Conditional_25_ng_template_1_Conditional_18_For_4_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-select-option", 49);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const c_r57 = ctx.$implicit;
    \u0275\u0275property("value", c_r57.cupperId);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(c_r57.nombre);
  }
}
function ResultsPage_Conditional_25_ng_template_1_Conditional_18_Template(rf, ctx) {
  if (rf & 1) {
    const _r56 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "label", 160);
    \u0275\u0275text(1, "Selecciona el catador");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(2, "ion-select", 161);
    \u0275\u0275listener("ionChange", function ResultsPage_Conditional_25_ng_template_1_Conditional_18_Template_ion_select_ionChange_2_listener($event) {
      \u0275\u0275restoreView(_r56);
      const ctx_r0 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r0.cambiarCatadorExportar($event.detail.value));
    });
    \u0275\u0275repeaterCreate(3, ResultsPage_Conditional_25_ng_template_1_Conditional_18_For_4_Template, 2, 2, "ion-select-option", 49, _forTrack1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext(3);
    \u0275\u0275advance(2);
    \u0275\u0275property("value", ctx_r0.catadorExportarId());
    \u0275\u0275advance();
    \u0275\u0275repeater(ctx_r0.catadoresExportables());
  }
}
function ResultsPage_Conditional_25_ng_template_1_Conditional_19_For_6_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275text(0, " sin ficha ");
  }
}
function ResultsPage_Conditional_25_ng_template_1_Conditional_19_For_6_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275text(0);
    \u0275\u0275pipe(1, "number");
  }
  if (rf & 2) {
    const o_r59 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275textInterpolate1(" +", \u0275\u0275pipeBind2(1, 1, o_r59.desviacion, "1.2-2"), " generoso ");
  }
}
function ResultsPage_Conditional_25_ng_template_1_Conditional_19_For_6_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275text(0);
    \u0275\u0275pipe(1, "number");
  }
  if (rf & 2) {
    const o_r59 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275textInterpolate1(" ", \u0275\u0275pipeBind2(1, 1, o_r59.desviacion, "1.2-2"), " estricto ");
  }
}
function ResultsPage_Conditional_25_ng_template_1_Conditional_19_For_6_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275text(0, " calibrado ");
  }
}
function ResultsPage_Conditional_25_ng_template_1_Conditional_19_For_6_Template(rf, ctx) {
  if (rf & 1) {
    const _r58 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "li", 166)(1, "ion-checkbox", 167);
    \u0275\u0275listener("ionChange", function ResultsPage_Conditional_25_ng_template_1_Conditional_19_For_6_Template_ion_checkbox_ionChange_1_listener($event) {
      const o_r59 = \u0275\u0275restoreView(_r58).$implicit;
      const ctx_r0 = \u0275\u0275nextContext(4);
      return \u0275\u0275resetView(ctx_r0.toggleCatadorPanel(o_r59.id, $event.detail.checked));
    });
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "span", 168);
    \u0275\u0275conditionalCreate(4, ResultsPage_Conditional_25_ng_template_1_Conditional_19_For_6_Conditional_4_Template, 1, 0)(5, ResultsPage_Conditional_25_ng_template_1_Conditional_19_For_6_Conditional_5_Template, 2, 4)(6, ResultsPage_Conditional_25_ng_template_1_Conditional_19_For_6_Conditional_6_Template, 2, 4)(7, ResultsPage_Conditional_25_ng_template_1_Conditional_19_For_6_Conditional_7_Template, 1, 0);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const o_r59 = ctx.$implicit;
    \u0275\u0275classProp("rc-export__panel-item--off", !o_r59.tieneFicha);
    \u0275\u0275advance();
    \u0275\u0275property("checked", o_r59.seleccionado && o_r59.tieneFicha)("disabled", !o_r59.tieneFicha);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", o_r59.nombre, " ");
    \u0275\u0275advance();
    \u0275\u0275classProp("rc-export__calib--alto", o_r59.desviacion > 0.5)("rc-export__calib--bajo", o_r59.desviacion < -0.5);
    \u0275\u0275advance();
    \u0275\u0275conditional(!o_r59.tieneFicha ? 4 : o_r59.desviacion > 0.5 ? 5 : o_r59.desviacion < -0.5 ? 6 : 7);
  }
}
function ResultsPage_Conditional_25_ng_template_1_Conditional_19_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 162);
    \u0275\u0275text(1, "Catadores incluidos en el consolidado");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(2, "p", 163);
    \u0275\u0275text(3, "Desmarca a los catadores descalibrados: sus fichas no se usar\xE1n en el PDF.");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "ul", 164);
    \u0275\u0275repeaterCreate(5, ResultsPage_Conditional_25_ng_template_1_Conditional_19_For_6_Template, 8, 10, "li", 165, _forTrack8);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext(3);
    \u0275\u0275advance(5);
    \u0275\u0275repeater(ctx_r0.opcionesPanel());
  }
}
function ResultsPage_Conditional_25_ng_template_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r54 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 149)(1, "div", 150)(2, "h2");
    \u0275\u0275text(3, "\xBFC\xF3mo quieres exportar tu PDF?");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "ion-button", 151);
    \u0275\u0275listener("click", function ResultsPage_Conditional_25_ng_template_1_Template_ion_button_click_4_listener() {
      \u0275\u0275restoreView(_r54);
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.cerrarExportar());
    });
    \u0275\u0275element(5, "ion-icon", 152);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(6, "label", 153);
    \u0275\u0275text(7, "Muestra #");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "ion-select", 154);
    \u0275\u0275listener("ionChange", function ResultsPage_Conditional_25_ng_template_1_Template_ion_select_ionChange_8_listener($event) {
      \u0275\u0275restoreView(_r54);
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.cambiarMuestraExportar($event.detail.value));
    });
    \u0275\u0275repeaterCreate(9, ResultsPage_Conditional_25_ng_template_1_For_10_Template, 2, 2, "ion-select-option", 49, \u0275\u0275repeaterTrackByIdentity);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(11, "ion-segment", 155);
    \u0275\u0275listener("ionChange", function ResultsPage_Conditional_25_ng_template_1_Template_ion_segment_ionChange_11_listener($event) {
      \u0275\u0275restoreView(_r54);
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.cambiarModoExportacion($event.detail.value));
    });
    \u0275\u0275elementStart(12, "ion-segment-button", 156)(13, "ion-label");
    \u0275\u0275text(14, "Por catador");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(15, "ion-segment-button", 157)(16, "ion-label");
    \u0275\u0275text(17, "Panel");
    \u0275\u0275elementEnd()()();
    \u0275\u0275conditionalCreate(18, ResultsPage_Conditional_25_ng_template_1_Conditional_18_Template, 5, 1)(19, ResultsPage_Conditional_25_ng_template_1_Conditional_19_Template, 7, 0);
    \u0275\u0275elementStart(20, "ion-button", 158);
    \u0275\u0275listener("click", function ResultsPage_Conditional_25_ng_template_1_Template_ion_button_click_20_listener() {
      \u0275\u0275restoreView(_r54);
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.confirmarExportar());
    });
    \u0275\u0275element(21, "ion-icon", 21);
    \u0275\u0275text(22, " Exportar a PDF (Formato SCA) ");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(23, "p", 159);
    \u0275\u0275text(24, 'En la ventana de impresi\xF3n elige "Guardar como PDF".');
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(8);
    \u0275\u0275property("value", ctx_r0.muestraHoja());
    \u0275\u0275advance();
    \u0275\u0275repeater(ctx_r0.numerosMuestra());
    \u0275\u0275advance(2);
    \u0275\u0275property("value", ctx_r0.modoExportacion());
    \u0275\u0275advance(7);
    \u0275\u0275conditional(ctx_r0.modoExportacion() === "catador" ? 18 : 19);
    \u0275\u0275advance(2);
    \u0275\u0275property("disabled", !ctx_r0.puedeConfirmarExportar());
  }
}
function ResultsPage_Conditional_25_Template(rf, ctx) {
  if (rf & 1) {
    const _r53 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "ion-modal", 148);
    \u0275\u0275listener("didDismiss", function ResultsPage_Conditional_25_Template_ion_modal_didDismiss_0_listener() {
      \u0275\u0275restoreView(_r53);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.cerrarExportar());
    });
    \u0275\u0275template(1, ResultsPage_Conditional_25_ng_template_1_Template, 25, 4, "ng-template");
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275property("isOpen", ctx_r0.modalExportarAbierto());
  }
}
function ResultsPage_ng_template_26_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 171);
    \u0275\u0275text(1);
    \u0275\u0275pipe(2, "number");
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const v_r60 = \u0275\u0275nextContext().v;
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind2(2, 1, v_r60, "1.0-1"));
  }
}
function ResultsPage_ng_template_26_Conditional_16_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "i", 182);
  }
  if (rf & 2) {
    const v_r60 = \u0275\u0275nextContext().v;
    \u0275\u0275styleProp("left", v_r60 / 15 * 100, "%");
  }
}
function ResultsPage_ng_template_26_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 169)(1, "div", 170)(2, "b");
    \u0275\u0275text(3);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "small");
    \u0275\u0275text(5, "Intensidad");
    \u0275\u0275conditionalCreate(6, ResultsPage_ng_template_26_Conditional_6_Template, 3, 4, "span", 171);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(7, "div", 172)(8, "div", 173)(9, "span");
    \u0275\u0275text(10, "BAJA");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(11, "span");
    \u0275\u0275text(12, "MEDIA");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(13, "span");
    \u0275\u0275text(14, "ALTA");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(15, "div", 174);
    \u0275\u0275conditionalCreate(16, ResultsPage_ng_template_26_Conditional_16_Template, 1, 2, "i", 175);
    \u0275\u0275elementEnd();
    \u0275\u0275element(17, "div", 176);
    \u0275\u0275elementStart(18, "div", 177)(19, "span", 178);
    \u0275\u0275text(20, "0");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(21, "span", 179);
    \u0275\u0275text(22, "5");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(23, "span", 180);
    \u0275\u0275text(24, "10");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(25, "span", 181);
    \u0275\u0275text(26, "15");
    \u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    const titulo_r61 = ctx.titulo;
    const v_r60 = ctx.v;
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(titulo_r61);
    \u0275\u0275advance(3);
    \u0275\u0275conditional(v_r60 !== null ? 6 : -1);
    \u0275\u0275advance(10);
    \u0275\u0275conditional(v_r60 !== null ? 16 : -1);
  }
}
function ResultsPage_ng_template_28_For_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 186);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const n_r62 = ctx.$implicit;
    const v_r63 = \u0275\u0275nextContext().v;
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275classProp("sca-c--on", ctx_r0.circuloMarcado(v_r63) === n_r62);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(n_r62);
  }
}
function ResultsPage_ng_template_28_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 183);
    \u0275\u0275repeaterCreate(1, ResultsPage_ng_template_28_For_2_Template, 2, 3, "span", 184, \u0275\u0275repeaterTrackByIdentity);
    \u0275\u0275elementStart(3, "span", 185);
    \u0275\u0275text(4);
    \u0275\u0275pipe(5, "number");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const v_r63 = ctx.v;
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275repeater(ctx_r0.escala9);
    \u0275\u0275advance(2);
    \u0275\u0275classProp("sca-final--on", v_r63 !== null);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(v_r63 === null ? "FINAL" : \u0275\u0275pipeBind2(5, 3, v_r63, "1.0-2"));
  }
}
function ResultsPage_ng_template_30_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "b");
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const etiqueta_r64 = \u0275\u0275nextContext().etiqueta;
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(etiqueta_r64);
  }
}
function ResultsPage_ng_template_30_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275text(0);
  }
  if (rf & 2) {
    const etiqueta_r64 = \u0275\u0275nextContext().etiqueta;
    \u0275\u0275textInterpolate(etiqueta_r64);
  }
}
function ResultsPage_ng_template_30_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "small");
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const detalle_r65 = \u0275\u0275nextContext().detalle;
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(detalle_r65);
  }
}
function ResultsPage_ng_template_30_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 187);
    \u0275\u0275element(1, "i");
    \u0275\u0275conditionalCreate(2, ResultsPage_ng_template_30_Conditional_2_Template, 2, 1, "b")(3, ResultsPage_ng_template_30_Conditional_3_Template, 1, 1);
    \u0275\u0275conditionalCreate(4, ResultsPage_ng_template_30_Conditional_4_Template, 2, 1, "small");
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const on_r66 = ctx.on;
    const principal_r67 = ctx.principal;
    const detalle_r65 = ctx.detalle;
    \u0275\u0275classProp("sca-cb--on", on_r66);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(principal_r67 ? 2 : 3);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(detalle_r65 ? 4 : -1);
  }
}
function ResultsPage_ng_template_32_For_1_For_2_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_ng_template_32_For_1_For_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275template(0, ResultsPage_ng_template_32_For_1_For_2_ng_container_0_Template, 1, 0, "ng-container", 60);
  }
  if (rf & 2) {
    const c_r68 = ctx.$implicit;
    const marcadas_r69 = \u0275\u0275nextContext(2).marcadas;
    \u0275\u0275nextContext();
    const scaCasilla_r70 = \u0275\u0275reference(31);
    \u0275\u0275property("ngTemplateOutlet", scaCasilla_r70)("ngTemplateOutletContext", \u0275\u0275pureFunction3(2, _c8, marcadas_r69.has(c_r68.clave), c_r68.etiqueta, c_r68.principal));
  }
}
function ResultsPage_ng_template_32_For_1_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 188);
    \u0275\u0275repeaterCreate(1, ResultsPage_ng_template_32_For_1_For_2_Template, 1, 6, "ng-container", null, _forTrack3);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const fila_r71 = ctx.$implicit;
    \u0275\u0275advance();
    \u0275\u0275repeater(fila_r71);
  }
}
function ResultsPage_ng_template_32_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275repeaterCreate(0, ResultsPage_ng_template_32_For_1_Template, 3, 0, "div", 188, \u0275\u0275repeaterTrackByIndex);
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275repeater(ctx_r0.descriptoresSca);
  }
}
function ResultsPage_ng_template_34_For_4_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_ng_template_34_For_4_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 188);
    \u0275\u0275template(1, ResultsPage_ng_template_34_For_4_ng_container_1_Template, 1, 0, "ng-container", 60);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const g_r72 = ctx.$implicit;
    const marcadas_r73 = \u0275\u0275nextContext().marcadas;
    \u0275\u0275nextContext();
    const scaCasilla_r70 = \u0275\u0275reference(31);
    \u0275\u0275advance();
    \u0275\u0275property("ngTemplateOutlet", scaCasilla_r70)("ngTemplateOutletContext", \u0275\u0275pureFunction2(2, _c9, marcadas_r73.has(g_r72.clave), g_r72.etiqueta));
  }
}
function ResultsPage_ng_template_34_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 189)(1, "p", 190);
    \u0275\u0275text(2, "Gustos Predominantes (2)");
    \u0275\u0275elementEnd();
    \u0275\u0275repeaterCreate(3, ResultsPage_ng_template_34_For_4_Template, 2, 5, "div", 188, _forTrack3);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance(3);
    \u0275\u0275repeater(ctx_r0.gustosSca);
  }
}
function ResultsPage_ng_template_36_For_1_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_ng_template_36_For_1_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 188);
    \u0275\u0275template(1, ResultsPage_ng_template_36_For_1_ng_container_1_Template, 1, 0, "ng-container", 60);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const b_r74 = ctx.$implicit;
    const marcadas_r75 = \u0275\u0275nextContext().marcadas;
    \u0275\u0275nextContext();
    const scaCasilla_r70 = \u0275\u0275reference(31);
    \u0275\u0275advance();
    \u0275\u0275property("ngTemplateOutlet", scaCasilla_r70)("ngTemplateOutletContext", \u0275\u0275pureFunction3(2, _c10, marcadas_r75.has(b_r74.clave), b_r74.etiqueta, b_r74.detalle));
  }
}
function ResultsPage_ng_template_36_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275repeaterCreate(0, ResultsPage_ng_template_36_For_1_Template, 2, 6, "div", 188, _forTrack3);
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275repeater(ctx_r0.bocaSca);
  }
}
function ResultsPage_ng_template_38_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 192);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const texto_r76 = \u0275\u0275nextContext().texto;
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(texto_r76);
  }
}
function ResultsPage_ng_template_38_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 191)(1, "p", 190);
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(3, ResultsPage_ng_template_38_Conditional_3_Template, 2, 1, "p", 192);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const texto_r76 = ctx.texto;
    const titulo_r77 = ctx.titulo;
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(titulo_r77 || "Notas");
    \u0275\u0275advance();
    \u0275\u0275conditional(texto_r76 ? 3 : -1);
  }
}
function ResultsPage_ng_template_40_For_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "i");
  }
  if (rf & 2) {
    const i_r78 = ctx.$implicit;
    const n_r79 = \u0275\u0275nextContext().n;
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275classProp("on", n_r79 !== null && i_r78 <= ctx_r0.circuloMarcadoTazas(n_r79));
  }
}
function ResultsPage_ng_template_40_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 193);
    \u0275\u0275repeaterCreate(1, ResultsPage_ng_template_40_For_2_Template, 1, 2, "i", 194, \u0275\u0275repeaterTrackByIdentity);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    \u0275\u0275advance();
    \u0275\u0275repeater(\u0275\u0275pureFunction0(0, _c11));
  }
}
function ResultsPage_Conditional_42_Conditional_2_Conditional_28_For_5_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "li")(1, "i");
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
    \u0275\u0275text(3);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const l_r80 = ctx.$implicit;
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(l_r80.n);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(l_r80.etiqueta.toUpperCase());
  }
}
function ResultsPage_Conditional_42_Conditional_2_Conditional_28_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 203)(1, "p");
    \u0275\u0275text(2, "IMPRESI\xD3N DE CALIDAD");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "ol");
    \u0275\u0275repeaterCreate(4, ResultsPage_Conditional_42_Conditional_2_Conditional_28_For_5_Template, 4, 2, "li", null, _forTrack9);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext(3);
    \u0275\u0275advance(4);
    \u0275\u0275repeater(ctx_r0.LEYENDA_HEDONICA);
  }
}
function ResultsPage_Conditional_42_Conditional_2_Conditional_29_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 206)(1, "strong");
    \u0275\u0275text(2);
    \u0275\u0275pipe(3, "number");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "span");
    \u0275\u0275text(5, "Puntaje panel");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(6, "div", 206)(7, "strong");
    \u0275\u0275text(8);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(9, "span");
    \u0275\u0275text(10, "Clasificaci\xF3n");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const rp_r81 = \u0275\u0275nextContext();
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind2(3, 2, rp_r81.puntaje, "1.2-2"));
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate(rp_r81.clasificacion);
  }
}
function ResultsPage_Conditional_42_Conditional_2_Conditional_29_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 206)(1, "strong");
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "span");
    \u0275\u0275text(4, "M\xEDn \u2013 M\xE1x");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const rp_r81 = \u0275\u0275nextContext();
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(rp_r81.minMax);
  }
}
function ResultsPage_Conditional_42_Conditional_2_Conditional_29_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "section", 204);
    \u0275\u0275conditionalCreate(1, ResultsPage_Conditional_42_Conditional_2_Conditional_29_Conditional_1_Template, 11, 5);
    \u0275\u0275elementStart(2, "div", 206)(3, "strong");
    \u0275\u0275text(4);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "span");
    \u0275\u0275text(6, "Fichas");
    \u0275\u0275elementEnd()();
    \u0275\u0275conditionalCreate(7, ResultsPage_Conditional_42_Conditional_2_Conditional_29_Conditional_7_Template, 5, 1, "div", 206);
    \u0275\u0275elementStart(8, "p", 207);
    \u0275\u0275text(9);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const rp_r81 = ctx;
    \u0275\u0275advance();
    \u0275\u0275conditional(rp_r81.puntaje !== null ? 1 : -1);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(rp_r81.fichas);
    \u0275\u0275advance(3);
    \u0275\u0275conditional(rp_r81.puntaje !== null ? 7 : -1);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1(" ", rp_r81.recortado ? "Promedio recortado SCA (se descartan m\xE1ximo y m\xEDnimo)." : "Promedio simple de las fichas seleccionadas.", " Intensidades: promedio \xB7 Casillas: mayor\xEDa (> 50 %) \xB7 C\xEDrculos: entero m\xE1s cercano al promedio. ");
  }
}
function ResultsPage_Conditional_42_Conditional_2_Conditional_30_ng_container_13_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_Conditional_42_Conditional_2_Conditional_30_ng_container_14_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_Conditional_42_Conditional_2_Conditional_30_ng_container_16_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_Conditional_42_Conditional_2_Conditional_30_ng_container_17_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_Conditional_42_Conditional_2_Conditional_30_ng_container_20_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_Conditional_42_Conditional_2_Conditional_30_ng_container_21_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_Conditional_42_Conditional_2_Conditional_30_ng_container_23_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_Conditional_42_Conditional_2_Conditional_30_ng_container_25_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_Conditional_42_Conditional_2_Conditional_30_ng_container_26_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_Conditional_42_Conditional_2_Conditional_30_ng_container_28_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_Conditional_42_Conditional_2_Conditional_30_ng_container_29_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_Conditional_42_Conditional_2_Conditional_30_ng_container_32_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_Conditional_42_Conditional_2_Conditional_30_ng_container_33_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_Conditional_42_Conditional_2_Conditional_30_ng_container_34_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_Conditional_42_Conditional_2_Conditional_30_ng_container_36_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_Conditional_42_Conditional_2_Conditional_30_ng_container_38_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_Conditional_42_Conditional_2_Conditional_30_ng_container_40_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_Conditional_42_Conditional_2_Conditional_30_ng_container_42_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_Conditional_42_Conditional_2_Conditional_30_ng_container_44_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_Conditional_42_Conditional_2_Conditional_30_ng_container_46_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_Conditional_42_Conditional_2_Conditional_30_ng_container_48_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_Conditional_42_Conditional_2_Conditional_30_ng_container_50_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_Conditional_42_Conditional_2_Conditional_30_ng_container_52_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_Conditional_42_Conditional_2_Conditional_30_ng_container_54_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_Conditional_42_Conditional_2_Conditional_30_ng_container_56_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_Conditional_42_Conditional_2_Conditional_30_ng_container_59_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_Conditional_42_Conditional_2_Conditional_30_ng_container_60_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_Conditional_42_Conditional_2_Conditional_30_ng_container_62_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_Conditional_42_Conditional_2_Conditional_30_ng_container_72_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_Conditional_42_Conditional_2_Conditional_30_ng_container_73_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_Conditional_42_Conditional_2_Conditional_30_ng_container_80_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_Conditional_42_Conditional_2_Conditional_30_ng_container_84_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_Conditional_42_Conditional_2_Conditional_30_For_90_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_Conditional_42_Conditional_2_Conditional_30_For_90_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275template(0, ResultsPage_Conditional_42_Conditional_2_Conditional_30_For_90_ng_container_0_Template, 1, 0, "ng-container", 60);
  }
  if (rf & 2) {
    const d_r82 = ctx.$implicit;
    const h_r83 = \u0275\u0275nextContext(2);
    \u0275\u0275nextContext(2);
    const scaCasilla_r70 = \u0275\u0275reference(31);
    \u0275\u0275property("ngTemplateOutlet", scaCasilla_r70)("ngTemplateOutletContext", \u0275\u0275pureFunction2(2, _c9, h_r83.ficha.defectos.has(d_r82.clave), d_r82.etiqueta.toUpperCase()));
  }
}
function ResultsPage_Conditional_42_Conditional_2_Conditional_30_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 208)(1, "div", 209)(2, "span", 210);
    \u0275\u0275text(3, "PARTE 1: EVALUACI\xD3N DESCRIPTIVA");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "span", 210);
    \u0275\u0275text(5, "NIVEL DE TUESTE");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "span", 211)(7, "em");
    \u0275\u0275text(8);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(9, "span", 212);
    \u0275\u0275text(10, "PARTE 2: EVALUACI\xD3N AFECTIVA");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(11, "div", 213)(12, "div", 214);
    \u0275\u0275template(13, ResultsPage_Conditional_42_Conditional_2_Conditional_30_ng_container_13_Template, 1, 0, "ng-container", 60)(14, ResultsPage_Conditional_42_Conditional_2_Conditional_30_ng_container_14_Template, 1, 0, "ng-container", 60);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(15, "div", 215);
    \u0275\u0275template(16, ResultsPage_Conditional_42_Conditional_2_Conditional_30_ng_container_16_Template, 1, 0, "ng-container", 60)(17, ResultsPage_Conditional_42_Conditional_2_Conditional_30_ng_container_17_Template, 1, 0, "ng-container", 60);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(18, "div", 216)(19, "div", 217);
    \u0275\u0275template(20, ResultsPage_Conditional_42_Conditional_2_Conditional_30_ng_container_20_Template, 1, 0, "ng-container", 60);
    \u0275\u0275elementEnd();
    \u0275\u0275template(21, ResultsPage_Conditional_42_Conditional_2_Conditional_30_ng_container_21_Template, 1, 0, "ng-container", 60);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(22, "div", 218);
    \u0275\u0275template(23, ResultsPage_Conditional_42_Conditional_2_Conditional_30_ng_container_23_Template, 1, 0, "ng-container", 60);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(24, "div", 214);
    \u0275\u0275template(25, ResultsPage_Conditional_42_Conditional_2_Conditional_30_ng_container_25_Template, 1, 0, "ng-container", 60)(26, ResultsPage_Conditional_42_Conditional_2_Conditional_30_ng_container_26_Template, 1, 0, "ng-container", 60);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(27, "div", 215);
    \u0275\u0275template(28, ResultsPage_Conditional_42_Conditional_2_Conditional_30_ng_container_28_Template, 1, 0, "ng-container", 60)(29, ResultsPage_Conditional_42_Conditional_2_Conditional_30_ng_container_29_Template, 1, 0, "ng-container", 60);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(30, "div", 219)(31, "div", 217);
    \u0275\u0275template(32, ResultsPage_Conditional_42_Conditional_2_Conditional_30_ng_container_32_Template, 1, 0, "ng-container", 60)(33, ResultsPage_Conditional_42_Conditional_2_Conditional_30_ng_container_33_Template, 1, 0, "ng-container", 60);
    \u0275\u0275elementEnd();
    \u0275\u0275template(34, ResultsPage_Conditional_42_Conditional_2_Conditional_30_ng_container_34_Template, 1, 0, "ng-container", 60);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(35, "div", 218);
    \u0275\u0275template(36, ResultsPage_Conditional_42_Conditional_2_Conditional_30_ng_container_36_Template, 1, 0, "ng-container", 60);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(37, "div", 220);
    \u0275\u0275template(38, ResultsPage_Conditional_42_Conditional_2_Conditional_30_ng_container_38_Template, 1, 0, "ng-container", 60);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(39, "div", 215);
    \u0275\u0275template(40, ResultsPage_Conditional_42_Conditional_2_Conditional_30_ng_container_40_Template, 1, 0, "ng-container", 60);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(41, "div", 221);
    \u0275\u0275template(42, ResultsPage_Conditional_42_Conditional_2_Conditional_30_ng_container_42_Template, 1, 0, "ng-container", 60);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(43, "div", 222);
    \u0275\u0275template(44, ResultsPage_Conditional_42_Conditional_2_Conditional_30_ng_container_44_Template, 1, 0, "ng-container", 60);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(45, "div", 220);
    \u0275\u0275template(46, ResultsPage_Conditional_42_Conditional_2_Conditional_30_ng_container_46_Template, 1, 0, "ng-container", 60);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(47, "div", 215);
    \u0275\u0275template(48, ResultsPage_Conditional_42_Conditional_2_Conditional_30_ng_container_48_Template, 1, 0, "ng-container", 60);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(49, "div", 221);
    \u0275\u0275template(50, ResultsPage_Conditional_42_Conditional_2_Conditional_30_ng_container_50_Template, 1, 0, "ng-container", 60);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(51, "div", 222);
    \u0275\u0275template(52, ResultsPage_Conditional_42_Conditional_2_Conditional_30_ng_container_52_Template, 1, 0, "ng-container", 60);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(53, "div", 220);
    \u0275\u0275template(54, ResultsPage_Conditional_42_Conditional_2_Conditional_30_ng_container_54_Template, 1, 0, "ng-container", 60);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(55, "div", 215);
    \u0275\u0275template(56, ResultsPage_Conditional_42_Conditional_2_Conditional_30_ng_container_56_Template, 1, 0, "ng-container", 60);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(57, "div", 223)(58, "div", 217);
    \u0275\u0275template(59, ResultsPage_Conditional_42_Conditional_2_Conditional_30_ng_container_59_Template, 1, 0, "ng-container", 60);
    \u0275\u0275elementEnd();
    \u0275\u0275template(60, ResultsPage_Conditional_42_Conditional_2_Conditional_30_ng_container_60_Template, 1, 0, "ng-container", 60);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(61, "div", 224);
    \u0275\u0275template(62, ResultsPage_Conditional_42_Conditional_2_Conditional_30_ng_container_62_Template, 1, 0, "ng-container", 60);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(63, "div", 225)(64, "span", 226);
    \u0275\u0275text(65, "OTRAS NOTAS");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(66, "p", 192);
    \u0275\u0275text(67);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(68, "div", 227)(69, "div", 228)(70, "b", 229);
    \u0275\u0275text(71, "Impresi\xF3n global");
    \u0275\u0275elementEnd();
    \u0275\u0275template(72, ResultsPage_Conditional_42_Conditional_2_Conditional_30_ng_container_72_Template, 1, 0, "ng-container", 60);
    \u0275\u0275elementEnd();
    \u0275\u0275template(73, ResultsPage_Conditional_42_Conditional_2_Conditional_30_ng_container_73_Template, 1, 0, "ng-container", 60);
    \u0275\u0275pipe(74, "number");
    \u0275\u0275elementStart(75, "div", 230)(76, "div", 231)(77, "div")(78, "b");
    \u0275\u0275text(79, "TAZAS NO UNIFORMES");
    \u0275\u0275elementEnd();
    \u0275\u0275template(80, ResultsPage_Conditional_42_Conditional_2_Conditional_30_ng_container_80_Template, 1, 0, "ng-container", 60);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(81, "div")(82, "b");
    \u0275\u0275text(83, "TAZAS DEFECTUOSAS");
    \u0275\u0275elementEnd();
    \u0275\u0275template(84, ResultsPage_Conditional_42_Conditional_2_Conditional_30_ng_container_84_Template, 1, 0, "ng-container", 60);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(85, "div", 232)(86, "b");
    \u0275\u0275text(87, "DEFECTO (DE HABERLO)");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(88, "div");
    \u0275\u0275repeaterCreate(89, ResultsPage_Conditional_42_Conditional_2_Conditional_30_For_90_Template, 1, 5, "ng-container", null, _forTrack3);
    \u0275\u0275elementEnd()()()()();
  }
  if (rf & 2) {
    const h_r83 = \u0275\u0275nextContext();
    const ctx_r0 = \u0275\u0275nextContext(2);
    const scaSlider_r84 = \u0275\u0275reference(27);
    const scaCirculos_r85 = \u0275\u0275reference(29);
    const scaDescriptores_r86 = \u0275\u0275reference(33);
    const scaGustos_r87 = \u0275\u0275reference(35);
    const scaBoca_r88 = \u0275\u0275reference(37);
    const scaNotas_r89 = \u0275\u0275reference(39);
    const scaTazas_r90 = \u0275\u0275reference(41);
    \u0275\u0275advance(8);
    \u0275\u0275textInterpolate(h_r83.nivelTueste || "");
    \u0275\u0275advance(5);
    \u0275\u0275property("ngTemplateOutlet", scaSlider_r84)("ngTemplateOutletContext", \u0275\u0275pureFunction1(69, _c12, h_r83.ficha.intensidad.fragancia));
    \u0275\u0275advance();
    \u0275\u0275property("ngTemplateOutlet", scaSlider_r84)("ngTemplateOutletContext", \u0275\u0275pureFunction1(71, _c13, h_r83.ficha.intensidad.aroma));
    \u0275\u0275advance(2);
    \u0275\u0275property("ngTemplateOutlet", scaCirculos_r85)("ngTemplateOutletContext", \u0275\u0275pureFunction1(73, _c14, h_r83.ficha.calidad.fragancia));
    \u0275\u0275advance();
    \u0275\u0275property("ngTemplateOutlet", scaCirculos_r85)("ngTemplateOutletContext", \u0275\u0275pureFunction1(75, _c14, h_r83.ficha.calidad.aroma));
    \u0275\u0275advance(3);
    \u0275\u0275property("ngTemplateOutlet", scaDescriptores_r86)("ngTemplateOutletContext", \u0275\u0275pureFunction1(77, _c15, h_r83.ficha.olfativo));
    \u0275\u0275advance();
    \u0275\u0275property("ngTemplateOutlet", scaNotas_r89)("ngTemplateOutletContext", \u0275\u0275pureFunction1(79, _c16, h_r83.ficha.notas.olfativo));
    \u0275\u0275advance(2);
    \u0275\u0275property("ngTemplateOutlet", scaNotas_r89)("ngTemplateOutletContext", \u0275\u0275pureFunction1(82, _c16, ctx_r0.etiquetasAfectivas(h_r83, \u0275\u0275pureFunction0(81, _c17))));
    \u0275\u0275advance(2);
    \u0275\u0275property("ngTemplateOutlet", scaSlider_r84)("ngTemplateOutletContext", \u0275\u0275pureFunction1(84, _c18, h_r83.ficha.intensidad.sabor));
    \u0275\u0275advance();
    \u0275\u0275property("ngTemplateOutlet", scaSlider_r84)("ngTemplateOutletContext", \u0275\u0275pureFunction1(86, _c19, h_r83.ficha.intensidad.sabor_residual));
    \u0275\u0275advance(2);
    \u0275\u0275property("ngTemplateOutlet", scaCirculos_r85)("ngTemplateOutletContext", \u0275\u0275pureFunction1(88, _c14, h_r83.ficha.calidad.sabor));
    \u0275\u0275advance();
    \u0275\u0275property("ngTemplateOutlet", scaCirculos_r85)("ngTemplateOutletContext", \u0275\u0275pureFunction1(90, _c14, h_r83.ficha.calidad.sabor_residual));
    \u0275\u0275advance(3);
    \u0275\u0275property("ngTemplateOutlet", scaDescriptores_r86)("ngTemplateOutletContext", \u0275\u0275pureFunction1(92, _c15, h_r83.ficha.gustativo));
    \u0275\u0275advance();
    \u0275\u0275property("ngTemplateOutlet", scaGustos_r87)("ngTemplateOutletContext", \u0275\u0275pureFunction1(94, _c15, h_r83.ficha.gustos));
    \u0275\u0275advance();
    \u0275\u0275property("ngTemplateOutlet", scaNotas_r89)("ngTemplateOutletContext", \u0275\u0275pureFunction1(96, _c16, h_r83.ficha.notas.gustativo));
    \u0275\u0275advance(2);
    \u0275\u0275property("ngTemplateOutlet", scaNotas_r89)("ngTemplateOutletContext", \u0275\u0275pureFunction1(99, _c16, ctx_r0.etiquetasAfectivas(h_r83, \u0275\u0275pureFunction0(98, _c20))));
    \u0275\u0275advance(2);
    \u0275\u0275property("ngTemplateOutlet", scaSlider_r84)("ngTemplateOutletContext", \u0275\u0275pureFunction1(101, _c21, h_r83.ficha.intensidad.acidez));
    \u0275\u0275advance(2);
    \u0275\u0275property("ngTemplateOutlet", scaCirculos_r85)("ngTemplateOutletContext", \u0275\u0275pureFunction1(103, _c14, h_r83.ficha.calidad.acidez));
    \u0275\u0275advance(2);
    \u0275\u0275property("ngTemplateOutlet", scaNotas_r89)("ngTemplateOutletContext", \u0275\u0275pureFunction1(105, _c16, h_r83.ficha.notas.acidez));
    \u0275\u0275advance(2);
    \u0275\u0275property("ngTemplateOutlet", scaNotas_r89)("ngTemplateOutletContext", \u0275\u0275pureFunction1(108, _c16, ctx_r0.etiquetasAfectivas(h_r83, \u0275\u0275pureFunction0(107, _c22))));
    \u0275\u0275advance(2);
    \u0275\u0275property("ngTemplateOutlet", scaSlider_r84)("ngTemplateOutletContext", \u0275\u0275pureFunction1(110, _c23, h_r83.ficha.intensidad.dulzor));
    \u0275\u0275advance(2);
    \u0275\u0275property("ngTemplateOutlet", scaCirculos_r85)("ngTemplateOutletContext", \u0275\u0275pureFunction1(112, _c14, h_r83.ficha.calidad.dulzor));
    \u0275\u0275advance(2);
    \u0275\u0275property("ngTemplateOutlet", scaNotas_r89)("ngTemplateOutletContext", \u0275\u0275pureFunction1(114, _c16, h_r83.ficha.notas.dulzor));
    \u0275\u0275advance(2);
    \u0275\u0275property("ngTemplateOutlet", scaNotas_r89)("ngTemplateOutletContext", \u0275\u0275pureFunction1(117, _c16, ctx_r0.etiquetasAfectivas(h_r83, \u0275\u0275pureFunction0(116, _c24))));
    \u0275\u0275advance(2);
    \u0275\u0275property("ngTemplateOutlet", scaSlider_r84)("ngTemplateOutletContext", \u0275\u0275pureFunction1(119, _c25, h_r83.ficha.intensidad.sensacion_boca));
    \u0275\u0275advance(2);
    \u0275\u0275property("ngTemplateOutlet", scaCirculos_r85)("ngTemplateOutletContext", \u0275\u0275pureFunction1(121, _c14, h_r83.ficha.calidad.sensacion_boca));
    \u0275\u0275advance(3);
    \u0275\u0275property("ngTemplateOutlet", scaBoca_r88)("ngTemplateOutletContext", \u0275\u0275pureFunction1(123, _c15, h_r83.ficha.boca));
    \u0275\u0275advance();
    \u0275\u0275property("ngTemplateOutlet", scaNotas_r89)("ngTemplateOutletContext", \u0275\u0275pureFunction1(125, _c16, h_r83.ficha.notas.boca));
    \u0275\u0275advance(2);
    \u0275\u0275property("ngTemplateOutlet", scaNotas_r89)("ngTemplateOutletContext", \u0275\u0275pureFunction1(128, _c16, ctx_r0.etiquetasAfectivas(h_r83, \u0275\u0275pureFunction0(127, _c26))));
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(h_r83.ficha.notas.otras);
    \u0275\u0275advance(5);
    \u0275\u0275property("ngTemplateOutlet", scaCirculos_r85)("ngTemplateOutletContext", \u0275\u0275pureFunction1(130, _c14, h_r83.ficha.impresionGlobal));
    \u0275\u0275advance();
    \u0275\u0275property("ngTemplateOutlet", scaNotas_r89)("ngTemplateOutletContext", \u0275\u0275pureFunction1(132, _c16, h_r83.ficha.puntaje !== null ? "Puntaje CVA: " + \u0275\u0275pipeBind2(74, 66, h_r83.ficha.puntaje, "1.2-2") + " \xB7 " + ctx_r0.etiquetaCalidad(h_r83.ficha.impresionGlobal) : ctx_r0.etiquetaCalidad(h_r83.ficha.impresionGlobal)));
    \u0275\u0275advance(7);
    \u0275\u0275property("ngTemplateOutlet", scaTazas_r90)("ngTemplateOutletContext", \u0275\u0275pureFunction1(134, _c27, h_r83.ficha.tazasNoUniformes));
    \u0275\u0275advance(4);
    \u0275\u0275property("ngTemplateOutlet", scaTazas_r90)("ngTemplateOutletContext", \u0275\u0275pureFunction1(136, _c27, h_r83.ficha.tazasDefectuosas));
    \u0275\u0275advance(5);
    \u0275\u0275repeater(ctx_r0.defectosSca);
  }
}
function ResultsPage_Conditional_42_Conditional_2_Conditional_31_ng_container_12_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_Conditional_42_Conditional_2_Conditional_31_ng_container_13_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_Conditional_42_Conditional_2_Conditional_31_ng_container_15_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_Conditional_42_Conditional_2_Conditional_31_ng_container_17_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_Conditional_42_Conditional_2_Conditional_31_ng_container_19_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_Conditional_42_Conditional_2_Conditional_31_ng_container_20_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_Conditional_42_Conditional_2_Conditional_31_ng_container_22_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_Conditional_42_Conditional_2_Conditional_31_ng_container_25_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_Conditional_42_Conditional_2_Conditional_31_ng_container_26_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_Conditional_42_Conditional_2_Conditional_31_ng_container_28_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_Conditional_42_Conditional_2_Conditional_31_ng_container_30_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_Conditional_42_Conditional_2_Conditional_31_ng_container_32_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_Conditional_42_Conditional_2_Conditional_31_ng_container_34_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_Conditional_42_Conditional_2_Conditional_31_ng_container_36_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_Conditional_42_Conditional_2_Conditional_31_ng_container_38_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_Conditional_42_Conditional_2_Conditional_31_ng_container_40_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_Conditional_42_Conditional_2_Conditional_31_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 233)(1, "span", 234);
    \u0275\u0275text(2, "N\xBA DE MUESTRA ");
    \u0275\u0275elementStart(3, "em");
    \u0275\u0275text(4);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(5, "span", 210);
    \u0275\u0275text(6, "NIVEL DE TUESTE");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "span", 211)(8, "em");
    \u0275\u0275text(9);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(10, "div", 235)(11, "div", 214);
    \u0275\u0275template(12, ResultsPage_Conditional_42_Conditional_2_Conditional_31_ng_container_12_Template, 1, 0, "ng-container", 60)(13, ResultsPage_Conditional_42_Conditional_2_Conditional_31_ng_container_13_Template, 1, 0, "ng-container", 60);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(14, "div", 236);
    \u0275\u0275template(15, ResultsPage_Conditional_42_Conditional_2_Conditional_31_ng_container_15_Template, 1, 0, "ng-container", 60);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(16, "div", 237);
    \u0275\u0275template(17, ResultsPage_Conditional_42_Conditional_2_Conditional_31_ng_container_17_Template, 1, 0, "ng-container", 60);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(18, "div", 214);
    \u0275\u0275template(19, ResultsPage_Conditional_42_Conditional_2_Conditional_31_ng_container_19_Template, 1, 0, "ng-container", 60)(20, ResultsPage_Conditional_42_Conditional_2_Conditional_31_ng_container_20_Template, 1, 0, "ng-container", 60);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(21, "div", 236);
    \u0275\u0275template(22, ResultsPage_Conditional_42_Conditional_2_Conditional_31_ng_container_22_Template, 1, 0, "ng-container", 60);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(23, "div", 238)(24, "div", 239);
    \u0275\u0275template(25, ResultsPage_Conditional_42_Conditional_2_Conditional_31_ng_container_25_Template, 1, 0, "ng-container", 60);
    \u0275\u0275elementEnd();
    \u0275\u0275template(26, ResultsPage_Conditional_42_Conditional_2_Conditional_31_ng_container_26_Template, 1, 0, "ng-container", 60);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(27, "div", 240);
    \u0275\u0275template(28, ResultsPage_Conditional_42_Conditional_2_Conditional_31_ng_container_28_Template, 1, 0, "ng-container", 60);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(29, "div", 241);
    \u0275\u0275template(30, ResultsPage_Conditional_42_Conditional_2_Conditional_31_ng_container_30_Template, 1, 0, "ng-container", 60);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(31, "div", 240);
    \u0275\u0275template(32, ResultsPage_Conditional_42_Conditional_2_Conditional_31_ng_container_32_Template, 1, 0, "ng-container", 60);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(33, "div", 241);
    \u0275\u0275template(34, ResultsPage_Conditional_42_Conditional_2_Conditional_31_ng_container_34_Template, 1, 0, "ng-container", 60);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(35, "div", 242);
    \u0275\u0275template(36, ResultsPage_Conditional_42_Conditional_2_Conditional_31_ng_container_36_Template, 1, 0, "ng-container", 60);
    \u0275\u0275elementStart(37, "div", 243);
    \u0275\u0275template(38, ResultsPage_Conditional_42_Conditional_2_Conditional_31_ng_container_38_Template, 1, 0, "ng-container", 60);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(39, "div", 218);
    \u0275\u0275template(40, ResultsPage_Conditional_42_Conditional_2_Conditional_31_ng_container_40_Template, 1, 0, "ng-container", 60);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(41, "div", 244)(42, "span", 226);
    \u0275\u0275text(43, "OTRAS NOTAS");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(44, "p", 192);
    \u0275\u0275text(45);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const h_r83 = \u0275\u0275nextContext();
    \u0275\u0275nextContext(2);
    const scaSlider_r84 = \u0275\u0275reference(27);
    const scaDescriptores_r86 = \u0275\u0275reference(33);
    const scaGustos_r87 = \u0275\u0275reference(35);
    const scaBoca_r88 = \u0275\u0275reference(37);
    const scaNotas_r89 = \u0275\u0275reference(39);
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(h_r83.numeroMuestra);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(h_r83.nivelTueste || "");
    \u0275\u0275advance(3);
    \u0275\u0275property("ngTemplateOutlet", scaSlider_r84)("ngTemplateOutletContext", \u0275\u0275pureFunction1(35, _c12, h_r83.ficha.intensidad.fragancia));
    \u0275\u0275advance();
    \u0275\u0275property("ngTemplateOutlet", scaSlider_r84)("ngTemplateOutletContext", \u0275\u0275pureFunction1(37, _c13, h_r83.ficha.intensidad.aroma));
    \u0275\u0275advance(2);
    \u0275\u0275property("ngTemplateOutlet", scaNotas_r89)("ngTemplateOutletContext", \u0275\u0275pureFunction1(39, _c16, h_r83.ficha.notas.olfativo));
    \u0275\u0275advance(2);
    \u0275\u0275property("ngTemplateOutlet", scaDescriptores_r86)("ngTemplateOutletContext", \u0275\u0275pureFunction1(41, _c15, h_r83.ficha.olfativo));
    \u0275\u0275advance(2);
    \u0275\u0275property("ngTemplateOutlet", scaSlider_r84)("ngTemplateOutletContext", \u0275\u0275pureFunction1(43, _c18, h_r83.ficha.intensidad.sabor));
    \u0275\u0275advance();
    \u0275\u0275property("ngTemplateOutlet", scaSlider_r84)("ngTemplateOutletContext", \u0275\u0275pureFunction1(45, _c19, h_r83.ficha.intensidad.sabor_residual));
    \u0275\u0275advance(2);
    \u0275\u0275property("ngTemplateOutlet", scaNotas_r89)("ngTemplateOutletContext", \u0275\u0275pureFunction1(47, _c16, h_r83.ficha.notas.gustativo));
    \u0275\u0275advance(3);
    \u0275\u0275property("ngTemplateOutlet", scaDescriptores_r86)("ngTemplateOutletContext", \u0275\u0275pureFunction1(49, _c15, h_r83.ficha.gustativo));
    \u0275\u0275advance();
    \u0275\u0275property("ngTemplateOutlet", scaGustos_r87)("ngTemplateOutletContext", \u0275\u0275pureFunction1(51, _c15, h_r83.ficha.gustos));
    \u0275\u0275advance(2);
    \u0275\u0275property("ngTemplateOutlet", scaSlider_r84)("ngTemplateOutletContext", \u0275\u0275pureFunction1(53, _c21, h_r83.ficha.intensidad.acidez));
    \u0275\u0275advance(2);
    \u0275\u0275property("ngTemplateOutlet", scaNotas_r89)("ngTemplateOutletContext", \u0275\u0275pureFunction1(55, _c16, h_r83.ficha.notas.acidez));
    \u0275\u0275advance(2);
    \u0275\u0275property("ngTemplateOutlet", scaSlider_r84)("ngTemplateOutletContext", \u0275\u0275pureFunction1(57, _c23, h_r83.ficha.intensidad.dulzor));
    \u0275\u0275advance(2);
    \u0275\u0275property("ngTemplateOutlet", scaNotas_r89)("ngTemplateOutletContext", \u0275\u0275pureFunction1(59, _c16, h_r83.ficha.notas.dulzor));
    \u0275\u0275advance(2);
    \u0275\u0275property("ngTemplateOutlet", scaSlider_r84)("ngTemplateOutletContext", \u0275\u0275pureFunction1(61, _c25, h_r83.ficha.intensidad.sensacion_boca));
    \u0275\u0275advance(2);
    \u0275\u0275property("ngTemplateOutlet", scaBoca_r88)("ngTemplateOutletContext", \u0275\u0275pureFunction1(63, _c15, h_r83.ficha.boca));
    \u0275\u0275advance(2);
    \u0275\u0275property("ngTemplateOutlet", scaNotas_r89)("ngTemplateOutletContext", \u0275\u0275pureFunction1(65, _c16, h_r83.ficha.notas.boca));
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(h_r83.ficha.notas.otras);
  }
}
function ResultsPage_Conditional_42_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "article", 196)(1, "header", 197)(2, "div", 198)(3, "p", 199);
    \u0275\u0275text(4, "PacamaraQs \xB7 Evaluaci\xF3n sensorial CVA");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "h1");
    \u0275\u0275text(6);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "div", 200)(8, "div", 201)(9, "span");
    \u0275\u0275text(10, "Nombre");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(11, "b");
    \u0275\u0275text(12);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(13, "div", 202)(14, "span");
    \u0275\u0275text(15, "Fecha");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(16, "b");
    \u0275\u0275text(17);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(18, "div", 201)(19, "span");
    \u0275\u0275text(20, "Objetivo");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(21, "b");
    \u0275\u0275text(22);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(23, "div", 202)(24, "span");
    \u0275\u0275text(25, "N\xBA de muestra");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(26, "b");
    \u0275\u0275text(27);
    \u0275\u0275elementEnd()()()();
    \u0275\u0275conditionalCreate(28, ResultsPage_Conditional_42_Conditional_2_Conditional_28_Template, 6, 0, "div", 203);
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(29, ResultsPage_Conditional_42_Conditional_2_Conditional_29_Template, 10, 4, "section", 204);
    \u0275\u0275conditionalCreate(30, ResultsPage_Conditional_42_Conditional_2_Conditional_30_Template, 91, 138)(31, ResultsPage_Conditional_42_Conditional_2_Conditional_31_Template, 46, 67);
    \u0275\u0275elementStart(32, "footer", 205);
    \u0275\u0275text(33, " Formato modificado para PacamaraQs, basado en el Sistema de Evaluaci\xF3n del Caf\xE9 de la SCA (Versi\xF3n 2, junio 2024). No es un documento oficial de la SCA. ");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    let tmp_24_0;
    const h_r83 = ctx;
    \u0275\u0275classProp("sca-page--combinado", h_r83.formato === "combinado");
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate(h_r83.titulo);
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate(h_r83.nombre);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(h_r83.fecha);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(h_r83.objetivo);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(h_r83.numeroMuestra);
    \u0275\u0275advance();
    \u0275\u0275conditional(h_r83.formato === "combinado" ? 28 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional((tmp_24_0 = h_r83.resumenPanel) ? 29 : -1, tmp_24_0);
    \u0275\u0275advance();
    \u0275\u0275conditional(h_r83.formato === "combinado" ? 30 : 31);
  }
}
function ResultsPage_Conditional_42_Conditional_3_Conditional_13_For_18_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "tr")(1, "td");
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "td");
    \u0275\u0275text(4);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "td", 252);
    \u0275\u0275text(6);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "td", 254);
    \u0275\u0275text(8);
    \u0275\u0275pipe(9, "number");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(10, "td");
    \u0275\u0275text(11);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const f_r91 = ctx.$implicit;
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(f_r91.posicion || "\u2014");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1("Muestra ", f_r91.numeroMuestra);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(f_r91.totalVotos);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(f_r91.promedio === null ? "\u2014" : \u0275\u0275pipeBind2(9, 5, f_r91.promedio, "1.2-2"));
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(f_r91.etiqueta);
  }
}
function ResultsPage_Conditional_42_Conditional_3_Conditional_13_For_21_For_6_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "tr")(1, "td", 256);
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "td", 257);
    \u0275\u0275text(4);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "td")(6, "div", 258);
    \u0275\u0275element(7, "i");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(8, "td", 259);
    \u0275\u0275text(9);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const d_r92 = ctx.$implicit;
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(d_r92.valor);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(d_r92.etiqueta);
    \u0275\u0275advance(3);
    \u0275\u0275styleProp("width", d_r92.porcentaje, "%");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(d_r92.votos);
  }
}
function ResultsPage_Conditional_42_Conditional_3_Conditional_13_For_21_For_16_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "tr")(1, "td");
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "td", 252);
    \u0275\u0275text(4);
    \u0275\u0275pipe(5, "number");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const a_r93 = ctx.$implicit;
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(a_r93.etiqueta);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(a_r93.valor === null ? "\u2014" : \u0275\u0275pipeBind2(5, 2, a_r93.valor, "1.1-1"));
  }
}
function ResultsPage_Conditional_42_Conditional_3_Conditional_13_For_21_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "section", 251)(1, "h2");
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "table")(4, "tbody");
    \u0275\u0275repeaterCreate(5, ResultsPage_Conditional_42_Conditional_3_Conditional_13_For_21_For_6_Template, 10, 5, "tr", null, _forTrack4);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(7, "table", 255)(8, "thead")(9, "tr")(10, "th");
    \u0275\u0275text(11, "Atributo");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(12, "th", 252);
    \u0275\u0275text(13, "Calidad (1\u20139)");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(14, "tbody");
    \u0275\u0275repeaterCreate(15, ResultsPage_Conditional_42_Conditional_3_Conditional_13_For_21_For_16_Template, 6, 5, "tr", null, _forTrack3);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const f_r94 = ctx.$implicit;
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1("Muestra ", f_r94.numeroMuestra, " \xB7 distribuci\xF3n de votos");
    \u0275\u0275advance(3);
    \u0275\u0275repeater(f_r94.distribucion);
    \u0275\u0275advance(10);
    \u0275\u0275repeater(f_r94.atributos);
  }
}
function ResultsPage_Conditional_42_Conditional_3_Conditional_13_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "section", 251)(1, "h2");
    \u0275\u0275text(2, "Promedio hed\xF3nico por muestra (escala 1\u20139)");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "table")(4, "thead")(5, "tr")(6, "th");
    \u0275\u0275text(7, "#");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "th");
    \u0275\u0275text(9, "Muestra");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(10, "th", 252);
    \u0275\u0275text(11, "Votos");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(12, "th", 252);
    \u0275\u0275text(13, "Promedio");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(14, "th");
    \u0275\u0275text(15, "Valoraci\xF3n");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(16, "tbody");
    \u0275\u0275repeaterCreate(17, ResultsPage_Conditional_42_Conditional_3_Conditional_13_For_18_Template, 12, 8, "tr", null, _forTrack2);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(19, "div", 253);
    \u0275\u0275repeaterCreate(20, ResultsPage_Conditional_42_Conditional_3_Conditional_13_For_21_Template, 17, 1, "section", 251, _forTrack2);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext(3);
    \u0275\u0275advance(17);
    \u0275\u0275repeater(ctx_r0.resultadosHedonicos());
    \u0275\u0275advance(3);
    \u0275\u0275repeater(ctx_r0.resultadosHedonicos());
  }
}
function ResultsPage_Conditional_42_Conditional_3_Conditional_14_For_1_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275text(0);
  }
  if (rf & 2) {
    const ficha_r95 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275textInterpolate1(" \xB7 registrada por ", ficha_r95.registradaPor, " ");
  }
}
function ResultsPage_Conditional_42_Conditional_3_Conditional_14_For_1_For_7_For_5_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "dt");
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(2, "dd");
    \u0275\u0275text(3);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const campo_r96 = ctx.$implicit;
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(campo_r96.etiqueta);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(campo_r96.valor);
  }
}
function ResultsPage_Conditional_42_Conditional_3_Conditional_14_For_1_For_7_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "section", 251)(1, "h2");
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "dl", 263);
    \u0275\u0275repeaterCreate(4, ResultsPage_Conditional_42_Conditional_3_Conditional_14_For_1_For_7_For_5_Template, 4, 2, null, null, _forTrack7);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const seccion_r97 = ctx.$implicit;
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(seccion_r97.titulo);
    \u0275\u0275advance(2);
    \u0275\u0275repeater(seccion_r97.campos);
  }
}
function ResultsPage_Conditional_42_Conditional_3_Conditional_14_For_1_Conditional_11_For_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span");
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const c_r98 = ctx.$implicit;
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(c_r98);
  }
}
function ResultsPage_Conditional_42_Conditional_3_Conditional_14_For_1_Conditional_11_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 261);
    \u0275\u0275repeaterCreate(1, ResultsPage_Conditional_42_Conditional_3_Conditional_14_For_1_Conditional_11_For_2_Template, 2, 1, "span", null, \u0275\u0275repeaterTrackByIdentity);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ficha_r95 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275advance();
    \u0275\u0275repeater(ficha_r95.certificaciones);
  }
}
function ResultsPage_Conditional_42_Conditional_3_Conditional_14_For_1_Conditional_12_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 262);
    \u0275\u0275text(1, "Sin certificaciones registradas.");
    \u0275\u0275elementEnd();
  }
}
function ResultsPage_Conditional_42_Conditional_3_Conditional_14_For_1_Conditional_13_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "section", 251)(1, "h2");
    \u0275\u0275text(2, "Notas");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "p");
    \u0275\u0275text(4);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ficha_r95 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(ficha_r95.notas);
  }
}
function ResultsPage_Conditional_42_Conditional_3_Conditional_14_For_1_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "article")(1, "section", 251)(2, "h2");
    \u0275\u0275text(3);
    \u0275\u0275conditionalCreate(4, ResultsPage_Conditional_42_Conditional_3_Conditional_14_For_1_Conditional_4_Template, 1, 1);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(5, "div", 253);
    \u0275\u0275repeaterCreate(6, ResultsPage_Conditional_42_Conditional_3_Conditional_14_For_1_For_7_Template, 6, 1, "section", 251, _forTrack6);
    \u0275\u0275elementStart(8, "section", 251)(9, "h2");
    \u0275\u0275text(10, "Certificaciones");
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(11, ResultsPage_Conditional_42_Conditional_3_Conditional_14_For_1_Conditional_11_Template, 3, 0, "div", 261)(12, ResultsPage_Conditional_42_Conditional_3_Conditional_14_For_1_Conditional_12_Template, 2, 0, "p", 262);
    \u0275\u0275elementEnd()();
    \u0275\u0275conditionalCreate(13, ResultsPage_Conditional_42_Conditional_3_Conditional_14_For_1_Conditional_13_Template, 5, 1, "section", 251);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ficha_r95 = ctx.$implicit;
    const \u0275$index_1810_r99 = ctx.$index;
    \u0275\u0275classProp("rp-page-break", !(\u0275$index_1810_r99 === 0));
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate1("Muestra ", ficha_r95.numeroMuestra);
    \u0275\u0275advance();
    \u0275\u0275conditional(ficha_r95.registradaPor ? 4 : -1);
    \u0275\u0275advance(2);
    \u0275\u0275repeater(ficha_r95.secciones);
    \u0275\u0275advance(5);
    \u0275\u0275conditional(ficha_r95.certificaciones.length > 0 ? 11 : 12);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ficha_r95.notas ? 13 : -1);
  }
}
function ResultsPage_Conditional_42_Conditional_3_Conditional_14_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275repeaterCreate(0, ResultsPage_Conditional_42_Conditional_3_Conditional_14_For_1_Template, 14, 6, "article", 260, \u0275\u0275repeaterTrackByIndex);
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext(3);
    \u0275\u0275repeater(ctx_r0.fichasTecnicas());
  }
}
function ResultsPage_Conditional_42_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "header", 245)(1, "div")(2, "p", 246);
    \u0275\u0275text(3, "PacamaraQs \xB7 Evaluaci\xF3n sensorial SCA CVA");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "h1", 247);
    \u0275\u0275text(5);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "p", 248);
    \u0275\u0275text(7);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(8, "p", 249);
    \u0275\u0275text(9);
    \u0275\u0275pipe(10, "date");
    \u0275\u0275element(11, "br");
    \u0275\u0275text(12);
    \u0275\u0275elementEnd()();
    \u0275\u0275conditionalCreate(13, ResultsPage_Conditional_42_Conditional_3_Conditional_13_Template, 22, 0)(14, ResultsPage_Conditional_42_Conditional_3_Conditional_14_Template, 2, 0);
    \u0275\u0275elementStart(15, "p", 250);
    \u0275\u0275text(16, "Metodolog\xEDa SCA Coffee Value Assessment (CVA) \xB7 Documento generado por PacamaraQs.");
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const r_r100 = \u0275\u0275nextContext();
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(ctx_r0.esExtrinseco() ? "Ficha t\xE9cnica del caf\xE9" : "Reporte de cataci\xF3n");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate2("", r_r100.nombreSesion, " \xB7 Formato ", ctx_r0.tituloFormato());
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1("Generado: ", \u0275\u0275pipeBind2(10, 7, ctx_r0.fechaReporte(), "medium"));
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate2("", r_r100.totalMuestras, " muestra(s) \xB7 ", r_r100.catadores.length, " catador(es)");
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r0.esAfectivo() ? 13 : ctx_r0.esExtrinseco() ? 14 : -1);
  }
}
function ResultsPage_Conditional_42_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 27, 12);
    \u0275\u0275conditionalCreate(2, ResultsPage_Conditional_42_Conditional_2_Template, 34, 10, "article", 195)(3, ResultsPage_Conditional_42_Conditional_3_Template, 17, 10);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    let tmp_15_0;
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance(2);
    \u0275\u0275conditional((tmp_15_0 = ctx_r0.formatoHoja() && ctx_r0.hojaSca()) ? 2 : 3, tmp_15_0);
  }
}
var ATRIBUTOS_CVA = [
  { clave: "fragancia", etiqueta: "Fragancia" },
  { clave: "aroma", etiqueta: "Aroma" },
  { clave: "sabor", etiqueta: "Sabor" },
  { clave: "sabor_residual", etiqueta: "Sabor residual" },
  { clave: "acidez", etiqueta: "Acidez" },
  { clave: "dulzor", etiqueta: "Dulzor" },
  { clave: "sensacion_boca", etiqueta: "Sensaci\xF3n en boca" }
];
var ESCALA_HEDONICA_DESC = [9, 8, 7, 6, 5, 4, 3, 2, 1];
var INTENSIDAD_MAX = 15;
var HEDONICA_MAX = 9;
function clasificarPuntaje(puntaje) {
  if (puntaje >= 90)
    return { etiqueta: "Excepcional", color: "#15803d", fondo: "#f0fdf4" };
  if (puntaje >= 85)
    return { etiqueta: "Excelente", color: "#1d4ed8", fondo: "#eff6ff" };
  if (puntaje >= 80)
    return { etiqueta: "Muy bueno", color: "#a16207", fondo: "#fefce8" };
  if (puntaje >= 75)
    return { etiqueta: "Bueno", color: "#c2410c", fondo: "#fff7ed" };
  return { etiqueta: "Regular", color: "#6c757d", fondo: "#f8f9fa" };
}
function etiquetaHedonica(promedio2) {
  if (promedio2 === null)
    return "Sin votos";
  const valor = Math.min(HEDONICA_MAX, Math.max(1, Math.round(promedio2)));
  return ETIQUETAS_HEDONICAS[valor] ?? "";
}
var redondear2 = (n) => Math.round(n * 100) / 100;
var ETIQUETA_ATRIBUTO = {
  fragancia: "Fragancia",
  aroma: "Aroma",
  sabor: "Sabor",
  sabor_residual: "Sabor residual",
  acidez: "Acidez",
  dulzor: "Dulzor",
  sensacion_boca: "Sensaci\xF3n en boca"
};
function formatearFecha(valor) {
  const fecha = valor instanceof Date ? valor : new Date(valor);
  return Number.isNaN(fecha.getTime()) ? "" : fecha.toLocaleDateString("es", { day: "2-digit", month: "short", year: "numeric" });
}
var porcentajeDe = (valor, maximo) => valor === null || maximo <= 0 ? 0 : Math.min(100, Math.max(0, Math.round(valor / maximo * 1e3) / 10));
var MEDIDOR_CX = 100;
var MEDIDOR_CY = 100;
var MEDIDOR_RADIO = 72;
var AGUJA_RADIO = 60;
function puntoEnMedidor(valor, radio) {
  const v = Math.min(100, Math.max(0, Number.isFinite(valor) ? valor : 0));
  const angulo = Math.PI * (1 - v / 100);
  return {
    x: Math.round((MEDIDOR_CX + radio * Math.cos(angulo)) * 100) / 100,
    y: Math.round((MEDIDOR_CY - radio * Math.sin(angulo)) * 100) / 100
  };
}
function arco(desde, hasta, clase) {
  const a = puntoEnMedidor(desde, MEDIDOR_RADIO);
  const b = puntoEnMedidor(hasta, MEDIDOR_RADIO);
  return { d: `M ${a.x} ${a.y} A ${MEDIDOR_RADIO} ${MEDIDOR_RADIO} 0 0 1 ${b.x} ${b.y}`, clase };
}
function atributosDeFicha(atributos) {
  return ATRIBUTOS_CVA.map(({ clave, etiqueta }) => ({
    clave,
    etiqueta,
    intensidad: atributos[clave]?.intensidad ?? null,
    calidad: atributos[clave]?.calidad ?? null
  })).filter((a) => a.intensidad !== null || a.calidad !== null);
}
var _ResultsPage = class _ResultsPage {
  constructor() {
    this.route = inject(ActivatedRoute);
    this.resultsService = inject(ResultsService);
    this.impresion = inject(ImpresionService);
    this.navCtrl = inject(NavController);
    this.toastCtrl = inject(ToastController);
    this.injector = inject(Injector);
    this.sesionId = "";
    this.resultados = signal(
      null,
      ...ngDevMode ? [{ debugName: "resultados" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.cargando = signal(
      true,
      ...ngDevMode ? [{ debugName: "cargando" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.error = signal(
      null,
      ...ngDevMode ? [{ debugName: "error" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.accesoDenegado = signal(
      false,
      ...ngDevMode ? [{ debugName: "accesoDenegado" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.panelAbierto = signal(
      false,
      ...ngDevMode ? [{ debugName: "panelAbierto" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.imprimiendo = signal(
      false,
      ...ngDevMode ? [{ debugName: "imprimiendo" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.fechaReporte = signal(
      /* @__PURE__ */ new Date(),
      ...ngDevMode ? [{ debugName: "fechaReporte" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.reporteImprimible = viewChild(
      "reporteImprimible",
      ...ngDevMode ? [{ debugName: "reporteImprimible" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.atributosCva = ATRIBUTOS_CVA;
    this.tituloFormato = computed(
      () => {
        const formato = this.resultados()?.formatoCva;
        return formato ? getFormatoById(formato).titulo : "";
      },
      ...ngDevMode ? [{ debugName: "tituloFormato" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.formato = computed(
      () => this.resultados()?.formatoCva ?? "",
      ...ngDevMode ? [{ debugName: "formato" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.esCombinado = computed(
      () => this.formato() === FormatoCva.COMBINADO.id,
      ...ngDevMode ? [{ debugName: "esCombinado" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.esAfectivo = computed(
      () => this.formato() === FormatoCva.AFECTIVO.id,
      ...ngDevMode ? [{ debugName: "esAfectivo" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.esDescriptivo = computed(
      () => this.formato() === FormatoCva.DESCRIPTIVO.id,
      ...ngDevMode ? [{ debugName: "esDescriptivo" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.esExtrinseco = computed(
      () => this.formato() === FormatoCva.EXTRINSECA.id,
      ...ngDevMode ? [{ debugName: "esExtrinseco" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.ranking = computed(
      () => {
        const muestras = this.resultados()?.muestras ?? [];
        return [...muestras].filter((m) => m.evaluacionesRecibidas > 0).sort((a, b) => b.puntajePromedioPanel - a.puntajePromedioPanel).map((m, indice) => __spreadProps(__spreadValues({}, m), { posicion: indice + 1, clasificacion: clasificarPuntaje(m.puntajePromedioPanel) }));
      },
      ...ngDevMode ? [{ debugName: "ranking" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.muestrasSinFichas = computed(
      () => this.resultados()?.muestras.filter((m) => m.evaluacionesRecibidas === 0) ?? [],
      ...ngDevMode ? [{ debugName: "muestrasSinFichas" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.promedioPanel = computed(
      () => {
        const filas = this.ranking();
        if (filas.length === 0)
          return 0;
        return Math.round(filas.reduce((total, f) => total + f.puntajePromedioPanel, 0) / filas.length * 100) / 100;
      },
      ...ngDevMode ? [{ debugName: "promedioPanel" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.clasificacionPanel = computed(
      () => clasificarPuntaje(this.promedioPanel()),
      ...ngDevMode ? [{ debugName: "clasificacionPanel" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.catadoresCompletos = computed(
      () => this.resultados()?.catadores.filter((c) => c.estado === "enviado").length ?? 0,
      ...ngDevMode ? [{ debugName: "catadoresCompletos" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.porcentajeCompletado = computed(
      () => {
        const total = this.resultados()?.catadores.length ?? 0;
        return total === 0 ? 0 : Math.round(this.catadoresCompletos() / total * 100);
      },
      ...ngDevMode ? [{ debugName: "porcentajeCompletado" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.hayRecorte = computed(
      () => this.ranking().some((f) => f.recortado),
      ...ngDevMode ? [{ debugName: "hayRecorte" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.numerosMuestra = computed(
      () => [...new Set((this.resultados()?.muestras ?? []).map((m) => m.numeroMuestra))].sort((a, b) => a - b),
      ...ngDevMode ? [{ debugName: "numerosMuestra" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.fichasPorMuestra = computed(
      () => {
        const conteo = /* @__PURE__ */ new Map();
        for (const catador of this.resultados()?.catadores ?? []) {
          for (const ficha of catador.puntajesPorMuestra) {
            conteo.set(ficha.numeroMuestra, (conteo.get(ficha.numeroMuestra) ?? 0) + 1);
          }
        }
        return conteo;
      },
      ...ngDevMode ? [{ debugName: "fichasPorMuestra" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.arcosMedidor = [
      arco(0, 30, "rc-gauge__arc--bajo"),
      arco(30, 50, "rc-gauge__arc--medio"),
      arco(50, 75, "rc-gauge__arc--alto"),
      arco(75, 100, "rc-gauge__arc--top")
    ];
    this.centroMedidor = { x: MEDIDOR_CX, y: MEDIDOR_CY };
    this.muestraMedidorNumero = signal(
      null,
      ...ngDevMode ? [{ debugName: "muestraMedidorNumero" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.muestraEnMedidor = computed(
      () => {
        const filas = this.ranking();
        const elegida = this.muestraMedidorNumero();
        return filas.find((f) => f.numeroMuestra === elegida) ?? filas[0] ?? null;
      },
      ...ngDevMode ? [{ debugName: "muestraEnMedidor" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.agujaPanel = computed(
      () => puntoEnMedidor(this.promedioPanel(), AGUJA_RADIO),
      ...ngDevMode ? [{ debugName: "agujaPanel" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.agujaMuestra = computed(
      () => puntoEnMedidor(this.muestraEnMedidor()?.puntajePromedioPanel ?? 0, AGUJA_RADIO),
      ...ngDevMode ? [{ debugName: "agujaMuestra" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.catadorReporteId = signal(
      null,
      ...ngDevMode ? [{ debugName: "catadorReporteId" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.catadorReporte = computed(
      () => {
        const catadores = this.resultados()?.catadores ?? [];
        const elegido = this.catadorReporteId();
        return catadores.find((c) => c.cupperId === elegido) ?? catadores.find((c) => c.estado === "enviado") ?? catadores[0] ?? null;
      },
      ...ngDevMode ? [{ debugName: "catadorReporte" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.fichasReporte = computed(
      () => this.fichasDe(this.catadorReporte()).filter((f) => f.puntaje > 0),
      ...ngDevMode ? [{ debugName: "fichasReporte" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.muestraDetalleNumero = signal(
      null,
      ...ngDevMode ? [{ debugName: "muestraDetalleNumero" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.resultadosHedonicos = computed(
      () => {
        const r = this.resultados();
        if (!r)
          return [];
        const filas = this.numerosMuestra().map((numeroMuestra) => {
          const votos = r.votosHedonicos.filter((v) => v.numeroMuestra === numeroMuestra);
          const totalVotos = votos.reduce((t, v) => t + v.votos, 0);
          const promedio2 = totalVotos === 0 ? null : redondear2(votos.reduce((t, v) => t + v.valor * v.votos, 0) / totalVotos);
          const distribucion = ESCALA_HEDONICA_DESC.map((valor) => {
            const n = votos.find((v) => v.valor === valor)?.votos ?? 0;
            return { valor, votos: n, porcentaje: porcentajeDe(n, totalVotos), etiqueta: ETIQUETAS_HEDONICAS[valor] ?? "" };
          });
          const atributos = ATRIBUTOS_CVA.map(({ clave, etiqueta }) => {
            const valor = r.atributosPorMuestra.find((a) => a.numeroMuestra === numeroMuestra && a.atributo === clave)?.calidadPromedio ?? null;
            return { clave, etiqueta, valor, porcentaje: porcentajeDe(valor, HEDONICA_MAX) };
          });
          return { numeroMuestra, posicion: 0, totalVotos, promedio: promedio2, etiqueta: etiquetaHedonica(promedio2), distribucion, atributos };
        });
        return filas.sort((a, b) => (b.promedio ?? -1) - (a.promedio ?? -1) || a.numeroMuestra - b.numeroMuestra).map((f, i) => __spreadProps(__spreadValues({}, f), { posicion: f.promedio === null ? 0 : i + 1 }));
      },
      ...ngDevMode ? [{ debugName: "resultadosHedonicos" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.hedonicoSeleccionado = computed(
      () => {
        const filas = this.resultadosHedonicos();
        const elegida = this.muestraDetalleNumero();
        return filas.find((f) => f.numeroMuestra === elegida) ?? filas[0] ?? null;
      },
      ...ngDevMode ? [{ debugName: "hedonicoSeleccionado" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.perfilesDescriptivos = computed(
      () => {
        const r = this.resultados();
        if (!r)
          return [];
        return this.numerosMuestra().map((numeroMuestra) => ({
          numeroMuestra,
          fichas: this.fichasPorMuestra().get(numeroMuestra) ?? 0,
          atributos: ATRIBUTOS_CVA.map(({ clave, etiqueta }) => {
            const fila = r.atributosPorMuestra.find((a) => a.numeroMuestra === numeroMuestra && a.atributo === clave);
            const valor = fila?.intensidadPromedio ?? null;
            return { clave, etiqueta, valor, porcentaje: porcentajeDe(valor, INTENSIDAD_MAX), respuestas: fila?.respuestas ?? 0 };
          })
        }));
      },
      ...ngDevMode ? [{ debugName: "perfilesDescriptivos" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.perfilSeleccionado = computed(
      () => {
        const perfiles = this.perfilesDescriptivos();
        const elegida = this.muestraDetalleNumero();
        return perfiles.find((p) => p.numeroMuestra === elegida) ?? perfiles[0] ?? null;
      },
      ...ngDevMode ? [{ debugName: "perfilSeleccionado" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.fichasTecnicas = computed(
      () => this.resultados()?.fichasTecnicas ?? [],
      ...ngDevMode ? [{ debugName: "fichasTecnicas" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.modalExportarAbierto = signal(
      false,
      ...ngDevMode ? [{ debugName: "modalExportarAbierto" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.modoExportacion = signal(
      "panel",
      ...ngDevMode ? [{ debugName: "modoExportacion" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.muestraExportar = signal(
      null,
      ...ngDevMode ? [{ debugName: "muestraExportar" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.catadorExportarId = signal(
      null,
      ...ngDevMode ? [{ debugName: "catadorExportarId" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.catadoresExportables = computed(
      () => this.resultados()?.catadores.filter((c) => c.muestrasEvaluadas > 0) ?? [],
      ...ngDevMode ? [{ debugName: "catadoresExportables" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.formatoHoja = computed(
      () => this.esCombinado() ? "combinado" : this.esDescriptivo() ? "descriptivo" : null,
      ...ngDevMode ? [{ debugName: "formatoHoja" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.escala9 = [1, 2, 3, 4, 5, 6, 7, 8, 9];
    this.descriptoresSca = DESCRIPTORES_SCA;
    this.gustosSca = GUSTOS_SCA;
    this.bocaSca = BOCA_SCA;
    this.defectosSca = DEFECTOS_SCA;
    this.circuloMarcado = circuloMarcado;
    this.etiquetaCalidad = etiquetaCalidad;
    this.LEYENDA_HEDONICA = [1, 2, 3, 4, 5, 6, 7, 8, 9].map((n) => ({ n, etiqueta: ETIQUETAS_HEDONICAS[n] ?? "" }));
    this.catadoresPanelIds = signal(
      /* @__PURE__ */ new Set(),
      ...ngDevMode ? [{ debugName: "catadoresPanelIds" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.muestraHoja = computed(
      () => this.muestraExportar() ?? this.muestraEnMedidor()?.numeroMuestra ?? this.numerosMuestra()[0] ?? null,
      ...ngDevMode ? [{ debugName: "muestraHoja" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.catadorExportar = computed(
      () => this.resultados()?.catadores.find((c) => c.cupperId === this.catadorExportarId()) ?? null,
      ...ngDevMode ? [{ debugName: "catadorExportar" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.opcionesPanel = computed(
      () => {
        const muestra = this.muestraHoja();
        const seleccion = this.catadoresPanelIds();
        return this.catadoresExportables().map((c) => ({
          id: c.cupperId,
          nombre: c.nombre,
          tieneFicha: c.puntajesPorMuestra.some((p) => p.numeroMuestra === muestra),
          seleccionado: seleccion.has(c.cupperId),
          desviacion: c.desviacionRespectoPanel
        }));
      },
      ...ngDevMode ? [{ debugName: "opcionesPanel" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.puedeConfirmarExportar = computed(
      () => {
        if (this.imprimiendo() || this.muestraHoja() === null)
          return false;
        if (!this.formatoHoja())
          return true;
        if (this.modoExportacion() === "catador") {
          return this.catadorExportar()?.puntajesPorMuestra.some((p) => p.numeroMuestra === this.muestraHoja()) ?? false;
        }
        return this.opcionesPanel().some((o) => o.seleccionado && o.tieneFicha);
      },
      ...ngDevMode ? [{ debugName: "puedeConfirmarExportar" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.hojaSca = computed(
      () => {
        const r = this.resultados();
        const formato = this.formatoHoja();
        const numero = this.muestraHoja();
        if (!r || !formato || numero === null)
          return null;
        const muestra = r.muestras.find((m) => m.numeroMuestra === numero);
        const base = {
          formato,
          titulo: formato === "combinado" ? "Formato Combinado" : "Formato Descriptivo",
          objetivo: r.nombreSesion,
          numeroMuestra: numero,
          nivelTueste: muestra?.nivelTueste ?? null
        };
        if (this.modoExportacion() === "catador") {
          const catador = this.catadorExportar();
          const ficha = catador?.puntajesPorMuestra.find((p) => p.numeroMuestra === numero);
          if (!catador || !ficha)
            return null;
          return __spreadProps(__spreadValues({}, base), {
            esPanel: false,
            nombre: catador.nombre,
            fecha: formatearFecha(catador.submittedAt ?? this.fechaReporte()),
            ficha: leerFichaSca(ficha),
            resumenPanel: null
          });
        }
        const seleccion = this.catadoresPanelIds();
        const conFicha = r.catadores.map((c) => ({ catador: c, ficha: c.puntajesPorMuestra.find((p) => p.numeroMuestra === numero) })).filter((x) => !!x.ficha);
        const incluidos = conFicha.filter((x) => seleccion.has(x.catador.cupperId));
        const excluidos = conFicha.filter((x) => !seleccion.has(x.catador.cupperId));
        if (incluidos.length === 0)
          return null;
        const resumen = [
          `Consolidado de ${incluidos.length} ficha(s): ${incluidos.map((x) => x.catador.nombre).join(", ")}.`,
          excluidos.length ? `Excluidos por el organizador: ${excluidos.map((x) => x.catador.nombre).join(", ")}.` : "",
          "Notas y descriptores libres: ver el reporte individual de cada catador."
        ].filter(Boolean).join(" ");
        const puntajes = incluidos.map((x) => x.ficha.puntaje).filter((p) => p > 0);
        const puntaje = formato === "combinado" ? puntajePanel(puntajes) : null;
        return __spreadProps(__spreadValues({}, base), {
          esPanel: true,
          nombre: "Consolidado del Panel",
          fecha: formatearFecha(this.fechaReporte()),
          ficha: consolidarFichas(incluidos.map((x) => leerFichaSca(x.ficha)), resumen),
          resumenPanel: {
            puntaje,
            clasificacion: puntaje === null ? "" : clasificarPuntaje(puntaje).etiqueta,
            fichas: `${incluidos.length} / ${conFicha.length}`,
            minMax: puntajes.length ? `${Math.min(...puntajes).toFixed(2)} \u2013 ${Math.max(...puntajes).toFixed(2)}` : "\u2014",
            recortado: puntajes.length >= 5
          }
        });
      },
      ...ngDevMode ? [{ debugName: "hojaSca" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.tituloReporte = computed(
      () => {
        const r = this.resultados();
        if (!r)
          return "Reporte PacamaraQs";
        const partes = [this.esExtrinseco() ? "Ficha t\xE9cnica" : "Reporte SCA", r.nombreSesion, this.tituloFormato()];
        if (this.formatoHoja()) {
          const muestra = this.muestraHoja();
          if (muestra)
            partes.push(`Muestra ${muestra}`);
          if (this.modoExportacion() === "catador") {
            if (this.catadorExportar())
              partes.push(this.catadorExportar().nombre);
          } else {
            partes.push("Panel");
          }
        }
        return partes.filter(Boolean).join(" - ");
      },
      ...ngDevMode ? [{ debugName: "tituloReporte" }] : (
        /* istanbul ignore next */
        []
      )
    );
    addIcons({
      checkmarkCircleOutline,
      closeOutline,
      documentTextOutline,
      downloadOutline,
      hourglassOutline,
      lockClosedOutline,
      medalOutline,
      ribbonOutline,
      trophyOutline
    });
  }
  async ngOnInit() {
    const sesionId = this.route.snapshot.paramMap.get("id")?.trim() ?? "";
    this.sesionId = sesionId;
    if (!sesionId) {
      this.error.set("No se encontr\xF3 el ID de la sesi\xF3n.");
      this.cargando.set(false);
      return;
    }
    try {
      const resultados = await this.resultsService.obtenerResultadosSesion(sesionId);
      this.resultados.set(resultados);
      if (!resultados)
        this.error.set("No se encontraron resultados para esta sesi\xF3n.");
    } catch (error) {
      const codigo = codigoDeError(error);
      if (codigo === "42501")
        this.accesoDenegado.set(true);
      if (codigo === "22023")
        this.panelAbierto.set(true);
      this.error.set(mensajeDeError(error, "No se pudieron cargar los resultados."));
    } finally {
      this.cargando.set(false);
    }
  }
  seleccionarMuestraMedidor(numeroMuestra) {
    this.muestraMedidorNumero.set(numeroMuestra);
  }
  seleccionarCatadorReporte(cupperId) {
    this.catadorReporteId.set(cupperId);
  }
  seleccionarMuestraDetalle(valor) {
    const n = Number(valor);
    if (Number.isFinite(n))
      this.muestraDetalleNumero.set(n);
  }
  /** Abre el modal; opcionalmente pre-seleccionado desde una ficha individual. */
  abrirExportar(opciones) {
    if (this.catadoresPanelIds().size === 0) {
      this.catadoresPanelIds.set(new Set(this.catadoresExportables().map((c) => c.cupperId)));
    }
    if (opciones) {
      this.muestraExportar.set(opciones.numeroMuestra);
      this.catadorExportarId.set(opciones.cupperId);
      this.modoExportacion.set("catador");
    } else {
      this.muestraExportar.set(this.muestraHoja());
      this.catadorExportarId.set(this.catadorExportarId() ?? this.catadorReporte()?.cupperId ?? null);
    }
    this.modalExportarAbierto.set(true);
  }
  cerrarExportar() {
    this.modalExportarAbierto.set(false);
  }
  cambiarModoExportacion(valor) {
    if (valor === "panel" || valor === "catador")
      this.modoExportacion.set(valor);
  }
  cambiarMuestraExportar(valor) {
    const n = Number(valor);
    this.muestraExportar.set(Number.isFinite(n) ? n : null);
  }
  cambiarCatadorExportar(valor) {
    this.catadorExportarId.set(typeof valor === "string" ? valor : null);
  }
  /** Texto de la columna afectiva: valor hedónico de cada atributo de la fila. */
  etiquetasAfectivas(hoja, atributos) {
    return atributos.map((a) => {
      const valor = hoja.ficha.calidad[a];
      if (valor === null)
        return "";
      const prefijo = hoja.esPanel && !Number.isInteger(valor) ? `prom. ${valor.toFixed(2)} \u2192 ` : "";
      return `${ETIQUETA_ATRIBUTO[a]}: ${prefijo}${etiquetaCalidad(valor)}`;
    }).filter(Boolean).join(" \xB7 ");
  }
  /** Cajas de tazas (0–5) que se marcan: entero más cercano. */
  circuloMarcadoTazas(valor) {
    return Math.min(5, Math.max(0, Math.round(valor)));
  }
  toggleCatadorPanel(cupperId, incluir) {
    const siguiente = new Set(this.catadoresPanelIds());
    if (incluir)
      siguiente.add(cupperId);
    else
      siguiente.delete(cupperId);
    this.catadoresPanelIds.set(siguiente);
  }
  async confirmarExportar() {
    if (!this.puedeConfirmarExportar())
      return;
    this.cerrarExportar();
    await this.exportarPDF();
  }
  /**
   * Imprime el reporte del formato activo. El usuario elige "Guardar como
   * PDF" en el diálogo del navegador. Se espera un render para que la
   * plantilla oculta refleje la muestra / catador elegidos en el modal.
   */
  async exportarPDF() {
    if (!this.resultados() || this.imprimiendo())
      return;
    this.imprimiendo.set(true);
    this.fechaReporte.set(/* @__PURE__ */ new Date());
    try {
      await this.esperarRender();
      const contenedor = this.reporteImprimible()?.nativeElement;
      if (!contenedor)
        throw new Error("No se pudo preparar el reporte para imprimir.");
      await this.impresion.imprimir(this.tituloReporte(), contenedor.innerHTML);
    } catch (error) {
      const toast = await this.toastCtrl.create({
        message: mensajeDeError(error, "No se pudo generar el PDF."),
        duration: 3e3,
        color: "danger"
      });
      await toast.present();
    } finally {
      this.imprimiendo.set(false);
    }
  }
  /** Con fichas pendientes, el organizador finaliza el panel desde el monitoreo. */
  irAMonitoreo() {
    if (this.sesionId)
      void this.navCtrl.navigateForward(`/session/${this.sesionId}/organizer-dashboard`);
  }
  volverAlPanel() {
    void this.navCtrl.navigateRoot("/dashboard");
  }
  fichasDe(catador) {
    return [...catador?.puntajesPorMuestra ?? []].sort((a, b) => a.numeroMuestra - b.numeroMuestra).map((p) => ({
      numeroMuestra: p.numeroMuestra,
      puntaje: p.puntaje,
      tazasNoUniformes: p.tazasNoUniformes,
      tazasDefectuosas: p.tazasDefectuosas,
      impresionGlobal: p.impresionGlobal,
      atributos: atributosDeFicha(p.atributos),
      clasificacion: clasificarPuntaje(p.puntaje)
    }));
  }
  esperarRender() {
    return new Promise((resolve) => afterNextRender(() => resolve(), { injector: this.injector }));
  }
};
_ResultsPage.\u0275fac = function ResultsPage_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _ResultsPage)();
};
_ResultsPage.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _ResultsPage, selectors: [["app-results"]], viewQuery: function ResultsPage_Query(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275viewQuerySignal(ctx.reporteImprimible, _c02, 5);
  }
  if (rf & 2) {
    \u0275\u0275queryAdvance();
  }
}, decls: 43, vars: 6, consts: [["medidor", ""], ["metaSesion", ""], ["participacion", ""], ["selectorMuestra", ""], ["scaSlider", ""], ["scaCirculos", ""], ["scaCasilla", ""], ["scaDescriptores", ""], ["scaGustos", ""], ["scaBoca", ""], ["scaNotas", ""], ["scaTazas", ""], ["reporteImprimible", ""], [1, "ion-no-border"], [1, "rs-toolbar"], ["slot", "start"], ["defaultHref", "/dashboard", "text", ""], [1, "rs-title"], [1, "rs-subtitle"], ["slot", "end"], ["fill", "outline", "size", "small", 3, "click", "disabled"], ["name", "download-outline", "slot", "start"], [1, "ion-padding", "rs-content"], [1, "rs-container"], ["role", "status", 1, "rs-center"], ["role", "alert", 1, "cupping-card", "rs-center"], [1, "rc-export-modal", 3, "isOpen"], ["hidden", "", "aria-hidden", "true"], [1, "rc-card", "rc-gauge"], ["viewBox", "0 0 200 112", "role", "img", 1, "rc-gauge__svg"], ["x", "100", "y", "22", "text-anchor", "middle", 1, "rc-gauge__tick"], [1, "rc-gauge__needle"], ["r", "6", 1, "rc-gauge__hub"], [1, "rc-gauge__value"], [1, "rc-gauge__label"], [1, "rc-card"], [1, "rs-meta"], [1, "rs-meta__status"], [1, "rs-meta__headline"], ["name", "checkmark-circle-outline", "aria-hidden", "true"], [1, "rs-meta__detail"], [1, "rs-meta__stats"], [1, "rs-section-title", "rc-section-title--tight"], [1, "rs-muted", "rs-note"], ["lines", "full", 1, "rx-list"], ["slot", "start", "aria-hidden", "true", 1, "rc-avatar"], [1, "rx-list__name"], ["slot", "end", 1, "rc-chip"], ["scrollable", "true", 1, "rx-samples", 3, "ionChange", "value"], [3, "value"], ["name", "crescent"], [1, "rs-actions"], [1, "primary-btn"], ["fill", "outline", 3, "click"], ["name", "lock-closed-outline", "aria-hidden", "true", 1, "rs-lock"], ["name", "hourglass-outline", "aria-hidden", "true", 1, "rs-lock"], [1, "rs-muted"], [1, "primary-btn", 3, "click"], [1, "rc-grid-flush"], ["size", "12", "size-md", "6"], [4, "ngTemplateOutlet", "ngTemplateOutletContext"], [1, "rs-table-wrap"], [1, "rs-table", "rc-ranking"], ["scope", "col"], ["tabindex", "0", 1, "rc-ranking__row", 3, "rc-ranking__row--active"], [1, "rs-muted", "rs-note", "rc-note-bottom"], [1, "rc-block"], ["size", "12", "size-sm", "6", "size-lg", "4"], [1, "rs-formula"], [1, "rs-section-title"], [1, "rs-formula__expr"], [1, "primary-btn", 3, "click", "disabled"], ["tabindex", "0", 1, "rc-ranking__row", 3, "click", "keydown.enter", "keydown.space"], [1, "rs-rank"], ["aria-hidden", "true", 3, "name"], [1, "rc-ranking__name"], [1, "rc-chip", "rc-chip--live"], [1, "rs-tag"], [1, "rs-score"], [1, "rs-tag", 3, "title"], [1, "rc-chip"], ["colspan", "6", 1, "rs-muted"], ["type", "button", 1, "rc-cupper-select", 3, "click"], [3, "catador"], [1, "rc-report__head"], [1, "rc-report__who"], ["aria-hidden", "true", 1, "rc-avatar"], [1, "rc-report__name"], [1, "rc-report__meta"], [1, "rc-report__score"], [1, "rc-fichas", 3, "multiple"], [1, "rc-ficha", 3, "value"], ["slot", "header", "lines", "none", 1, "rc-ficha__header"], ["slot", "end", 1, "rc-ficha__score"], ["slot", "content", 1, "rc-ficha__body"], [1, "rc-ficha__row"], [1, "rc-ficha__row", "rc-ficha__row--total"], [1, "rc-ficha__actions"], ["size", "small", "fill", "outline", 3, "click"], [1, "rc-ficha__row", "rc-ficha__row--head"], [1, "rc-ficha__cols"], ["scope", "col", 1, "ra-col-bar"], [1, "ra-col-bar"], [1, "rx-bar-line"], [1, "rx-bar", "rx-bar--hedonic"], [1, "rc-chip", "ra-chip"], ["colspan", "5", 1, "rs-muted"], ["role", "list", 1, "rx-bars"], [1, "rx-bars__row"], ["role", "list", 1, "ra-dist"], [1, "ra-dist__row", 3, "ra-dist__row--empty"], [1, "ra-dist__total"], [1, "ra-dist__row"], [1, "ra-dist__value"], [1, "ra-dist__label"], [1, "ra-dist__count"], [1, "rx-bars__label"], [1, "rx-bars__value"], [1, "rs-table", "rd-matrix"], ["scope", "col", 1, "rd-matrix__num"], [1, "rd-head"], ["aria-hidden", "true", 1, "rd-scale"], [1, "rd-scale__ticks"], ["role", "list", 1, "rx-bars", "rd-bars"], [1, "rx-bar", "rx-bar--intensity", "rd-bar"], ["scope", "row"], [1, "rd-matrix__num"], [1, "rd-cell"], [1, "rc-card", "re-card"], [1, "re-head"], [1, "re-head__title"], ["name", "document-text-outline", "aria-hidden", "true"], ["size", "12", "size-md", "6", "size-xl", "4"], [1, "re-section"], [1, "re-certs"], [1, "re-dl"], [1, "rc-chip", "re-cert"], ["name", "ribbon-outline", "aria-hidden", "true"], [1, "re-notes"], [1, "rs-center"], ["name", "document-text-outline", "aria-hidden", "true", 1, "rs-lock"], [1, "cupping-card", "rs-meta"], [1, "cupping-card"], [1, "rs-table"], [1, "rs-grid"], ["name", "trophy-outline", "aria-label", "Primer lugar"], [1, "rs-badge"], ["colspan", "4"], [1, "rc-export-modal", 3, "didDismiss", "isOpen"], [1, "rc-export"], [1, "rc-export__head"], ["fill", "clear", "size", "small", "aria-label", "Cerrar", 3, "click"], ["name", "close-outline", "slot", "icon-only"], ["for", "rc-export-muestra", 1, "rc-export__label"], ["id", "rc-export-muestra", "interface", "popover", "placeholder", "Selecciona una muestra", 1, "rc-export__select", 3, "ionChange", "value"], [1, "rc-export__segment", 3, "ionChange", "value"], ["value", "catador"], ["value", "panel"], ["expand", "block", 1, "primary-btn", "rc-export__go", 3, "click", "disabled"], [1, "rc-export__hint"], ["for", "rc-export-catador", 1, "rc-export__label"], ["id", "rc-export-catador", "interface", "popover", "placeholder", "Selecciona un catador", 1, "rc-export__select", 3, "ionChange", "value"], [1, "rc-export__label"], [1, "rc-export__help"], ["role", "list", 1, "rc-export__panel"], [1, "rc-export__panel-item", 3, "rc-export__panel-item--off"], [1, "rc-export__panel-item"], ["labelPlacement", "end", "justify", "start", 3, "ionChange", "checked", "disabled"], [1, "rc-export__calib"], [1, "sca-attr"], [1, "sca-attr__name"], [1, "sca-attr__val"], [1, "sca-slider"], [1, "sca-slider__zones"], [1, "sca-slider__bar"], [1, "sca-slider__mark", 3, "left"], [1, "sca-slider__ticks"], [1, "sca-slider__nums"], [2, "left", "0"], [2, "left", "33.333%"], [2, "left", "66.667%"], [2, "left", "100%"], [1, "sca-slider__mark"], [1, "sca-circles"], [1, "sca-c", 3, "sca-c--on"], [1, "sca-final"], [1, "sca-c"], [1, "sca-cb"], [1, "sca-desc__row"], [1, "sca-gustos"], [1, "sca-label"], [1, "sca-notes"], [1, "sca-notes__text"], [1, "sca-boxes"], [3, "on"], [1, "sca-page", 3, "sca-page--combinado"], [1, "sca-page"], [1, "sca-head"], [1, "sca-head__main"], [1, "sca-head__brand"], [1, "sca-fields"], [1, "sca-field", "sca-field--wide"], [1, "sca-field"], [1, "sca-legend"], ["aria-label", "Consolidado del panel", 1, "sca-kpis"], [1, "sca-legal"], [1, "sca-kpi"], [1, "sca-kpis__note"], [1, "sca-bars"], [1, "sca-bars__left"], [1, "sca-bar"], [1, "sca-roast"], [1, "sca-bar", "sca-bars__right"], [1, "sca-comb"], [1, "sca-l", "sca-l--sliders"], [1, "sca-r", "sca-r--circles"], [1, "sca-l", "sca-split", "sca-h-desc"], [1, "sca-desc"], [1, "sca-r"], [1, "sca-l", "sca-split", "sca-h-desc2"], [1, "sca-l", "sca-l--one"], [1, "sca-l", "sca-h-note"], [1, "sca-r", "sca-h-note"], [1, "sca-l", "sca-split", "sca-split--boca", "sca-h-boca"], [1, "sca-r", "sca-h-boca"], [1, "sca-l", "sca-otras"], [1, "sca-bar", "sca-bar--block"], [1, "sca-r", "sca-global"], [1, "sca-global__head"], [1, "sca-global__title"], [1, "sca-cups"], [1, "sca-cups__left"], [1, "sca-cups__right"], [1, "sca-bars", "sca-bars--desc"], [1, "sca-bar", "sca-bar--muestra"], [1, "sca-desc-grid"], [1, "sca-r", "sca-span2"], [1, "sca-l", "sca-desc", "sca-desc--2col"], [1, "sca-l", "sca-desc-gustos"], [1, "sca-desc", "sca-desc--2col"], [1, "sca-l", "sca-l--one", "sca-h-attr"], [1, "sca-r", "sca-h-attr"], [1, "sca-l"], [1, "sca-desc", "sca-desc--boca"], [1, "sca-l", "sca-otras", "sca-full"], [1, "rp-head"], [1, "rp-brand"], [1, "rp-title"], [1, "rp-sub"], [1, "rp-meta"], [1, "rp-foot"], [1, "rp-section"], [1, "num"], [1, "rp-grid"], [1, "num", "rp-score"], [2, "margin-top", "6px"], [2, "width", "8%"], [1, "rp-muted", 2, "width", "38%"], [1, "rp-bar"], [1, "num", 2, "width", "8%"], [3, "rp-page-break"], [1, "rp-chips"], [1, "rp-muted"], [1, "rp-dl"]], template: function ResultsPage_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-header", 13)(1, "ion-toolbar", 14)(2, "ion-buttons", 15);
    \u0275\u0275element(3, "ion-back-button", 16);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "ion-title")(5, "div", 17);
    \u0275\u0275text(6);
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(7, ResultsPage_Conditional_7_Template, 2, 2, "div", 18);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "ion-buttons", 19)(9, "ion-button", 20);
    \u0275\u0275listener("click", function ResultsPage_Template_ion_button_click_9_listener() {
      return ctx.formatoHoja() ? ctx.abrirExportar() : ctx.exportarPDF();
    });
    \u0275\u0275element(10, "ion-icon", 21);
    \u0275\u0275text(11, " Exportar PDF ");
    \u0275\u0275elementEnd()()()();
    \u0275\u0275template(12, ResultsPage_ng_template_12_Template, 15, 15, "ng-template", null, 0, \u0275\u0275templateRefExtractor)(14, ResultsPage_ng_template_14_Template, 24, 5, "ng-template", null, 1, \u0275\u0275templateRefExtractor)(16, ResultsPage_ng_template_16_Template, 9, 0, "ng-template", null, 2, \u0275\u0275templateRefExtractor)(18, ResultsPage_ng_template_18_Template, 3, 1, "ng-template", null, 3, \u0275\u0275templateRefExtractor);
    \u0275\u0275elementStart(20, "ion-content", 22)(21, "main", 23);
    \u0275\u0275conditionalCreate(22, ResultsPage_Conditional_22_Template, 2, 0, "div", 24)(23, ResultsPage_Conditional_23_Template, 8, 2, "section", 25)(24, ResultsPage_Conditional_24_Template, 5, 1);
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(25, ResultsPage_Conditional_25_Template, 2, 1, "ion-modal", 26);
    \u0275\u0275template(26, ResultsPage_ng_template_26_Template, 27, 3, "ng-template", null, 4, \u0275\u0275templateRefExtractor)(28, ResultsPage_ng_template_28_Template, 6, 6, "ng-template", null, 5, \u0275\u0275templateRefExtractor)(30, ResultsPage_ng_template_30_Template, 5, 4, "ng-template", null, 6, \u0275\u0275templateRefExtractor)(32, ResultsPage_ng_template_32_Template, 2, 0, "ng-template", null, 7, \u0275\u0275templateRefExtractor)(34, ResultsPage_ng_template_34_Template, 5, 0, "ng-template", null, 8, \u0275\u0275templateRefExtractor)(36, ResultsPage_ng_template_36_Template, 2, 0, "ng-template", null, 9, \u0275\u0275templateRefExtractor)(38, ResultsPage_ng_template_38_Template, 4, 2, "ng-template", null, 10, \u0275\u0275templateRefExtractor)(40, ResultsPage_ng_template_40_Template, 3, 1, "ng-template", null, 11, \u0275\u0275templateRefExtractor);
    \u0275\u0275conditionalCreate(42, ResultsPage_Conditional_42_Template, 4, 1, "div", 27);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    let tmp_13_0;
    let tmp_15_0;
    let tmp_17_0;
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate(ctx.esExtrinseco() ? "Ficha t\xE9cnica" : "Resultados finales");
    \u0275\u0275advance();
    \u0275\u0275conditional((tmp_13_0 = ctx.resultados()) ? 7 : -1, tmp_13_0);
    \u0275\u0275advance(2);
    \u0275\u0275property("disabled", !ctx.resultados() || ctx.imprimiendo());
    \u0275\u0275advance(13);
    \u0275\u0275conditional(ctx.cargando() ? 22 : (tmp_15_0 = ctx.error()) ? 23 : (tmp_15_0 = ctx.resultados()) ? 24 : -1, tmp_15_0);
    \u0275\u0275advance(3);
    \u0275\u0275conditional(ctx.formatoHoja() ? 25 : -1);
    \u0275\u0275advance(17);
    \u0275\u0275conditional((tmp_17_0 = ctx.resultados()) ? 42 : -1, tmp_17_0);
  }
}, dependencies: [
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonButton,
  IonBackButton,
  IonButtons,
  IonIcon,
  IonSpinner,
  IonCard,
  IonCardContent,
  IonGrid,
  IonRow,
  IonCol,
  IonBadge,
  IonList,
  IonAccordionGroup,
  IonAccordion,
  IonItem,
  IonLabel,
  IonModal,
  IonSegment,
  IonSegmentButton,
  IonSelect,
  IonSelectOption,
  IonCheckbox,
  CupperResultCardComponent,
  CommonModule,
  NgTemplateOutlet,
  DecimalPipe,
  DatePipe
], styles: ['@charset "UTF-8";\n\n\n.rs-toolbar[_ngcontent-%COMP%] {\n  --%NS%background: var(--%NS%app-bg-card);\n}\n.rs-title[_ngcontent-%COMP%] {\n  color: var(--%NS%app-text-main);\n  font-size: 15px;\n  font-weight: 700;\n}\n.rs-subtitle[_ngcontent-%COMP%] {\n  color: var(--%NS%app-text-muted);\n  font-size: 12px;\n  font-weight: 400;\n}\n.rs-content[_ngcontent-%COMP%] {\n  --%NS%background: var(--%NS%app-bg-screen);\n}\n.rs-container[_ngcontent-%COMP%] {\n  width: min(100%, 960px);\n  margin: 0 auto;\n  padding-bottom: 24px;\n}\n.rs-center[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  gap: 12px;\n  padding: 32px 16px;\n  text-align: center;\n}\n.rs-lock[_ngcontent-%COMP%] {\n  color: var(--%NS%app-text-muted);\n  font-size: 32px;\n}\n.rs-section-title[_ngcontent-%COMP%] {\n  margin: 0 0 12px;\n  color: var(--%NS%app-text-muted);\n  font-size: 11px;\n  font-weight: 700;\n  letter-spacing: 0.05em;\n  text-transform: uppercase;\n}\n.rs-muted[_ngcontent-%COMP%] {\n  color: var(--%NS%app-text-muted);\n}\n.rs-note[_ngcontent-%COMP%] {\n  margin: 0 0 12px;\n  font-size: 12px;\n}\n.rs-meta[_ngcontent-%COMP%] {\n  display: flex;\n  flex-wrap: wrap;\n  align-items: center;\n  justify-content: space-between;\n  gap: 16px;\n}\n.rs-meta__headline[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  margin: 0;\n  color: var(--%NS%app-text-main);\n  font-weight: 600;\n}\n.rs-meta__detail[_ngcontent-%COMP%] {\n  margin: 6px 0 0;\n  color: var(--%NS%app-text-muted);\n  font-size: 13px;\n}\n.rs-meta__stats[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 24px;\n  text-align: center;\n}\n.rs-meta__stats[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%] {\n  display: block;\n  color: var(--%NS%app-text-main);\n  font-size: 16px;\n}\n.rs-meta__stats[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  color: var(--%NS%app-text-muted);\n  font-size: 11px;\n}\n.rs-table-wrap[_ngcontent-%COMP%] {\n  overflow-x: auto;\n}\n.rs-table[_ngcontent-%COMP%] {\n  width: 100%;\n  border-collapse: collapse;\n  font-size: 13px;\n}\n.rs-table[_ngcontent-%COMP%]   th[_ngcontent-%COMP%], \n.rs-table[_ngcontent-%COMP%]   td[_ngcontent-%COMP%] {\n  padding: 10px 8px;\n  border-bottom: 1px solid var(--%NS%app-border);\n  text-align: left;\n  white-space: nowrap;\n}\n.rs-table[_ngcontent-%COMP%]   thead[_ngcontent-%COMP%]   th[_ngcontent-%COMP%] {\n  color: var(--%NS%app-text-muted);\n  font-size: 11px;\n  font-weight: 600;\n  text-transform: uppercase;\n}\n.rs-table[_ngcontent-%COMP%]   tfoot[_ngcontent-%COMP%]   td[_ngcontent-%COMP%] {\n  color: var(--%NS%app-text-muted);\n  font-weight: 600;\n}\n.rs-rank[_ngcontent-%COMP%] {\n  color: var(--%NS%app-text-muted);\n}\n.rs-rank[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  color: #ca8a04;\n  vertical-align: middle;\n}\n.rs-score[_ngcontent-%COMP%] {\n  color: var(--%NS%app-score);\n  font-size: 15px;\n  font-weight: 700;\n}\n.rs-tag[_ngcontent-%COMP%] {\n  margin-left: 6px;\n  padding: 2px 6px;\n  border-radius: 4px;\n  background: var(--%NS%app-bg-subtle);\n  color: var(--%NS%app-text-muted);\n  font-size: 10px;\n  font-weight: 500;\n}\n.rs-badge[_ngcontent-%COMP%] {\n  display: inline-block;\n  padding: 3px 8px;\n  border-radius: 6px;\n  font-size: 11px;\n  font-weight: 600;\n}\n.rs-grid[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));\n  gap: 12px;\n  margin-bottom: 16px;\n}\n.rs-formula[_ngcontent-%COMP%] {\n  margin-bottom: 16px;\n  padding: 16px;\n  border-radius: var(--%NS%app-radius-card);\n  background: var(--%NS%app-bg-subtle);\n}\n.rs-formula__expr[_ngcontent-%COMP%] {\n  margin: 0 0 8px;\n  color: var(--%NS%app-text-main);\n  font-family: var(--%NS%app-font-mono);\n  font-size: 14px;\n}\n.rs-actions[_ngcontent-%COMP%] {\n  display: flex;\n  flex-wrap: wrap;\n  justify-content: flex-end;\n  gap: 12px;\n}\n[_nghost-%COMP%] {\n  --%NS%rc-gauge-bajo: #e53935;\n  --%NS%rc-gauge-medio: #f5b400;\n  --%NS%rc-gauge-alto: #8fdc6a;\n  --%NS%rc-gauge-top: #12a150;\n  --%NS%rc-row-active: #fbe9e4;\n  --%NS%rc-medal-1: #ca8a04;\n  --%NS%rc-medal-2: #94a3b8;\n  --%NS%rc-medal-3: #b45309;\n}\n.rc-card[_ngcontent-%COMP%] {\n  margin: 0 0 16px;\n  border: 1px solid var(--%NS%app-border);\n  border-radius: var(--%NS%app-radius-card);\n  background: var(--%NS%app-bg-card);\n  box-shadow: none;\n}\n.rc-card[_ngcontent-%COMP%]   ion-card-content[_ngcontent-%COMP%] {\n  padding: 16px;\n}\n.rc-grid-flush[_ngcontent-%COMP%] {\n  --%NS%ion-grid-padding: 0;\n  margin: 0 -5px;\n}\n.rc-grid-flush[_ngcontent-%COMP%]   ion-col[_ngcontent-%COMP%] {\n  --%NS%ion-grid-column-padding: 5px;\n}\n.rc-grid-flush[_ngcontent-%COMP%]   .rc-card[_ngcontent-%COMP%] {\n  height: calc(100% - 10px);\n  margin-bottom: 10px;\n}\n.rc-section-title--tight[_ngcontent-%COMP%] {\n  margin-bottom: 4px;\n}\n.rc-note-bottom[_ngcontent-%COMP%] {\n  margin: 12px 0 0;\n}\n.rc-block[_ngcontent-%COMP%] {\n  margin-bottom: 16px;\n}\n.rc-gauge[_ngcontent-%COMP%]   ion-card-content[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  padding: 16px 16px 12px;\n}\n.rc-gauge__svg[_ngcontent-%COMP%] {\n  width: min(100%, 220px);\n  height: auto;\n  overflow: visible;\n}\n.rc-gauge__arc[_ngcontent-%COMP%] {\n  fill: none;\n  stroke-width: 22;\n}\n.rc-gauge__arc--bajo[_ngcontent-%COMP%] {\n  stroke: var(--%NS%rc-gauge-bajo);\n}\n.rc-gauge__arc--medio[_ngcontent-%COMP%] {\n  stroke: var(--%NS%rc-gauge-medio);\n}\n.rc-gauge__arc--alto[_ngcontent-%COMP%] {\n  stroke: var(--%NS%rc-gauge-alto);\n}\n.rc-gauge__arc--top[_ngcontent-%COMP%] {\n  stroke: var(--%NS%rc-gauge-top);\n}\n.rc-gauge__tick[_ngcontent-%COMP%] {\n  fill: var(--%NS%app-text-muted);\n  font-size: 9px;\n}\n.rc-gauge__needle[_ngcontent-%COMP%] {\n  stroke: var(--%NS%app-text-main);\n  stroke-width: 4;\n  stroke-linecap: round;\n  transition: all 0.4s ease;\n}\n.rc-gauge__hub[_ngcontent-%COMP%] {\n  fill: var(--%NS%app-text-main);\n}\n.rc-gauge__value[_ngcontent-%COMP%] {\n  margin: 8px 0 2px;\n  color: var(--%NS%app-score);\n  font-size: 22px;\n  font-weight: 700;\n}\n.rc-gauge__label[_ngcontent-%COMP%] {\n  margin: 0;\n  color: var(--%NS%app-text-muted);\n  font-size: 10px;\n  letter-spacing: 0.04em;\n  text-align: center;\n  text-transform: uppercase;\n}\n.rc-ranking__row[_ngcontent-%COMP%] {\n  cursor: pointer;\n  transition: background-color 0.15s ease;\n}\n.rc-ranking__row[_ngcontent-%COMP%]:hover {\n  background: var(--%NS%app-bg-subtle);\n}\n.rc-ranking__row[_ngcontent-%COMP%]:focus-visible {\n  outline: 2px solid var(--%NS%app-primary-dark);\n  outline-offset: -2px;\n}\n.rc-ranking__row--active[_ngcontent-%COMP%], \n.rc-ranking__row--%NS%active[_ngcontent-%COMP%]:hover {\n  background: var(--%NS%rc-row-active);\n}\n.rc-ranking__name[_ngcontent-%COMP%] {\n  color: var(--%NS%app-text-main);\n  font-weight: 600;\n}\n.rc-medal[_ngcontent-%COMP%] {\n  margin-right: 2px;\n  vertical-align: middle;\n}\n.rc-medal--1[_ngcontent-%COMP%] {\n  color: var(--%NS%rc-medal-1);\n}\n.rc-medal--2[_ngcontent-%COMP%] {\n  color: var(--%NS%rc-medal-2);\n}\n.rc-medal--3[_ngcontent-%COMP%] {\n  color: var(--%NS%rc-medal-3);\n}\n.rc-medal--n[_ngcontent-%COMP%] {\n  color: var(--%NS%app-text-faint);\n}\n.rc-chip[_ngcontent-%COMP%] {\n  --%NS%padding-top: 3px;\n  --%NS%padding-bottom: 3px;\n  --%NS%padding-start: 8px;\n  --%NS%padding-end: 8px;\n  border-radius: 6px;\n  font-size: 11px;\n  font-weight: 600;\n}\n.rc-chip--live[_ngcontent-%COMP%] {\n  --%NS%background: #dcfce7;\n  --%NS%color: var(--%NS%app-success);\n  margin-left: 6px;\n  font-size: 10px;\n  font-weight: 500;\n}\n.rc-cupper-select[_ngcontent-%COMP%] {\n  display: block;\n  width: 100%;\n  height: 100%;\n  padding: 0;\n  border: 2px solid transparent;\n  border-radius: calc(var(--%NS%app-radius-card) + 2px);\n  background: none;\n  font: inherit;\n  text-align: inherit;\n  cursor: pointer;\n  transition: border-color 0.15s ease;\n}\n.rc-cupper-select[_ngcontent-%COMP%]:hover {\n  border-color: var(--%NS%app-border);\n}\n.rc-cupper-select[_ngcontent-%COMP%]:focus-visible {\n  outline: 2px solid var(--%NS%app-primary-dark);\n  outline-offset: 2px;\n}\n.rc-cupper-select--active[_ngcontent-%COMP%], \n.rc-cupper-select--%NS%active[_ngcontent-%COMP%]:hover {\n  border-color: var(--%NS%app-primary-dark);\n}\n.rc-report__head[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  gap: 12px;\n  margin: 8px 0 12px;\n  padding-bottom: 12px;\n  border-bottom: 1px solid var(--%NS%app-border);\n}\n.rc-report__who[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  min-width: 0;\n}\n.rc-avatar[_ngcontent-%COMP%] {\n  display: inline-flex;\n  flex: 0 0 32px;\n  align-items: center;\n  justify-content: center;\n  width: 32px;\n  height: 32px;\n  border: 1px solid var(--%NS%app-border);\n  border-radius: 50%;\n  background: var(--%NS%app-bg-subtle);\n  color: var(--%NS%app-text-main);\n  font-size: 13px;\n  font-weight: 700;\n}\n.rc-report__name[_ngcontent-%COMP%] {\n  margin: 0;\n  color: var(--%NS%app-text-main);\n  font-weight: 600;\n}\n.rc-report__meta[_ngcontent-%COMP%] {\n  margin: 2px 0 0;\n  color: var(--%NS%app-text-muted);\n  font-size: 11px;\n}\n.rc-report__score[_ngcontent-%COMP%] {\n  text-align: right;\n}\n.rc-report__score[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%] {\n  display: block;\n  color: var(--%NS%app-text-main);\n  font-size: 20px;\n}\n.rc-report__score[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  color: var(--%NS%app-text-muted);\n  font-size: 9px;\n  text-transform: uppercase;\n}\n.rc-fichas[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 8px;\n}\n.rc-ficha[_ngcontent-%COMP%] {\n  overflow: hidden;\n  border-radius: var(--%NS%app-radius-control);\n  background: var(--%NS%app-bg-subtle);\n}\n.rc-ficha__header[_ngcontent-%COMP%] {\n  --%NS%background: var(--%NS%app-bg-subtle);\n  --%NS%min-height: 40px;\n  font-size: 13px;\n  font-weight: 600;\n}\n.rc-ficha__header[_ngcontent-%COMP%]   ion-badge[_ngcontent-%COMP%] {\n  margin-inline-end: 8px;\n}\n.rc-ficha__score[_ngcontent-%COMP%] {\n  color: var(--%NS%app-score);\n  font-size: 13px;\n  font-weight: 700;\n}\n.rc-ficha__body[_ngcontent-%COMP%] {\n  padding: 4px 16px 12px;\n  background: var(--%NS%app-bg-subtle);\n}\n.rc-ficha__row[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  padding: 6px 0;\n  border-bottom: 1px solid var(--%NS%app-border);\n  color: var(--%NS%app-text-main);\n  font-size: 13px;\n}\n.rc-ficha__row--total[_ngcontent-%COMP%] {\n  border-bottom: none;\n}\n.rc-ficha__row--total[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  font-weight: 600;\n}\n.rc-ficha__row--total[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%] {\n  color: var(--%NS%app-score);\n}\n.rc-ficha__actions[_ngcontent-%COMP%] {\n  display: flex;\n  flex-wrap: wrap;\n  gap: 8px;\n  margin-top: 4px;\n}\n.rc-export-modal[_ngcontent-%COMP%] {\n  --%NS%width: min(92vw, 360px);\n  --%NS%height: auto;\n  --%NS%border-radius: var(--%NS%app-radius-card);\n}\n.rc-export[_ngcontent-%COMP%] {\n  padding: 16px;\n}\n.rc-export__head[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  margin-bottom: 12px;\n}\n.rc-export__head[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n  margin: 0;\n  color: var(--%NS%app-text-main);\n  font-size: 15px;\n  font-weight: 700;\n}\n.rc-export__label[_ngcontent-%COMP%] {\n  display: block;\n  margin: 0 0 6px;\n  color: var(--%NS%app-text-main);\n  font-size: 12px;\n  font-weight: 600;\n}\n.rc-export__select[_ngcontent-%COMP%] {\n  margin-bottom: 12px;\n  padding: 0 12px;\n  border: 1px solid var(--%NS%app-border-input);\n  border-radius: var(--%NS%app-radius-control);\n  font-size: 13px;\n}\n.rc-export__segment[_ngcontent-%COMP%] {\n  --%NS%background: transparent;\n  gap: 8px;\n  margin-bottom: 12px;\n}\n.rc-export__segment[_ngcontent-%COMP%]   ion-segment-button[_ngcontent-%COMP%] {\n  --%NS%background: var(--%NS%app-bg-subtle);\n  --%NS%background-checked: var(--%NS%app-primary-dark);\n  --%NS%color: var(--%NS%app-text-main);\n  --%NS%color-checked: #ffffff;\n  --%NS%indicator-color: transparent;\n  --%NS%border-radius: var(--%NS%app-radius-control);\n  min-height: 38px;\n  border: 1px solid var(--%NS%app-border);\n  border-radius: var(--%NS%app-radius-control);\n  font-size: 13px;\n  text-transform: none;\n}\n.rc-export__go[_ngcontent-%COMP%] {\n  margin: 4px 0 0;\n}\n@media (max-width: 576px) {\n  .rs-meta__stats[_ngcontent-%COMP%] {\n    gap: 16px;\n  }\n  .rc-report__score[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%] {\n    font-size: 18px;\n  }\n}\n.rc-export__hint[_ngcontent-%COMP%] {\n  margin: 8px 0 0;\n  color: var(--%NS%app-text-muted);\n  font-size: 11px;\n  text-align: center;\n}\n.rc-ficha__row--head[_ngcontent-%COMP%] {\n  color: var(--%NS%app-text-muted);\n  font-size: 11px;\n  text-transform: uppercase;\n}\n.rc-ficha__cols[_ngcontent-%COMP%] {\n  display: inline-grid;\n  grid-template-columns: 72px 64px;\n  text-align: right;\n}\n.rc-ficha__cols[_ngcontent-%COMP%]   em[_ngcontent-%COMP%] {\n  font-style: normal;\n}\n[_nghost-%COMP%] {\n  --%NS%rx-hedonic: #b45309;\n  --%NS%rx-intensity: var(--%NS%app-primary-dark);\n  --%NS%rx-track: var(--%NS%app-bg-subtle);\n}\n.rx-bar[_ngcontent-%COMP%] {\n  position: relative;\n  flex: 1 1 auto;\n  min-width: 40px;\n  height: 10px;\n  overflow: hidden;\n  border-radius: 999px;\n  background: var(--%NS%rx-track);\n}\n.rx-bar[_ngcontent-%COMP%]   i[_ngcontent-%COMP%] {\n  position: absolute;\n  inset: 0 auto 0 0;\n  border-radius: inherit;\n  transition: width 0.35s ease;\n}\n.rx-bar--hedonic[_ngcontent-%COMP%]   i[_ngcontent-%COMP%] {\n  background: var(--%NS%rx-hedonic);\n}\n.rx-bar--intensity[_ngcontent-%COMP%]   i[_ngcontent-%COMP%] {\n  background: var(--%NS%rx-intensity);\n}\n.rx-bars[_ngcontent-%COMP%] {\n  margin: 0;\n  padding: 0;\n  list-style: none;\n}\n.rx-bars__row[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: minmax(96px, 34%) 1fr 40px;\n  align-items: center;\n  gap: 10px;\n  padding: 7px 0;\n  border-bottom: 1px solid var(--%NS%app-border);\n  font-size: 13px;\n}\n.rx-bars__row[_ngcontent-%COMP%]:last-child {\n  border-bottom: none;\n}\n.rx-bars__label[_ngcontent-%COMP%] {\n  color: var(--%NS%app-text-main);\n}\n.rx-bars__value[_ngcontent-%COMP%] {\n  color: var(--%NS%app-text-main);\n  font-variant-numeric: tabular-nums;\n  text-align: right;\n}\n.rx-bar-line[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  min-width: 160px;\n}\n.rx-samples[_ngcontent-%COMP%] {\n  --%NS%background: transparent;\n  margin: 0 0 12px;\n}\n.rx-samples[_ngcontent-%COMP%]   ion-segment-button[_ngcontent-%COMP%] {\n  --%NS%background: var(--%NS%app-bg-card);\n  --%NS%background-checked: var(--%NS%app-primary-dark);\n  --%NS%color: var(--%NS%app-text-main);\n  --%NS%color-checked: #ffffff;\n  --%NS%indicator-color: transparent;\n  --%NS%border-radius: 999px;\n  flex: 0 0 auto;\n  min-width: 104px;\n  min-height: 32px;\n  margin-right: 6px;\n  border: 1px solid var(--%NS%app-border);\n  border-radius: 999px;\n  font-size: 12px;\n  text-transform: none;\n}\n.rx-list[_ngcontent-%COMP%] {\n  margin: 0 -16px -16px;\n  background: transparent;\n}\n.rx-list[_ngcontent-%COMP%]   ion-item[_ngcontent-%COMP%] {\n  --%NS%background: transparent;\n  --%NS%padding-start: 16px;\n  --%NS%inner-padding-end: 16px;\n}\n.rx-list[_ngcontent-%COMP%]   .rc-avatar[_ngcontent-%COMP%] {\n  margin-inline-end: 12px;\n}\n.rx-list__name[_ngcontent-%COMP%] {\n  color: var(--%NS%app-text-main);\n  font-size: 14px;\n  font-weight: 600;\n}\n.rx-list[_ngcontent-%COMP%]   ion-label[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  color: var(--%NS%app-text-muted);\n  font-size: 12px;\n}\n.rx-chip--ok[_ngcontent-%COMP%] {\n  --%NS%background: #dcfce7;\n  --%NS%color: var(--%NS%app-success);\n}\n.rx-chip--pending[_ngcontent-%COMP%] {\n  --%NS%background: var(--%NS%app-bg-subtle);\n  --%NS%color: var(--%NS%app-text-muted);\n}\n.ra-col-bar[_ngcontent-%COMP%] {\n  width: 38%;\n}\n.ra-chip[_ngcontent-%COMP%] {\n  --%NS%background: #fef3c7;\n  --%NS%color: #92400e;\n}\n.ra-dist[_ngcontent-%COMP%] {\n  margin: 0;\n  padding: 0;\n  list-style: none;\n}\n.ra-dist__row[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: 22px minmax(110px, 40%) 1fr 28px;\n  align-items: center;\n  gap: 8px;\n  padding: 5px 0;\n  font-size: 13px;\n}\n.ra-dist__row--empty[_ngcontent-%COMP%] {\n  opacity: 0.55;\n}\n.ra-dist__value[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  width: 22px;\n  height: 22px;\n  border-radius: 6px;\n  background: var(--%NS%app-bg-subtle);\n  color: var(--%NS%app-text-main);\n  font-size: 12px;\n  font-weight: 700;\n}\n.ra-dist__label[_ngcontent-%COMP%] {\n  color: var(--%NS%app-text-muted);\n  font-size: 12px;\n}\n.ra-dist__count[_ngcontent-%COMP%] {\n  color: var(--%NS%app-text-main);\n  text-align: right;\n  font-variant-numeric: tabular-nums;\n}\n.ra-dist__total[_ngcontent-%COMP%] {\n  margin: 10px 0 0;\n  padding-top: 10px;\n  border-top: 1px solid var(--%NS%app-border);\n  color: var(--%NS%app-text-muted);\n  font-size: 12px;\n}\n.rd-scale[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: minmax(96px, 34%) 1fr 40px;\n  gap: 10px;\n  color: var(--%NS%app-text-faint);\n  font-size: 10px;\n}\n.rd-scale__ticks[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n}\n.rd-scale__ticks[_ngcontent-%COMP%]   em[_ngcontent-%COMP%] {\n  font-style: normal;\n}\n.rd-bar[_ngcontent-%COMP%] {\n  height: 12px;\n  background-image:\n    linear-gradient(\n      90deg,\n      transparent calc(33.33% - 1px),\n      var(--%NS%app-border) calc(33.33% - 1px),\n      var(--%NS%app-border) 33.33%,\n      transparent 33.33%,\n      transparent calc(66.66% - 1px),\n      var(--%NS%app-border) calc(66.66% - 1px),\n      var(--%NS%app-border) 66.66%,\n      transparent 66.66%);\n}\n.rd-matrix[_ngcontent-%COMP%]   th[scope=row][_ngcontent-%COMP%] {\n  color: var(--%NS%app-text-main);\n  font-size: 13px;\n  font-weight: 500;\n  text-transform: none;\n}\n.rd-matrix__num[_ngcontent-%COMP%] {\n  text-align: center !important;\n}\n.rd-cell[_ngcontent-%COMP%] {\n  --%NS%rd-alpha: 0;\n  display: inline-block;\n  min-width: 44px;\n  padding: 3px 8px;\n  border-radius: 6px;\n  background: rgba(47, 62, 70, calc(var(--%NS%rd-alpha) * 0.85));\n  color: var(--%NS%app-text-main);\n  font-variant-numeric: tabular-nums;\n  font-weight: 600;\n}\n.rd-cell--dark[_ngcontent-%COMP%] {\n  color: #ffffff;\n}\n.re-head[_ngcontent-%COMP%] {\n  margin-bottom: 12px;\n  padding-bottom: 12px;\n  border-bottom: 1px solid var(--%NS%app-border);\n}\n.re-head__title[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: flex-start;\n  gap: 10px;\n}\n.re-head__title[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  flex: 0 0 auto;\n  margin-top: 2px;\n  color: var(--%NS%app-primary-dark);\n  font-size: 22px;\n}\n.re-head__title[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n  margin: 0;\n  color: var(--%NS%app-text-main);\n  font-size: 16px;\n  font-weight: 700;\n}\n.re-head__title[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  margin: 2px 0 0;\n  font-size: 12px;\n}\n.re-section[_ngcontent-%COMP%] {\n  margin-bottom: 12px;\n}\n.re-dl[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: minmax(110px, 42%) 1fr;\n  margin: 0;\n  font-size: 13px;\n}\n.re-dl[_ngcontent-%COMP%]   dt[_ngcontent-%COMP%], \n.re-dl[_ngcontent-%COMP%]   dd[_ngcontent-%COMP%] {\n  margin: 0;\n  padding: 6px 0;\n  border-bottom: 1px solid var(--%NS%app-border);\n}\n.re-dl[_ngcontent-%COMP%]   dt[_ngcontent-%COMP%] {\n  padding-right: 8px;\n  color: var(--%NS%app-text-muted);\n}\n.re-dl[_ngcontent-%COMP%]   dd[_ngcontent-%COMP%] {\n  color: var(--%NS%app-text-main);\n  font-weight: 500;\n  overflow-wrap: anywhere;\n}\n.re-dl__empty[_ngcontent-%COMP%] {\n  color: var(--%NS%app-text-faint) !important;\n  font-weight: 400 !important;\n}\n.re-certs[_ngcontent-%COMP%] {\n  display: flex;\n  flex-wrap: wrap;\n  gap: 6px;\n}\n.re-cert[_ngcontent-%COMP%] {\n  --%NS%background: #ecfdf5;\n  --%NS%color: #047857;\n  display: inline-flex;\n  align-items: center;\n  gap: 4px;\n  font-size: 12px;\n}\n.re-notes[_ngcontent-%COMP%] {\n  margin: 0;\n  color: var(--%NS%app-text-main);\n  font-size: 13px;\n  white-space: pre-line;\n}\n@media (max-width: 576px) {\n  .rx-bars__row[_ngcontent-%COMP%], \n   .rd-scale[_ngcontent-%COMP%] {\n    grid-template-columns: minmax(84px, 38%) 1fr 34px;\n    gap: 8px;\n  }\n  .ra-dist__row[_ngcontent-%COMP%] {\n    grid-template-columns: 22px 1fr 34px;\n  }\n  .ra-dist__label[_ngcontent-%COMP%] {\n    display: none;\n  }\n  .rx-bar-line[_ngcontent-%COMP%] {\n    min-width: 120px;\n  }\n  .re-dl[_ngcontent-%COMP%] {\n    grid-template-columns: 1fr;\n  }\n  .re-dl[_ngcontent-%COMP%]   dt[_ngcontent-%COMP%] {\n    padding-bottom: 0;\n    border-bottom: none;\n    font-size: 11px;\n  }\n}\n.rc-export__help[_ngcontent-%COMP%] {\n  margin: -2px 0 8px;\n  color: var(--%NS%app-text-muted);\n  font-size: 11px;\n}\n.rc-export__panel[_ngcontent-%COMP%] {\n  max-height: 38vh;\n  margin: 0 0 12px;\n  padding: 0;\n  overflow-y: auto;\n  border: 1px solid var(--%NS%app-border);\n  border-radius: var(--%NS%app-radius-control);\n  list-style: none;\n}\n.rc-export__panel-item[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  gap: 8px;\n  min-height: 40px;\n  padding: 0 12px;\n  border-bottom: 1px solid var(--%NS%app-border);\n  font-size: 13px;\n}\n.rc-export__panel-item[_ngcontent-%COMP%]:last-child {\n  border-bottom: none;\n}\n.rc-export__panel-item[_ngcontent-%COMP%]   ion-checkbox[_ngcontent-%COMP%] {\n  --%NS%size: 18px;\n  --%NS%checkbox-background-checked: var(--%NS%app-primary-dark);\n  --%NS%border-color-checked: var(--%NS%app-primary-dark);\n  flex: 1;\n  color: var(--%NS%app-text-main);\n}\n.rc-export__panel-item--off[_ngcontent-%COMP%] {\n  opacity: 0.55;\n}\n.rc-export__calib[_ngcontent-%COMP%] {\n  color: var(--%NS%app-success);\n  font-size: 11px;\n  white-space: nowrap;\n}\n.rc-export__calib--alto[_ngcontent-%COMP%] {\n  color: #b45309;\n}\n.rc-export__calib--bajo[_ngcontent-%COMP%] {\n  color: #1d4ed8;\n}\n/*# sourceMappingURL=results.page.css.map */'] });
var ResultsPage = _ResultsPage;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ResultsPage, [{
    type: Component,
    args: [{ selector: "app-results", standalone: true, imports: [
      IonHeader,
      IonToolbar,
      IonTitle,
      IonContent,
      IonButton,
      IonBackButton,
      IonButtons,
      IonIcon,
      IonSpinner,
      IonCard,
      IonCardContent,
      IonGrid,
      IonRow,
      IonCol,
      IonBadge,
      IonList,
      IonAccordionGroup,
      IonAccordion,
      IonItem,
      IonLabel,
      IonModal,
      IonSegment,
      IonSegmentButton,
      IonSelect,
      IonSelectOption,
      IonCheckbox,
      CupperResultCardComponent,
      CommonModule
    ], template: `<ion-header class="ion-no-border">
  <ion-toolbar class="rs-toolbar">
    <ion-buttons slot="start">
      <ion-back-button defaultHref="/dashboard" text=""></ion-back-button>
    </ion-buttons>
    <ion-title>
      <div class="rs-title">{{ esExtrinseco() ? 'Ficha t\xE9cnica' : 'Resultados finales' }}</div>
      @if (resultados(); as rs) {
        <div class="rs-subtitle">{{ rs.nombreSesion }} \xB7 {{ tituloFormato() }}</div>
      }
    </ion-title>
    <ion-buttons slot="end">
      <ion-button fill="outline" size="small" [disabled]="!resultados() || imprimiendo()"
        (click)="formatoHoja() ? abrirExportar() : exportarPDF()">
        <ion-icon name="download-outline" slot="start"></ion-icon>
        Exportar PDF
      </ion-button>
    </ion-buttons>
  </ion-toolbar>
</ion-header>

<!-- Medidor semicircular reutilizable (escala 0\u2013100) -->
<ng-template #medidor let-valor="valor" let-aguja="aguja" let-etiqueta="etiqueta">
  <ion-card class="rc-card rc-gauge">
    <ion-card-content>
      <svg class="rc-gauge__svg" viewBox="0 0 200 112" role="img" [attr.aria-label]="etiqueta + ': ' + (valor | number:'1.2-2')">
        @for (a of arcosMedidor; track a.clase) {
          <path [attr.d]="a.d" [attr.class]="'rc-gauge__arc ' + a.clase"></path>
        }
        <text x="100" y="22" text-anchor="middle" class="rc-gauge__tick">50</text>
        <line class="rc-gauge__needle" [attr.x1]="centroMedidor.x" [attr.y1]="centroMedidor.y"
          [attr.x2]="aguja.x" [attr.y2]="aguja.y"></line>
        <circle class="rc-gauge__hub" [attr.cx]="centroMedidor.x" [attr.cy]="centroMedidor.y" r="6"></circle>
      </svg>
      <p class="rc-gauge__value">{{ valor | number:'1.2-2' }}</p>
      <p class="rc-gauge__label">{{ etiqueta }}</p>
    </ion-card-content>
  </ion-card>
</ng-template>

<!-- Estado de la sesi\xF3n (Afectivo / Descriptivo) -->
<ng-template #metaSesion let-r="r" let-detalle="detalle">
  <ion-card class="rc-card">
    <ion-card-content class="rs-meta">
      <div class="rs-meta__status">
        <p class="rs-meta__headline">
          <ion-icon name="checkmark-circle-outline" aria-hidden="true"></ion-icon>
          Sesi\xF3n cerrada \xB7 {{ porcentajeCompletado() }}% completada
        </p>
        <p class="rs-meta__detail">{{ detalle }}</p>
      </div>
      <div class="rs-meta__stats">
        <div><strong>{{ r.totalMuestras }}</strong><span>Muestras</span></div>
        <div><strong>{{ r.catadores.length }}</strong><span>Catadores</span></div>
        <div><strong>{{ tituloFormato() }}</strong><span>Formato</span></div>
      </div>
    </ion-card-content>
  </ion-card>
</ng-template>

<!-- Participaci\xF3n sin puntajes (Afectivo / Descriptivo) -->
<ng-template #participacion let-r="r">
  <ion-card class="rc-card">
    <ion-card-content>
      <h2 class="rs-section-title rc-section-title--tight">Participaci\xF3n del panel</h2>
      <p class="rs-muted rs-note">Fichas enviadas por cada catador.</p>
      <ion-list lines="full" class="rx-list">
        @for (c of r.catadores; track c.cupperId) {
          <ion-item>
            <span slot="start" class="rc-avatar" aria-hidden="true">{{ c.nombre.charAt(0).toUpperCase() }}</span>
            <ion-label>
              <h3 class="rx-list__name">{{ c.nombre }}</h3>
              <p>{{ c.esOrganizador ? 'Organizador' : 'Catador' }} \xB7 {{ c.muestrasEvaluadas }} / {{ c.muestrasAsignadas }} muestras</p>
            </ion-label>
            <ion-badge slot="end" class="rc-chip" [class.rx-chip--ok]="c.estado === 'enviado'" [class.rx-chip--pending]="c.estado !== 'enviado'">
              {{ c.estado === 'enviado' ? 'Enviado' : 'Pendiente' }}
            </ion-badge>
          </ion-item>
        }
      </ion-list>
    </ion-card-content>
  </ion-card>
</ng-template>

<!-- Selector de muestra (Afectivo / Descriptivo) -->
<ng-template #selectorMuestra let-actual="actual">
  <ion-segment class="rx-samples" scrollable="true" [value]="actual" (ionChange)="seleccionarMuestraDetalle($event.detail.value)">
    @for (n of numerosMuestra(); track n) {
      <ion-segment-button [value]="n"><ion-label>Muestra {{ n }}</ion-label></ion-segment-button>
    }
  </ion-segment>
</ng-template>

<ion-content class="ion-padding rs-content">
  <main class="rs-container">
    @if (cargando()) {
      <div class="rs-center" role="status"><ion-spinner name="crescent"></ion-spinner></div>
    } @else if (error(); as mensaje) {
      <section class="cupping-card rs-center" role="alert">
        @if (accesoDenegado()) {
          <ion-icon name="lock-closed-outline" class="rs-lock" aria-hidden="true"></ion-icon>
          <h2>Resultados reservados al organizador</h2>
          <p>{{ mensaje }}</p>
        } @else if (panelAbierto()) {
          <ion-icon name="hourglass-outline" class="rs-lock" aria-hidden="true"></ion-icon>
          <h2>El panel sigue abierto</h2>
          <p class="rs-muted">
            Los resultados se consolidan cuando todos los catadores env\xEDan sus fichas.
            Desde el monitoreo puedes ver qui\xE9n falta, cerrar muestras o finalizar el panel.
          </p>
        } @else {
          <p>{{ mensaje }}</p>
        }
        <div class="rs-actions">
          @if (panelAbierto()) {
            <ion-button class="primary-btn" (click)="irAMonitoreo()">Monitorear y finalizar panel</ion-button>
          }
          <ion-button fill="outline" (click)="volverAlPanel()">Volver al panel</ion-button>
        </div>
      </section>
    } @else if (resultados(); as r) {
      @if (esCombinado()) {
        <!-- \u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550 FORMATO COMBINADO \u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550 -->

        <!-- Medidores -->
        <ion-grid class="rc-grid-flush">
          <ion-row>
            <ion-col size="12" size-md="6">
              <ng-container *ngTemplateOutlet="medidor; context: {
                valor: promedioPanel(), aguja: agujaPanel(), etiqueta: 'Promedio puntaje del panel' }"></ng-container>
            </ion-col>
            <ion-col size="12" size-md="6">
              <ng-container *ngTemplateOutlet="medidor; context: {
                valor: muestraEnMedidor()?.puntajePromedioPanel ?? 0,
                aguja: agujaMuestra(),
                etiqueta: 'Promedio del panel por muestra \xB7 Muestra ' + (muestraEnMedidor()?.numeroMuestra ?? '\u2014') }"></ng-container>
            </ion-col>
          </ion-row>
        </ion-grid>

        <!-- Estado de la sesi\xF3n -->
        <ng-container *ngTemplateOutlet="metaSesion; context: { r: r, detalle: hayRecorte()
          ? 'Consolidaci\xF3n mediante promedio recortado SCA (se descartan m\xE1ximo y m\xEDnimo con 5 o m\xE1s catadores).'
          : 'Consolidaci\xF3n mediante promedio simple (menos de 5 fichas por muestra).' }"></ng-container>

        <!-- Ranking -->
        <ion-card class="rc-card">
          <ion-card-content>
            <h2 class="rs-section-title rc-section-title--tight">Ranking \u2014 promedio del panel</h2>
            <p class="rs-muted rs-note">Haz clic en una muestra para ver su promedio del panel en el medidor.</p>
            <div class="rs-table-wrap">
              <table class="rs-table rc-ranking">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Muestra</th>
                    <th scope="col">Fichas</th>
                    <th scope="col">M\xEDn \u2013 M\xE1x</th>
                    <th scope="col">Puntaje panel</th>
                    <th scope="col">Clasificaci\xF3n</th>
                  </tr>
                </thead>
                <tbody>
                  @for (fila of ranking(); track fila.numeroMuestra) {
                    @let activa = fila.numeroMuestra === muestraEnMedidor()?.numeroMuestra;
                    <tr class="rc-ranking__row" [class.rc-ranking__row--active]="activa"
                      tabindex="0" [attr.aria-selected]="activa"
                      (click)="seleccionarMuestraMedidor(fila.numeroMuestra)"
                      (keydown.enter)="seleccionarMuestraMedidor(fila.numeroMuestra)"
                      (keydown.space)="$event.preventDefault(); seleccionarMuestraMedidor(fila.numeroMuestra)">
                      <td class="rs-rank">
                        <ion-icon [name]="fila.posicion === 1 ? 'trophy-outline' : 'medal-outline'"
                          [class]="'rc-medal rc-medal--' + (fila.posicion <= 3 ? fila.posicion : 'n')" aria-hidden="true"></ion-icon>
                        #{{ fila.posicion }}
                      </td>
                      <td>
                        <span class="rc-ranking__name">Muestra {{ fila.numeroMuestra }}</span>
                        @if (activa) { <ion-badge class="rc-chip rc-chip--live">en el medidor</ion-badge> }
                        @if (fila.cerradaForzada) { <span class="rs-tag">cerrada</span> }
                      </td>
                      <td>{{ fila.evaluacionesRecibidas }} / {{ fila.evaluacionesEsperadas }}</td>
                      <td class="rs-muted">{{ fila.puntajeMin | number:'1.2-2' }} \u2013 {{ fila.puntajeMax | number:'1.2-2' }}</td>
                      <td class="rs-score">
                        {{ fila.puntajePromedioPanel | number:'1.2-2' }}
                        @if (fila.recortado) {
                          <span class="rs-tag" title="Promedio simple: {{ fila.puntajePromedioSimple | number:'1.2-2' }}">recortado</span>
                        }
                      </td>
                      <td>
                        <ion-badge class="rc-chip" [style.--background]="fila.clasificacion.fondo" [style.--color]="fila.clasificacion.color">
                          {{ fila.clasificacion.etiqueta }}
                        </ion-badge>
                      </td>
                    </tr>
                  } @empty {
                    <tr><td colspan="6" class="rs-muted">Ninguna muestra recibi\xF3 fichas.</td></tr>
                  }
                </tbody>
              </table>
            </div>
            @if (muestrasSinFichas().length > 0) {
              <p class="rs-muted rs-note rc-note-bottom">
                Sin fichas: {{ muestrasSinFichas().length }} muestra(s) cerradas sin evaluaciones.
              </p>
            }
          </ion-card-content>
        </ion-card>

        <!-- An\xE1lisis de catadores -->
        <section class="rc-block">
          <h2 class="rs-section-title rc-section-title--tight">An\xE1lisis de catadores</h2>
          <p class="rs-muted rs-note">Participaci\xF3n y consistencia individual dentro del panel. Selecciona un catador para ver su reporte.</p>
          <ion-grid class="rc-grid-flush">
            <ion-row>
              @for (catador of r.catadores; track catador.cupperId) {
                <ion-col size="12" size-sm="6" size-lg="4">
                  <button type="button" class="rc-cupper-select"
                    [class.rc-cupper-select--active]="catador.cupperId === catadorReporte()?.cupperId"
                    [attr.aria-pressed]="catador.cupperId === catadorReporte()?.cupperId"
                    (click)="seleccionarCatadorReporte(catador.cupperId)">
                    <app-cupper-result-card [catador]="catador"></app-cupper-result-card>
                  </button>
                </ion-col>
              }
            </ion-row>
          </ion-grid>
        </section>

        <!-- Reporte de sesi\xF3n individual -->
        @if (catadorReporte(); as cat) {
          <ion-card class="rc-card">
            <ion-card-content>
              <h2 class="rs-section-title rc-section-title--tight">Reporte de sesi\xF3n individual</h2>
              <div class="rc-report__head">
                <div class="rc-report__who">
                  <span class="rc-avatar" aria-hidden="true">{{ cat.nombre.charAt(0).toUpperCase() }}</span>
                  <div>
                    <p class="rc-report__name">{{ cat.nombre }}</p>
                    <p class="rc-report__meta">
                      {{ cat.muestrasEvaluadas }} de {{ cat.muestrasAsignadas }} muestras evaluadas \xB7 estado {{ cat.estado }}
                    </p>
                  </div>
                </div>
                <div class="rc-report__score">
                  <strong>{{ cat.puntajePromedio | number:'1.2-2' }}</strong>
                  <span>Promedio</span>
                </div>
              </div>

              @if (fichasReporte().length > 0) {
                <p class="rs-muted rs-note">Haz clic en una ficha para ver su detalle.</p>
                <ion-accordion-group class="rc-fichas" [multiple]="false">
                  @for (ficha of fichasReporte(); track ficha.numeroMuestra) {
                    <ion-accordion [value]="cat.cupperId + '-' + ficha.numeroMuestra" class="rc-ficha">
                      <ion-item slot="header" lines="none" class="rc-ficha__header">
                        <ion-label>Muestra {{ ficha.numeroMuestra }}</ion-label>
                        <ion-badge slot="end" class="rc-chip" [style.--background]="ficha.clasificacion.fondo" [style.--color]="ficha.clasificacion.color">
                          {{ ficha.clasificacion.etiqueta }}
                        </ion-badge>
                        <span slot="end" class="rc-ficha__score">{{ ficha.puntaje | number:'1.2-2' }}</span>
                      </ion-item>
                      <div slot="content" class="rc-ficha__body">
                        @if (ficha.atributos.length > 0) {
                          <div class="rc-ficha__row rc-ficha__row--head">
                            <span>Atributo</span><span class="rc-ficha__cols"><em>Intensidad</em><em>Calidad</em></span>
                          </div>
                          @for (a of ficha.atributos; track a.clave) {
                            <div class="rc-ficha__row">
                              <span>{{ a.etiqueta }}</span>
                              <span class="rc-ficha__cols">
                                <strong>{{ a.intensidad === null ? '\u2014' : (a.intensidad | number:'1.0-2') }}</strong>
                                <strong>{{ a.calidad === null ? '\u2014' : (a.calidad | number:'1.0-2') }}</strong>
                              </span>
                            </div>
                          }
                        }
                        @if (ficha.impresionGlobal !== null) {
                          <div class="rc-ficha__row"><span>Impresi\xF3n global</span><strong>{{ ficha.impresionGlobal | number:'1.0-2' }}</strong></div>
                        }
                        <div class="rc-ficha__row"><span>Tazas no uniformes</span><strong>{{ ficha.tazasNoUniformes }}</strong></div>
                        <div class="rc-ficha__row"><span>Tazas defectuosas</span><strong>{{ ficha.tazasDefectuosas }}</strong></div>
                        <div class="rc-ficha__row rc-ficha__row--total">
                          <span>Puntaje final</span><strong>{{ ficha.puntaje | number:'1.2-2' }}</strong>
                        </div>
                        <div class="rc-ficha__actions">
                          <ion-button size="small" fill="outline"
                            (click)="abrirExportar({ numeroMuestra: ficha.numeroMuestra, cupperId: cat.cupperId })">
                            Exportar PDF
                          </ion-button>
                        </div>
                      </div>
                    </ion-accordion>
                  }
                </ion-accordion-group>
              } @else {
                <p class="rs-muted rs-note">Este catador a\xFAn no tiene fichas enviadas.</p>
              }
            </ion-card-content>
          </ion-card>
        }

        <!-- F\xF3rmula -->
        <section class="rs-formula">
          <h2 class="rs-section-title">F\xF3rmula CVA aplicada</h2>
          <p class="rs-formula__expr">S = 0.65625 \xD7 \u03A3h\u1D62 + 52.75 \u2212 2u \u2212 4d</p>
          <p class="rs-muted">
            El consolidado descarta el valor m\xE1s alto y el m\xE1s bajo por muestra cuando hay 5 o m\xE1s fichas.
          </p>
        </section>

        <div class="rs-actions">
          <ion-button fill="outline" (click)="volverAlPanel()">Volver al panel</ion-button>
          <ion-button class="primary-btn" [disabled]="imprimiendo()" (click)="abrirExportar()">
            <ion-icon name="download-outline" slot="start"></ion-icon>
            Exportar a PDF (Formato SCA)
          </ion-button>
        </div>
      } @else if (esAfectivo()) {
        <!-- \u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550 FORMATO AFECTIVO \u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550 -->
        <ng-container *ngTemplateOutlet="metaSesion; context: { r: r,
          detalle: 'Escala hed\xF3nica de 9 puntos: 1 = extremadamente baja \xB7 5 = neutral \xB7 9 = extremadamente alta.' }"></ng-container>

        <!-- Promedio hed\xF3nico por muestra -->
        <ion-card class="rc-card">
          <ion-card-content>
            <h2 class="rs-section-title rc-section-title--tight">Agrado del panel \u2014 escala hed\xF3nica (1 a 9)</h2>
            <p class="rs-muted rs-note">Promedio de la Impresi\xF3n Global por muestra. Haz clic en una muestra para ver sus votos.</p>
            <div class="rs-table-wrap">
              <table class="rs-table rc-ranking">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Muestra</th>
                    <th scope="col">Votos</th>
                    <th scope="col" class="ra-col-bar">Promedio hed\xF3nico</th>
                    <th scope="col">Valoraci\xF3n</th>
                  </tr>
                </thead>
                <tbody>
                  @for (fila of resultadosHedonicos(); track fila.numeroMuestra) {
                    @let activa = fila.numeroMuestra === hedonicoSeleccionado()?.numeroMuestra;
                    <tr class="rc-ranking__row" [class.rc-ranking__row--active]="activa" tabindex="0" [attr.aria-selected]="activa"
                      (click)="seleccionarMuestraDetalle(fila.numeroMuestra)"
                      (keydown.enter)="seleccionarMuestraDetalle(fila.numeroMuestra)"
                      (keydown.space)="$event.preventDefault(); seleccionarMuestraDetalle(fila.numeroMuestra)">
                      <td class="rs-rank">{{ fila.posicion ? '#' + fila.posicion : '\u2014' }}</td>
                      <td><span class="rc-ranking__name">Muestra {{ fila.numeroMuestra }}</span></td>
                      <td>{{ fila.totalVotos }}</td>
                      <td class="ra-col-bar">
                        <div class="rx-bar-line">
                          <div class="rx-bar rx-bar--hedonic"><i [style.width.%]="(fila.promedio ?? 0) / 9 * 100"></i></div>
                          <strong class="rs-score">{{ fila.promedio === null ? '\u2014' : (fila.promedio | number:'1.2-2') }}</strong>
                        </div>
                      </td>
                      <td><ion-badge class="rc-chip ra-chip">{{ fila.etiqueta }}</ion-badge></td>
                    </tr>
                  } @empty {
                    <tr><td colspan="5" class="rs-muted">La sesi\xF3n no tiene muestras.</td></tr>
                  }
                </tbody>
              </table>
            </div>
          </ion-card-content>
        </ion-card>

        @if (hedonicoSeleccionado(); as sel) {
          <ng-container *ngTemplateOutlet="selectorMuestra; context: { actual: sel.numeroMuestra }"></ng-container>
          <ion-grid class="rc-grid-flush">
            <ion-row>
              <!-- Distribuci\xF3n de votos -->
              <ion-col size="12" size-md="6">
                <ion-card class="rc-card">
                  <ion-card-content>
                    <h2 class="rs-section-title rc-section-title--tight">Distribuci\xF3n de votos \xB7 Muestra {{ sel.numeroMuestra }}</h2>
                    <p class="rs-muted rs-note">Cu\xE1ntos catadores eligieron cada punto de la escala (Impresi\xF3n Global).</p>
                    @if (sel.totalVotos > 0) {
                      <ul class="ra-dist" role="list">
                        @for (d of sel.distribucion; track d.valor) {
                          <li class="ra-dist__row" [class.ra-dist__row--empty]="d.votos === 0">
                            <span class="ra-dist__value">{{ d.valor }}</span>
                            <span class="ra-dist__label">{{ d.etiqueta }}</span>
                            <div class="rx-bar rx-bar--hedonic"><i [style.width.%]="d.porcentaje"></i></div>
                            <strong class="ra-dist__count">{{ d.votos }}</strong>
                          </li>
                        }
                      </ul>
                      <p class="ra-dist__total">
                        {{ sel.totalVotos }} voto(s) \xB7 promedio <strong>{{ sel.promedio | number:'1.2-2' }}</strong> ({{ sel.etiqueta }})
                      </p>
                    } @else {
                      <p class="rs-muted rs-note">Esta muestra no recibi\xF3 votos de Impresi\xF3n Global.</p>
                    }
                  </ion-card-content>
                </ion-card>
              </ion-col>
              <!-- Calidad por atributo -->
              <ion-col size="12" size-md="6">
                <ion-card class="rc-card">
                  <ion-card-content>
                    <h2 class="rs-section-title rc-section-title--tight">Calidad por atributo \xB7 Muestra {{ sel.numeroMuestra }}</h2>
                    <p class="rs-muted rs-note">Promedio del panel en la escala hed\xF3nica (1 a 9).</p>
                    <ul class="rx-bars" role="list">
                      @for (a of sel.atributos; track a.clave) {
                        <li class="rx-bars__row">
                          <span class="rx-bars__label">{{ a.etiqueta }}</span>
                          <div class="rx-bar rx-bar--hedonic"><i [style.width.%]="a.porcentaje"></i></div>
                          <strong class="rx-bars__value">{{ a.valor === null ? '\u2014' : (a.valor | number:'1.1-1') }}</strong>
                        </li>
                      }
                    </ul>
                  </ion-card-content>
                </ion-card>
              </ion-col>
            </ion-row>
          </ion-grid>
        }

        <ng-container *ngTemplateOutlet="participacion; context: { r: r }"></ng-container>

        <div class="rs-actions">
          <ion-button fill="outline" (click)="volverAlPanel()">Volver al panel</ion-button>
          <ion-button class="primary-btn" [disabled]="imprimiendo()" (click)="exportarPDF()">
            <ion-icon name="download-outline" slot="start"></ion-icon>
            Exportar a PDF (Formato SCA)
          </ion-button>
        </div>
      } @else if (esDescriptivo()) {
        <!-- \u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550 FORMATO DESCRIPTIVO \u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550 -->
        <ng-container *ngTemplateOutlet="metaSesion; context: { r: r,
          detalle: 'Perfil sensorial objetivo: intensidad f\xEDsica de 0 (ausente) a 15 (muy intensa), sin juicio de calidad.' }"></ng-container>

        @if (perfilSeleccionado(); as perfil) {
          <ng-container *ngTemplateOutlet="selectorMuestra; context: { actual: perfil.numeroMuestra }"></ng-container>

          <ion-card class="rc-card">
            <ion-card-content>
              <div class="rd-head">
                <div>
                  <h2 class="rs-section-title rc-section-title--tight">Perfil de intensidad \xB7 Muestra {{ perfil.numeroMuestra }}</h2>
                  <p class="rs-muted rs-note">Promedio del panel por atributo ({{ perfil.fichas }} ficha(s)).</p>
                </div>
              </div>
              <div class="rd-scale" aria-hidden="true">
                <span></span><span class="rd-scale__ticks"><em>0</em><em>5</em><em>10</em><em>15</em></span><span></span>
              </div>
              <ul class="rx-bars rd-bars" role="list">
                @for (a of perfil.atributos; track a.clave) {
                  <li class="rx-bars__row">
                    <span class="rx-bars__label">{{ a.etiqueta }}</span>
                    <div class="rx-bar rx-bar--intensity rd-bar"><i [style.width.%]="a.porcentaje"></i></div>
                    <strong class="rx-bars__value">{{ a.valor === null ? '\u2014' : (a.valor | number:'1.1-1') }}</strong>
                  </li>
                }
              </ul>
            </ion-card-content>
          </ion-card>
        }

        <!-- Comparativa entre muestras -->
        <ion-card class="rc-card">
          <ion-card-content>
            <h2 class="rs-section-title rc-section-title--tight">Comparativa de intensidades</h2>
            <p class="rs-muted rs-note">Promedio del panel (0\u201315). El tono de cada celda es proporcional a la intensidad.</p>
            <div class="rs-table-wrap">
              <table class="rs-table rd-matrix">
                <thead>
                  <tr>
                    <th scope="col">Atributo</th>
                    @for (p of perfilesDescriptivos(); track p.numeroMuestra) {
                      <th scope="col" class="rd-matrix__num">M{{ p.numeroMuestra }}</th>
                    }
                  </tr>
                </thead>
                <tbody>
                  @for (atr of atributosCva; track atr.clave; let i = $index) {
                    <tr>
                      <th scope="row">{{ atr.etiqueta }}</th>
                      @for (p of perfilesDescriptivos(); track p.numeroMuestra) {
                        <td class="rd-matrix__num">
                          <span class="rd-cell" [class.rd-cell--dark]="p.atributos[i].porcentaje > 55" [style.--rd-alpha]="p.atributos[i].porcentaje / 100">
                            {{ p.atributos[i].valor === null ? '\u2014' : (p.atributos[i].valor | number:'1.1-1') }}
                          </span>
                        </td>
                      }
                    </tr>
                  }
                </tbody>
              </table>
            </div>
          </ion-card-content>
        </ion-card>

        <ng-container *ngTemplateOutlet="participacion; context: { r: r }"></ng-container>

        <div class="rs-actions">
          <ion-button fill="outline" (click)="volverAlPanel()">Volver al panel</ion-button>
          <ion-button class="primary-btn" [disabled]="imprimiendo()" (click)="abrirExportar()">
            <ion-icon name="download-outline" slot="start"></ion-icon>
            Exportar a PDF (Formato SCA)
          </ion-button>
        </div>
      } @else if (esExtrinseco()) {
        <!-- \u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550 FORMATO EXTR\xCDNSECO \u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550 -->
        @for (ficha of fichasTecnicas(); track ficha.numeroMuestra + '-' + $index) {
          <ion-card class="rc-card re-card">
            <ion-card-content>
              <div class="re-head">
                <div class="re-head__title">
                  <ion-icon name="document-text-outline" aria-hidden="true"></ion-icon>
                  <div>
                    <h2>Ficha t\xE9cnica del caf\xE9 \xB7 Muestra {{ ficha.numeroMuestra }}</h2>
                    <p class="rs-muted">
                      @if (ficha.registradaPor) { Registrada por {{ ficha.registradaPor }} }
                      @if (ficha.registradaEn) { \xB7 {{ ficha.registradaEn | date:'mediumDate' }} }
                    </p>
                  </div>
                </div>
              </div>

              <ion-grid class="rc-grid-flush">
                <ion-row>
                  @for (seccion of ficha.secciones; track seccion.titulo) {
                    <ion-col size="12" size-md="6" size-xl="4">
                      <section class="re-section">
                        <h3 class="rs-section-title">{{ seccion.titulo }}</h3>
                        <dl class="re-dl">
                          @for (campo of seccion.campos; track campo.etiqueta) {
                            <dt>{{ campo.etiqueta }}</dt>
                            <dd [class.re-dl__empty]="campo.valor === '\u2014'">{{ campo.valor }}</dd>
                          }
                        </dl>
                      </section>
                    </ion-col>
                  }
                </ion-row>
              </ion-grid>

              <section class="re-section">
                <h3 class="rs-section-title">Certificaciones</h3>
                @if (ficha.certificaciones.length > 0) {
                  <div class="re-certs">
                    @for (c of ficha.certificaciones; track c) {
                      <ion-badge class="rc-chip re-cert"><ion-icon name="ribbon-outline" aria-hidden="true"></ion-icon> {{ c }}</ion-badge>
                    }
                  </div>
                } @else {
                  <p class="rs-muted rs-note">Sin certificaciones registradas.</p>
                }
              </section>

              @if (ficha.notas) {
                <section class="re-section">
                  <h3 class="rs-section-title">Notas</h3>
                  <p class="re-notes">{{ ficha.notas }}</p>
                </section>
              }
            </ion-card-content>
          </ion-card>
        } @empty {
          <ion-card class="rc-card">
            <ion-card-content class="rs-center">
              <ion-icon name="document-text-outline" class="rs-lock" aria-hidden="true"></ion-icon>
              <p>Esta sesi\xF3n no tiene fichas t\xE9cnicas registradas.</p>
            </ion-card-content>
          </ion-card>
        }

        <div class="rs-actions">
          <ion-button fill="outline" (click)="volverAlPanel()">Volver al panel</ion-button>
          <ion-button class="primary-btn" [disabled]="imprimiendo() || fichasTecnicas().length === 0" (click)="exportarPDF()">
            <ion-icon name="download-outline" slot="start"></ion-icon>
            Exportar Ficha T\xE9cnica a PDF
          </ion-button>
        </div>
      } @else {
        <!-- \u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550 FORMATO NO RECONOCIDO (vista original) \u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550 -->
        <section class="cupping-card rs-meta">
          <div class="rs-meta__status">
            <p class="rs-meta__headline">
              <ion-icon name="checkmark-circle-outline" aria-hidden="true"></ion-icon>
              Sesi\xF3n cerrada \xB7 {{ porcentajeCompletado() }}% completada
            </p>
            <p class="rs-meta__detail">
              {{ hayRecorte()
                ? 'Consolidaci\xF3n mediante promedio recortado SCA (se descartan m\xE1ximo y m\xEDnimo con 5 o m\xE1s catadores).'
                : 'Consolidaci\xF3n mediante promedio simple (menos de 5 fichas por muestra).' }}
            </p>
          </div>
          <div class="rs-meta__stats">
            <div><strong>{{ r.totalMuestras }}</strong><span>Muestras</span></div>
            <div><strong>{{ r.catadores.length }}</strong><span>Catadores</span></div>
            <div><strong>{{ tituloFormato() }}</strong><span>Formato</span></div>
          </div>
        </section>
  
        <section class="cupping-card">
          <h2 class="rs-section-title">Ranking \u2014 promedio del panel</h2>
          <div class="rs-table-wrap">
            <table class="rs-table">
              <thead>
                <tr>
                  <th scope="col">#</th>
                  <th scope="col">Muestra</th>
                  <th scope="col">Fichas</th>
                  <th scope="col">M\xEDn \u2013 M\xE1x</th>
                  <th scope="col">Puntaje panel</th>
                  <th scope="col">Clasificaci\xF3n</th>
                </tr>
              </thead>
              <tbody>
                @for (fila of ranking(); track fila.numeroMuestra) {
                  <tr>
                    <td class="rs-rank">
                      @if (fila.posicion === 1) {
                        <ion-icon name="trophy-outline" aria-label="Primer lugar"></ion-icon>
                      }
                      #{{ fila.posicion }}
                    </td>
                    <td>
                      Muestra {{ fila.numeroMuestra }}
                      @if (fila.cerradaForzada) { <span class="rs-tag">cerrada</span> }
                    </td>
                    <td>{{ fila.evaluacionesRecibidas }} / {{ fila.evaluacionesEsperadas }}</td>
                    <td class="rs-muted">{{ fila.puntajeMin | number:'1.2-2' }} \u2013 {{ fila.puntajeMax | number:'1.2-2' }}</td>
                    <td class="rs-score">
                      {{ fila.puntajePromedioPanel | number:'1.2-2' }}
                      @if (fila.recortado) {
                        <span class="rs-tag" title="Promedio simple: {{ fila.puntajePromedioSimple | number:'1.2-2' }}">recortado</span>
                      }
                    </td>
                    <td>
                      <span class="rs-badge" [style.color]="fila.clasificacion.color" [style.background]="fila.clasificacion.fondo">
                        {{ fila.clasificacion.etiqueta }}
                      </span>
                    </td>
                  </tr>
                } @empty {
                  <tr><td colspan="6" class="rs-muted">Ninguna muestra recibi\xF3 fichas.</td></tr>
                }
              </tbody>
              @if (ranking().length > 0) {
                <tfoot>
                  <tr>
                    <td colspan="4">Promedio del panel</td>
                    <td class="rs-score">{{ promedioPanel() | number:'1.2-2' }}</td>
                    <td>
                      <span class="rs-badge" [style.color]="clasificacionPanel().color" [style.background]="clasificacionPanel().fondo">
                        {{ clasificacionPanel().etiqueta }}
                      </span>
                    </td>
                  </tr>
                </tfoot>
              }
            </table>
          </div>
          @if (muestrasSinFichas().length > 0) {
            <p class="rs-muted rs-note">
              Sin fichas: {{ muestrasSinFichas().length }} muestra(s) cerradas sin evaluaciones.
            </p>
          }
        </section>
  
        <section>
          <h2 class="rs-section-title">An\xE1lisis de catadores</h2>
          <p class="rs-muted rs-note">Participaci\xF3n y consistencia individual dentro del panel.</p>
          <div class="rs-grid">
            @for (catador of r.catadores; track catador.cupperId) {
              <app-cupper-result-card [catador]="catador"></app-cupper-result-card>
            }
          </div>
        </section>
  
        <section class="rs-formula">
          <h2 class="rs-section-title">F\xF3rmula CVA aplicada</h2>
          <p class="rs-formula__expr">S = 0.65625 \xD7 \u03A3h\u1D62 + 52.75 \u2212 2u \u2212 4d</p>
          <p class="rs-muted">
            El consolidado descarta el valor m\xE1s alto y el m\xE1s bajo por muestra cuando hay 5 o m\xE1s fichas.
          </p>
        </section>
  
        <div class="rs-actions">
          <ion-button fill="outline" (click)="volverAlPanel()">Volver al panel</ion-button>
          <ion-button class="primary-btn" (click)="exportarPDF()">
            <ion-icon name="download-outline" slot="start"></ion-icon>
            Exportar a PDF (Formato SCA)
          </ion-button>
        </div>
      }
    }
  </main>

  <!-- Modal de exportaci\xF3n (formatos con hoja SCA: Combinado y Descriptivo) -->
  @if (formatoHoja()) {
    <ion-modal class="rc-export-modal" [isOpen]="modalExportarAbierto()" (didDismiss)="cerrarExportar()">
      <ng-template>
        <div class="rc-export">
          <div class="rc-export__head">
            <h2>\xBFC\xF3mo quieres exportar tu PDF?</h2>
            <ion-button fill="clear" size="small" aria-label="Cerrar" (click)="cerrarExportar()">
              <ion-icon name="close-outline" slot="icon-only"></ion-icon>
            </ion-button>
          </div>

          <label class="rc-export__label" for="rc-export-muestra">Muestra #</label>
          <ion-select id="rc-export-muestra" class="rc-export__select" interface="popover" placeholder="Selecciona una muestra"
            [value]="muestraHoja()" (ionChange)="cambiarMuestraExportar($event.detail.value)">
            @for (n of numerosMuestra(); track n) {
              <ion-select-option [value]="n">Muestra {{ n }}</ion-select-option>
            }
          </ion-select>

          <ion-segment class="rc-export__segment" [value]="modoExportacion()" (ionChange)="cambiarModoExportacion($event.detail.value)">
            <ion-segment-button value="catador"><ion-label>Por catador</ion-label></ion-segment-button>
            <ion-segment-button value="panel"><ion-label>Panel</ion-label></ion-segment-button>
          </ion-segment>

          @if (modoExportacion() === 'catador') {
            <label class="rc-export__label" for="rc-export-catador">Selecciona el catador</label>
            <ion-select id="rc-export-catador" class="rc-export__select" interface="popover" placeholder="Selecciona un catador"
              [value]="catadorExportarId()" (ionChange)="cambiarCatadorExportar($event.detail.value)">
              @for (c of catadoresExportables(); track c.cupperId) {
                <ion-select-option [value]="c.cupperId">{{ c.nombre }}</ion-select-option>
              }
            </ion-select>
          } @else {
            <p class="rc-export__label">Catadores incluidos en el consolidado</p>
            <p class="rc-export__help">Desmarca a los catadores descalibrados: sus fichas no se usar\xE1n en el PDF.</p>
            <ul class="rc-export__panel" role="list">
              @for (o of opcionesPanel(); track o.id) {
                <li class="rc-export__panel-item" [class.rc-export__panel-item--off]="!o.tieneFicha">
                  <ion-checkbox labelPlacement="end" justify="start"
                    [checked]="o.seleccionado && o.tieneFicha" [disabled]="!o.tieneFicha"
                    (ionChange)="toggleCatadorPanel(o.id, $event.detail.checked)">
                    {{ o.nombre }}
                  </ion-checkbox>
                  <span class="rc-export__calib"
                    [class.rc-export__calib--alto]="o.desviacion > 0.5" [class.rc-export__calib--bajo]="o.desviacion < -0.5">
                    @if (!o.tieneFicha) { sin ficha }
                    @else if (o.desviacion > 0.5) { +{{ o.desviacion | number:'1.2-2' }} generoso }
                    @else if (o.desviacion < -0.5) { {{ o.desviacion | number:'1.2-2' }} estricto }
                    @else { calibrado }
                  </span>
                </li>
              }
            </ul>
          }

          <ion-button expand="block" class="primary-btn rc-export__go" [disabled]="!puedeConfirmarExportar()" (click)="confirmarExportar()">
            <ion-icon name="download-outline" slot="start"></ion-icon>
            Exportar a PDF (Formato SCA)
          </ion-button>
          <p class="rc-export__hint">En la ventana de impresi\xF3n elige "Guardar como PDF".</p>
        </div>
      </ng-template>
    </ion-modal>
  }

  <!-- \u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550 Piezas de la hoja SCA (se copian al iframe de impresi\xF3n) \u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550 -->
  <ng-template #scaSlider let-titulo="titulo" let-v="v">
    <div class="sca-attr">
      <div class="sca-attr__name"><b>{{ titulo }}</b><small>Intensidad@if (v !== null) {<span class="sca-attr__val">{{ v | number:'1.0-1' }}</span>}</small></div>
      <div class="sca-slider">
        <div class="sca-slider__zones"><span>BAJA</span><span>MEDIA</span><span>ALTA</span></div>
        <div class="sca-slider__bar">
          @if (v !== null) {
            <i class="sca-slider__mark" [style.left.%]="v / 15 * 100"></i>
          }
        </div>
        <div class="sca-slider__ticks"></div>
        <div class="sca-slider__nums"><span style="left:0">0</span><span style="left:33.333%">5</span><span style="left:66.667%">10</span><span style="left:100%">15</span></div>
      </div>
    </div>
  </ng-template>

  <ng-template #scaCirculos let-v="v">
    <div class="sca-circles">
      @for (n of escala9; track n) {
        <span class="sca-c" [class.sca-c--on]="circuloMarcado(v) === n">{{ n }}</span>
      }
      <span class="sca-final" [class.sca-final--on]="v !== null">{{ v === null ? 'FINAL' : (v | number:'1.0-2') }}</span>
    </div>
  </ng-template>

  <ng-template #scaCasilla let-on="on" let-etiqueta="etiqueta" let-principal="principal" let-detalle="detalle">
    <span class="sca-cb" [class.sca-cb--on]="on"><i></i>@if (principal) {<b>{{ etiqueta }}</b>} @else {{{ etiqueta }}}@if (detalle) { <small>{{ detalle }}</small>}</span>
  </ng-template>

  <ng-template #scaDescriptores let-marcadas="marcadas">
    @for (fila of descriptoresSca; track $index) {
      <div class="sca-desc__row">
        @for (c of fila; track c.clave) {
          <ng-container *ngTemplateOutlet="scaCasilla; context: { on: marcadas.has(c.clave), etiqueta: c.etiqueta, principal: c.principal }"></ng-container>
        }
      </div>
    }
  </ng-template>

  <ng-template #scaGustos let-marcadas="marcadas">
    <div class="sca-gustos">
      <p class="sca-label">Gustos Predominantes (2)</p>
      @for (g of gustosSca; track g.clave) {
        <div class="sca-desc__row"><ng-container *ngTemplateOutlet="scaCasilla; context: { on: marcadas.has(g.clave), etiqueta: g.etiqueta, principal: true }"></ng-container></div>
      }
    </div>
  </ng-template>

  <ng-template #scaBoca let-marcadas="marcadas">
    @for (b of bocaSca; track b.clave) {
      <div class="sca-desc__row"><ng-container *ngTemplateOutlet="scaCasilla; context: { on: marcadas.has(b.clave), etiqueta: b.etiqueta, principal: true, detalle: b.detalle }"></ng-container></div>
    }
  </ng-template>

  <ng-template #scaNotas let-texto="texto" let-titulo="titulo">
    <div class="sca-notes"><p class="sca-label">{{ titulo || 'Notas' }}</p>@if (texto) {<p class="sca-notes__text">{{ texto }}</p>}</div>
  </ng-template>

  <ng-template #scaTazas let-n="n">
    <span class="sca-boxes">@for (i of [1, 2, 3, 4, 5]; track i) {<i [class.on]="n !== null && i <= circuloMarcadoTazas(n)"></i>}</span>
  </ng-template>

  <!--
    Reporte imprimible: HTML plano (sin componentes Ionic) que ImpresionService
    copia a un iframe aislado con su propia hoja de estilos (clases sca-* y rp-*).
  -->
  @if (resultados(); as r) {
    <div #reporteImprimible hidden aria-hidden="true">
      @if (formatoHoja() && hojaSca(); as h) {
        <article class="sca-page" [class.sca-page--combinado]="h.formato === 'combinado'">
          <!-- Cabecera -->
          <header class="sca-head">
            <div class="sca-head__main">
              <p class="sca-head__brand">PacamaraQs \xB7 Evaluaci\xF3n sensorial CVA</p>
              <h1>{{ h.titulo }}</h1>
              <div class="sca-fields">
                <div class="sca-field sca-field--wide"><span>Nombre</span><b>{{ h.nombre }}</b></div>
                <div class="sca-field"><span>Fecha</span><b>{{ h.fecha }}</b></div>
                <div class="sca-field sca-field--wide"><span>Objetivo</span><b>{{ h.objetivo }}</b></div>
                <div class="sca-field"><span>N\xBA de muestra</span><b>{{ h.numeroMuestra }}</b></div>
              </div>
            </div>
            @if (h.formato === 'combinado') {
              <div class="sca-legend">
                <p>IMPRESI\xD3N DE CALIDAD</p>
                <ol>@for (l of LEYENDA_HEDONICA; track l.n) {<li><i>{{ l.n }}</i>{{ l.etiqueta.toUpperCase() }}</li>}</ol>
              </div>
            }
          </header>

          <!-- Consolidado del panel -->
          @if (h.resumenPanel; as rp) {
            <section class="sca-kpis" aria-label="Consolidado del panel">
              @if (rp.puntaje !== null) {
                <div class="sca-kpi"><strong>{{ rp.puntaje | number:'1.2-2' }}</strong><span>Puntaje panel</span></div>
                <div class="sca-kpi"><strong>{{ rp.clasificacion }}</strong><span>Clasificaci\xF3n</span></div>
              }
              <div class="sca-kpi"><strong>{{ rp.fichas }}</strong><span>Fichas</span></div>
              @if (rp.puntaje !== null) {
                <div class="sca-kpi"><strong>{{ rp.minMax }}</strong><span>M\xEDn \u2013 M\xE1x</span></div>
              }
              <p class="sca-kpis__note">
                {{ rp.recortado ? 'Promedio recortado SCA (se descartan m\xE1ximo y m\xEDnimo).' : 'Promedio simple de las fichas seleccionadas.' }}
                Intensidades: promedio \xB7 Casillas: mayor\xEDa (&gt; 50 %) \xB7 C\xEDrculos: entero m\xE1s cercano al promedio.
              </p>
            </section>
          }

          @if (h.formato === 'combinado') {
            <!-- \u2550\u2550\u2550\u2550\u2550\u2550 FORMATO COMBINADO \u2550\u2550\u2550\u2550\u2550\u2550 -->
            <div class="sca-bars">
              <div class="sca-bars__left">
                <span class="sca-bar">PARTE 1: EVALUACI\xD3N DESCRIPTIVA</span>
                <span class="sca-bar">NIVEL DE TUESTE</span>
                <span class="sca-roast"><em>{{ h.nivelTueste || '' }}</em></span>
              </div>
              <span class="sca-bar sca-bars__right">PARTE 2: EVALUACI\xD3N AFECTIVA</span>
            </div>

            <div class="sca-comb">
              <!-- Fragancia / Aroma -->
              <div class="sca-l sca-l--sliders">
                <ng-container *ngTemplateOutlet="scaSlider; context: { titulo: 'Fragancia', v: h.ficha.intensidad.fragancia }"></ng-container>
                <ng-container *ngTemplateOutlet="scaSlider; context: { titulo: 'Aroma', v: h.ficha.intensidad.aroma }"></ng-container>
              </div>
              <div class="sca-r sca-r--circles">
                <ng-container *ngTemplateOutlet="scaCirculos; context: { v: h.ficha.calidad.fragancia }"></ng-container>
                <ng-container *ngTemplateOutlet="scaCirculos; context: { v: h.ficha.calidad.aroma }"></ng-container>
              </div>
              <div class="sca-l sca-split sca-h-desc">
                <div class="sca-desc"><ng-container *ngTemplateOutlet="scaDescriptores; context: { marcadas: h.ficha.olfativo }"></ng-container></div>
                <ng-container *ngTemplateOutlet="scaNotas; context: { texto: h.ficha.notas.olfativo }"></ng-container>
              </div>
              <div class="sca-r"><ng-container *ngTemplateOutlet="scaNotas; context: { texto: etiquetasAfectivas(h, ['fragancia', 'aroma']) }"></ng-container></div>

              <!-- Sabor / Sabor residual -->
              <div class="sca-l sca-l--sliders">
                <ng-container *ngTemplateOutlet="scaSlider; context: { titulo: 'Sabor', v: h.ficha.intensidad.sabor }"></ng-container>
                <ng-container *ngTemplateOutlet="scaSlider; context: { titulo: 'Sabor Residual', v: h.ficha.intensidad.sabor_residual }"></ng-container>
              </div>
              <div class="sca-r sca-r--circles">
                <ng-container *ngTemplateOutlet="scaCirculos; context: { v: h.ficha.calidad.sabor }"></ng-container>
                <ng-container *ngTemplateOutlet="scaCirculos; context: { v: h.ficha.calidad.sabor_residual }"></ng-container>
              </div>
              <div class="sca-l sca-split sca-h-desc2">
                <div class="sca-desc">
                  <ng-container *ngTemplateOutlet="scaDescriptores; context: { marcadas: h.ficha.gustativo }"></ng-container>
                  <ng-container *ngTemplateOutlet="scaGustos; context: { marcadas: h.ficha.gustos }"></ng-container>
                </div>
                <ng-container *ngTemplateOutlet="scaNotas; context: { texto: h.ficha.notas.gustativo }"></ng-container>
              </div>
              <div class="sca-r"><ng-container *ngTemplateOutlet="scaNotas; context: { texto: etiquetasAfectivas(h, ['sabor', 'sabor_residual']) }"></ng-container></div>

              <!-- Acidez -->
              <div class="sca-l sca-l--one"><ng-container *ngTemplateOutlet="scaSlider; context: { titulo: 'Acidez', v: h.ficha.intensidad.acidez }"></ng-container></div>
              <div class="sca-r sca-r--circles"><ng-container *ngTemplateOutlet="scaCirculos; context: { v: h.ficha.calidad.acidez }"></ng-container></div>
              <div class="sca-l sca-h-note"><ng-container *ngTemplateOutlet="scaNotas; context: { texto: h.ficha.notas.acidez }"></ng-container></div>
              <div class="sca-r sca-h-note"><ng-container *ngTemplateOutlet="scaNotas; context: { texto: etiquetasAfectivas(h, ['acidez']) }"></ng-container></div>

              <!-- Dulzor -->
              <div class="sca-l sca-l--one"><ng-container *ngTemplateOutlet="scaSlider; context: { titulo: 'Dulzor', v: h.ficha.intensidad.dulzor }"></ng-container></div>
              <div class="sca-r sca-r--circles"><ng-container *ngTemplateOutlet="scaCirculos; context: { v: h.ficha.calidad.dulzor }"></ng-container></div>
              <div class="sca-l sca-h-note"><ng-container *ngTemplateOutlet="scaNotas; context: { texto: h.ficha.notas.dulzor }"></ng-container></div>
              <div class="sca-r sca-h-note"><ng-container *ngTemplateOutlet="scaNotas; context: { texto: etiquetasAfectivas(h, ['dulzor']) }"></ng-container></div>

              <!-- Sensaci\xF3n en boca -->
              <div class="sca-l sca-l--one"><ng-container *ngTemplateOutlet="scaSlider; context: { titulo: 'Sensaci\xF3n en boca', v: h.ficha.intensidad.sensacion_boca }"></ng-container></div>
              <div class="sca-r sca-r--circles"><ng-container *ngTemplateOutlet="scaCirculos; context: { v: h.ficha.calidad.sensacion_boca }"></ng-container></div>
              <div class="sca-l sca-split sca-split--boca sca-h-boca">
                <div class="sca-desc"><ng-container *ngTemplateOutlet="scaBoca; context: { marcadas: h.ficha.boca }"></ng-container></div>
                <ng-container *ngTemplateOutlet="scaNotas; context: { texto: h.ficha.notas.boca }"></ng-container>
              </div>
              <div class="sca-r sca-h-boca"><ng-container *ngTemplateOutlet="scaNotas; context: { texto: etiquetasAfectivas(h, ['sensacion_boca']) }"></ng-container></div>

              <!-- Otras notas | Impresi\xF3n global -->
              <div class="sca-l sca-otras">
                <span class="sca-bar sca-bar--block">OTRAS NOTAS</span>
                <p class="sca-notes__text">{{ h.ficha.notas.otras }}</p>
              </div>
              <div class="sca-r sca-global">
                <div class="sca-global__head">
                  <b class="sca-global__title">Impresi\xF3n global</b>
                  <ng-container *ngTemplateOutlet="scaCirculos; context: { v: h.ficha.impresionGlobal }"></ng-container>
                </div>
                <ng-container *ngTemplateOutlet="scaNotas; context: { texto: h.ficha.puntaje !== null ? 'Puntaje CVA: ' + (h.ficha.puntaje | number:'1.2-2') + ' \xB7 ' + etiquetaCalidad(h.ficha.impresionGlobal) : etiquetaCalidad(h.ficha.impresionGlobal) }"></ng-container>
                <div class="sca-cups">
                  <div class="sca-cups__left">
                    <div><b>TAZAS NO UNIFORMES</b><ng-container *ngTemplateOutlet="scaTazas; context: { n: h.ficha.tazasNoUniformes }"></ng-container></div>
                    <div><b>TAZAS DEFECTUOSAS</b><ng-container *ngTemplateOutlet="scaTazas; context: { n: h.ficha.tazasDefectuosas }"></ng-container></div>
                  </div>
                  <div class="sca-cups__right">
                    <b>DEFECTO (DE HABERLO)</b>
                    <div>
                      @for (d of defectosSca; track d.clave) {
                        <ng-container *ngTemplateOutlet="scaCasilla; context: { on: h.ficha.defectos.has(d.clave), etiqueta: d.etiqueta.toUpperCase(), principal: true }"></ng-container>
                      }
                    </div>
                  </div>
                </div>
              </div>
            </div>
          } @else {
            <!-- \u2550\u2550\u2550\u2550\u2550\u2550 FORMATO DESCRIPTIVO \u2550\u2550\u2550\u2550\u2550\u2550 -->
            <div class="sca-bars sca-bars--desc">
              <span class="sca-bar sca-bar--muestra">N\xBA DE MUESTRA <em>{{ h.numeroMuestra }}</em></span>
              <span class="sca-bar">NIVEL DE TUESTE</span>
              <span class="sca-roast"><em>{{ h.nivelTueste || '' }}</em></span>
            </div>
            <div class="sca-desc-grid">
              <div class="sca-l sca-l--sliders">
                <ng-container *ngTemplateOutlet="scaSlider; context: { titulo: 'Fragancia', v: h.ficha.intensidad.fragancia }"></ng-container>
                <ng-container *ngTemplateOutlet="scaSlider; context: { titulo: 'Aroma', v: h.ficha.intensidad.aroma }"></ng-container>
              </div>
              <div class="sca-r sca-span2"><ng-container *ngTemplateOutlet="scaNotas; context: { texto: h.ficha.notas.olfativo }"></ng-container></div>
              <div class="sca-l sca-desc sca-desc--2col"><ng-container *ngTemplateOutlet="scaDescriptores; context: { marcadas: h.ficha.olfativo }"></ng-container></div>

              <div class="sca-l sca-l--sliders">
                <ng-container *ngTemplateOutlet="scaSlider; context: { titulo: 'Sabor', v: h.ficha.intensidad.sabor }"></ng-container>
                <ng-container *ngTemplateOutlet="scaSlider; context: { titulo: 'Sabor Residual', v: h.ficha.intensidad.sabor_residual }"></ng-container>
              </div>
              <div class="sca-r sca-span2"><ng-container *ngTemplateOutlet="scaNotas; context: { texto: h.ficha.notas.gustativo }"></ng-container></div>
              <div class="sca-l sca-desc-gustos">
                <div class="sca-desc sca-desc--2col"><ng-container *ngTemplateOutlet="scaDescriptores; context: { marcadas: h.ficha.gustativo }"></ng-container></div>
                <ng-container *ngTemplateOutlet="scaGustos; context: { marcadas: h.ficha.gustos }"></ng-container>
              </div>

              <div class="sca-l sca-l--one sca-h-attr"><ng-container *ngTemplateOutlet="scaSlider; context: { titulo: 'Acidez', v: h.ficha.intensidad.acidez }"></ng-container></div>
              <div class="sca-r sca-h-attr"><ng-container *ngTemplateOutlet="scaNotas; context: { texto: h.ficha.notas.acidez }"></ng-container></div>

              <div class="sca-l sca-l--one sca-h-attr"><ng-container *ngTemplateOutlet="scaSlider; context: { titulo: 'Dulzor', v: h.ficha.intensidad.dulzor }"></ng-container></div>
              <div class="sca-r sca-h-attr"><ng-container *ngTemplateOutlet="scaNotas; context: { texto: h.ficha.notas.dulzor }"></ng-container></div>

              <div class="sca-l">
                <ng-container *ngTemplateOutlet="scaSlider; context: { titulo: 'Sensaci\xF3n en boca', v: h.ficha.intensidad.sensacion_boca }"></ng-container>
                <div class="sca-desc sca-desc--boca"><ng-container *ngTemplateOutlet="scaBoca; context: { marcadas: h.ficha.boca }"></ng-container></div>
              </div>
              <div class="sca-r"><ng-container *ngTemplateOutlet="scaNotas; context: { texto: h.ficha.notas.boca }"></ng-container></div>

              <div class="sca-l sca-otras sca-full">
                <span class="sca-bar sca-bar--block">OTRAS NOTAS</span>
                <p class="sca-notes__text">{{ h.ficha.notas.otras }}</p>
              </div>
            </div>
          }

          <footer class="sca-legal">
            Formato modificado para PacamaraQs, basado en el Sistema de Evaluaci\xF3n del Caf\xE9 de la SCA (Versi\xF3n 2, junio 2024).
            No es un documento oficial de la SCA.
          </footer>
        </article>
      } @else {
        <header class="rp-head">
          <div>
            <p class="rp-brand">PacamaraQs \xB7 Evaluaci\xF3n sensorial SCA CVA</p>
            <h1 class="rp-title">{{ esExtrinseco() ? 'Ficha t\xE9cnica del caf\xE9' : 'Reporte de cataci\xF3n' }}</h1>
            <p class="rp-sub">{{ r.nombreSesion }} \xB7 Formato {{ tituloFormato() }}</p>
          </div>
          <p class="rp-meta">Generado: {{ fechaReporte() | date:'medium' }}<br>{{ r.totalMuestras }} muestra(s) \xB7 {{ r.catadores.length }} catador(es)</p>
        </header>

        @if (esAfectivo()) {
        <section class="rp-section">
          <h2>Promedio hed\xF3nico por muestra (escala 1\u20139)</h2>
          <table>
            <thead><tr><th>#</th><th>Muestra</th><th class="num">Votos</th><th class="num">Promedio</th><th>Valoraci\xF3n</th></tr></thead>
            <tbody>
              @for (f of resultadosHedonicos(); track f.numeroMuestra) {
                <tr>
                  <td>{{ f.posicion || '\u2014' }}</td>
                  <td>Muestra {{ f.numeroMuestra }}</td>
                  <td class="num">{{ f.totalVotos }}</td>
                  <td class="num rp-score">{{ f.promedio === null ? '\u2014' : (f.promedio | number:'1.2-2') }}</td>
                  <td>{{ f.etiqueta }}</td>
                </tr>
              }
            </tbody>
          </table>
        </section>
        <div class="rp-grid">
          @for (f of resultadosHedonicos(); track f.numeroMuestra) {
            <section class="rp-section">
              <h2>Muestra {{ f.numeroMuestra }} \xB7 distribuci\xF3n de votos</h2>
              <table>
                <tbody>
                  @for (d of f.distribucion; track d.valor) {
                    <tr>
                      <td style="width: 8%">{{ d.valor }}</td>
                      <td style="width: 38%" class="rp-muted">{{ d.etiqueta }}</td>
                      <td><div class="rp-bar"><i [style.width.%]="d.porcentaje"></i></div></td>
                      <td class="num" style="width: 8%">{{ d.votos }}</td>
                    </tr>
                  }
                </tbody>
              </table>
              <table style="margin-top: 6px">
                <thead><tr><th>Atributo</th><th class="num">Calidad (1\u20139)</th></tr></thead>
                <tbody>
                  @for (a of f.atributos; track a.clave) {
                    <tr><td>{{ a.etiqueta }}</td><td class="num">{{ a.valor === null ? '\u2014' : (a.valor | number:'1.1-1') }}</td></tr>
                  }
                </tbody>
              </table>
            </section>
          }
        </div>
        } @else if (esExtrinseco()) {
        @for (ficha of fichasTecnicas(); track $index; let primera = $first) {
          <article [class.rp-page-break]="!primera">
            <section class="rp-section">
              <h2>Muestra {{ ficha.numeroMuestra }}@if (ficha.registradaPor) { \xB7 registrada por {{ ficha.registradaPor }} }</h2>
            </section>
            <div class="rp-grid">
              @for (seccion of ficha.secciones; track seccion.titulo) {
                <section class="rp-section">
                  <h2>{{ seccion.titulo }}</h2>
                  <dl class="rp-dl">
                    @for (campo of seccion.campos; track campo.etiqueta) {
                      <dt>{{ campo.etiqueta }}</dt><dd>{{ campo.valor }}</dd>
                    }
                  </dl>
                </section>
              }
              <section class="rp-section">
                <h2>Certificaciones</h2>
                @if (ficha.certificaciones.length > 0) {
                  <div class="rp-chips">@for (c of ficha.certificaciones; track c) { <span>{{ c }}</span> }</div>
                } @else {
                  <p class="rp-muted">Sin certificaciones registradas.</p>
                }
              </section>
            </div>
            @if (ficha.notas) {
              <section class="rp-section"><h2>Notas</h2><p>{{ ficha.notas }}</p></section>
            }
          </article>
        }
              }

        <p class="rp-foot">Metodolog\xEDa SCA Coffee Value Assessment (CVA) \xB7 Documento generado por PacamaraQs.</p>
      }
    </div>
  }
</ion-content>
`, styles: ['@charset "UTF-8";\n\n/* src/app/pages/session/results/results.page.scss */\n.rs-toolbar {\n  --background: var(--app-bg-card);\n}\n.rs-title {\n  color: var(--app-text-main);\n  font-size: 15px;\n  font-weight: 700;\n}\n.rs-subtitle {\n  color: var(--app-text-muted);\n  font-size: 12px;\n  font-weight: 400;\n}\n.rs-content {\n  --background: var(--app-bg-screen);\n}\n.rs-container {\n  width: min(100%, 960px);\n  margin: 0 auto;\n  padding-bottom: 24px;\n}\n.rs-center {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  gap: 12px;\n  padding: 32px 16px;\n  text-align: center;\n}\n.rs-lock {\n  color: var(--app-text-muted);\n  font-size: 32px;\n}\n.rs-section-title {\n  margin: 0 0 12px;\n  color: var(--app-text-muted);\n  font-size: 11px;\n  font-weight: 700;\n  letter-spacing: 0.05em;\n  text-transform: uppercase;\n}\n.rs-muted {\n  color: var(--app-text-muted);\n}\n.rs-note {\n  margin: 0 0 12px;\n  font-size: 12px;\n}\n.rs-meta {\n  display: flex;\n  flex-wrap: wrap;\n  align-items: center;\n  justify-content: space-between;\n  gap: 16px;\n}\n.rs-meta__headline {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  margin: 0;\n  color: var(--app-text-main);\n  font-weight: 600;\n}\n.rs-meta__detail {\n  margin: 6px 0 0;\n  color: var(--app-text-muted);\n  font-size: 13px;\n}\n.rs-meta__stats {\n  display: flex;\n  gap: 24px;\n  text-align: center;\n}\n.rs-meta__stats strong {\n  display: block;\n  color: var(--app-text-main);\n  font-size: 16px;\n}\n.rs-meta__stats span {\n  color: var(--app-text-muted);\n  font-size: 11px;\n}\n.rs-table-wrap {\n  overflow-x: auto;\n}\n.rs-table {\n  width: 100%;\n  border-collapse: collapse;\n  font-size: 13px;\n}\n.rs-table th,\n.rs-table td {\n  padding: 10px 8px;\n  border-bottom: 1px solid var(--app-border);\n  text-align: left;\n  white-space: nowrap;\n}\n.rs-table thead th {\n  color: var(--app-text-muted);\n  font-size: 11px;\n  font-weight: 600;\n  text-transform: uppercase;\n}\n.rs-table tfoot td {\n  color: var(--app-text-muted);\n  font-weight: 600;\n}\n.rs-rank {\n  color: var(--app-text-muted);\n}\n.rs-rank ion-icon {\n  color: #ca8a04;\n  vertical-align: middle;\n}\n.rs-score {\n  color: var(--app-score);\n  font-size: 15px;\n  font-weight: 700;\n}\n.rs-tag {\n  margin-left: 6px;\n  padding: 2px 6px;\n  border-radius: 4px;\n  background: var(--app-bg-subtle);\n  color: var(--app-text-muted);\n  font-size: 10px;\n  font-weight: 500;\n}\n.rs-badge {\n  display: inline-block;\n  padding: 3px 8px;\n  border-radius: 6px;\n  font-size: 11px;\n  font-weight: 600;\n}\n.rs-grid {\n  display: grid;\n  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));\n  gap: 12px;\n  margin-bottom: 16px;\n}\n.rs-formula {\n  margin-bottom: 16px;\n  padding: 16px;\n  border-radius: var(--app-radius-card);\n  background: var(--app-bg-subtle);\n}\n.rs-formula__expr {\n  margin: 0 0 8px;\n  color: var(--app-text-main);\n  font-family: var(--app-font-mono);\n  font-size: 14px;\n}\n.rs-actions {\n  display: flex;\n  flex-wrap: wrap;\n  justify-content: flex-end;\n  gap: 12px;\n}\n:host {\n  --rc-gauge-bajo: #e53935;\n  --rc-gauge-medio: #f5b400;\n  --rc-gauge-alto: #8fdc6a;\n  --rc-gauge-top: #12a150;\n  --rc-row-active: #fbe9e4;\n  --rc-medal-1: #ca8a04;\n  --rc-medal-2: #94a3b8;\n  --rc-medal-3: #b45309;\n}\n.rc-card {\n  margin: 0 0 16px;\n  border: 1px solid var(--app-border);\n  border-radius: var(--app-radius-card);\n  background: var(--app-bg-card);\n  box-shadow: none;\n}\n.rc-card ion-card-content {\n  padding: 16px;\n}\n.rc-grid-flush {\n  --ion-grid-padding: 0;\n  margin: 0 -5px;\n}\n.rc-grid-flush ion-col {\n  --ion-grid-column-padding: 5px;\n}\n.rc-grid-flush .rc-card {\n  height: calc(100% - 10px);\n  margin-bottom: 10px;\n}\n.rc-section-title--tight {\n  margin-bottom: 4px;\n}\n.rc-note-bottom {\n  margin: 12px 0 0;\n}\n.rc-block {\n  margin-bottom: 16px;\n}\n.rc-gauge ion-card-content {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  padding: 16px 16px 12px;\n}\n.rc-gauge__svg {\n  width: min(100%, 220px);\n  height: auto;\n  overflow: visible;\n}\n.rc-gauge__arc {\n  fill: none;\n  stroke-width: 22;\n}\n.rc-gauge__arc--bajo {\n  stroke: var(--rc-gauge-bajo);\n}\n.rc-gauge__arc--medio {\n  stroke: var(--rc-gauge-medio);\n}\n.rc-gauge__arc--alto {\n  stroke: var(--rc-gauge-alto);\n}\n.rc-gauge__arc--top {\n  stroke: var(--rc-gauge-top);\n}\n.rc-gauge__tick {\n  fill: var(--app-text-muted);\n  font-size: 9px;\n}\n.rc-gauge__needle {\n  stroke: var(--app-text-main);\n  stroke-width: 4;\n  stroke-linecap: round;\n  transition: all 0.4s ease;\n}\n.rc-gauge__hub {\n  fill: var(--app-text-main);\n}\n.rc-gauge__value {\n  margin: 8px 0 2px;\n  color: var(--app-score);\n  font-size: 22px;\n  font-weight: 700;\n}\n.rc-gauge__label {\n  margin: 0;\n  color: var(--app-text-muted);\n  font-size: 10px;\n  letter-spacing: 0.04em;\n  text-align: center;\n  text-transform: uppercase;\n}\n.rc-ranking__row {\n  cursor: pointer;\n  transition: background-color 0.15s ease;\n}\n.rc-ranking__row:hover {\n  background: var(--app-bg-subtle);\n}\n.rc-ranking__row:focus-visible {\n  outline: 2px solid var(--app-primary-dark);\n  outline-offset: -2px;\n}\n.rc-ranking__row--active,\n.rc-ranking__row--active:hover {\n  background: var(--rc-row-active);\n}\n.rc-ranking__name {\n  color: var(--app-text-main);\n  font-weight: 600;\n}\n.rc-medal {\n  margin-right: 2px;\n  vertical-align: middle;\n}\n.rc-medal--1 {\n  color: var(--rc-medal-1);\n}\n.rc-medal--2 {\n  color: var(--rc-medal-2);\n}\n.rc-medal--3 {\n  color: var(--rc-medal-3);\n}\n.rc-medal--n {\n  color: var(--app-text-faint);\n}\n.rc-chip {\n  --padding-top: 3px;\n  --padding-bottom: 3px;\n  --padding-start: 8px;\n  --padding-end: 8px;\n  border-radius: 6px;\n  font-size: 11px;\n  font-weight: 600;\n}\n.rc-chip--live {\n  --background: #dcfce7;\n  --color: var(--app-success);\n  margin-left: 6px;\n  font-size: 10px;\n  font-weight: 500;\n}\n.rc-cupper-select {\n  display: block;\n  width: 100%;\n  height: 100%;\n  padding: 0;\n  border: 2px solid transparent;\n  border-radius: calc(var(--app-radius-card) + 2px);\n  background: none;\n  font: inherit;\n  text-align: inherit;\n  cursor: pointer;\n  transition: border-color 0.15s ease;\n}\n.rc-cupper-select:hover {\n  border-color: var(--app-border);\n}\n.rc-cupper-select:focus-visible {\n  outline: 2px solid var(--app-primary-dark);\n  outline-offset: 2px;\n}\n.rc-cupper-select--active,\n.rc-cupper-select--active:hover {\n  border-color: var(--app-primary-dark);\n}\n.rc-report__head {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  gap: 12px;\n  margin: 8px 0 12px;\n  padding-bottom: 12px;\n  border-bottom: 1px solid var(--app-border);\n}\n.rc-report__who {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  min-width: 0;\n}\n.rc-avatar {\n  display: inline-flex;\n  flex: 0 0 32px;\n  align-items: center;\n  justify-content: center;\n  width: 32px;\n  height: 32px;\n  border: 1px solid var(--app-border);\n  border-radius: 50%;\n  background: var(--app-bg-subtle);\n  color: var(--app-text-main);\n  font-size: 13px;\n  font-weight: 700;\n}\n.rc-report__name {\n  margin: 0;\n  color: var(--app-text-main);\n  font-weight: 600;\n}\n.rc-report__meta {\n  margin: 2px 0 0;\n  color: var(--app-text-muted);\n  font-size: 11px;\n}\n.rc-report__score {\n  text-align: right;\n}\n.rc-report__score strong {\n  display: block;\n  color: var(--app-text-main);\n  font-size: 20px;\n}\n.rc-report__score span {\n  color: var(--app-text-muted);\n  font-size: 9px;\n  text-transform: uppercase;\n}\n.rc-fichas {\n  display: flex;\n  flex-direction: column;\n  gap: 8px;\n}\n.rc-ficha {\n  overflow: hidden;\n  border-radius: var(--app-radius-control);\n  background: var(--app-bg-subtle);\n}\n.rc-ficha__header {\n  --background: var(--app-bg-subtle);\n  --min-height: 40px;\n  font-size: 13px;\n  font-weight: 600;\n}\n.rc-ficha__header ion-badge {\n  margin-inline-end: 8px;\n}\n.rc-ficha__score {\n  color: var(--app-score);\n  font-size: 13px;\n  font-weight: 700;\n}\n.rc-ficha__body {\n  padding: 4px 16px 12px;\n  background: var(--app-bg-subtle);\n}\n.rc-ficha__row {\n  display: flex;\n  justify-content: space-between;\n  padding: 6px 0;\n  border-bottom: 1px solid var(--app-border);\n  color: var(--app-text-main);\n  font-size: 13px;\n}\n.rc-ficha__row--total {\n  border-bottom: none;\n}\n.rc-ficha__row--total span {\n  font-weight: 600;\n}\n.rc-ficha__row--total strong {\n  color: var(--app-score);\n}\n.rc-ficha__actions {\n  display: flex;\n  flex-wrap: wrap;\n  gap: 8px;\n  margin-top: 4px;\n}\n.rc-export-modal {\n  --width: min(92vw, 360px);\n  --height: auto;\n  --border-radius: var(--app-radius-card);\n}\n.rc-export {\n  padding: 16px;\n}\n.rc-export__head {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  margin-bottom: 12px;\n}\n.rc-export__head h2 {\n  margin: 0;\n  color: var(--app-text-main);\n  font-size: 15px;\n  font-weight: 700;\n}\n.rc-export__label {\n  display: block;\n  margin: 0 0 6px;\n  color: var(--app-text-main);\n  font-size: 12px;\n  font-weight: 600;\n}\n.rc-export__select {\n  margin-bottom: 12px;\n  padding: 0 12px;\n  border: 1px solid var(--app-border-input);\n  border-radius: var(--app-radius-control);\n  font-size: 13px;\n}\n.rc-export__segment {\n  --background: transparent;\n  gap: 8px;\n  margin-bottom: 12px;\n}\n.rc-export__segment ion-segment-button {\n  --background: var(--app-bg-subtle);\n  --background-checked: var(--app-primary-dark);\n  --color: var(--app-text-main);\n  --color-checked: #ffffff;\n  --indicator-color: transparent;\n  --border-radius: var(--app-radius-control);\n  min-height: 38px;\n  border: 1px solid var(--app-border);\n  border-radius: var(--app-radius-control);\n  font-size: 13px;\n  text-transform: none;\n}\n.rc-export__go {\n  margin: 4px 0 0;\n}\n@media (max-width: 576px) {\n  .rs-meta__stats {\n    gap: 16px;\n  }\n  .rc-report__score strong {\n    font-size: 18px;\n  }\n}\n.rc-export__hint {\n  margin: 8px 0 0;\n  color: var(--app-text-muted);\n  font-size: 11px;\n  text-align: center;\n}\n.rc-ficha__row--head {\n  color: var(--app-text-muted);\n  font-size: 11px;\n  text-transform: uppercase;\n}\n.rc-ficha__cols {\n  display: inline-grid;\n  grid-template-columns: 72px 64px;\n  text-align: right;\n}\n.rc-ficha__cols em {\n  font-style: normal;\n}\n:host {\n  --rx-hedonic: #b45309;\n  --rx-intensity: var(--app-primary-dark);\n  --rx-track: var(--app-bg-subtle);\n}\n.rx-bar {\n  position: relative;\n  flex: 1 1 auto;\n  min-width: 40px;\n  height: 10px;\n  overflow: hidden;\n  border-radius: 999px;\n  background: var(--rx-track);\n}\n.rx-bar i {\n  position: absolute;\n  inset: 0 auto 0 0;\n  border-radius: inherit;\n  transition: width 0.35s ease;\n}\n.rx-bar--hedonic i {\n  background: var(--rx-hedonic);\n}\n.rx-bar--intensity i {\n  background: var(--rx-intensity);\n}\n.rx-bars {\n  margin: 0;\n  padding: 0;\n  list-style: none;\n}\n.rx-bars__row {\n  display: grid;\n  grid-template-columns: minmax(96px, 34%) 1fr 40px;\n  align-items: center;\n  gap: 10px;\n  padding: 7px 0;\n  border-bottom: 1px solid var(--app-border);\n  font-size: 13px;\n}\n.rx-bars__row:last-child {\n  border-bottom: none;\n}\n.rx-bars__label {\n  color: var(--app-text-main);\n}\n.rx-bars__value {\n  color: var(--app-text-main);\n  font-variant-numeric: tabular-nums;\n  text-align: right;\n}\n.rx-bar-line {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  min-width: 160px;\n}\n.rx-samples {\n  --background: transparent;\n  margin: 0 0 12px;\n}\n.rx-samples ion-segment-button {\n  --background: var(--app-bg-card);\n  --background-checked: var(--app-primary-dark);\n  --color: var(--app-text-main);\n  --color-checked: #ffffff;\n  --indicator-color: transparent;\n  --border-radius: 999px;\n  flex: 0 0 auto;\n  min-width: 104px;\n  min-height: 32px;\n  margin-right: 6px;\n  border: 1px solid var(--app-border);\n  border-radius: 999px;\n  font-size: 12px;\n  text-transform: none;\n}\n.rx-list {\n  margin: 0 -16px -16px;\n  background: transparent;\n}\n.rx-list ion-item {\n  --background: transparent;\n  --padding-start: 16px;\n  --inner-padding-end: 16px;\n}\n.rx-list .rc-avatar {\n  margin-inline-end: 12px;\n}\n.rx-list__name {\n  color: var(--app-text-main);\n  font-size: 14px;\n  font-weight: 600;\n}\n.rx-list ion-label p {\n  color: var(--app-text-muted);\n  font-size: 12px;\n}\n.rx-chip--ok {\n  --background: #dcfce7;\n  --color: var(--app-success);\n}\n.rx-chip--pending {\n  --background: var(--app-bg-subtle);\n  --color: var(--app-text-muted);\n}\n.ra-col-bar {\n  width: 38%;\n}\n.ra-chip {\n  --background: #fef3c7;\n  --color: #92400e;\n}\n.ra-dist {\n  margin: 0;\n  padding: 0;\n  list-style: none;\n}\n.ra-dist__row {\n  display: grid;\n  grid-template-columns: 22px minmax(110px, 40%) 1fr 28px;\n  align-items: center;\n  gap: 8px;\n  padding: 5px 0;\n  font-size: 13px;\n}\n.ra-dist__row--empty {\n  opacity: 0.55;\n}\n.ra-dist__value {\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  width: 22px;\n  height: 22px;\n  border-radius: 6px;\n  background: var(--app-bg-subtle);\n  color: var(--app-text-main);\n  font-size: 12px;\n  font-weight: 700;\n}\n.ra-dist__label {\n  color: var(--app-text-muted);\n  font-size: 12px;\n}\n.ra-dist__count {\n  color: var(--app-text-main);\n  text-align: right;\n  font-variant-numeric: tabular-nums;\n}\n.ra-dist__total {\n  margin: 10px 0 0;\n  padding-top: 10px;\n  border-top: 1px solid var(--app-border);\n  color: var(--app-text-muted);\n  font-size: 12px;\n}\n.rd-scale {\n  display: grid;\n  grid-template-columns: minmax(96px, 34%) 1fr 40px;\n  gap: 10px;\n  color: var(--app-text-faint);\n  font-size: 10px;\n}\n.rd-scale__ticks {\n  display: flex;\n  justify-content: space-between;\n}\n.rd-scale__ticks em {\n  font-style: normal;\n}\n.rd-bar {\n  height: 12px;\n  background-image:\n    linear-gradient(\n      90deg,\n      transparent calc(33.33% - 1px),\n      var(--app-border) calc(33.33% - 1px),\n      var(--app-border) 33.33%,\n      transparent 33.33%,\n      transparent calc(66.66% - 1px),\n      var(--app-border) calc(66.66% - 1px),\n      var(--app-border) 66.66%,\n      transparent 66.66%);\n}\n.rd-matrix th[scope=row] {\n  color: var(--app-text-main);\n  font-size: 13px;\n  font-weight: 500;\n  text-transform: none;\n}\n.rd-matrix__num {\n  text-align: center !important;\n}\n.rd-cell {\n  --rd-alpha: 0;\n  display: inline-block;\n  min-width: 44px;\n  padding: 3px 8px;\n  border-radius: 6px;\n  background: rgba(47, 62, 70, calc(var(--rd-alpha) * 0.85));\n  color: var(--app-text-main);\n  font-variant-numeric: tabular-nums;\n  font-weight: 600;\n}\n.rd-cell--dark {\n  color: #ffffff;\n}\n.re-head {\n  margin-bottom: 12px;\n  padding-bottom: 12px;\n  border-bottom: 1px solid var(--app-border);\n}\n.re-head__title {\n  display: flex;\n  align-items: flex-start;\n  gap: 10px;\n}\n.re-head__title ion-icon {\n  flex: 0 0 auto;\n  margin-top: 2px;\n  color: var(--app-primary-dark);\n  font-size: 22px;\n}\n.re-head__title h2 {\n  margin: 0;\n  color: var(--app-text-main);\n  font-size: 16px;\n  font-weight: 700;\n}\n.re-head__title p {\n  margin: 2px 0 0;\n  font-size: 12px;\n}\n.re-section {\n  margin-bottom: 12px;\n}\n.re-dl {\n  display: grid;\n  grid-template-columns: minmax(110px, 42%) 1fr;\n  margin: 0;\n  font-size: 13px;\n}\n.re-dl dt,\n.re-dl dd {\n  margin: 0;\n  padding: 6px 0;\n  border-bottom: 1px solid var(--app-border);\n}\n.re-dl dt {\n  padding-right: 8px;\n  color: var(--app-text-muted);\n}\n.re-dl dd {\n  color: var(--app-text-main);\n  font-weight: 500;\n  overflow-wrap: anywhere;\n}\n.re-dl__empty {\n  color: var(--app-text-faint) !important;\n  font-weight: 400 !important;\n}\n.re-certs {\n  display: flex;\n  flex-wrap: wrap;\n  gap: 6px;\n}\n.re-cert {\n  --background: #ecfdf5;\n  --color: #047857;\n  display: inline-flex;\n  align-items: center;\n  gap: 4px;\n  font-size: 12px;\n}\n.re-notes {\n  margin: 0;\n  color: var(--app-text-main);\n  font-size: 13px;\n  white-space: pre-line;\n}\n@media (max-width: 576px) {\n  .rx-bars__row,\n  .rd-scale {\n    grid-template-columns: minmax(84px, 38%) 1fr 34px;\n    gap: 8px;\n  }\n  .ra-dist__row {\n    grid-template-columns: 22px 1fr 34px;\n  }\n  .ra-dist__label {\n    display: none;\n  }\n  .rx-bar-line {\n    min-width: 120px;\n  }\n  .re-dl {\n    grid-template-columns: 1fr;\n  }\n  .re-dl dt {\n    padding-bottom: 0;\n    border-bottom: none;\n    font-size: 11px;\n  }\n}\n.rc-export__help {\n  margin: -2px 0 8px;\n  color: var(--app-text-muted);\n  font-size: 11px;\n}\n.rc-export__panel {\n  max-height: 38vh;\n  margin: 0 0 12px;\n  padding: 0;\n  overflow-y: auto;\n  border: 1px solid var(--app-border);\n  border-radius: var(--app-radius-control);\n  list-style: none;\n}\n.rc-export__panel-item {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  gap: 8px;\n  min-height: 40px;\n  padding: 0 12px;\n  border-bottom: 1px solid var(--app-border);\n  font-size: 13px;\n}\n.rc-export__panel-item:last-child {\n  border-bottom: none;\n}\n.rc-export__panel-item ion-checkbox {\n  --size: 18px;\n  --checkbox-background-checked: var(--app-primary-dark);\n  --border-color-checked: var(--app-primary-dark);\n  flex: 1;\n  color: var(--app-text-main);\n}\n.rc-export__panel-item--off {\n  opacity: 0.55;\n}\n.rc-export__calib {\n  color: var(--app-success);\n  font-size: 11px;\n  white-space: nowrap;\n}\n.rc-export__calib--alto {\n  color: #b45309;\n}\n.rc-export__calib--bajo {\n  color: #1d4ed8;\n}\n/*# sourceMappingURL=results.page.css.map */\n'] }]
  }], () => [], { reporteImprimible: [{ type: ViewChild, args: ["reporteImprimible", { isSignal: true }] }] });
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(ResultsPage, { className: "ResultsPage", filePath: "src/app/pages/session/results/results.page.ts", lineNumber: 198 });
})();
export {
  ATRIBUTOS_CVA,
  ResultsPage,
  clasificarPuntaje,
  etiquetaHedonica,
  puntoEnMedidor
};
//# debugId=60e223b7-cdeb-5225-be03-1a3b959a856b
//# sourceMappingURL=results.page-BFHRW2HO.js.map
