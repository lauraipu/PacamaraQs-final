import {
  c,
  l
} from "./chunk-BMQUG2PJ.js";
import {
  n
} from "./chunk-4BTEZGN2.js";
import {
  J,
  Y
} from "./chunk-ETZFPO3Y.js";
import "./chunk-DI3VEDFV.js";
import "./chunk-PAXKX5KU.js";

// node_modules/@ionic/core/components/p-BBsseItU.js
/*!
 * (C) Ionic http://ionicframework.com - MIT License
 */
var n2 = () => {
  const n3 = window;
  n3.addEventListener("statusTap", (() => {
    J((() => {
      const o = document.elementFromPoint(n3.innerWidth / 2, n3.innerHeight / 2);
      if (!o) return;
      const e = l(o);
      e && new Promise(((o2) => n(e, o2))).then((() => {
        Y((async () => {
          e.style.setProperty("--overflow", "hidden"), await c(e, 300), e.style.removeProperty("--overflow");
        }));
      }));
    }));
  }));
};
export {
  n2 as startStatusTap
};
//# debugId=1e93a40a-5575-5f32-8813-7b75d9b9eb50
//# sourceMappingURL=p-BBsseItU-V3HUUCQR.js.map
