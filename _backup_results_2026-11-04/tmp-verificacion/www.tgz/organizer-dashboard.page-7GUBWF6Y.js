import {
  GRACE_PERIOD_MS,
  RealtimeService
} from "./chunk-7SA6TBRT.js";
import {
  mensajeDeError
} from "./chunk-OFWJO6PD.js";
import {
  SesionService
} from "./chunk-KN5DCTIK.js";
import {
  checkmarkCircle,
  cloudOfflineOutline,
  ellipseOutline,
  lockClosed,
  personCircleOutline,
  playForwardOutline
} from "./chunk-ISYXHPYK.js";
import {
  addIcons
} from "./chunk-4JFQPQWK.js";
import {
  AuthService
} from "./chunk-SYUCMH2K.js";
import {
  ActivatedRoute,
  AlertController,
  CommonModule,
  Component,
  Input,
  IonButton,
  IonContent,
  IonHeader,
  IonIcon,
  IonSpinner,
  IonTitle,
  IonToolbar,
  Router,
  ToastController,
  computed,
  inject,
  setClassMetadata,
  signal,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵattribute,
  ɵɵclassProp,
  ɵɵconditional,
  ɵɵconditionalCreate,
  ɵɵdefineComponent,
  ɵɵdomElement,
  ɵɵdomElementEnd,
  ɵɵdomElementStart,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵlistener,
  ɵɵnextContext,
  ɵɵproperty,
  ɵɵrepeater,
  ɵɵrepeaterCreate,
  ɵɵrepeaterTrackByIdentity,
  ɵɵrepeaterTrackByIndex,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵstyleProp,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1,
  ɵɵtextInterpolate2
} from "./chunk-ELFI4Z7L.js";
import "./chunk-BMQUG2PJ.js";
import "./chunk-3OZZMUVI.js";
import "./chunk-3GAB7GSC.js";
import "./chunk-B7Y4FMY7.js";
import "./chunk-NQCL7WZ3.js";
import "./chunk-4BTEZGN2.js";
import "./chunk-XTVSKRH4.js";
import "./chunk-ETZFPO3Y.js";
import "./chunk-LLS636HS.js";
import "./chunk-KQQH3YTO.js";
import "./chunk-DI3VEDFV.js";
import "./chunk-PAXKX5KU.js";

// src/app/shared/components/progress-tracker/progress-tracker.component.ts
function ProgressTrackerComponent_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275domElementStart(0, "p", 6);
    \u0275\u0275text(1, "Esperando a que los dem\xE1s terminen...");
    \u0275\u0275domElementEnd();
  }
}
function ProgressTrackerComponent_Conditional_9_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275domElementStart(0, "p", 7);
    \u0275\u0275text(1, "\xA1Todos han terminado!");
    \u0275\u0275domElementEnd();
  }
}
var _ProgressTrackerComponent = class _ProgressTrackerComponent {
  constructor() {
    this.completados = 0;
    this.total = 0;
  }
  get porcentaje() {
    if (this.total === 0)
      return 0;
    return Math.round(this.completados / this.total * 100);
  }
};
_ProgressTrackerComponent.\u0275fac = function ProgressTrackerComponent_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _ProgressTrackerComponent)();
};
_ProgressTrackerComponent.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _ProgressTrackerComponent, selectors: [["app-progress-tracker"]], inputs: { completados: "completados", total: "total" }, decls: 10, vars: 6, consts: [[1, "progress-container"], [1, "progress-header"], [1, "label"], [1, "value"], [1, "progress-bar-bg"], [1, "progress-bar-fill"], [1, "progress-hint"], [1, "progress-hint", "success"]], template: function ProgressTrackerComponent_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275domElementStart(0, "div", 0)(1, "div", 1)(2, "span", 2);
    \u0275\u0275text(3, "Catadores que han terminado");
    \u0275\u0275domElementEnd();
    \u0275\u0275domElementStart(4, "span", 3);
    \u0275\u0275text(5);
    \u0275\u0275domElementEnd()();
    \u0275\u0275domElementStart(6, "div", 4);
    \u0275\u0275domElement(7, "div", 5);
    \u0275\u0275domElementEnd();
    \u0275\u0275conditionalCreate(8, ProgressTrackerComponent_Conditional_8_Template, 2, 0, "p", 6);
    \u0275\u0275conditionalCreate(9, ProgressTrackerComponent_Conditional_9_Template, 2, 0, "p", 7);
    \u0275\u0275domElementEnd();
  }
  if (rf & 2) {
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate2("", ctx.completados, " de ", ctx.total);
    \u0275\u0275advance(2);
    \u0275\u0275styleProp("width", ctx.porcentaje, "%");
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx.completados < ctx.total ? 8 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx.completados === ctx.total && ctx.total > 0 ? 9 : -1);
  }
}, dependencies: [CommonModule], styles: ["\n.progress-container[_ngcontent-%COMP%] {\n  background: #FFFFFF;\n  border: 1px solid #E2E8F0;\n  border-radius: 12px;\n  padding: 20px;\n  margin-bottom: 16px;\n}\n.progress-header[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  margin-bottom: 12px;\n}\n.progress-header[_ngcontent-%COMP%]   .label[_ngcontent-%COMP%] {\n  font-size: 13px;\n  font-weight: 600;\n  color: #62748E;\n}\n.progress-header[_ngcontent-%COMP%]   .value[_ngcontent-%COMP%] {\n  font-size: 13px;\n  font-weight: 700;\n  color: #0F172B;\n}\n.progress-bar-bg[_ngcontent-%COMP%] {\n  height: 8px;\n  background: #F1F5F9;\n  border-radius: 4px;\n  overflow: hidden;\n}\n.progress-bar-fill[_ngcontent-%COMP%] {\n  height: 100%;\n  background: #2F3E46;\n  border-radius: 4px;\n  transition: width 0.5s ease;\n}\n.progress-hint[_ngcontent-%COMP%] {\n  margin-top: 12px;\n  font-size: 12px;\n  color: #62748E;\n  text-align: center;\n}\n.progress-hint.success[_ngcontent-%COMP%] {\n  color: #15803D;\n  font-weight: 600;\n}\n/*# sourceMappingURL=progress-tracker.component.css.map */"] });
var ProgressTrackerComponent = _ProgressTrackerComponent;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ProgressTrackerComponent, [{
    type: Component,
    args: [{ selector: "app-progress-tracker", standalone: true, imports: [CommonModule], template: '<div class="progress-container">\n  <div class="progress-header">\n    <span class="label">Catadores que han terminado</span>\n    <span class="value">{{ completados }} de {{ total }}</span>\n  </div>\n  <div class="progress-bar-bg">\n    <div class="progress-bar-fill" [style.width.%]="porcentaje"></div>\n  </div>\n  @if (completados < total) {\n    <p class="progress-hint">Esperando a que los dem\xE1s terminen...</p>\n  }\n  @if (completados === total && total > 0) {\n    <p class="progress-hint success">\xA1Todos han terminado!</p>\n  }\n</div>', styles: ["/* src/app/shared/components/progress-tracker/progress-tracker.component.scss */\n.progress-container {\n  background: #FFFFFF;\n  border: 1px solid #E2E8F0;\n  border-radius: 12px;\n  padding: 20px;\n  margin-bottom: 16px;\n}\n.progress-header {\n  display: flex;\n  justify-content: space-between;\n  margin-bottom: 12px;\n}\n.progress-header .label {\n  font-size: 13px;\n  font-weight: 600;\n  color: #62748E;\n}\n.progress-header .value {\n  font-size: 13px;\n  font-weight: 700;\n  color: #0F172B;\n}\n.progress-bar-bg {\n  height: 8px;\n  background: #F1F5F9;\n  border-radius: 4px;\n  overflow: hidden;\n}\n.progress-bar-fill {\n  height: 100%;\n  background: #2F3E46;\n  border-radius: 4px;\n  transition: width 0.5s ease;\n}\n.progress-hint {\n  margin-top: 12px;\n  font-size: 12px;\n  color: #62748E;\n  text-align: center;\n}\n.progress-hint.success {\n  color: #15803D;\n  font-weight: 600;\n}\n/*# sourceMappingURL=progress-tracker.component.css.map */\n"] }]
  }], null, { completados: [{
    type: Input
  }], total: [{
    type: Input
  }] });
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(ProgressTrackerComponent, { className: "ProgressTrackerComponent", filePath: "src/app/shared/components/progress-tracker/progress-tracker.component.ts", lineNumber: 11 });
})();

// src/app/pages/session/organizer-dashboard/organizer-dashboard.page.ts
var _forTrack0 = ($index, $item) => $item.usuarioId;
var _forTrack1 = ($index, $item) => $item.numero;
function OrganizerDashboardPage_Conditional_9_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 6);
    \u0275\u0275element(1, "ion-icon", 9);
    \u0275\u0275text(2, " Reconectando\u2026 el progreso se actualiza cada pocos segundos mientras tanto. ");
    \u0275\u0275elementEnd();
  }
}
function OrganizerDashboardPage_Conditional_10_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 7);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx);
  }
}
function OrganizerDashboardPage_Conditional_11_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 8);
    \u0275\u0275element(1, "ion-spinner", 10);
    \u0275\u0275elementEnd();
  }
}
function OrganizerDashboardPage_Conditional_12_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r2 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "section", 12)(1, "div")(2, "h2", 14);
    \u0275\u0275text(3, "Guiar al panel");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "p", 19);
    \u0275\u0275text(5, "Lleva a todos los catadores a la misma muestra.");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(6, "div", 21)(7, "ion-button", 22);
    \u0275\u0275listener("click", function OrganizerDashboardPage_Conditional_12_Conditional_1_Template_ion_button_click_7_listener() {
      \u0275\u0275restoreView(_r2);
      const ctx_r2 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r2.guiarPanel(-1));
    });
    \u0275\u0275text(8, "\u2190");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(9, "span", 23);
    \u0275\u0275text(10);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(11, "ion-button", 22);
    \u0275\u0275listener("click", function OrganizerDashboardPage_Conditional_12_Conditional_1_Template_ion_button_click_11_listener() {
      \u0275\u0275restoreView(_r2);
      const ctx_r2 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r2.guiarPanel(1));
    });
    \u0275\u0275element(12, "ion-icon", 24);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(7);
    \u0275\u0275property("disabled", ctx_r2.muestraGuiada() <= 1);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate1("Muestra ", ctx_r2.muestraGuiada());
    \u0275\u0275advance();
    \u0275\u0275property("disabled", ctx_r2.muestraGuiada() >= ctx_r2.numeroMuestras());
  }
}
function OrganizerDashboardPage_Conditional_12_For_12_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "th", 17);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const n_r4 = ctx.$implicit;
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1("M", n_r4);
  }
}
function OrganizerDashboardPage_Conditional_12_For_15_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 28);
    \u0275\u0275text(1, "org.");
    \u0275\u0275elementEnd();
  }
}
function OrganizerDashboardPage_Conditional_12_For_15_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 29);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const fila_r5 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1("inestable \xB7 ", fila_r5.segundosGracia, " s");
  }
}
function OrganizerDashboardPage_Conditional_12_For_15_For_8_Case_1_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-icon", 30);
  }
}
function OrganizerDashboardPage_Conditional_12_For_15_For_8_Case_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-icon", 31);
  }
}
function OrganizerDashboardPage_Conditional_12_For_15_For_8_Case_3_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-icon", 32);
  }
}
function OrganizerDashboardPage_Conditional_12_For_15_For_8_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "td");
    \u0275\u0275conditionalCreate(1, OrganizerDashboardPage_Conditional_12_For_15_For_8_Case_1_Template, 1, 0, "ion-icon", 30)(2, OrganizerDashboardPage_Conditional_12_For_15_For_8_Case_2_Template, 1, 0, "ion-icon", 31)(3, OrganizerDashboardPage_Conditional_12_For_15_For_8_Case_3_Template, 1, 0, "ion-icon", 32);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    let tmp_22_0;
    const celda_r6 = ctx.$implicit;
    \u0275\u0275attribute("aria-label", celda_r6);
    \u0275\u0275advance();
    \u0275\u0275conditional((tmp_22_0 = celda_r6) === "enviada" ? 1 : tmp_22_0 === "cerrada" ? 2 : 3);
  }
}
function OrganizerDashboardPage_Conditional_12_For_15_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "tr")(1, "th", 25);
    \u0275\u0275element(2, "span", 26);
    \u0275\u0275elementStart(3, "span", 27);
    \u0275\u0275text(4);
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(5, OrganizerDashboardPage_Conditional_12_For_15_Conditional_5_Template, 2, 0, "span", 28);
    \u0275\u0275conditionalCreate(6, OrganizerDashboardPage_Conditional_12_For_15_Conditional_6_Template, 2, 1, "span", 29);
    \u0275\u0275elementEnd();
    \u0275\u0275repeaterCreate(7, OrganizerDashboardPage_Conditional_12_For_15_For_8_Template, 4, 2, "td", null, \u0275\u0275repeaterTrackByIndex);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const fila_r5 = ctx.$implicit;
    \u0275\u0275classProp("od-row--unstable", fila_r5.conexion === "inestable");
    \u0275\u0275advance(2);
    \u0275\u0275classProp("od-presence--online", fila_r5.conexion === "en_linea")("od-presence--unstable", fila_r5.conexion === "inestable");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(fila_r5.nombre);
    \u0275\u0275advance();
    \u0275\u0275conditional(fila_r5.esOrganizador ? 5 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(fila_r5.conexion === "inestable" ? 6 : -1);
    \u0275\u0275advance();
    \u0275\u0275repeater(fila_r5.celdas);
  }
}
function OrganizerDashboardPage_Conditional_12_ForEmpty_16_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "tr")(1, "td", 33);
    \u0275\u0275text(2, "Nadie se ha unido a\xFAn.");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275attribute("colspan", ctx_r2.numeroMuestras() + 1);
  }
}
function OrganizerDashboardPage_Conditional_12_Conditional_17_For_5_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 35);
    \u0275\u0275listener("click", function OrganizerDashboardPage_Conditional_12_Conditional_17_For_5_Conditional_1_Template_button_click_0_listener() {
      \u0275\u0275restoreView(_r7);
      const m_r8 = \u0275\u0275nextContext().$implicit;
      const ctx_r2 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r2.forzarCierreMuestra(m_r8.numero, m_r8.pendientes));
    });
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const m_r8 = \u0275\u0275nextContext().$implicit;
    const ctx_r2 = \u0275\u0275nextContext(3);
    \u0275\u0275property("disabled", ctx_r2.accionEnCurso() !== null);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" Cerrar (", m_r8.pendientes, ") ");
  }
}
function OrganizerDashboardPage_Conditional_12_Conditional_17_For_5_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "td");
    \u0275\u0275conditionalCreate(1, OrganizerDashboardPage_Conditional_12_Conditional_17_For_5_Conditional_1_Template, 2, 2, "button", 34);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const m_r8 = ctx.$implicit;
    \u0275\u0275advance();
    \u0275\u0275conditional(!m_r8.cerrada && m_r8.pendientes > 0 ? 1 : -1);
  }
}
function OrganizerDashboardPage_Conditional_12_Conditional_17_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "tfoot")(1, "tr")(2, "th", 25);
    \u0275\u0275text(3, "Desbloquear");
    \u0275\u0275elementEnd();
    \u0275\u0275repeaterCreate(4, OrganizerDashboardPage_Conditional_12_Conditional_17_For_5_Template, 2, 1, "td", null, _forTrack1);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(4);
    \u0275\u0275repeater(ctx_r2.pendientesPorMuestra());
  }
}
function OrganizerDashboardPage_Conditional_12_Conditional_21_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-spinner", 10);
  }
}
function OrganizerDashboardPage_Conditional_12_Conditional_22_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275text(0, " Ver resultados del panel \u2192 ");
  }
}
function OrganizerDashboardPage_Conditional_12_Conditional_23_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275text(0, " Finalizar panel y ver resultados ");
  }
}
function OrganizerDashboardPage_Conditional_12_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = \u0275\u0275getCurrentView();
    \u0275\u0275element(0, "app-progress-tracker", 11);
    \u0275\u0275conditionalCreate(1, OrganizerDashboardPage_Conditional_12_Conditional_1_Template, 13, 3, "section", 12);
    \u0275\u0275elementStart(2, "section", 13)(3, "h2", 14);
    \u0275\u0275text(4, "Fichas por catador");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "div", 15)(6, "table", 16)(7, "thead")(8, "tr")(9, "th", 17);
    \u0275\u0275text(10, "Catador");
    \u0275\u0275elementEnd();
    \u0275\u0275repeaterCreate(11, OrganizerDashboardPage_Conditional_12_For_12_Template, 2, 1, "th", 17, \u0275\u0275repeaterTrackByIdentity);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(13, "tbody");
    \u0275\u0275repeaterCreate(14, OrganizerDashboardPage_Conditional_12_For_15_Template, 9, 9, "tr", 18, _forTrack0, false, OrganizerDashboardPage_Conditional_12_ForEmpty_16_Template, 3, 1, "tr");
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(17, OrganizerDashboardPage_Conditional_12_Conditional_17_Template, 6, 0, "tfoot");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(18, "p", 19);
    \u0275\u0275text(19, "Por evaluaci\xF3n ciega solo ves el avance, nunca los puntajes. Un catador desconectado m\xE1s de 45 s se retira autom\xE1ticamente si no ha entregado todas sus fichas.");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(20, "ion-button", 20);
    \u0275\u0275listener("click", function OrganizerDashboardPage_Conditional_12_Template_ion_button_click_20_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.finalizarSesion());
    });
    \u0275\u0275conditionalCreate(21, OrganizerDashboardPage_Conditional_12_Conditional_21_Template, 1, 0, "ion-spinner", 10)(22, OrganizerDashboardPage_Conditional_12_Conditional_22_Template, 1, 0)(23, OrganizerDashboardPage_Conditional_12_Conditional_23_Template, 1, 0);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext();
    \u0275\u0275property("completados", ctx_r2.terminados())("total", ctx_r2.filas().length);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r2.panelEnProgreso() && ctx_r2.numeroMuestras() > 1 ? 1 : -1);
    \u0275\u0275advance(10);
    \u0275\u0275repeater(ctx_r2.muestras());
    \u0275\u0275advance(3);
    \u0275\u0275repeater(ctx_r2.filas());
    \u0275\u0275advance(3);
    \u0275\u0275conditional(ctx_r2.panelEnProgreso() ? 17 : -1);
    \u0275\u0275advance(3);
    \u0275\u0275property("disabled", ctx_r2.accionEnCurso() !== null);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r2.accionEnCurso() === "finalizar" ? 21 : ctx_r2.panelCerrado() ? 22 : 23);
  }
}
var SONDEO_PROGRESO_MS = 3e4;
var SONDEO_SIN_SOCKET_MS = 8e3;
var _OrganizerDashboardPage = class _OrganizerDashboardPage {
  constructor() {
    this.route = inject(ActivatedRoute);
    this.router = inject(Router);
    this.authService = inject(AuthService);
    this.sesionService = inject(SesionService);
    this.realtimeService = inject(RealtimeService);
    this.alertCtrl = inject(AlertController);
    this.toastCtrl = inject(ToastController);
    this.nombreSesion = signal(
      "",
      ...ngDevMode ? [{ debugName: "nombreSesion" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.progreso = signal(
      null,
      ...ngDevMode ? [{ debugName: "progreso" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.cargando = signal(
      true,
      ...ngDevMode ? [{ debugName: "cargando" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.accionEnCurso = signal(
      null,
      ...ngDevMode ? [{ debugName: "accionEnCurso" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.error = signal(
      null,
      ...ngDevMode ? [{ debugName: "error" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.muestraGuiada = signal(
      1,
      ...ngDevMode ? [{ debugName: "muestraGuiada" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.sala = signal(
      null,
      ...ngDevMode ? [{ debugName: "sala" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.ahora = signal(
      Date.now(),
      ...ngDevMode ? [{ debugName: "ahora" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.sinConexion = computed(
      () => {
        const sala = this.sala();
        return sala !== null && sala.estadoConexion() !== "conectado";
      },
      ...ngDevMode ? [{ debugName: "sinConexion" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.numeroMuestras = computed(
      () => this.progreso()?.numeroMuestras ?? 0,
      ...ngDevMode ? [{ debugName: "numeroMuestras" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.muestras = computed(
      () => Array.from({ length: this.numeroMuestras() }, (_, i) => i + 1),
      ...ngDevMode ? [{ debugName: "muestras" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.panelCerrado = computed(
      () => this.progreso()?.estado === "completada",
      ...ngDevMode ? [{ debugName: "panelCerrado" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.panelEnProgreso = computed(
      () => this.progreso()?.estado === "en_progreso",
      ...ngDevMode ? [{ debugName: "panelEnProgreso" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.filas = computed(
      () => {
        const progreso = this.progreso();
        if (!progreso)
          return [];
        const cerradas = new Set(progreso.muestrasCerradas);
        const presencia = this.sala()?.presencia() ?? /* @__PURE__ */ new Map();
        const ahora = this.ahora();
        return progreso.catadores.map((catador) => {
          const enviadas = new Set(catador.muestrasEnviadas);
          const celdas = this.muestras().map((n) => enviadas.has(n) ? "enviada" : cerradas.has(n) ? "cerrada" : "pendiente");
          const registro = presencia.get(catador.usuarioId);
          const conexion = registro?.estado ?? "desconectado";
          return {
            usuarioId: catador.usuarioId,
            nombre: catador.nombre,
            esOrganizador: catador.esOrganizador,
            conexion,
            segundosGracia: conexion === "inestable" && registro ? Math.max(0, Math.ceil((registro.desde + GRACE_PERIOD_MS - ahora) / 1e3)) : null,
            celdas,
            enviadas: enviadas.size,
            terminado: celdas.every((c) => c !== "pendiente")
          };
        });
      },
      ...ngDevMode ? [{ debugName: "filas" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.terminados = computed(
      () => this.filas().filter((f) => f.terminado).length,
      ...ngDevMode ? [{ debugName: "terminados" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.pendientesPorMuestra = computed(
      () => this.muestras().map((n, indice) => ({
        numero: n,
        pendientes: this.filas().filter((f) => f.celdas[indice] === "pendiente").length,
        cerrada: this.progreso()?.muestrasCerradas.includes(n) ?? false
      })),
      ...ngDevMode ? [{ debugName: "pendientesPorMuestra" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.sesionId = "";
    this.activo = false;
    addIcons({ checkmarkCircle, cloudOfflineOutline, ellipseOutline, lockClosed, personCircleOutline, playForwardOutline });
  }
  ionViewWillEnter() {
    void this.conectar();
  }
  ionViewWillLeave() {
    this.desconectar();
  }
  ngOnDestroy() {
    this.desconectar();
  }
  async conectar() {
    if (this.activo)
      return;
    this.activo = true;
    this.cargando.set(true);
    this.error.set(null);
    this.progreso.set(null);
    this.sesionId = this.route.snapshot.paramMap.get("id")?.trim() ?? "";
    if (!this.sesionId) {
      this.error.set("No se encontr\xF3 el ID de la sesi\xF3n.");
      this.cargando.set(false);
      return;
    }
    try {
      await this.authService.asegurarInicializado();
      const usuario = this.authService.usuario();
      if (!usuario)
        throw new Error("Debes iniciar sesi\xF3n.");
      const sesion = await this.sesionService.obtenerSesionPorId(this.sesionId);
      if (!this.activo)
        return;
      if (!sesion)
        throw new Error("No se encontr\xF3 la sesi\xF3n.");
      this.nombreSesion.set(sesion.nombre);
      await this.actualizarProgreso();
      if (!this.activo)
        return;
      const sala = this.realtimeService.abrirSala({
        sesionId: this.sesionId,
        usuarioId: usuario.id,
        nombre: usuario.nombre,
        rol: "organizador"
      });
      this.sala.set(sala);
      this.eventosSub = sala.eventos$.subscribe((evento) => void this.manejarEvento(evento));
      this.sondeoId = setInterval(() => void this.actualizarProgreso(), SONDEO_PROGRESO_MS);
      this.sondeoRapidoId = setInterval(() => {
        if (this.sinConexion())
          void this.actualizarProgreso();
      }, SONDEO_SIN_SOCKET_MS);
      this.relojId = setInterval(() => {
        if (this.filas().some((f) => f.conexion === "inestable"))
          this.ahora.set(Date.now());
      }, 1e3);
    } catch (error) {
      this.error.set(mensajeDeError(error, "No se pudo cargar el panel."));
    } finally {
      this.cargando.set(false);
    }
  }
  desconectar() {
    this.activo = false;
    this.eventosSub?.unsubscribe();
    this.eventosSub = void 0;
    clearInterval(this.sondeoId);
    clearInterval(this.sondeoRapidoId);
    clearInterval(this.relojId);
    const sala = this.sala();
    if (sala)
      this.realtimeService.liberarSala(sala);
    this.sala.set(null);
  }
  async manejarEvento(evento) {
    switch (evento.tipo) {
      case "EVALUACION_ENVIADA":
      case "PARTICIPANTE_RETIRADO":
      case "RESYNC":
        await this.actualizarProgreso();
        break;
      default:
        break;
    }
  }
  async actualizarProgreso() {
    if (!this.activo)
      return;
    try {
      const progreso = await this.sesionService.obtenerProgresoPanel(this.sesionId);
      if (!this.activo)
        return;
      this.progreso.set(progreso);
      this.error.set(null);
    } catch (error) {
      console.error("No se pudo actualizar el progreso del panel:", error);
      this.error.set(mensajeDeError(error, "No se pudo actualizar el progreso."));
    }
  }
  async guiarPanel(delta) {
    const total = this.numeroMuestras();
    if (total === 0 || this.accionEnCurso())
      return;
    const destino = Math.min(total, Math.max(1, this.muestraGuiada() + delta));
    this.muestraGuiada.set(destino);
    const ok = await this.sala()?.enviar({ tipo: "CAMBIAR_MUESTRA", numeroMuestra: destino });
    await this.toast(ok ? `Panel guiado a la muestra ${destino}.` : "Sin conexi\xF3n: no se pudo avisar al panel.", ok ? "dark" : "warning");
  }
  async forzarCierreMuestra(numeroMuestra, pendientes) {
    if (this.accionEnCurso())
      return;
    const confirmado = await this.confirmar(`Cerrar muestra ${numeroMuestra}`, `${pendientes} ficha(s) pendiente(s) de esta muestra no se aceptar\xE1n y no contar\xE1n en el consolidado.`, "Cerrar muestra");
    if (!confirmado)
      return;
    this.accionEnCurso.set(`muestra-${numeroMuestra}`);
    try {
      const resultado = await this.sesionService.forzarCierreMuestra(this.sesionId, numeroMuestra);
      await this.sala()?.enviar({ tipo: "MUESTRA_CERRADA", numeroMuestra });
      if (resultado.sesionCompletada) {
        await this.sala()?.enviar({ tipo: "SESION_FINALIZADA" });
        await this.irAResultados();
        return;
      }
      await this.actualizarProgreso();
    } catch (error) {
      this.error.set(mensajeDeError(error, "No se pudo cerrar la muestra."));
    } finally {
      this.accionEnCurso.set(null);
    }
  }
  async finalizarSesion() {
    if (this.panelCerrado()) {
      await this.irAResultados();
      return;
    }
    if (this.accionEnCurso())
      return;
    const pendientes = this.filas().filter((f) => !f.terminado).length;
    const confirmado = await this.confirmar("Finalizar panel", pendientes > 0 ? `Hay ${pendientes} catador(es) con fichas pendientes. Se cerrar\xE1n todas las muestras y no se aceptar\xE1n m\xE1s env\xEDos.` : "Se cerrar\xE1 el panel y se calcular\xE1n los resultados.", "Finalizar y ver resultados");
    if (!confirmado)
      return;
    this.accionEnCurso.set("finalizar");
    try {
      await this.sesionService.finalizarSesionForzado(this.sesionId, pendientes > 0 ? `Finalizado por el organizador con ${pendientes} catador(es) pendiente(s)` : void 0);
      await this.sala()?.enviar({ tipo: "SESION_FINALIZADA" });
      await this.irAResultados();
    } catch (error) {
      this.error.set(mensajeDeError(error, "No se pudo finalizar el panel."));
    } finally {
      this.accionEnCurso.set(null);
    }
  }
  async confirmar(header, message, textoConfirmar) {
    const alerta = await this.alertCtrl.create({
      header,
      message,
      buttons: [
        { text: "Cancelar", role: "cancel" },
        { text: textoConfirmar, role: "confirm" }
      ]
    });
    await alerta.present();
    const { role } = await alerta.onDidDismiss();
    return role === "confirm";
  }
  async toast(message, color) {
    const toast = await this.toastCtrl.create({ message, duration: 2e3, color });
    await toast.present();
  }
  async irAResultados() {
    await this.router.navigateByUrl(`/session/${this.sesionId}/results`, { replaceUrl: true });
  }
};
_OrganizerDashboardPage.\u0275fac = function OrganizerDashboardPage_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _OrganizerDashboardPage)();
};
_OrganizerDashboardPage.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _OrganizerDashboardPage, selectors: [["app-organizer-dashboard"]], decls: 13, vars: 4, consts: [[1, "ion-no-border"], [1, "od-toolbar"], [1, "od-title"], [1, "od-subtitle"], [1, "ion-padding", "od-content"], [1, "od-container"], ["role", "status", 1, "od-banner"], ["role", "alert", 1, "od-error"], ["role", "status", 1, "od-empty"], ["name", "cloud-offline-outline", "aria-hidden", "true"], ["name", "crescent"], [3, "completados", "total"], [1, "cupping-card", "od-guide"], [1, "cupping-card"], [1, "od-section-title"], [1, "od-table-wrap"], [1, "od-table"], ["scope", "col"], [3, "od-row--unstable"], [1, "od-hint"], ["expand", "block", 1, "primary-btn", 3, "click", "disabled"], [1, "od-stepper"], ["fill", "outline", "size", "small", 3, "click", "disabled"], [1, "od-stepper__value"], ["name", "play-forward-outline", "aria-label", "Siguiente muestra"], ["scope", "row"], [1, "od-presence"], [1, "od-name"], [1, "od-tag"], [1, "od-grace"], ["name", "checkmark-circle", "color", "success"], ["name", "lock-closed", "color", "medium"], ["name", "ellipse-outline", "color", "medium"], [1, "od-empty"], ["type", "button", 1, "od-close-btn", 3, "disabled"], ["type", "button", 1, "od-close-btn", 3, "click", "disabled"]], template: function OrganizerDashboardPage_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-header", 0)(1, "ion-toolbar", 1)(2, "ion-title")(3, "div", 2);
    \u0275\u0275text(4, "Sala de control");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "div", 3);
    \u0275\u0275text(6);
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(7, "ion-content", 4)(8, "main", 5);
    \u0275\u0275conditionalCreate(9, OrganizerDashboardPage_Conditional_9_Template, 3, 0, "div", 6);
    \u0275\u0275conditionalCreate(10, OrganizerDashboardPage_Conditional_10_Template, 2, 1, "div", 7);
    \u0275\u0275conditionalCreate(11, OrganizerDashboardPage_Conditional_11_Template, 2, 0, "div", 8)(12, OrganizerDashboardPage_Conditional_12_Template, 24, 7);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    let tmp_2_0;
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate(ctx.nombreSesion());
    \u0275\u0275advance(3);
    \u0275\u0275conditional(ctx.sinConexion() ? 9 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional((tmp_2_0 = ctx.error()) ? 10 : -1, tmp_2_0);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx.cargando() ? 11 : ctx.progreso() ? 12 : -1);
  }
}, dependencies: [
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonIcon,
  IonButton,
  IonSpinner,
  CommonModule,
  ProgressTrackerComponent
], styles: ["\n.od-toolbar[_ngcontent-%COMP%] {\n  --%NS%background: var(--%NS%app-bg-card);\n}\n.od-title[_ngcontent-%COMP%] {\n  color: var(--%NS%app-text-main);\n  font-size: 15px;\n  font-weight: 700;\n}\n.od-subtitle[_ngcontent-%COMP%] {\n  color: var(--%NS%app-text-muted);\n  font-size: 12px;\n  font-weight: 400;\n}\n.od-content[_ngcontent-%COMP%] {\n  --%NS%background: var(--%NS%app-bg-screen);\n}\n.od-container[_ngcontent-%COMP%] {\n  width: min(100%, 720px);\n  margin: 0 auto;\n}\n.od-section-title[_ngcontent-%COMP%] {\n  margin: 0 0 4px;\n  color: var(--%NS%app-text-muted);\n  font-size: 11px;\n  font-weight: 700;\n  letter-spacing: 0.05em;\n  text-transform: uppercase;\n}\n.od-hint[_ngcontent-%COMP%] {\n  margin: 8px 0 0;\n  color: var(--%NS%app-text-muted);\n  font-size: 12px;\n}\n.od-empty[_ngcontent-%COMP%] {\n  padding: 24px;\n  color: var(--%NS%app-text-muted);\n  text-align: center;\n}\n.od-error[_ngcontent-%COMP%] {\n  margin-bottom: 16px;\n  padding: 12px;\n  border-radius: 8px;\n  background: var(--%NS%app-error-bg);\n  color: var(--%NS%app-error-text);\n  font-size: 13px;\n}\n.od-banner[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  margin-bottom: 16px;\n  padding: 10px 12px;\n  border-radius: 8px;\n  background: #fef9c3;\n  color: #854d0e;\n  font-size: 12px;\n}\n.od-guide[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  gap: 12px;\n}\n.od-stepper[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n}\n.od-stepper__value[_ngcontent-%COMP%] {\n  min-width: 88px;\n  color: var(--%NS%app-text-main);\n  font-weight: 700;\n  text-align: center;\n}\n.od-table-wrap[_ngcontent-%COMP%] {\n  margin-top: 8px;\n  overflow-x: auto;\n}\n.od-table[_ngcontent-%COMP%] {\n  width: 100%;\n  border-collapse: collapse;\n  font-size: 13px;\n}\n.od-table[_ngcontent-%COMP%]   th[_ngcontent-%COMP%], \n.od-table[_ngcontent-%COMP%]   td[_ngcontent-%COMP%] {\n  padding: 8px 6px;\n  border-bottom: 1px solid var(--%NS%app-border);\n  text-align: center;\n}\n.od-table[_ngcontent-%COMP%]   thead[_ngcontent-%COMP%]   th[_ngcontent-%COMP%] {\n  color: var(--%NS%app-text-muted);\n  font-size: 11px;\n  font-weight: 600;\n}\n.od-table[_ngcontent-%COMP%]   tbody[_ngcontent-%COMP%]   th[_ngcontent-%COMP%], \n.od-table[_ngcontent-%COMP%]   tfoot[_ngcontent-%COMP%]   th[_ngcontent-%COMP%] {\n  color: var(--%NS%app-text-main);\n  font-weight: 500;\n  text-align: left;\n  white-space: nowrap;\n}\n.od-table[_ngcontent-%COMP%]   tfoot[_ngcontent-%COMP%]   th[_ngcontent-%COMP%] {\n  color: var(--%NS%app-text-muted);\n  font-size: 11px;\n}\n.od-table[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 18px;\n  vertical-align: middle;\n}\n.od-row--unstable[_ngcontent-%COMP%] {\n  background: #fefce8;\n}\n.od-presence[_ngcontent-%COMP%] {\n  display: inline-block;\n  width: 8px;\n  height: 8px;\n  margin-right: 6px;\n  border-radius: 50%;\n  background: var(--%NS%app-text-faint);\n}\n.od-presence--online[_ngcontent-%COMP%] {\n  background: var(--%NS%app-success);\n}\n.od-presence--unstable[_ngcontent-%COMP%] {\n  background: #eab308;\n}\n.od-tag[_ngcontent-%COMP%] {\n  margin-left: 4px;\n  color: var(--%NS%app-text-muted);\n  font-size: 10px;\n}\n.od-grace[_ngcontent-%COMP%] {\n  display: block;\n  color: #a16207;\n  font-size: 11px;\n  font-weight: 600;\n}\n.od-close-btn[_ngcontent-%COMP%] {\n  padding: 4px 8px;\n  border: 1px solid var(--%NS%app-border);\n  border-radius: 6px;\n  background: var(--%NS%app-bg-card);\n  color: var(--%NS%app-text-main);\n  font: inherit;\n  font-size: 11px;\n  cursor: pointer;\n  white-space: nowrap;\n}\n.od-close-btn[_ngcontent-%COMP%]:disabled {\n  opacity: 0.5;\n  cursor: default;\n}\n/*# sourceMappingURL=organizer-dashboard.page.css.map */"] });
var OrganizerDashboardPage = _OrganizerDashboardPage;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(OrganizerDashboardPage, [{
    type: Component,
    args: [{ selector: "app-organizer-dashboard", standalone: true, imports: [
      IonHeader,
      IonToolbar,
      IonTitle,
      IonContent,
      IonIcon,
      IonButton,
      IonSpinner,
      CommonModule,
      ProgressTrackerComponent
    ], template: `<ion-header class="ion-no-border">
  <ion-toolbar class="od-toolbar">
    <ion-title>
      <div class="od-title">Sala de control</div>
      <div class="od-subtitle">{{ nombreSesion() }}</div>
    </ion-title>
  </ion-toolbar>
</ion-header>

<ion-content class="ion-padding od-content">
  <main class="od-container">
    @if (sinConexion()) {
      <div class="od-banner" role="status">
        <ion-icon name="cloud-offline-outline" aria-hidden="true"></ion-icon>
        Reconectando\u2026 el progreso se actualiza cada pocos segundos mientras tanto.
      </div>
    }

    @if (error(); as mensaje) {
      <div class="od-error" role="alert">{{ mensaje }}</div>
    }

    @if (cargando()) {
      <div class="od-empty" role="status"><ion-spinner name="crescent"></ion-spinner></div>
    } @else if (progreso()) {
      <app-progress-tracker [completados]="terminados()" [total]="filas().length"></app-progress-tracker>

      @if (panelEnProgreso() && numeroMuestras() > 1) {
        <section class="cupping-card od-guide">
          <div>
            <h2 class="od-section-title">Guiar al panel</h2>
            <p class="od-hint">Lleva a todos los catadores a la misma muestra.</p>
          </div>
          <div class="od-stepper">
            <ion-button fill="outline" size="small" [disabled]="muestraGuiada() <= 1" (click)="guiarPanel(-1)">\u2190</ion-button>
            <span class="od-stepper__value">Muestra {{ muestraGuiada() }}</span>
            <ion-button fill="outline" size="small" [disabled]="muestraGuiada() >= numeroMuestras()" (click)="guiarPanel(1)">
              <ion-icon name="play-forward-outline" aria-label="Siguiente muestra"></ion-icon>
            </ion-button>
          </div>
        </section>
      }

      <section class="cupping-card">
        <h2 class="od-section-title">Fichas por catador</h2>
        <div class="od-table-wrap">
          <table class="od-table">
            <thead>
              <tr>
                <th scope="col">Catador</th>
                @for (n of muestras(); track n) {
                  <th scope="col">M{{ n }}</th>
                }
              </tr>
            </thead>
            <tbody>
              @for (fila of filas(); track fila.usuarioId) {
                <tr [class.od-row--unstable]="fila.conexion === 'inestable'">
                  <th scope="row">
                    <span
                      class="od-presence"
                      [class.od-presence--online]="fila.conexion === 'en_linea'"
                      [class.od-presence--unstable]="fila.conexion === 'inestable'"></span>
                    <span class="od-name">{{ fila.nombre }}</span>
                    @if (fila.esOrganizador) { <span class="od-tag">org.</span> }
                    @if (fila.conexion === 'inestable') {
                      <span class="od-grace">inestable \xB7 {{ fila.segundosGracia }} s</span>
                    }
                  </th>
                  @for (celda of fila.celdas; track $index) {
                    <td [attr.aria-label]="celda">
                      @switch (celda) {
                        @case ('enviada') { <ion-icon name="checkmark-circle" color="success"></ion-icon> }
                        @case ('cerrada') { <ion-icon name="lock-closed" color="medium"></ion-icon> }
                        @default { <ion-icon name="ellipse-outline" color="medium"></ion-icon> }
                      }
                    </td>
                  }
                </tr>
              } @empty {
                <tr><td class="od-empty" [attr.colspan]="numeroMuestras() + 1">Nadie se ha unido a\xFAn.</td></tr>
              }
            </tbody>
            @if (panelEnProgreso()) {
              <tfoot>
                <tr>
                  <th scope="row">Desbloquear</th>
                  @for (m of pendientesPorMuestra(); track m.numero) {
                    <td>
                      @if (!m.cerrada && m.pendientes > 0) {
                        <button
                          type="button"
                          class="od-close-btn"
                          [disabled]="accionEnCurso() !== null"
                          (click)="forzarCierreMuestra(m.numero, m.pendientes)">
                          Cerrar ({{ m.pendientes }})
                        </button>
                      }
                    </td>
                  }
                </tr>
              </tfoot>
            }
          </table>
        </div>
        <p class="od-hint">Por evaluaci\xF3n ciega solo ves el avance, nunca los puntajes. Un catador desconectado m\xE1s de 45 s se retira autom\xE1ticamente si no ha entregado todas sus fichas.</p>
      </section>

      <ion-button expand="block" class="primary-btn" [disabled]="accionEnCurso() !== null" (click)="finalizarSesion()">
        @if (accionEnCurso() === 'finalizar') {
          <ion-spinner name="crescent"></ion-spinner>
        } @else if (panelCerrado()) {
          Ver resultados del panel \u2192
        } @else {
          Finalizar panel y ver resultados
        }
      </ion-button>
    }
  </main>
</ion-content>
`, styles: ["/* src/app/pages/session/organizer-dashboard/organizer-dashboard.page.scss */\n.od-toolbar {\n  --background: var(--app-bg-card);\n}\n.od-title {\n  color: var(--app-text-main);\n  font-size: 15px;\n  font-weight: 700;\n}\n.od-subtitle {\n  color: var(--app-text-muted);\n  font-size: 12px;\n  font-weight: 400;\n}\n.od-content {\n  --background: var(--app-bg-screen);\n}\n.od-container {\n  width: min(100%, 720px);\n  margin: 0 auto;\n}\n.od-section-title {\n  margin: 0 0 4px;\n  color: var(--app-text-muted);\n  font-size: 11px;\n  font-weight: 700;\n  letter-spacing: 0.05em;\n  text-transform: uppercase;\n}\n.od-hint {\n  margin: 8px 0 0;\n  color: var(--app-text-muted);\n  font-size: 12px;\n}\n.od-empty {\n  padding: 24px;\n  color: var(--app-text-muted);\n  text-align: center;\n}\n.od-error {\n  margin-bottom: 16px;\n  padding: 12px;\n  border-radius: 8px;\n  background: var(--app-error-bg);\n  color: var(--app-error-text);\n  font-size: 13px;\n}\n.od-banner {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  margin-bottom: 16px;\n  padding: 10px 12px;\n  border-radius: 8px;\n  background: #fef9c3;\n  color: #854d0e;\n  font-size: 12px;\n}\n.od-guide {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  gap: 12px;\n}\n.od-stepper {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n}\n.od-stepper__value {\n  min-width: 88px;\n  color: var(--app-text-main);\n  font-weight: 700;\n  text-align: center;\n}\n.od-table-wrap {\n  margin-top: 8px;\n  overflow-x: auto;\n}\n.od-table {\n  width: 100%;\n  border-collapse: collapse;\n  font-size: 13px;\n}\n.od-table th,\n.od-table td {\n  padding: 8px 6px;\n  border-bottom: 1px solid var(--app-border);\n  text-align: center;\n}\n.od-table thead th {\n  color: var(--app-text-muted);\n  font-size: 11px;\n  font-weight: 600;\n}\n.od-table tbody th,\n.od-table tfoot th {\n  color: var(--app-text-main);\n  font-weight: 500;\n  text-align: left;\n  white-space: nowrap;\n}\n.od-table tfoot th {\n  color: var(--app-text-muted);\n  font-size: 11px;\n}\n.od-table ion-icon {\n  font-size: 18px;\n  vertical-align: middle;\n}\n.od-row--unstable {\n  background: #fefce8;\n}\n.od-presence {\n  display: inline-block;\n  width: 8px;\n  height: 8px;\n  margin-right: 6px;\n  border-radius: 50%;\n  background: var(--app-text-faint);\n}\n.od-presence--online {\n  background: var(--app-success);\n}\n.od-presence--unstable {\n  background: #eab308;\n}\n.od-tag {\n  margin-left: 4px;\n  color: var(--app-text-muted);\n  font-size: 10px;\n}\n.od-grace {\n  display: block;\n  color: #a16207;\n  font-size: 11px;\n  font-weight: 600;\n}\n.od-close-btn {\n  padding: 4px 8px;\n  border: 1px solid var(--app-border);\n  border-radius: 6px;\n  background: var(--app-bg-card);\n  color: var(--app-text-main);\n  font: inherit;\n  font-size: 11px;\n  cursor: pointer;\n  white-space: nowrap;\n}\n.od-close-btn:disabled {\n  opacity: 0.5;\n  cursor: default;\n}\n/*# sourceMappingURL=organizer-dashboard.page.css.map */\n"] }]
  }], () => [], null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(OrganizerDashboardPage, { className: "OrganizerDashboardPage", filePath: "src/app/pages/session/organizer-dashboard/organizer-dashboard.page.ts", lineNumber: 54 });
})();
export {
  OrganizerDashboardPage
};
//# debugId=706ca8dd-6b30-52bb-8299-c86e0bbf901c
//# sourceMappingURL=organizer-dashboard.page-7GUBWF6Y.js.map
