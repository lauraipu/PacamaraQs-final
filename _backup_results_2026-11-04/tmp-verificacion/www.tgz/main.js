import {
  AuthService
} from "./chunk-JH4CNQSM.js";
import {
  Component,
  IonApp,
  IonRouterOutlet,
  IonicRouteStrategy,
  PreloadAllModules,
  RouteReuseStrategy,
  Router,
  SupabaseService,
  bootstrapApplication,
  inject,
  provideIonicAngular,
  provideRouter,
  setClassMetadata,
  withComponentInputBinding,
  withPreloading,
  ɵsetClassDebugInfo,
  ɵɵdefineComponent,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart
} from "./chunk-DEQWXDMW.js";
import "./chunk-BMQUG2PJ.js";
import "./chunk-3OZZMUVI.js";
import "./chunk-3GAB7GSC.js";
import "./chunk-B7Y4FMY7.js";
import "./chunk-NQCL7WZ3.js";
import "./chunk-4BTEZGN2.js";
import "./chunk-XTVSKRH4.js";
import "./chunk-ETZFPO3Y.js";
import "./chunk-LLS636HS.js";
import "./chunk-KQQH3YTO.js";
import "./chunk-DI3VEDFV.js";
import "./chunk-PAXKX5KU.js";

// src/app/core/guards/auth.guard.ts
var authGuard = async (_route, state) => {
  const authService = inject(AuthService);
  const router = inject(Router);
  try {
    await authService.asegurarInicializado();
    if (authService.autenticado())
      return true;
    return router.createUrlTree(["/login"], { queryParams: { returnUrl: state.url } });
  } catch (error) {
    console.error("No se pudo validar la sesi\xF3n autenticada:", error);
    return router.createUrlTree(["/login"], {
      queryParams: { returnUrl: state.url, authError: "session" }
    });
  }
};

// src/app/core/guards/organizer.guard.ts
var organizerGuard = async (route) => {
  const supabase = inject(SupabaseService).client;
  const router = inject(Router);
  const sesionId = route.paramMap.get("id") || route.paramMap.get("sesionId");
  if (!sesionId)
    return router.createUrlTree(["/dashboard"]);
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user)
      return router.createUrlTree(["/login"]);
    const { data: sesion } = await supabase.from("sesiones").select("organizador_id").eq("id", sesionId).single();
    if (sesion && sesion.organizador_id === user.id) {
      return true;
    }
    return router.createUrlTree([`/session/${sesionId}/evaluation-complete`]);
  } catch {
    return router.createUrlTree(["/dashboard"]);
  }
};

// src/app/core/guards/role.guard.ts
var roleGuard = async (route) => {
  const authService = inject(AuthService);
  const router = inject(Router);
  const rolesPermitidos = route.data["roles"];
  if (!rolesPermitidos?.length) {
    console.error("La ruta protegida no define roles permitidos.");
    return router.createUrlTree(["/login"]);
  }
  try {
    await authService.asegurarInicializado();
    if (!authService.autenticado())
      return router.createUrlTree(["/login"]);
    const rol = await authService.obtenerRol();
    if (rolesPermitidos.includes(rol))
      return true;
    return router.createUrlTree([authService.rutaInicioPorRol(rol)]);
  } catch (error) {
    console.error("No se pudo validar el rol del usuario:", error);
    return router.createUrlTree(["/login"], { queryParams: { authError: "role" } });
  }
};

// src/app/app.routes.ts
var ROLES_APP = ["catador"];
var ROLES_ADMIN = ["administrador"];
var routes = [
  {
    path: "login",
    loadComponent: () => import("./login.page-T3RRNAWN.js").then((m) => m.LoginPage)
  },
  {
    path: "registro",
    loadComponent: () => import("./registro.page-RHQ7KSYG.js").then((m) => m.RegistroPage)
  },
  {
    path: "dashboard",
    loadComponent: () => import("./dashboard.page-4REEAZZ6.js").then((m) => m.DashboardPage),
    canActivate: [authGuard, roleGuard],
    data: { roles: ROLES_APP }
  },
  {
    path: "admin-dashboard",
    loadComponent: () => import("./admin-dashboard.page-LNVP2KR5.js").then((m) => m.AdminDashboardPage),
    canActivate: [authGuard, roleGuard],
    data: { roles: ROLES_ADMIN }
  },
  {
    path: "affective-form/:sesionId",
    loadComponent: () => import("./affective-form.page-5KKYKHIB.js").then((m) => m.AffectiveFormPage),
    canActivate: [authGuard, roleGuard],
    data: { roles: ROLES_APP }
  },
  {
    path: "combined-form/:sesionId",
    loadComponent: () => import("./combined-form.page-TCIJUGB3.js").then((m) => m.CombinedFormPage),
    canActivate: [authGuard, roleGuard],
    data: { roles: ROLES_APP }
  },
  {
    path: "descriptive-form/:sesionId",
    loadComponent: () => import("./descriptive-form.page-P6YPTOH4.js").then((m) => m.DescriptiveFormPage),
    canActivate: [authGuard, roleGuard],
    data: { roles: ROLES_APP }
  },
  {
    path: "extrinsic-form/:sesionId",
    loadComponent: () => import("./extrinsic-form.page-MF4NOCD2.js").then((m) => m.ExtrinsicFormPage),
    canActivate: [authGuard, roleGuard],
    data: { roles: ROLES_APP }
  },
  {
    path: "session/create",
    loadComponent: () => import("./create-session.page-RBZPMWHV.js").then((m) => m.CreateSessionPage),
    canActivate: [authGuard, roleGuard],
    data: { roles: ROLES_APP }
  },
  {
    path: "create-session",
    redirectTo: "session/create",
    pathMatch: "full"
  },
  {
    path: "session/waiting/:sesionId",
    loadComponent: () => import("./waiting-room.page-BAMZCXB2.js").then((m) => m.WaitingRoomPage),
    canActivate: [authGuard, roleGuard],
    data: { roles: ROLES_APP }
  },
  {
    path: "session/:id/organizer-dashboard",
    loadComponent: () => import("./organizer-dashboard.page-PD3CU4Z6.js").then((m) => m.OrganizerDashboardPage),
    canActivate: [authGuard, roleGuard, organizerGuard],
    data: { roles: ROLES_APP }
  },
  {
    path: "session/:id/evaluation-complete",
    loadComponent: () => import("./evaluation-complete.page-WHNVXURP.js").then((m) => m.EvaluationCompletePage),
    canActivate: [authGuard, roleGuard],
    data: { roles: ROLES_APP }
  },
  {
    path: "session/:id/results",
    loadComponent: () => import("./results.page-BFHRW2HO.js").then((m) => m.ResultsPage),
    canActivate: [authGuard, roleGuard, organizerGuard],
    data: { roles: ROLES_APP }
  },
  {
    path: "waiting-room",
    redirectTo: "dashboard",
    pathMatch: "full"
  },
  {
    path: "",
    redirectTo: "login",
    pathMatch: "full"
  },
  { path: "**", redirectTo: "login" }
];

// src/app/app.component.ts
var _AppComponent = class _AppComponent {
  constructor() {
  }
};
_AppComponent.\u0275fac = function AppComponent_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _AppComponent)();
};
_AppComponent.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _AppComponent, selectors: [["app-root"]], decls: 2, vars: 0, template: function AppComponent_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-app");
    \u0275\u0275element(1, "ion-router-outlet");
    \u0275\u0275elementEnd();
  }
}, dependencies: [IonApp, IonRouterOutlet], encapsulation: 2 });
var AppComponent = _AppComponent;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(AppComponent, [{
    type: Component,
    args: [{ selector: "app-root", imports: [IonApp, IonRouterOutlet], template: "<ion-app>\r\n  <ion-router-outlet></ion-router-outlet>\r\n</ion-app>\r\n" }]
  }], () => [], null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(AppComponent, { className: "AppComponent", filePath: "src/app/app.component.ts", lineNumber: 9 });
})();

// src/main.ts
bootstrapApplication(AppComponent, {
  providers: [
    { provide: RouteReuseStrategy, useClass: IonicRouteStrategy },
    provideIonicAngular(),
    provideRouter(routes, withPreloading(PreloadAllModules), withComponentInputBinding())
  ]
});
//# debugId=09de1784-ccf1-5140-ba3b-10dd92b31bb6
//# sourceMappingURL=main.js.map
