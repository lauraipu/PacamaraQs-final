import {
  Clipboard
} from "./chunk-KXKZQCE7.js";
import {
  SesionService
} from "./chunk-BHVR7Z6N.js";
import {
  EstadoSesion,
  FormatoCva,
  checkmarkCircle,
  informationCircleOutline
} from "./chunk-IN4O4X7H.js";
import {
  addIcons
} from "./chunk-4JFQPQWK.js";
import {
  AuthService
} from "./chunk-JH4CNQSM.js";
import {
  ChangeDetectorRef,
  CommonModule,
  Component,
  FormsModule,
  IonBackButton,
  IonButton,
  IonButtons,
  IonContent,
  IonFooter,
  IonHeader,
  IonIcon,
  IonInput,
  IonRange,
  IonSpinner,
  IonTextarea,
  IonTitle,
  IonToggle,
  IonToolbar,
  NgControlStatus,
  NgIf,
  NgModel,
  RequiredValidator,
  Router,
  RouterLink,
  ToastController,
  inject,
  setClassMetadata,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵattribute,
  ɵɵclassProp,
  ɵɵconditional,
  ɵɵconditionalCreate,
  ɵɵcontrol,
  ɵɵcontrolCreate,
  ɵɵdefineComponent,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵlistener,
  ɵɵnextContext,
  ɵɵproperty,
  ɵɵrepeater,
  ɵɵrepeaterCreate,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵtemplate,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1,
  ɵɵtwoWayBindingSet,
  ɵɵtwoWayListener,
  ɵɵtwoWayProperty
} from "./chunk-DEQWXDMW.js";
import "./chunk-BMQUG2PJ.js";
import "./chunk-3OZZMUVI.js";
import "./chunk-3GAB7GSC.js";
import "./chunk-B7Y4FMY7.js";
import "./chunk-NQCL7WZ3.js";
import "./chunk-4BTEZGN2.js";
import "./chunk-XTVSKRH4.js";
import "./chunk-ETZFPO3Y.js";
import "./chunk-LLS636HS.js";
import "./chunk-KQQH3YTO.js";
import "./chunk-DI3VEDFV.js";
import {
  __spreadProps,
  __spreadValues
} from "./chunk-PAXKX5KU.js";

// src/app/pages/session/create-session/create-session.page.ts
var _forTrack0 = ($index, $item) => $item.id;
function CreateSessionPage_Conditional_11_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 7);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx_r0.error);
  }
}
function CreateSessionPage_Conditional_12_For_17_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-icon", 24);
  }
}
function CreateSessionPage_Conditional_12_For_17_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 21);
    \u0275\u0275listener("click", function CreateSessionPage_Conditional_12_For_17_Template_button_click_0_listener() {
      const formato_r4 = \u0275\u0275restoreView(_r3).$implicit;
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.formatoSeleccionado = formato_r4.id);
    });
    \u0275\u0275elementStart(1, "span", 22)(2, "span", 23);
    \u0275\u0275text(3);
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(4, CreateSessionPage_Conditional_12_For_17_Conditional_4_Template, 1, 0, "ion-icon", 24);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "span", 25);
    \u0275\u0275text(6);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "span", 26);
    \u0275\u0275text(8);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const formato_r4 = ctx.$implicit;
    const ctx_r0 = \u0275\u0275nextContext(2);
    \u0275\u0275classProp("selected", ctx_r0.formatoSeleccionado === formato_r4.id);
    \u0275\u0275attribute("aria-pressed", ctx_r0.formatoSeleccionado === formato_r4.id);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(formato_r4.titulo);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r0.formatoSeleccionado === formato_r4.id ? 4 : -1);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(formato_r4.desc);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(formato_r4.tag);
  }
}
function CreateSessionPage_Conditional_12_section_18_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "section", 11)(1, "h2", 12);
    \u0275\u0275text(2, "Par\xE1metros del panel");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "div", 27)(4, "span", 28);
    \u0275\u0275text(5, "N\xFAmero de muestras");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "span", 29);
    \u0275\u0275text(7);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(8, "ion-range", 30);
    \u0275\u0275twoWayListener("ngModelChange", function CreateSessionPage_Conditional_12_section_18_Template_ion_range_ngModelChange_8_listener($event) {
      \u0275\u0275restoreView(_r5);
      const ctx_r0 = \u0275\u0275nextContext(2);
      \u0275\u0275twoWayBindingSet(ctx_r0.numeroMuestras, $event) || (ctx_r0.numeroMuestras = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd();
    \u0275\u0275controlCreate();
    \u0275\u0275elementStart(9, "div", 31)(10, "span");
    \u0275\u0275text(11, "1");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(12, "span");
    \u0275\u0275text(13, "20");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(14, "div", 27)(15, "span", 28);
    \u0275\u0275text(16, "Catadores objetivo");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(17, "span", 29);
    \u0275\u0275text(18);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(19, "ion-range", 32);
    \u0275\u0275twoWayListener("ngModelChange", function CreateSessionPage_Conditional_12_section_18_Template_ion_range_ngModelChange_19_listener($event) {
      \u0275\u0275restoreView(_r5);
      const ctx_r0 = \u0275\u0275nextContext(2);
      \u0275\u0275twoWayBindingSet(ctx_r0.catadoresObjetivo, $event) || (ctx_r0.catadoresObjetivo = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd();
    \u0275\u0275controlCreate();
    \u0275\u0275elementStart(20, "div", 33)(21, "span");
    \u0275\u0275text(22, "3 (m\xEDn.)");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(23, "span");
    \u0275\u0275text(24, "15");
    \u0275\u0275elementEnd()();
    \u0275\u0275element(25, "hr", 34);
    \u0275\u0275elementStart(26, "div", 35)(27, "div", 36)(28, "div", 37);
    \u0275\u0275text(29, "\xBFParticipar\xE1s como catador?");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(30, "div", 38);
    \u0275\u0275text(31, "Tu evaluaci\xF3n contar\xE1 igual en el promedio recortado del panel.");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(32, "ion-toggle", 39);
    \u0275\u0275twoWayListener("ngModelChange", function CreateSessionPage_Conditional_12_section_18_Template_ion_toggle_ngModelChange_32_listener($event) {
      \u0275\u0275restoreView(_r5);
      const ctx_r0 = \u0275\u0275nextContext(2);
      \u0275\u0275twoWayBindingSet(ctx_r0.participaComoCatador, $event) || (ctx_r0.participaComoCatador = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd();
    \u0275\u0275controlCreate();
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(33, "div", 40);
    \u0275\u0275element(34, "ion-icon", 41);
    \u0275\u0275elementStart(35, "span", 42);
    \u0275\u0275text(36, " La sesi\xF3n requiere m\xEDnimo 3 catadores para iniciar. El c\xF3digo expira cuando el organizador inicia la cata. ");
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(7);
    \u0275\u0275textInterpolate(ctx_r0.numeroMuestras);
    \u0275\u0275advance();
    \u0275\u0275twoWayProperty("ngModel", ctx_r0.numeroMuestras);
    \u0275\u0275property("min", 1)("max", 20)("step", 1);
    \u0275\u0275control();
    \u0275\u0275advance(10);
    \u0275\u0275textInterpolate(ctx_r0.catadoresObjetivo);
    \u0275\u0275advance();
    \u0275\u0275twoWayProperty("ngModel", ctx_r0.catadoresObjetivo);
    \u0275\u0275property("min", 3)("max", 15)("step", 1);
    \u0275\u0275control();
    \u0275\u0275advance(13);
    \u0275\u0275twoWayProperty("ngModel", ctx_r0.participaComoCatador);
    \u0275\u0275control();
  }
}
function CreateSessionPage_Conditional_12_Template(rf, ctx) {
  if (rf & 1) {
    const _r2 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "section", 11)(1, "h2", 12);
    \u0275\u0275text(2, "Informaci\xF3n general");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "div", 13)(4, "label", 14);
    \u0275\u0275text(5, "Nombre de la sesi\xF3n");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "ion-input", 15);
    \u0275\u0275twoWayListener("ngModelChange", function CreateSessionPage_Conditional_12_Template_ion_input_ngModelChange_6_listener($event) {
      \u0275\u0275restoreView(_r2);
      const ctx_r0 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r0.nombreSesion, $event) || (ctx_r0.nombreSesion = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd();
    \u0275\u0275controlCreate();
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "div")(8, "label", 16);
    \u0275\u0275text(9, "Notas adicionales");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(10, "ion-textarea", 17);
    \u0275\u0275twoWayListener("ngModelChange", function CreateSessionPage_Conditional_12_Template_ion_textarea_ngModelChange_10_listener($event) {
      \u0275\u0275restoreView(_r2);
      const ctx_r0 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r0.notasSesion, $event) || (ctx_r0.notasSesion = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd();
    \u0275\u0275controlCreate();
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(11, "section", 11)(12, "h2", 12);
    \u0275\u0275text(13, "Formato CVA");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(14, "p", 18);
    \u0275\u0275text(15, "Selecciona el tipo de evaluaci\xF3n seg\xFAn la metodolog\xEDa SCA CVA v2.");
    \u0275\u0275elementEnd();
    \u0275\u0275repeaterCreate(16, CreateSessionPage_Conditional_12_For_17_Template, 9, 7, "button", 19, _forTrack0);
    \u0275\u0275elementEnd();
    \u0275\u0275template(18, CreateSessionPage_Conditional_12_section_18_Template, 37, 11, "section", 20);
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance(6);
    \u0275\u0275twoWayProperty("ngModel", ctx_r0.nombreSesion);
    \u0275\u0275control();
    \u0275\u0275advance(4);
    \u0275\u0275twoWayProperty("ngModel", ctx_r0.notasSesion);
    \u0275\u0275property("autoGrow", true);
    \u0275\u0275control();
    \u0275\u0275advance(6);
    \u0275\u0275repeater(ctx_r0.formatosList);
    \u0275\u0275advance(2);
    \u0275\u0275property("ngIf", ctx_r0.formatoSeleccionado !== "extrinseca");
  }
}
function CreateSessionPage_Conditional_13_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "section", 11)(1, "h2", 12);
    \u0275\u0275text(2, "Evaluaci\xF3n individual");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "p", 18);
    \u0275\u0275text(4, " El formato extr\xEDnseco no usa c\xF3digo de acceso: registras t\xFA mismo la ficha t\xE9cnica del caf\xE9 (origen, proceso y comercializaci\xF3n). Al enviarla, la sesi\xF3n se cierra y puedes ver o exportar la ficha. ");
    \u0275\u0275elementEnd()();
  }
}
function CreateSessionPage_Conditional_13_Conditional_1_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275text(0, " Copiado ");
  }
}
function CreateSessionPage_Conditional_13_Conditional_1_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275text(0, " Copiando\u2026 ");
  }
}
function CreateSessionPage_Conditional_13_Conditional_1_Conditional_9_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275text(0, " Copiar c\xF3digo ");
  }
}
function CreateSessionPage_Conditional_13_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r6 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "section", 43)(1, "h2", 12);
    \u0275\u0275text(2, "C\xF3digo de sesi\xF3n");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "div", 45)(4, "strong");
    \u0275\u0275text(5);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "ion-button", 46);
    \u0275\u0275listener("click", function CreateSessionPage_Conditional_13_Conditional_1_Template_ion_button_click_6_listener() {
      \u0275\u0275restoreView(_r6);
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.copiarCodigo());
    });
    \u0275\u0275conditionalCreate(7, CreateSessionPage_Conditional_13_Conditional_1_Conditional_7_Template, 1, 0)(8, CreateSessionPage_Conditional_13_Conditional_1_Conditional_8_Template, 1, 0)(9, CreateSessionPage_Conditional_13_Conditional_1_Conditional_9_Template, 1, 0);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(10, "p", 18);
    \u0275\u0275text(11, "Comparte este c\xF3digo con los catadores.");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(ctx_r0.codigoGenerado);
    \u0275\u0275advance();
    \u0275\u0275property("disabled", ctx_r0.isCopying);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r0.copiado ? 7 : ctx_r0.isCopying ? 8 : 9);
  }
}
function CreateSessionPage_Conditional_13_Conditional_23_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 44)(1, "span");
    \u0275\u0275text(2, "Modalidad");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "strong");
    \u0275\u0275text(4, "Individual \xB7 sin c\xF3digo");
    \u0275\u0275elementEnd()();
  }
}
function CreateSessionPage_Conditional_13_Conditional_24_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 44)(1, "span");
    \u0275\u0275text(2, "Catadores objetivo");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "strong");
    \u0275\u0275text(4);
    \u0275\u0275elementEnd()();
    \u0275\u0275element(5, "hr");
    \u0275\u0275elementStart(6, "div", 44)(7, "span");
    \u0275\u0275text(8, "Organizador catador");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(9, "strong");
    \u0275\u0275text(10);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(ctx_r0.catadoresObjetivo);
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate(ctx_r0.participaComoCatador ? "S\xED" : "No");
  }
}
function CreateSessionPage_Conditional_13_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275conditionalCreate(0, CreateSessionPage_Conditional_13_Conditional_0_Template, 5, 0, "section", 11)(1, CreateSessionPage_Conditional_13_Conditional_1_Template, 12, 3, "section", 43);
    \u0275\u0275elementStart(2, "section", 11)(3, "h2", 12);
    \u0275\u0275text(4, "Resumen de la sesi\xF3n");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "div", 44)(6, "span");
    \u0275\u0275text(7, "Nombre");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "strong");
    \u0275\u0275text(9);
    \u0275\u0275elementEnd()();
    \u0275\u0275element(10, "hr");
    \u0275\u0275elementStart(11, "div", 44)(12, "span");
    \u0275\u0275text(13, "Formato CVA");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(14, "strong");
    \u0275\u0275text(15);
    \u0275\u0275elementEnd()();
    \u0275\u0275element(16, "hr");
    \u0275\u0275elementStart(17, "div", 44)(18, "span");
    \u0275\u0275text(19, "Muestras");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(20, "strong");
    \u0275\u0275text(21);
    \u0275\u0275elementEnd()();
    \u0275\u0275element(22, "hr");
    \u0275\u0275conditionalCreate(23, CreateSessionPage_Conditional_13_Conditional_23_Template, 5, 0, "div", 44)(24, CreateSessionPage_Conditional_13_Conditional_24_Template, 11, 2);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275conditional(ctx_r0.formatoSeleccionado === "extrinseca" ? 0 : 1);
    \u0275\u0275advance(9);
    \u0275\u0275textInterpolate(ctx_r0.nombreSesion || "Sin nombre");
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate(ctx_r0.getTituloFormato());
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate(ctx_r0.formatoSeleccionado === "extrinseca" ? 1 : ctx_r0.numeroMuestras);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx_r0.formatoSeleccionado === "extrinseca" ? 23 : 24);
  }
}
function CreateSessionPage_Conditional_15_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-spinner", 48);
  }
}
function CreateSessionPage_Conditional_15_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275text(0);
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext(2);
    \u0275\u0275textInterpolate1(" ", ctx_r0.formatoSeleccionado === "extrinseca" ? "Crear sesi\xF3n \u2192" : "Generar c\xF3digo de acceso \u2192", " ");
  }
}
function CreateSessionPage_Conditional_15_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "ion-button", 47);
    \u0275\u0275listener("click", function CreateSessionPage_Conditional_15_Template_ion_button_click_0_listener() {
      \u0275\u0275restoreView(_r7);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.generarCodigo());
    });
    \u0275\u0275conditionalCreate(1, CreateSessionPage_Conditional_15_Conditional_1_Template, 1, 0, "ion-spinner", 48)(2, CreateSessionPage_Conditional_15_Conditional_2_Template, 1, 1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275property("disabled", !ctx_r0.nombreSesion.trim() || ctx_r0.isLoading);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r0.isLoading ? 1 : 2);
  }
}
function CreateSessionPage_Conditional_16_Template(rf, ctx) {
  if (rf & 1) {
    const _r8 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 10)(1, "ion-button", 49);
    \u0275\u0275text(2, " Salir ");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "ion-button", 50);
    \u0275\u0275listener("click", function CreateSessionPage_Conditional_16_Template_ion_button_click_3_listener() {
      \u0275\u0275restoreView(_r8);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.irASalaDeEspera());
    });
    \u0275\u0275text(4);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275property("disabled", ctx_r0.isLoading);
    \u0275\u0275advance(2);
    \u0275\u0275property("disabled", ctx_r0.isLoading);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", ctx_r0.formatoSeleccionado === "extrinseca" ? "Ir a la evaluaci\xF3n \u2192" : "Ir a sala de espera \u2192", " ");
  }
}
addIcons({ checkmarkCircle, informationCircleOutline });
var _CreateSessionPage = class _CreateSessionPage {
  constructor() {
    this.pasoActual = 1;
    this.nombreSesion = "";
    this.notasSesion = "";
    this.formatoSeleccionado = FormatoCva.COMBINADO.id;
    this.numeroMuestras = 6;
    this.catadoresObjetivo = 5;
    this.participaComoCatador = true;
    this.codigoGenerado = "";
    this.sesionIdGenerado = "";
    this.copiado = false;
    this.isLoading = false;
    this.isCopying = false;
    this.error = null;
    this.formatosList = [
      __spreadProps(__spreadValues({}, FormatoCva.COMBINADO), {
        desc: "Eval\xFAa intensidad f\xEDsica (1\u201315) y calidad hed\xF3nica (1\u20139) simult\xE1neamente.",
        tag: "Intensidad + Calidad"
      }),
      __spreadProps(__spreadValues({}, FormatoCva.AFECTIVO), {
        desc: "Solo calidad hed\xF3nica (1\u20139). Mide preferencia y agrado del consumidor.",
        tag: "Solo Calidad"
      }),
      __spreadProps(__spreadValues({}, FormatoCva.DESCRIPTIVO), {
        desc: "Solo intensidad f\xEDsica (1\u201315). Perfil sensorial objetivo sin juicio de calidad.",
        tag: "Solo Intensidad"
      }),
      __spreadProps(__spreadValues({}, FormatoCva.EXTRINSECA), {
        desc: "Evaluaci\xF3n de atributos externos: origen, presentaci\xF3n, empaque, precio percibido.",
        tag: "Atributos externos"
      })
    ];
    this.sesionService = inject(SesionService);
    this.authService = inject(AuthService);
    this.router = inject(Router);
    this.changeDetector = inject(ChangeDetectorRef);
    this.toastController = inject(ToastController);
  }
  getTituloFormato() {
    return this.formatosList.find((formato) => formato.id === this.formatoSeleccionado)?.titulo ?? "";
  }
  async generarCodigo() {
    if (!this.nombreSesion.trim()) {
      this.error = "El nombre de la sesi\xF3n no puede estar vac\xEDo.";
      return;
    }
    this.isLoading = true;
    this.error = null;
    try {
      const { user } = await this.authService.getUser();
      if (!user)
        throw new Error("Debes iniciar sesi\xF3n para crear una sesi\xF3n.");
      const esExtrinseco = this.formatoSeleccionado === FormatoCva.EXTRINSECA.id;
      const nuevaSesion = {
        id: "",
        codigoAcceso: "",
        nombre: this.nombreSesion.trim(),
        notas: this.notasSesion.trim(),
        formato: this.formatoSeleccionado,
        numeroMuestras: esExtrinseco ? 1 : this.numeroMuestras,
        catadoresObjetivo: esExtrinseco ? 3 : this.catadoresObjetivo,
        organizadorId: user.id,
        // informativo: el servidor usa auth.uid()
        organizadorParticipa: esExtrinseco ? false : this.participaComoCatador,
        estado: EstadoSesion.EN_ESPERA
      };
      const creada = await this.sesionService.crearSesion(nuevaSesion);
      this.codigoGenerado = creada.codigoAcceso;
      this.sesionIdGenerado = creada.id;
      this.pasoActual = 2;
      this.changeDetector.detectChanges();
    } catch (error) {
      console.error("ERROR COMPLETO DE SUPABASE:", error);
      this.error = this.mensajeError(error);
    } finally {
      this.isLoading = false;
      this.changeDetector.detectChanges();
    }
  }
  async copiarCodigo() {
    this.isCopying = true;
    this.error = null;
    try {
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(this.codigoGenerado);
      } else {
        await Clipboard.write({ string: this.codigoGenerado });
      }
      this.copiado = true;
      window.setTimeout(() => {
        this.copiado = false;
        this.changeDetector.markForCheck();
      }, 2e3);
      const toast = await this.toastController.create({
        message: "\xA1C\xF3digo copiado!",
        duration: 2e3,
        color: "dark"
      });
      await toast.present();
    } catch (error) {
      this.error = this.mensajeError(error);
      const toast = await this.toastController.create({
        message: `No se pudo copiar el c\xF3digo. ${this.mensajeError(error)}`,
        duration: 3500,
        color: "danger"
      });
      await toast.present();
    } finally {
      this.isCopying = false;
      this.changeDetector.markForCheck();
    }
  }
  async irASalaDeEspera() {
    const ruta = this.formatoSeleccionado === FormatoCva.EXTRINSECA.id ? `/extrinsic-form/${this.sesionIdGenerado}` : `/session/waiting/${this.sesionIdGenerado}`;
    await this.router.navigateByUrl(ruta, { replaceUrl: true });
  }
  mensajeError(error) {
    return error instanceof Error ? error.message : "Ocurri\xF3 un error inesperado.";
  }
};
_CreateSessionPage.\u0275fac = function CreateSessionPage_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _CreateSessionPage)();
};
_CreateSessionPage.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _CreateSessionPage, selectors: [["app-create-session"]], decls: 17, vars: 5, consts: [[1, "ion-no-border"], ["slot", "start"], ["defaultHref", "/dashboard", "text", ""], [1, "page-title"], [1, "page-subtitle"], [1, "ion-padding", "create-session-content"], [1, "create-session-container"], ["role", "alert", 1, "error-message"], [1, "ion-no-border", "create-session-footer"], ["expand", "block", 1, "primary-btn", 3, "disabled"], [1, "footer-actions"], [1, "cupping-card"], [1, "section-title"], [1, "session-field"], ["for", "session-name", 1, "input-label"], ["id", "session-name", "placeholder", "Ej.: Cosecha de mayo \u2014 Colombia", "required", "", 1, "custom-input", 3, "ngModelChange", "ngModel"], ["for", "session-notes", 1, "input-label"], ["id", "session-notes", "placeholder", "Informaci\xF3n sobre origen, proceso...", "rows", "3", 1, "custom-input", 3, "ngModelChange", "ngModel", "autoGrow"], [1, "help-text"], ["type", "button", 1, "formato-item", 3, "selected"], ["class", "cupping-card", 4, "ngIf"], ["type", "button", 1, "formato-item", 3, "click"], [1, "format-heading"], [1, "format-name"], ["name", "checkmark-circle", "aria-label", "Seleccionado", 1, "selected-mark"], [1, "format-description"], [1, "format-tag"], [1, "slider-header"], [1, "slider-label"], [1, "slider-value"], ["aria-label", "N\xFAmero de muestras", 3, "ngModelChange", "ngModel", "min", "max", "step"], [1, "slider-limits", "samples-limits"], ["aria-label", "Catadores objetivo", 3, "ngModelChange", "ngModel", "min", "max", "step"], [1, "slider-limits"], [1, "divider"], [1, "participar-container"], [1, "participar-text"], [1, "participar-title"], [1, "participar-desc"], ["aria-label", "Participar como catador", 1, "custom-toggle", 3, "ngModelChange", "ngModel"], ["role", "note", 1, "info-box"], ["name", "information-circle-outline", "aria-hidden", "true", 1, "info-icon"], [1, "info-text"], [1, "cupping-card", "code-card"], [1, "summary-row"], [1, "code-display"], ["fill", "outline", 1, "copy-button", 3, "click", "disabled"], ["expand", "block", 1, "primary-btn", 3, "click", "disabled"], ["name", "crescent"], ["fill", "outline", "routerLink", "/dashboard", 1, "edit-button", 3, "disabled"], ["expand", "block", 1, "primary-btn", "continue-button", 3, "click", "disabled"]], template: function CreateSessionPage_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-header", 0)(1, "ion-toolbar")(2, "ion-buttons", 1);
    \u0275\u0275element(3, "ion-back-button", 2);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "ion-title")(5, "div", 3);
    \u0275\u0275text(6);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "div", 4);
    \u0275\u0275text(8);
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(9, "ion-content", 5)(10, "main", 6);
    \u0275\u0275conditionalCreate(11, CreateSessionPage_Conditional_11_Template, 2, 1, "div", 7);
    \u0275\u0275conditionalCreate(12, CreateSessionPage_Conditional_12_Template, 19, 4)(13, CreateSessionPage_Conditional_13_Template, 25, 5);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(14, "ion-footer", 8);
    \u0275\u0275conditionalCreate(15, CreateSessionPage_Conditional_15_Template, 3, 2, "ion-button", 9)(16, CreateSessionPage_Conditional_16_Template, 5, 3, "div", 10);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate1(" ", ctx.pasoActual === 1 ? "Crear sesi\xF3n" : ctx.formatoSeleccionado === "extrinseca" ? "Sesi\xF3n creada" : "C\xF3digo de acceso", " ");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1(" ", ctx.pasoActual === 1 ? "Paso 1 \u2014 Configuraci\xF3n" : "Sesi\xF3n configurada", " ");
    \u0275\u0275advance(3);
    \u0275\u0275conditional(ctx.error ? 11 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx.pasoActual === 1 ? 12 : 13);
    \u0275\u0275advance(3);
    \u0275\u0275conditional(ctx.pasoActual === 1 ? 15 : 16);
  }
}, dependencies: [
  IonBackButton,
  IonButton,
  IonButtons,
  IonContent,
  IonFooter,
  IonHeader,
  IonIcon,
  IonInput,
  IonRange,
  IonSpinner,
  IonTextarea,
  IonTitle,
  IonToggle,
  IonToolbar,
  CommonModule,
  NgIf,
  FormsModule,
  NgControlStatus,
  RequiredValidator,
  NgModel,
  RouterLink
], styles: ["\nion-back-button[_ngcontent-%COMP%] {\n  --%NS%color: #0f344c;\n}\n/*# sourceMappingURL=create-session.page.css.map */"] });
var CreateSessionPage = _CreateSessionPage;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(CreateSessionPage, [{
    type: Component,
    args: [{ selector: "app-create-session", standalone: true, imports: [
      IonBackButton,
      IonButton,
      IonButtons,
      IonContent,
      IonFooter,
      IonHeader,
      IonIcon,
      IonInput,
      IonRange,
      IonSpinner,
      IonTextarea,
      IonTitle,
      IonToggle,
      IonToolbar,
      CommonModule,
      FormsModule,
      RouterLink
    ], template: `<ion-header class="ion-no-border">
  <ion-toolbar>
    <ion-buttons slot="start">
      <ion-back-button defaultHref="/dashboard" text=""></ion-back-button>
    </ion-buttons>
    <ion-title>
      <div class="page-title">
        {{ pasoActual === 1 ? 'Crear sesi\xF3n' : (formatoSeleccionado === 'extrinseca' ? 'Sesi\xF3n creada' : 'C\xF3digo de acceso') }}
      </div>
      <div class="page-subtitle">
        {{ pasoActual === 1 ? 'Paso 1 \u2014 Configuraci\xF3n' : 'Sesi\xF3n configurada' }}
      </div>
    </ion-title>
  </ion-toolbar>
</ion-header>

<ion-content class="ion-padding create-session-content">
  <main class="create-session-container">
    @if (error) {
      <div class="error-message" role="alert">{{ error }}</div>
    }

    @if (pasoActual === 1) {
      <section class="cupping-card">
        <h2 class="section-title">Informaci\xF3n general</h2>
        <div class="session-field">
          <label class="input-label" for="session-name">Nombre de la sesi\xF3n</label>
          <ion-input
            id="session-name"
            [(ngModel)]="nombreSesion"
            placeholder="Ej.: Cosecha de mayo \u2014 Colombia"
            class="custom-input"
            required
          ></ion-input>
        </div>
        <div>
          <label class="input-label" for="session-notes">Notas adicionales</label>
          <ion-textarea
            id="session-notes"
            [(ngModel)]="notasSesion"
            placeholder="Informaci\xF3n sobre origen, proceso..."
            class="custom-input"
            [autoGrow]="true"
            rows="3"
          ></ion-textarea>
        </div>
      </section>

      <section class="cupping-card">
        <h2 class="section-title">Formato CVA</h2>
        <p class="help-text">Selecciona el tipo de evaluaci\xF3n seg\xFAn la metodolog\xEDa SCA CVA v2.</p>

        @for (formato of formatosList; track formato.id) {
          <button
            type="button"
            class="formato-item"
            [class.selected]="formatoSeleccionado === formato.id"
            [attr.aria-pressed]="formatoSeleccionado === formato.id"
            (click)="formatoSeleccionado = formato.id"
          >
            <span class="format-heading">
              <span class="format-name">{{ formato.titulo }}</span>
              @if (formatoSeleccionado === formato.id) {
                <ion-icon
                  class="selected-mark"
                  name="checkmark-circle"
                  aria-label="Seleccionado"
                ></ion-icon>
              }
            </span>
            <span class="format-description">{{ formato.desc }}</span>
            <span class="format-tag">{{ formato.tag }}</span>
          </button>
        }
      </section>

      <section class="cupping-card" *ngIf="formatoSeleccionado !== 'extrinseca'">
        <h2 class="section-title">Par\xE1metros del panel</h2>

        <div class="slider-header">
          <span class="slider-label">N\xFAmero de muestras</span>
          <span class="slider-value">{{ numeroMuestras }}</span>
        </div>
        <ion-range
          [(ngModel)]="numeroMuestras"
          aria-label="N\xFAmero de muestras"
          [min]="1"
          [max]="20"
          [step]="1"
        ></ion-range>
        <div class="slider-limits samples-limits">
          <span>1</span><span>20</span>
        </div>

        <div class="slider-header">
          <span class="slider-label">Catadores objetivo</span>
          <span class="slider-value">{{ catadoresObjetivo }}</span>
        </div>
        <ion-range
          [(ngModel)]="catadoresObjetivo"
          aria-label="Catadores objetivo"
          [min]="3"
          [max]="15"
          [step]="1"
        ></ion-range>
        <div class="slider-limits">
          <span>3 (m\xEDn.)</span><span>15</span>
        </div>

        <hr class="divider">

        <div class="participar-container">
          <div class="participar-text">
            <div class="participar-title">\xBFParticipar\xE1s como catador?</div>
            <div class="participar-desc">Tu evaluaci\xF3n contar\xE1 igual en el promedio recortado del panel.</div>
          </div>
          <ion-toggle
            [(ngModel)]="participaComoCatador"
            class="custom-toggle"
            aria-label="Participar como catador"
          ></ion-toggle>
        </div>

        <div class="info-box" role="note">
          <ion-icon name="information-circle-outline" class="info-icon" aria-hidden="true"></ion-icon>
          <span class="info-text">
            La sesi\xF3n requiere m\xEDnimo 3 catadores para iniciar. El c\xF3digo expira cuando el organizador inicia la cata.
          </span>
        </div>
      </section>
    } @else {
      @if (formatoSeleccionado === 'extrinseca') {
        <!-- Extr\xEDnseco: evaluaci\xF3n individual, sin c\xF3digo ni sala de espera. -->
        <section class="cupping-card">
          <h2 class="section-title">Evaluaci\xF3n individual</h2>
          <p class="help-text">
            El formato extr\xEDnseco no usa c\xF3digo de acceso: registras t\xFA mismo la ficha t\xE9cnica del caf\xE9
            (origen, proceso y comercializaci\xF3n). Al enviarla, la sesi\xF3n se cierra y puedes ver o exportar la ficha.
          </p>
        </section>
      } @else {
      <section class="cupping-card code-card">
        <h2 class="section-title">C\xF3digo de sesi\xF3n</h2>
        <div class="code-display">
          <strong>{{ codigoGenerado }}</strong>
          <ion-button
            fill="outline"
            class="copy-button"
            (click)="copiarCodigo()"
            [disabled]="isCopying"
          >
            @if (copiado) {
              Copiado
            } @else if (isCopying) {
              Copiando\u2026
            } @else {
              Copiar c\xF3digo
            }
          </ion-button>
        </div>
        <p class="help-text">Comparte este c\xF3digo con los catadores.</p>
      </section>
      }

      <section class="cupping-card">
        <h2 class="section-title">Resumen de la sesi\xF3n</h2>
        <div class="summary-row"><span>Nombre</span><strong>{{ nombreSesion || 'Sin nombre' }}</strong></div>
        <hr>
        <div class="summary-row"><span>Formato CVA</span><strong>{{ getTituloFormato() }}</strong></div>
        <hr>
        <div class="summary-row">
          <span>Muestras</span>
          <strong>{{ formatoSeleccionado === 'extrinseca' ? 1 : numeroMuestras }}</strong>
        </div>
        <hr>
        @if (formatoSeleccionado === 'extrinseca') {
          <div class="summary-row">
            <span>Modalidad</span>
            <strong>Individual \xB7 sin c\xF3digo</strong>
          </div>
        } @else {
          <div class="summary-row">
            <span>Catadores objetivo</span>
            <strong>{{ catadoresObjetivo }}</strong>
          </div>
          <hr>
          <div class="summary-row">
            <span>Organizador catador</span>
            <strong>{{ participaComoCatador ? 'S\xED' : 'No' }}</strong>
          </div>
        }
      </section>
    }
  </main>
</ion-content>

<ion-footer class="ion-no-border create-session-footer">
  @if (pasoActual === 1) {
    <ion-button
      expand="block"
      class="primary-btn"
      (click)="generarCodigo()"
      [disabled]="!nombreSesion.trim() || isLoading"
    >
      @if (isLoading) {
        <ion-spinner name="crescent"></ion-spinner>
      } @else {
        {{ formatoSeleccionado === 'extrinseca' ? 'Crear sesi\xF3n \u2192' : 'Generar c\xF3digo de acceso \u2192' }}
      }
    </ion-button>
  } @else {
    <div class="footer-actions">
      <ion-button
        fill="outline"
        class="edit-button"
        routerLink="/dashboard"
        [disabled]="isLoading"
      >
        Salir
      </ion-button>
      <ion-button
        expand="block"
        class="primary-btn continue-button"
        (click)="irASalaDeEspera()"
        [disabled]="isLoading"
      >
        {{ formatoSeleccionado === 'extrinseca' ? 'Ir a la evaluaci\xF3n \u2192' : 'Ir a sala de espera \u2192' }}
      </ion-button>
    </div>
  }
</ion-footer>
`, styles: ["/* src/app/pages/session/create-session/create-session.page.scss */\nion-back-button {\n  --color: #0f344c;\n}\n/*# sourceMappingURL=create-session.page.css.map */\n"] }]
  }], null, null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(CreateSessionPage, { className: "CreateSessionPage", filePath: "src/app/pages/session/create-session/create-session.page.ts", lineNumber: 58 });
})();
export {
  CreateSessionPage
};
//# debugId=765d2ed4-e01f-580b-8132-5fa7e445260a
//# sourceMappingURL=create-session.page-RBZPMWHV.js.map
