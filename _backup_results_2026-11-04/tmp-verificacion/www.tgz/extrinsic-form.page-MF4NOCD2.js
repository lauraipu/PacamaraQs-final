import {
  BaseCataForm,
  EstadoFichaComponent
} from "./chunk-NSTJCVOE.js";
import "./chunk-NM5KBNCZ.js";
import "./chunk-DLWN5DPS.js";
import "./chunk-BHVR7Z6N.js";
import {
  arrowBackOutline
} from "./chunk-IN4O4X7H.js";
import "./chunk-OFWJO6PD.js";
import {
  addIcons
} from "./chunk-4JFQPQWK.js";
import "./chunk-JH4CNQSM.js";
import {
  CheckboxControlValueAccessor,
  CommonModule,
  Component,
  DefaultValueAccessor,
  FormsModule,
  IonContent,
  IonIcon,
  NgControlStatus,
  NgIf,
  NgModel,
  NgSelectOption,
  SelectControlValueAccessor,
  setClassMetadata,
  ɵNgSelectMultipleOption,
  ɵsetClassDebugInfo,
  ɵɵInheritDefinitionFeature,
  ɵɵadvance,
  ɵɵcontrol,
  ɵɵcontrolCreate,
  ɵɵdefineComponent,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵgetInheritedFactory,
  ɵɵlistener,
  ɵɵnextContext,
  ɵɵproperty,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵstyleProp,
  ɵɵtemplate,
  ɵɵtext,
  ɵɵtextInterpolate1,
  ɵɵtwoWayBindingSet,
  ɵɵtwoWayListener,
  ɵɵtwoWayProperty
} from "./chunk-DEQWXDMW.js";
import "./chunk-BMQUG2PJ.js";
import "./chunk-3OZZMUVI.js";
import "./chunk-3GAB7GSC.js";
import "./chunk-B7Y4FMY7.js";
import "./chunk-NQCL7WZ3.js";
import "./chunk-4BTEZGN2.js";
import "./chunk-XTVSKRH4.js";
import "./chunk-ETZFPO3Y.js";
import "./chunk-LLS636HS.js";
import "./chunk-KQQH3YTO.js";
import "./chunk-DI3VEDFV.js";
import "./chunk-PAXKX5KU.js";

// src/app/pages/evaluation/extrinsic-form/extrinsic-form.page.ts
function ExtrinsicFormPage_button_133_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 48);
    \u0275\u0275listener("click", function ExtrinsicFormPage_button_133_Template_button_click_0_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.irAMuestraAnterior());
    });
    \u0275\u0275text(1, " \u2190 Anterior ");
    \u0275\u0275elementEnd();
  }
}
addIcons({ arrowBackOutline });
var _ExtrinsicFormPage = class _ExtrinsicFormPage extends BaseCataForm {
  constructor() {
    super(...arguments);
    this.formulario = this.crearFormularioVacio();
  }
  crearFormularioVacio() {
    return {
      farming: {
        country: "",
        region: "",
        farmName: "",
        producers: "",
        species: "",
        variety: "",
        harvestDate: "",
        other: ""
      },
      processing: {
        processorName: "",
        wetMill: "",
        dryMill: "",
        processType: "",
        other: ""
      },
      trading: { grade: "", icoNumber: "", other: "" },
      certifications: {
        c4: false,
        fairTrade: false,
        organic: false,
        rainforest: false,
        other: ""
      },
      notes: ""
    };
  }
};
_ExtrinsicFormPage.\u0275fac = /* @__PURE__ */ (() => {
  let \u0275ExtrinsicFormPage_BaseFactory;
  return function ExtrinsicFormPage_Factory(__ngFactoryType__) {
    return (\u0275ExtrinsicFormPage_BaseFactory || (\u0275ExtrinsicFormPage_BaseFactory = \u0275\u0275getInheritedFactory(_ExtrinsicFormPage)))(__ngFactoryType__ || _ExtrinsicFormPage);
  };
})();
_ExtrinsicFormPage.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _ExtrinsicFormPage, selectors: [["app-extrinsic-form"]], features: [\u0275\u0275InheritDefinitionFeature], decls: 136, vars: 35, consts: [[1, "cva-combined", 3, "scrollY"], [3, "reintentar", "salir", "pendientes", "enLinea", "muestraCerrada", "rechazo", "esperandoFinalizar"], [1, "cva-header"], [1, "cva-header__inner"], [1, "cva-header__left"], ["type", "button", "aria-label", "Volver", 1, "cva-header__back-btn", 3, "click"], ["name", "arrow-back-outline"], [1, "cva-header__meta"], [1, "cva-header__session-name"], [1, "cva-header__sample-label"], [1, "cva-header__right"], [1, "cva-header__format-badge"], [1, "cva-header__progress-bar-wrap"], [1, "cva-header__progress-bar"], [1, "cva-header__progress-bar-fill"], [1, "cva-main"], [1, "cva-main__grid"], [1, "cva-main__column"], [1, "attr-card"], [1, "attr-card__title"], [1, "form-fields"], [1, "form-field"], [1, "intensity-slider__label"], ["type", "text", "placeholder", "Ej: Colombia", 1, "notes-panel__textarea", 3, "ngModelChange", "ngModel"], ["type", "text", "placeholder", "Ej: Huila", 1, "notes-panel__textarea", 3, "ngModelChange", "ngModel"], ["type", "text", "placeholder", "Ej: Finca El Mirador", 1, "notes-panel__textarea", 3, "ngModelChange", "ngModel"], ["type", "text", "placeholder", "Nombre(s) de productores", 1, "notes-panel__textarea", 3, "ngModelChange", "ngModel"], ["type", "text", "placeholder", "Ej: Ar\xE1bica", 1, "notes-panel__textarea", 3, "ngModelChange", "ngModel"], ["type", "text", "placeholder", "Ej: Geisha", 1, "notes-panel__textarea", 3, "ngModelChange", "ngModel"], ["type", "date", 1, "notes-panel__textarea", 3, "ngModelChange", "ngModel"], ["type", "text", 1, "notes-panel__textarea", 3, "ngModelChange", "ngModel"], [1, "notes-panel__textarea", 3, "ngModelChange", "ngModel"], ["value", ""], ["value", "lavado"], ["value", "natural"], ["value", "otro"], ["type", "text", "placeholder", "Ej: Supremo", 1, "notes-panel__textarea", 3, "ngModelChange", "ngModel"], [1, "mouthfeel__list"], [1, "mouthfeel__item"], ["type", "checkbox", 3, "ngModelChange", "ngModel"], ["type", "text", "placeholder", "Ej: Bird Friendly", 1, "notes-panel__textarea", 3, "ngModelChange", "ngModel"], [1, "cva-main__sidebar"], [1, "notes-panel"], [1, "notes-panel__header"], ["rows", "5", "placeholder", "Otra informaci\xF3n relevante...", 1, "notes-panel__textarea", 3, "ngModelChange", "ngModel"], [1, "sample-navigation"], ["type", "button", "class", "submit-btn sample-navigation__previous", 3, "click", 4, "ngIf"], ["type", "button", 1, "submit-btn", 3, "click", "disabled"], ["type", "button", 1, "submit-btn", "sample-navigation__previous", 3, "click"]], template: function ExtrinsicFormPage_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-content", 0)(1, "app-estado-ficha", 1);
    \u0275\u0275listener("reintentar", function ExtrinsicFormPage_Template_app_estado_ficha_reintentar_1_listener() {
      return ctx.reintentarSincronizacion();
    })("salir", function ExtrinsicFormPage_Template_app_estado_ficha_salir_1_listener() {
      return ctx.salirConPendientes();
    });
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(2, "header", 2)(3, "div", 3)(4, "div", 4)(5, "button", 5);
    \u0275\u0275listener("click", function ExtrinsicFormPage_Template_button_click_5_listener() {
      return ctx.volver();
    });
    \u0275\u0275element(6, "ion-icon", 6);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "div", 7)(8, "p", 8);
    \u0275\u0275text(9, "Evaluaci\xF3n Extr\xEDnseca");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(10, "p", 9);
    \u0275\u0275text(11);
    \u0275\u0275elementStart(12, "span");
    \u0275\u0275text(13);
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(14, "div", 10)(15, "span", 11);
    \u0275\u0275text(16, "Extr\xEDnseca");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(17, "div", 12)(18, "div", 13);
    \u0275\u0275element(19, "div", 14);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(20, "main", 15)(21, "div", 16)(22, "div", 17)(23, "article", 18)(24, "h3", 19);
    \u0275\u0275text(25, "1. Informaci\xF3n de cultivo (Farming)");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(26, "div", 20)(27, "label", 21)(28, "span", 22);
    \u0275\u0275text(29, "Pa\xEDs");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(30, "input", 23);
    \u0275\u0275twoWayListener("ngModelChange", function ExtrinsicFormPage_Template_input_ngModelChange_30_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.formulario.farming.country, $event) || (ctx.formulario.farming.country = $event);
      return $event;
    });
    \u0275\u0275elementEnd();
    \u0275\u0275controlCreate();
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(31, "label", 21)(32, "span", 22);
    \u0275\u0275text(33, "Regi\xF3n / Departamento");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(34, "input", 24);
    \u0275\u0275twoWayListener("ngModelChange", function ExtrinsicFormPage_Template_input_ngModelChange_34_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.formulario.farming.region, $event) || (ctx.formulario.farming.region = $event);
      return $event;
    });
    \u0275\u0275elementEnd();
    \u0275\u0275controlCreate();
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(35, "label", 21)(36, "span", 22);
    \u0275\u0275text(37, "Nombre de la finca o cooperativa");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(38, "input", 25);
    \u0275\u0275twoWayListener("ngModelChange", function ExtrinsicFormPage_Template_input_ngModelChange_38_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.formulario.farming.farmName, $event) || (ctx.formulario.farming.farmName = $event);
      return $event;
    });
    \u0275\u0275elementEnd();
    \u0275\u0275controlCreate();
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(39, "label", 21)(40, "span", 22);
    \u0275\u0275text(41, "Productor(es)");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(42, "input", 26);
    \u0275\u0275twoWayListener("ngModelChange", function ExtrinsicFormPage_Template_input_ngModelChange_42_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.formulario.farming.producers, $event) || (ctx.formulario.farming.producers = $event);
      return $event;
    });
    \u0275\u0275elementEnd();
    \u0275\u0275controlCreate();
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(43, "label", 21)(44, "span", 22);
    \u0275\u0275text(45, "Especie");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(46, "input", 27);
    \u0275\u0275twoWayListener("ngModelChange", function ExtrinsicFormPage_Template_input_ngModelChange_46_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.formulario.farming.species, $event) || (ctx.formulario.farming.species = $event);
      return $event;
    });
    \u0275\u0275elementEnd();
    \u0275\u0275controlCreate();
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(47, "label", 21)(48, "span", 22);
    \u0275\u0275text(49, "Variedad");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(50, "input", 28);
    \u0275\u0275twoWayListener("ngModelChange", function ExtrinsicFormPage_Template_input_ngModelChange_50_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.formulario.farming.variety, $event) || (ctx.formulario.farming.variety = $event);
      return $event;
    });
    \u0275\u0275elementEnd();
    \u0275\u0275controlCreate();
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(51, "label", 21)(52, "span", 22);
    \u0275\u0275text(53, "Fecha de cosecha");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(54, "input", 29);
    \u0275\u0275twoWayListener("ngModelChange", function ExtrinsicFormPage_Template_input_ngModelChange_54_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.formulario.farming.harvestDate, $event) || (ctx.formulario.farming.harvestDate = $event);
      return $event;
    });
    \u0275\u0275elementEnd();
    \u0275\u0275controlCreate();
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(55, "label", 21)(56, "span", 22);
    \u0275\u0275text(57, "Otra informaci\xF3n de cultivo");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(58, "input", 30);
    \u0275\u0275twoWayListener("ngModelChange", function ExtrinsicFormPage_Template_input_ngModelChange_58_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.formulario.farming.other, $event) || (ctx.formulario.farming.other = $event);
      return $event;
    });
    \u0275\u0275elementEnd();
    \u0275\u0275controlCreate();
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(59, "article", 18)(60, "h3", 19);
    \u0275\u0275text(61, "2. Informaci\xF3n de procesamiento");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(62, "div", 20)(63, "label", 21)(64, "span", 22);
    \u0275\u0275text(65, "Nombre del procesador");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(66, "input", 30);
    \u0275\u0275twoWayListener("ngModelChange", function ExtrinsicFormPage_Template_input_ngModelChange_66_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.formulario.processing.processorName, $event) || (ctx.formulario.processing.processorName = $event);
      return $event;
    });
    \u0275\u0275elementEnd();
    \u0275\u0275controlCreate();
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(67, "label", 21)(68, "span", 22);
    \u0275\u0275text(69, "Beneficio h\xFAmedo");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(70, "input", 30);
    \u0275\u0275twoWayListener("ngModelChange", function ExtrinsicFormPage_Template_input_ngModelChange_70_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.formulario.processing.wetMill, $event) || (ctx.formulario.processing.wetMill = $event);
      return $event;
    });
    \u0275\u0275elementEnd();
    \u0275\u0275controlCreate();
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(71, "label", 21)(72, "span", 22);
    \u0275\u0275text(73, "Beneficio seco");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(74, "input", 30);
    \u0275\u0275twoWayListener("ngModelChange", function ExtrinsicFormPage_Template_input_ngModelChange_74_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.formulario.processing.dryMill, $event) || (ctx.formulario.processing.dryMill = $event);
      return $event;
    });
    \u0275\u0275elementEnd();
    \u0275\u0275controlCreate();
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(75, "label", 21)(76, "span", 22);
    \u0275\u0275text(77, "Tipo de proceso");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(78, "select", 31);
    \u0275\u0275twoWayListener("ngModelChange", function ExtrinsicFormPage_Template_select_ngModelChange_78_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.formulario.processing.processType, $event) || (ctx.formulario.processing.processType = $event);
      return $event;
    });
    \u0275\u0275elementStart(79, "option", 32);
    \u0275\u0275text(80, "Seleccionar");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(81, "option", 33);
    \u0275\u0275text(82, "Lavado");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(83, "option", 34);
    \u0275\u0275text(84, "Natural");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(85, "option", 35);
    \u0275\u0275text(86, "Otro");
    \u0275\u0275elementEnd()();
    \u0275\u0275controlCreate();
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(87, "label", 21)(88, "span", 22);
    \u0275\u0275text(89, "Otro proceso");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(90, "input", 30);
    \u0275\u0275twoWayListener("ngModelChange", function ExtrinsicFormPage_Template_input_ngModelChange_90_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.formulario.processing.other, $event) || (ctx.formulario.processing.other = $event);
      return $event;
    });
    \u0275\u0275elementEnd();
    \u0275\u0275controlCreate();
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(91, "article", 18)(92, "h3", 19);
    \u0275\u0275text(93, "3. Informaci\xF3n de comercio (Trading)");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(94, "div", 20)(95, "label", 21)(96, "span", 22);
    \u0275\u0275text(97, "Grado (Size Grade / Other Grade)");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(98, "input", 36);
    \u0275\u0275twoWayListener("ngModelChange", function ExtrinsicFormPage_Template_input_ngModelChange_98_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.formulario.trading.grade, $event) || (ctx.formulario.trading.grade = $event);
      return $event;
    });
    \u0275\u0275elementEnd();
    \u0275\u0275controlCreate();
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(99, "label", 21)(100, "span", 22);
    \u0275\u0275text(101, "N\xFAmero ICO");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(102, "input", 30);
    \u0275\u0275twoWayListener("ngModelChange", function ExtrinsicFormPage_Template_input_ngModelChange_102_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.formulario.trading.icoNumber, $event) || (ctx.formulario.trading.icoNumber = $event);
      return $event;
    });
    \u0275\u0275elementEnd();
    \u0275\u0275controlCreate();
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(103, "label", 21)(104, "span", 22);
    \u0275\u0275text(105, "Otra informaci\xF3n comercial");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(106, "input", 30);
    \u0275\u0275twoWayListener("ngModelChange", function ExtrinsicFormPage_Template_input_ngModelChange_106_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.formulario.trading.other, $event) || (ctx.formulario.trading.other = $event);
      return $event;
    });
    \u0275\u0275elementEnd();
    \u0275\u0275controlCreate();
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(107, "article", 18)(108, "h3", 19);
    \u0275\u0275text(109, "4. Certificaciones");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(110, "div", 37)(111, "label", 38)(112, "input", 39);
    \u0275\u0275twoWayListener("ngModelChange", function ExtrinsicFormPage_Template_input_ngModelChange_112_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.formulario.certifications.c4, $event) || (ctx.formulario.certifications.c4 = $event);
      return $event;
    });
    \u0275\u0275elementEnd();
    \u0275\u0275controlCreate();
    \u0275\u0275text(113, " 4C");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(114, "label", 38)(115, "input", 39);
    \u0275\u0275twoWayListener("ngModelChange", function ExtrinsicFormPage_Template_input_ngModelChange_115_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.formulario.certifications.fairTrade, $event) || (ctx.formulario.certifications.fairTrade = $event);
      return $event;
    });
    \u0275\u0275elementEnd();
    \u0275\u0275controlCreate();
    \u0275\u0275text(116, " Fair Trade");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(117, "label", 38)(118, "input", 39);
    \u0275\u0275twoWayListener("ngModelChange", function ExtrinsicFormPage_Template_input_ngModelChange_118_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.formulario.certifications.organic, $event) || (ctx.formulario.certifications.organic = $event);
      return $event;
    });
    \u0275\u0275elementEnd();
    \u0275\u0275controlCreate();
    \u0275\u0275text(119, " Org\xE1nico");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(120, "label", 38)(121, "input", 39);
    \u0275\u0275twoWayListener("ngModelChange", function ExtrinsicFormPage_Template_input_ngModelChange_121_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.formulario.certifications.rainforest, $event) || (ctx.formulario.certifications.rainforest = $event);
      return $event;
    });
    \u0275\u0275elementEnd();
    \u0275\u0275controlCreate();
    \u0275\u0275text(122, " Rainforest Alliance");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(123, "label", 21)(124, "span", 22);
    \u0275\u0275text(125, "Otra certificaci\xF3n");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(126, "input", 40);
    \u0275\u0275twoWayListener("ngModelChange", function ExtrinsicFormPage_Template_input_ngModelChange_126_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.formulario.certifications.other, $event) || (ctx.formulario.certifications.other = $event);
      return $event;
    });
    \u0275\u0275elementEnd();
    \u0275\u0275controlCreate();
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(127, "aside", 41)(128, "div", 42)(129, "div", 43);
    \u0275\u0275text(130, "Notas extr\xEDnsecas");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(131, "textarea", 44);
    \u0275\u0275twoWayListener("ngModelChange", function ExtrinsicFormPage_Template_textarea_ngModelChange_131_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.formulario.notes, $event) || (ctx.formulario.notes = $event);
      return $event;
    });
    \u0275\u0275elementEnd();
    \u0275\u0275controlCreate();
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(132, "div", 45);
    \u0275\u0275template(133, ExtrinsicFormPage_button_133_Template, 2, 0, "button", 46);
    \u0275\u0275elementStart(134, "button", 47);
    \u0275\u0275listener("click", function ExtrinsicFormPage_Template_button_click_134_listener() {
      return ctx.irAMuestraSiguiente();
    });
    \u0275\u0275text(135);
    \u0275\u0275elementEnd()()()()()();
  }
  if (rf & 2) {
    \u0275\u0275property("scrollY", true);
    \u0275\u0275advance();
    \u0275\u0275property("pendientes", ctx.pendientesLocales())("enLinea", ctx.enLinea())("muestraCerrada", ctx.muestraActualCerrada())("rechazo", ctx.rechazoActual())("esperandoFinalizar", ctx.esperandoSincronizacion());
    \u0275\u0275advance(10);
    \u0275\u0275textInterpolate1("Muestra ", ctx.muestraActual(), " ");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1("de ", ctx.totalMuestras());
    \u0275\u0275advance(6);
    \u0275\u0275styleProp("width", ctx.muestraActual() / ctx.totalMuestras() * 100 + "%");
    \u0275\u0275advance(11);
    \u0275\u0275twoWayProperty("ngModel", ctx.formulario.farming.country);
    \u0275\u0275control();
    \u0275\u0275advance(4);
    \u0275\u0275twoWayProperty("ngModel", ctx.formulario.farming.region);
    \u0275\u0275control();
    \u0275\u0275advance(4);
    \u0275\u0275twoWayProperty("ngModel", ctx.formulario.farming.farmName);
    \u0275\u0275control();
    \u0275\u0275advance(4);
    \u0275\u0275twoWayProperty("ngModel", ctx.formulario.farming.producers);
    \u0275\u0275control();
    \u0275\u0275advance(4);
    \u0275\u0275twoWayProperty("ngModel", ctx.formulario.farming.species);
    \u0275\u0275control();
    \u0275\u0275advance(4);
    \u0275\u0275twoWayProperty("ngModel", ctx.formulario.farming.variety);
    \u0275\u0275control();
    \u0275\u0275advance(4);
    \u0275\u0275twoWayProperty("ngModel", ctx.formulario.farming.harvestDate);
    \u0275\u0275control();
    \u0275\u0275advance(4);
    \u0275\u0275twoWayProperty("ngModel", ctx.formulario.farming.other);
    \u0275\u0275control();
    \u0275\u0275advance(8);
    \u0275\u0275twoWayProperty("ngModel", ctx.formulario.processing.processorName);
    \u0275\u0275control();
    \u0275\u0275advance(4);
    \u0275\u0275twoWayProperty("ngModel", ctx.formulario.processing.wetMill);
    \u0275\u0275control();
    \u0275\u0275advance(4);
    \u0275\u0275twoWayProperty("ngModel", ctx.formulario.processing.dryMill);
    \u0275\u0275control();
    \u0275\u0275advance(4);
    \u0275\u0275twoWayProperty("ngModel", ctx.formulario.processing.processType);
    \u0275\u0275control();
    \u0275\u0275advance(12);
    \u0275\u0275twoWayProperty("ngModel", ctx.formulario.processing.other);
    \u0275\u0275control();
    \u0275\u0275advance(8);
    \u0275\u0275twoWayProperty("ngModel", ctx.formulario.trading.grade);
    \u0275\u0275control();
    \u0275\u0275advance(4);
    \u0275\u0275twoWayProperty("ngModel", ctx.formulario.trading.icoNumber);
    \u0275\u0275control();
    \u0275\u0275advance(4);
    \u0275\u0275twoWayProperty("ngModel", ctx.formulario.trading.other);
    \u0275\u0275control();
    \u0275\u0275advance(6);
    \u0275\u0275twoWayProperty("ngModel", ctx.formulario.certifications.c4);
    \u0275\u0275control();
    \u0275\u0275advance(3);
    \u0275\u0275twoWayProperty("ngModel", ctx.formulario.certifications.fairTrade);
    \u0275\u0275control();
    \u0275\u0275advance(3);
    \u0275\u0275twoWayProperty("ngModel", ctx.formulario.certifications.organic);
    \u0275\u0275control();
    \u0275\u0275advance(3);
    \u0275\u0275twoWayProperty("ngModel", ctx.formulario.certifications.rainforest);
    \u0275\u0275control();
    \u0275\u0275advance(5);
    \u0275\u0275twoWayProperty("ngModel", ctx.formulario.certifications.other);
    \u0275\u0275control();
    \u0275\u0275advance(5);
    \u0275\u0275twoWayProperty("ngModel", ctx.formulario.notes);
    \u0275\u0275control();
    \u0275\u0275advance(2);
    \u0275\u0275property("ngIf", ctx.muestraActual() > 1);
    \u0275\u0275advance();
    \u0275\u0275property("disabled", ctx.guardando());
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", ctx.guardando() ? "Guardando\u2026" : ctx.muestraActual() === ctx.totalMuestras() ? "Terminar cata" : "Siguiente muestra \u2192", " ");
  }
}, dependencies: [IonContent, IonIcon, CommonModule, NgIf, FormsModule, NgSelectOption, \u0275NgSelectMultipleOption, DefaultValueAccessor, CheckboxControlValueAccessor, SelectControlValueAccessor, NgControlStatus, NgModel, EstadoFichaComponent], encapsulation: 2 });
var ExtrinsicFormPage = _ExtrinsicFormPage;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ExtrinsicFormPage, [{
    type: Component,
    args: [{ selector: "app-extrinsic-form", standalone: true, imports: [IonContent, IonIcon, CommonModule, FormsModule, EstadoFichaComponent], template: `<ion-content class="cva-combined" [scrollY]="true">
  <app-estado-ficha
    [pendientes]="pendientesLocales()"
    [enLinea]="enLinea()"
    [muestraCerrada]="muestraActualCerrada()"
    [rechazo]="rechazoActual()"
    [esperandoFinalizar]="esperandoSincronizacion()"
    (reintentar)="reintentarSincronizacion()"
    (salir)="salirConPendientes()">
  </app-estado-ficha>
  <header class="cva-header">
    <div class="cva-header__inner">
      <div class="cva-header__left">
        <button type="button" class="cva-header__back-btn" aria-label="Volver" (click)="volver()">
          <ion-icon name="arrow-back-outline"></ion-icon>
        </button>
        <div class="cva-header__meta">
          <p class="cva-header__session-name">Evaluaci\xF3n Extr\xEDnseca</p>
          <p class="cva-header__sample-label">Muestra {{ muestraActual() }} <span>de {{ totalMuestras() }}</span></p>
        </div>
      </div>
      <div class="cva-header__right">
        <span class="cva-header__format-badge">Extr\xEDnseca</span>
      </div>
    </div>
    <div class="cva-header__progress-bar-wrap">
      <div class="cva-header__progress-bar">
        <div class="cva-header__progress-bar-fill" [style.width]="(muestraActual() / totalMuestras()) * 100 + '%'"></div>
      </div>
    </div>
  </header>

  <main class="cva-main">
    <div class="cva-main__grid">
      <div class="cva-main__column">
        <article class="attr-card">
          <h3 class="attr-card__title">1. Informaci\xF3n de cultivo (Farming)</h3>
          <div class="form-fields">
            <label class="form-field">
              <span class="intensity-slider__label">Pa\xEDs</span>
              <input class="notes-panel__textarea" type="text" [(ngModel)]="formulario.farming.country" placeholder="Ej: Colombia">
            </label>
            <label class="form-field">
              <span class="intensity-slider__label">Regi\xF3n / Departamento</span>
              <input class="notes-panel__textarea" type="text" [(ngModel)]="formulario.farming.region" placeholder="Ej: Huila">
            </label>
            <label class="form-field">
              <span class="intensity-slider__label">Nombre de la finca o cooperativa</span>
              <input class="notes-panel__textarea" type="text" [(ngModel)]="formulario.farming.farmName" placeholder="Ej: Finca El Mirador">
            </label>
            <label class="form-field">
              <span class="intensity-slider__label">Productor(es)</span>
              <input class="notes-panel__textarea" type="text" [(ngModel)]="formulario.farming.producers" placeholder="Nombre(s) de productores">
            </label>
            <label class="form-field">
              <span class="intensity-slider__label">Especie</span>
              <input class="notes-panel__textarea" type="text" [(ngModel)]="formulario.farming.species" placeholder="Ej: Ar\xE1bica">
            </label>
            <label class="form-field">
              <span class="intensity-slider__label">Variedad</span>
              <input class="notes-panel__textarea" type="text" [(ngModel)]="formulario.farming.variety" placeholder="Ej: Geisha">
            </label>
            <label class="form-field">
              <span class="intensity-slider__label">Fecha de cosecha</span>
              <input class="notes-panel__textarea" type="date" [(ngModel)]="formulario.farming.harvestDate">
            </label>
            <label class="form-field">
              <span class="intensity-slider__label">Otra informaci\xF3n de cultivo</span>
              <input class="notes-panel__textarea" type="text" [(ngModel)]="formulario.farming.other">
            </label>
          </div>
        </article>

        <article class="attr-card">
          <h3 class="attr-card__title">2. Informaci\xF3n de procesamiento</h3>
          <div class="form-fields">
            <label class="form-field">
              <span class="intensity-slider__label">Nombre del procesador</span>
              <input class="notes-panel__textarea" type="text" [(ngModel)]="formulario.processing.processorName">
            </label>
            <label class="form-field">
              <span class="intensity-slider__label">Beneficio h\xFAmedo</span>
              <input class="notes-panel__textarea" type="text" [(ngModel)]="formulario.processing.wetMill">
            </label>
            <label class="form-field">
              <span class="intensity-slider__label">Beneficio seco</span>
              <input class="notes-panel__textarea" type="text" [(ngModel)]="formulario.processing.dryMill">
            </label>
            <label class="form-field">
              <span class="intensity-slider__label">Tipo de proceso</span>
              <select class="notes-panel__textarea" [(ngModel)]="formulario.processing.processType">
                <option value="">Seleccionar</option>
                <option value="lavado">Lavado</option>
                <option value="natural">Natural</option>
                <option value="otro">Otro</option>
              </select>
            </label>
            <label class="form-field">
              <span class="intensity-slider__label">Otro proceso</span>
              <input class="notes-panel__textarea" type="text" [(ngModel)]="formulario.processing.other">
            </label>
          </div>
        </article>

        <article class="attr-card">
          <h3 class="attr-card__title">3. Informaci\xF3n de comercio (Trading)</h3>
          <div class="form-fields">
            <label class="form-field">
              <span class="intensity-slider__label">Grado (Size Grade / Other Grade)</span>
              <input class="notes-panel__textarea" type="text" [(ngModel)]="formulario.trading.grade" placeholder="Ej: Supremo">
            </label>
            <label class="form-field">
              <span class="intensity-slider__label">N\xFAmero ICO</span>
              <input class="notes-panel__textarea" type="text" [(ngModel)]="formulario.trading.icoNumber">
            </label>
            <label class="form-field">
              <span class="intensity-slider__label">Otra informaci\xF3n comercial</span>
              <input class="notes-panel__textarea" type="text" [(ngModel)]="formulario.trading.other">
            </label>
          </div>
        </article>

        <article class="attr-card">
          <h3 class="attr-card__title">4. Certificaciones</h3>
          <div class="mouthfeel__list">
            <label class="mouthfeel__item"><input type="checkbox" [(ngModel)]="formulario.certifications.c4"> 4C</label>
            <label class="mouthfeel__item"><input type="checkbox" [(ngModel)]="formulario.certifications.fairTrade"> Fair Trade</label>
            <label class="mouthfeel__item"><input type="checkbox" [(ngModel)]="formulario.certifications.organic"> Org\xE1nico</label>
            <label class="mouthfeel__item"><input type="checkbox" [(ngModel)]="formulario.certifications.rainforest"> Rainforest Alliance</label>
            <label class="form-field">
              <span class="intensity-slider__label">Otra certificaci\xF3n</span>
              <input class="notes-panel__textarea" type="text" [(ngModel)]="formulario.certifications.other" placeholder="Ej: Bird Friendly">
            </label>
          </div>
        </article>
      </div>

      <aside class="cva-main__sidebar">
        <div class="notes-panel">
          <div class="notes-panel__header">Notas extr\xEDnsecas</div>
          <textarea class="notes-panel__textarea" rows="5" [(ngModel)]="formulario.notes" placeholder="Otra informaci\xF3n relevante..."></textarea>
        </div>
        <div class="sample-navigation">
          <button
            *ngIf="muestraActual() > 1"
            type="button"
            class="submit-btn sample-navigation__previous"
            (click)="irAMuestraAnterior()">
            \u2190 Anterior
          </button>
          <button type="button" class="submit-btn" (click)="irAMuestraSiguiente()" [disabled]="guardando()">
            {{ guardando() ? 'Guardando\u2026' : (muestraActual() === totalMuestras() ? 'Terminar cata' : 'Siguiente muestra \u2192') }}
          </button>
        </div>
      </aside>
    </div>
  </main>
</ion-content>
` }]
  }], null, null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(ExtrinsicFormPage, { className: "ExtrinsicFormPage", filePath: "src/app/pages/evaluation/extrinsic-form/extrinsic-form.page.ts", lineNumber: 47 });
})();
export {
  ExtrinsicFormPage
};
//# debugId=fa042df6-52a5-5e97-af64-880d06bcda70
//# sourceMappingURL=extrinsic-form.page-MF4NOCD2.js.map
