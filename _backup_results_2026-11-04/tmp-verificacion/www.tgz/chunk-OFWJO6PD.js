// src/app/core/utils/errores.ts
var PATRONES_RED = [
  "failed to fetch",
  "networkerror",
  "network request failed",
  "load failed",
  "fetch failed",
  "the internet connection appears to be offline",
  "timeout",
  "timed out",
  "econnreset",
  "socket hang up"
];
var CODIGOS_PERMANENTES = /* @__PURE__ */ new Set([
  "42501",
  // RLS / privilegios: la muestra está cerrada o ya no eres participante
  "23514",
  // CHECK violado
  "23502",
  // NOT NULL violado
  "23503",
  // FK violada
  "22023",
  // parámetro inválido (RAISE de las RPC)
  "22P02",
  // texto inválido para el tipo
  "P0002",
  // no encontrado (RAISE de las RPC)
  "PGRST116",
  "PGRST204"
]);
function comoRegistro(error) {
  return typeof error === "object" && error !== null ? error : {};
}
function mensajeDeError(error, alternativo = "Ocurri\xF3 un error inesperado.") {
  if (typeof error === "string" && error.trim())
    return error;
  const mensaje = comoRegistro(error).message;
  return typeof mensaje === "string" && mensaje.trim() ? mensaje : alternativo;
}
function codigoDeError(error) {
  const codigo = comoRegistro(error).code;
  return typeof codigo === "string" ? codigo : "";
}
function esErrorDeRed(error) {
  if (typeof navigator !== "undefined" && navigator.onLine === false)
    return true;
  const registro = comoRegistro(error);
  const status = typeof registro.status === "number" ? registro.status : 0;
  if (status === 408 || status === 429 || status >= 500)
    return true;
  if (registro.name === "AbortError")
    return true;
  const texto = mensajeDeError(error, "").toLowerCase();
  return PATRONES_RED.some((patron) => texto.includes(patron));
}
function esErrorPermanente(error) {
  if (esErrorDeRed(error))
    return false;
  const codigo = codigoDeError(error);
  if (CODIGOS_PERMANENTES.has(codigo))
    return true;
  const status = comoRegistro(error).status;
  return typeof status === "number" && status >= 400 && status < 500 && status !== 401 && status !== 408 && status !== 429;
}

export {
  mensajeDeError,
  codigoDeError,
  esErrorPermanente
};
//# debugId=fed8398a-3f66-556e-b1ab-3ef32f9ead4c
//# sourceMappingURL=chunk-OFWJO6PD.js.map
