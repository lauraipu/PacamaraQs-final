import {
  ETIQUETAS_HEDONICAS
} from "./chunk-ECLBRM7C.js";
import {
  codigoDeError,
  mensajeDeError
} from "./chunk-OFWJO6PD.js";
import {
  FormatoCva,
  checkmarkCircleOutline,
  closeOutline,
  documentTextOutline,
  downloadOutline,
  getFormatoById,
  lockClosedOutline,
  medalOutline,
  ribbonOutline,
  sesionDtoToDomain,
  trophyOutline
} from "./chunk-ISYXHPYK.js";
import {
  addIcons
} from "./chunk-4JFQPQWK.js";
import {
  ActivatedRoute,
  CommonModule,
  Component,
  DOCUMENT,
  DatePipe,
  DecimalPipe,
  Injectable,
  Injector,
  Input,
  IonAccordion,
  IonAccordionGroup,
  IonBackButton,
  IonBadge,
  IonButton,
  IonButtons,
  IonCard,
  IonCardContent,
  IonCol,
  IonContent,
  IonGrid,
  IonHeader,
  IonIcon,
  IonItem,
  IonLabel,
  IonList,
  IonModal,
  IonRow,
  IonSegment,
  IonSegmentButton,
  IonSelect,
  IonSelectOption,
  IonSpinner,
  IonTitle,
  IonToolbar,
  NavController,
  NgClass,
  NgTemplateOutlet,
  SupabaseService,
  ToastController,
  ViewChild,
  afterNextRender,
  computed,
  inject,
  setClassMetadata,
  signal,
  viewChild,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵattribute,
  ɵɵclassMap,
  ɵɵclassProp,
  ɵɵconditional,
  ɵɵconditionalCreate,
  ɵɵdefineComponent,
  ɵɵdefineInjectable,
  ɵɵelement,
  ɵɵelementContainer,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵinterpolate1,
  ɵɵlistener,
  ɵɵnamespaceHTML,
  ɵɵnamespaceSVG,
  ɵɵnextContext,
  ɵɵpipe,
  ɵɵpipeBind2,
  ɵɵproperty,
  ɵɵpureFunction1,
  ɵɵpureFunction2,
  ɵɵpureFunction3,
  ɵɵqueryAdvance,
  ɵɵreference,
  ɵɵrepeater,
  ɵɵrepeaterCreate,
  ɵɵrepeaterTrackByIdentity,
  ɵɵrepeaterTrackByIndex,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵstyleProp,
  ɵɵtemplate,
  ɵɵtemplateRefExtractor,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1,
  ɵɵtextInterpolate2,
  ɵɵtextInterpolate3,
  ɵɵviewQuerySignal
} from "./chunk-ELFI4Z7L.js";
import "./chunk-BMQUG2PJ.js";
import "./chunk-3OZZMUVI.js";
import "./chunk-3GAB7GSC.js";
import "./chunk-B7Y4FMY7.js";
import "./chunk-NQCL7WZ3.js";
import "./chunk-4BTEZGN2.js";
import "./chunk-XTVSKRH4.js";
import "./chunk-ETZFPO3Y.js";
import "./chunk-LLS636HS.js";
import "./chunk-KQQH3YTO.js";
import "./chunk-DI3VEDFV.js";
import {
  __spreadProps,
  __spreadValues
} from "./chunk-PAXKX5KU.js";

// src/app/core/services/impresion.ts
var ESTILOS_REPORTE = `
  @page { size: A4; margin: 14mm 14mm 16mm; }
  * { box-sizing: border-box; }
  html, body { margin: 0; padding: 0; }
  body {
    color: #0f172b;
    font: 11px/1.45 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
    -webkit-print-color-adjust: exact;
    print-color-adjust: exact;
  }
  .rp-head { display: flex; justify-content: space-between; align-items: flex-end; gap: 16px;
    padding-bottom: 10px; margin-bottom: 14px; border-bottom: 2px solid #2f3e46; }
  .rp-brand { margin: 0; color: #62748e; font-size: 9px; font-weight: 700; letter-spacing: .08em; text-transform: uppercase; }
  .rp-title { margin: 2px 0 0; font-size: 18px; font-weight: 700; }
  .rp-sub { margin: 2px 0 0; color: #62748e; font-size: 11px; }
  .rp-meta { margin: 0; color: #62748e; font-size: 10px; text-align: right; white-space: nowrap; }
  .rp-section { margin: 0 0 14px; break-inside: avoid; page-break-inside: avoid; }
  .rp-section h2 { margin: 0 0 6px; color: #62748e; font-size: 9px; font-weight: 700; letter-spacing: .06em; text-transform: uppercase; }
  .rp-kpis { display: flex; gap: 8px; margin: 0 0 14px; }
  .rp-kpi { flex: 1; padding: 8px 10px; border: 1px solid #e2e8f0; border-radius: 6px; }
  .rp-kpi strong { display: block; color: #c2410c; font-size: 16px; }
  .rp-kpi span { color: #62748e; font-size: 9px; text-transform: uppercase; }
  table { width: 100%; border-collapse: collapse; }
  th, td { padding: 5px 6px; border-bottom: 1px solid #e2e8f0; text-align: left; vertical-align: top; }
  th { color: #62748e; font-size: 9px; font-weight: 600; text-transform: uppercase; }
  td.num, th.num { text-align: right; font-variant-numeric: tabular-nums; }
  .rp-score { color: #c2410c; font-weight: 700; }
  .rp-badge { display: inline-block; padding: 1px 6px; border-radius: 4px; font-size: 9px; font-weight: 600; }
  .rp-bar { position: relative; height: 8px; border-radius: 4px; background: #f1f5f9; overflow: hidden; }
  .rp-bar > i { position: absolute; inset: 0 auto 0 0; border-radius: 4px; background: #2f3e46; }
  .rp-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 0 18px; }
  .rp-dl { display: grid; grid-template-columns: 40% 60%; margin: 0; }
  .rp-dl dt, .rp-dl dd { margin: 0; padding: 4px 0; border-bottom: 1px solid #e2e8f0; }
  .rp-dl dt { color: #62748e; }
  .rp-chips span { display: inline-block; margin: 0 4px 4px 0; padding: 2px 8px; border: 1px solid #e2e8f0; border-radius: 10px; }
  .rp-muted { color: #62748e; }
  .rp-formula { margin-top: 10px; padding: 8px 10px; border-radius: 6px; background: #f1f5f9; font-family: ui-monospace, Menlo, monospace; }
  .rp-foot { margin-top: 18px; padding-top: 6px; border-top: 1px solid #e2e8f0; color: #94a3b8; font-size: 9px; }
  .rp-page-break { break-before: page; page-break-before: always; }
`;
var escaparHtml = (texto) => texto.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
var _ImpresionService = class _ImpresionService {
  constructor() {
    this.document = inject(DOCUMENT);
  }
  imprimir(titulo, contenidoHtml) {
    const doc = this.document;
    const iframe = doc.createElement("iframe");
    iframe.setAttribute("aria-hidden", "true");
    iframe.setAttribute("tabindex", "-1");
    Object.assign(iframe.style, {
      position: "fixed",
      right: "0",
      bottom: "0",
      width: "0",
      height: "0",
      border: "0",
      visibility: "hidden"
    });
    return new Promise((resolve, reject) => {
      let terminado = false;
      const limpiar = () => {
        if (terminado)
          return;
        terminado = true;
        iframe.remove();
        resolve();
      };
      iframe.onload = () => {
        const ventana = iframe.contentWindow;
        if (!ventana || typeof ventana.print !== "function") {
          iframe.remove();
          reject(new Error("Este dispositivo no permite imprimir desde la app. Abre PacamaraQs en un navegador de escritorio."));
          return;
        }
        ventana.addEventListener("afterprint", () => setTimeout(limpiar, 0), { once: true });
        ventana.focus();
        ventana.print();
        setTimeout(limpiar, 6e4);
      };
      iframe.srcdoc = `<!doctype html><html lang="es"><head><meta charset="utf-8"><title>${escaparHtml(titulo)}</title><style>${ESTILOS_REPORTE}</style></head><body>${contenidoHtml}</body></html>`;
      doc.body.appendChild(iframe);
    });
  }
};
_ImpresionService.\u0275fac = function ImpresionService_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _ImpresionService)();
};
_ImpresionService.\u0275prov = /* @__PURE__ */ \u0275\u0275defineInjectable({ token: _ImpresionService, factory: _ImpresionService.\u0275fac, providedIn: "root" });
var ImpresionService = _ImpresionService;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ImpresionService, [{
    type: Injectable,
    args: [{ providedIn: "root" }]
  }], null, null);
})();

// src/app/core/mappers/ficha-tecnica.mapper.ts
var SIN_DATO = "\u2014";
var CERTIFICACIONES_FORMULARIO = {
  c4: "4C",
  fairTrade: "Fair Trade",
  organic: "Org\xE1nico",
  rainforest: "Rainforest Alliance"
};
var comoRegistro = (valor) => valor !== null && typeof valor === "object" && !Array.isArray(valor) ? valor : {};
function textoDeCampo(valor) {
  if (valor === null || valor === void 0)
    return "";
  if (typeof valor === "boolean")
    return valor ? "S\xED" : "No";
  if (typeof valor === "number")
    return Number.isFinite(valor) ? String(valor) : "";
  if (typeof valor === "string")
    return valor.trim();
  return "";
}
var capitalizar = (texto) => texto ? texto.charAt(0).toUpperCase() + texto.slice(1) : texto;
function construirFichasTecnicas(fichas, registradas) {
  const pendientes = [...registradas];
  const tomarRegistro = (numeroMuestra) => {
    const indice = pendientes.findIndex((r) => Number(r.numero_muestra) === numeroMuestra);
    return indice >= 0 ? pendientes.splice(indice, 1)[0] : null;
  };
  const resultado = fichas.map((ficha) => {
    const numeroMuestra = Number(ficha.numero_muestra);
    return construirFicha(numeroMuestra, ficha, tomarRegistro(numeroMuestra));
  });
  for (const registro of pendientes) {
    resultado.push(construirFicha(Number(registro.numero_muestra), null, registro));
  }
  return resultado.sort((a, b) => a.numeroMuestra - b.numeroMuestra);
}
function construirFicha(numeroMuestra, ficha, registro) {
  const formulario = comoRegistro(ficha?.formulario);
  const cultivo = comoRegistro(formulario["farming"]);
  const proceso = comoRegistro(formulario["processing"]);
  const comercio = comoRegistro(formulario["trading"]);
  const certForm = comoRegistro(formulario["certifications"]);
  const tabla = comoRegistro(registro?.datos);
  const valor = (claveTabla, valorFormulario) => (claveTabla ? textoDeCampo(tabla[claveTabla]) : "") || textoDeCampo(valorFormulario) || SIN_DATO;
  const precio = textoDeCampo(tabla["precio_finca"]);
  const secciones = [
    {
      titulo: "Origen y cultivo",
      campos: [
        { etiqueta: "Pa\xEDs", valor: valor("pais", cultivo["country"]) },
        { etiqueta: "Regi\xF3n", valor: valor("region", cultivo["region"]) },
        { etiqueta: "Finca / Cooperativa", valor: valor("finca_o_coop", cultivo["farmName"]) },
        { etiqueta: "Productores", valor: valor("productores", cultivo["producers"]) },
        { etiqueta: "Especie", valor: valor("especie", cultivo["species"]) },
        { etiqueta: "Variedad", valor: valor("variedad", cultivo["variety"]) },
        { etiqueta: "Fecha de cosecha", valor: valor("fecha_cosecha", cultivo["harvestDate"]) },
        { etiqueta: "Otros (cultivo)", valor: valor("otro_cultivo", cultivo["other"]) }
      ]
    },
    {
      titulo: "Procesamiento",
      campos: [
        { etiqueta: "Procesador", valor: valor("nombre_procesador", proceso["processorName"]) },
        { etiqueta: "Beneficio h\xFAmedo", valor: valor("beneficio_humedo", proceso["wetMill"]) },
        { etiqueta: "Beneficio seco", valor: valor("beneficio_seco", proceso["dryMill"]) },
        { etiqueta: "Tipo de proceso", valor: capitalizar(valor("tipo_proceso", proceso["processType"])) },
        { etiqueta: "Descafeinado", valor: valor("descafeinado") },
        { etiqueta: "Descripci\xF3n del proceso", valor: valor("descripcion_proceso") },
        { etiqueta: "Otros (proceso)", valor: valor("otro_procesamiento", proceso["other"]) }
      ]
    },
    {
      titulo: "Comercializaci\xF3n",
      campos: [
        { etiqueta: "Grado", valor: valor("grado", comercio["grade"]) },
        { etiqueta: "N\xFAmero ICO", valor: valor("numero_ico", comercio["icoNumber"]) },
        { etiqueta: "Importador", valor: valor("importador") },
        { etiqueta: "Exportador", valor: valor("exportador") },
        { etiqueta: "Precio en finca", valor: precio || SIN_DATO },
        { etiqueta: "Tama\xF1o de lote", valor: valor("tamano_lote") },
        { etiqueta: "Otros (comercial)", valor: valor("otro_comercial", comercio["other"]) }
      ]
    }
  ];
  const otros = [
    { etiqueta: "Premios", valor: textoDeCampo(tabla["premios"]) },
    { etiqueta: "Otra informaci\xF3n", valor: textoDeCampo(tabla["otra_info"]) }
  ].filter((c) => c.valor !== "");
  if (otros.length > 0)
    secciones.push({ titulo: "Informaci\xF3n adicional", campos: otros });
  const certificaciones = new Set((registro?.certificaciones ?? []).map(textoDeCampo).filter(Boolean));
  for (const [clave, etiqueta] of Object.entries(CERTIFICACIONES_FORMULARIO)) {
    if (certForm[clave] === true)
      certificaciones.add(etiqueta);
  }
  const otraCert = textoDeCampo(certForm["other"]);
  if (otraCert)
    certificaciones.add(otraCert);
  return {
    numeroMuestra,
    registradaPor: ficha?.nombre ?? null,
    registradaEn: ficha?.registrado_en ?? (textoDeCampo(tabla["creado_en"]) || null),
    secciones,
    certificaciones: [...certificaciones].sort((a, b) => a.localeCompare(b, "es")),
    notas: textoDeCampo(formulario["notes"])
  };
}

// src/app/core/services/results.ts
var num = (valor) => {
  const n = typeof valor === "number" ? valor : Number(valor);
  return Number.isFinite(n) ? n : 0;
};
var numONulo = (valor) => {
  if (valor === null || valor === void 0 || valor === "")
    return null;
  const n = typeof valor === "number" ? valor : Number(valor);
  return Number.isFinite(n) ? n : null;
};
var _ResultsService = class _ResultsService {
  constructor() {
    this.supabase = inject(SupabaseService);
  }
  async obtenerResultadosSesion(sesionId) {
    const { data: sesionData, error: sesionError } = await this.supabase.client.from("sesiones").select("*").eq("id", sesionId).maybeSingle();
    if (sesionError)
      throw sesionError;
    if (!sesionData)
      return null;
    const sesion = sesionDtoToDomain(sesionData);
    const { data, error } = await this.supabase.client.rpc("get_resumen_panel", { p_sesion_id: sesionId });
    if (error)
      throw error;
    if (!data)
      return null;
    const resumen = data;
    const muestras = (resumen.por_muestra ?? []).map((m) => this.mapearMuestra(m));
    const catadores = (resumen.por_catador ?? []).map((c) => this.mapearCatador(c));
    return {
      sesionId,
      nombreSesion: sesion.nombre,
      formatoCva: sesion.formato,
      fechaCierre: (/* @__PURE__ */ new Date()).toISOString(),
      totalMuestras: sesion.numeroMuestras,
      totalCatadores: catadores.length,
      muestras,
      catadores,
      atributosPorMuestra: (resumen.por_atributo ?? []).map((a) => this.mapearPromedioAtributo(a)),
      votosHedonicos: (resumen.votos_hedonicos ?? []).map((v) => this.mapearVoto(v)),
      fichasTecnicas: construirFichasTecnicas(resumen.fichas_extrinsecas ?? [], resumen.extrinseca_registrada ?? [])
    };
  }
  /**
   * Antes el objeto snake_case de la RPC se asignaba directo a un modelo
   * camelCase: todas las tarjetas mostraban `undefined` y el `@for` hacía
   * track por `muestra.numeroMuestra` (undefined) → claves duplicadas.
   */
  mapearMuestra(m) {
    return {
      numeroMuestra: num(m.numero_muestra),
      nivelTueste: m.nivel_tueste,
      puntajePromedioPanel: num(m.puntaje_promedio_panel),
      puntajeMin: num(m.puntaje_min),
      puntajeMax: num(m.puntaje_max),
      desviacionEstandar: num(m.desviacion_estandar),
      evaluacionesRecibidas: num(m.evaluaciones_recibidas),
      evaluacionesEsperadas: num(m.evaluaciones_esperadas),
      recortado: m.recortado === true,
      puntajePromedioSimple: num(m.puntaje_promedio_simple),
      cerradaForzada: m.cerrada_forzada === true
    };
  }
  mapearCatador(c) {
    return {
      cupperId: c.cupper_id,
      nombre: c.nombre,
      esOrganizador: c.es_organizador,
      muestrasEvaluadas: num(c.muestras_evaluadas),
      muestrasAsignadas: num(c.muestras_asignadas),
      estado: c.estado,
      submittedAt: c.submitted_at,
      puntajePromedio: num(c.puntaje_promedio),
      desviacionRespectoPanel: num(c.desviacion_respecto_panel),
      puntajesPorMuestra: (c.puntajes_por_muestra ?? []).map((p) => ({
        numeroMuestra: num(p.numero_muestra),
        puntaje: num(p.puntaje),
        defectos: [],
        tazasNoUniformes: num(p.tazas_no_uniformes),
        tazasDefectuosas: num(p.tazas_defectuosas),
        impresionGlobal: numONulo(p.impresion_global),
        atributos: this.mapearAtributos(p.atributos)
      }))
    };
  }
  mapearAtributos(atributos) {
    const resultado = {};
    for (const [clave, valor] of Object.entries(atributos ?? {})) {
      resultado[clave] = { intensidad: numONulo(valor?.intensidad), calidad: numONulo(valor?.calidad) };
    }
    return resultado;
  }
  mapearPromedioAtributo(a) {
    return {
      numeroMuestra: num(a.numero_muestra),
      atributo: a.atributo,
      respuestas: num(a.respuestas),
      intensidadPromedio: numONulo(a.intensidad_promedio),
      calidadPromedio: numONulo(a.calidad_promedio)
    };
  }
  mapearVoto(v) {
    return { numeroMuestra: num(v.numero_muestra), valor: num(v.valor), votos: num(v.votos) };
  }
};
_ResultsService.\u0275fac = function ResultsService_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _ResultsService)();
};
_ResultsService.\u0275prov = /* @__PURE__ */ \u0275\u0275defineInjectable({ token: _ResultsService, factory: _ResultsService.\u0275fac, providedIn: "root" });
var ResultsService = _ResultsService;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ResultsService, [{
    type: Injectable,
    args: [{ providedIn: "root" }]
  }], null, null);
})();

// src/app/shared/components/cupper-result-card/cupper-result-card.component.ts
var _c0 = (a0, a1, a2) => ({ "generoso": a0, "estricto": a1, "calibrado": a2 });
function CupperResultCardComponent_Conditional_17_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span");
    \u0275\u0275text(1);
    \u0275\u0275pipe(2, "number");
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1("\u2191 +", \u0275\u0275pipeBind2(2, 1, ctx_r0.catador.desviacionRespectoPanel, "1.2-2"), " (Generoso)");
  }
}
function CupperResultCardComponent_Conditional_18_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span");
    \u0275\u0275text(1);
    \u0275\u0275pipe(2, "number");
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1("\u2193 ", \u0275\u0275pipeBind2(2, 1, ctx_r0.catador.desviacionRespectoPanel, "1.2-2"), " (Estricto)");
  }
}
function CupperResultCardComponent_Conditional_19_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span");
    \u0275\u0275text(1, "\u2713 Calibrado con el panel");
    \u0275\u0275elementEnd();
  }
}
var _CupperResultCardComponent = class _CupperResultCardComponent {
  get esGeneroso() {
    return this.catador.desviacionRespectoPanel > 0.5;
  }
  get esEstricto() {
    return this.catador.desviacionRespectoPanel < -0.5;
  }
  get estaCalibrado() {
    return Math.abs(this.catador.desviacionRespectoPanel) <= 0.5;
  }
};
_CupperResultCardComponent.\u0275fac = function CupperResultCardComponent_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _CupperResultCardComponent)();
};
_CupperResultCardComponent.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _CupperResultCardComponent, selectors: [["app-cupper-result-card"]], inputs: { catador: "catador" }, decls: 31, vars: 20, consts: [[1, "cupper-card"], [1, "cupper-header"], [1, "cupper-info"], [1, "avatar"], [1, "cupper-name"], [1, "cupper-role"], [1, "cupper-score"], [1, "score-value"], [1, "score-label"], [1, "calibration-badge", 3, "ngClass"], [1, "cupper-stats"], [1, "stat"], [1, "stat-label"], [1, "stat-value"]], template: function CupperResultCardComponent_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 0)(1, "div", 1)(2, "div", 2)(3, "div", 3);
    \u0275\u0275text(4);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "div")(6, "h4", 4);
    \u0275\u0275text(7);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "span", 5);
    \u0275\u0275text(9);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(10, "div", 6)(11, "span", 7);
    \u0275\u0275text(12);
    \u0275\u0275pipe(13, "number");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(14, "span", 8);
    \u0275\u0275text(15, "Promedio");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(16, "div", 9);
    \u0275\u0275conditionalCreate(17, CupperResultCardComponent_Conditional_17_Template, 3, 4, "span");
    \u0275\u0275conditionalCreate(18, CupperResultCardComponent_Conditional_18_Template, 3, 4, "span");
    \u0275\u0275conditionalCreate(19, CupperResultCardComponent_Conditional_19_Template, 2, 0, "span");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(20, "div", 10)(21, "div", 11)(22, "span", 12);
    \u0275\u0275text(23, "Muestras Evaluadas");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(24, "span", 13);
    \u0275\u0275text(25);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(26, "div", 11)(27, "span", 12);
    \u0275\u0275text(28, "Estado");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(29, "span", 13);
    \u0275\u0275text(30);
    \u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(ctx.catador.nombre.charAt(0).toUpperCase());
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(ctx.catador.nombre);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(ctx.catador.esOrganizador ? "Organizador" : "Catador");
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind2(13, 13, ctx.catador.puntajePromedio, "1.2-2"));
    \u0275\u0275advance(4);
    \u0275\u0275property("ngClass", \u0275\u0275pureFunction3(16, _c0, ctx.esGeneroso, ctx.esEstricto, ctx.estaCalibrado));
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx.esGeneroso ? 17 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx.esEstricto ? 18 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx.estaCalibrado ? 19 : -1);
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate2("", ctx.catador.muestrasEvaluadas, " / ", ctx.catador.muestrasAsignadas);
    \u0275\u0275advance(4);
    \u0275\u0275classProp("success", ctx.catador.estado === "enviado");
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", ctx.catador.estado === "enviado" ? "Enviado" : "Pendiente", " ");
  }
}, dependencies: [CommonModule, NgClass, DecimalPipe], styles: ["\n.cupper-card[_ngcontent-%COMP%] {\n  background: #FFFFFF;\n  border: 1px solid #E2E8F0;\n  border-radius: 12px;\n  padding: 16px;\n  margin-bottom: 12px;\n}\n.cupper-header[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  margin-bottom: 12px;\n}\n.cupper-info[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 12px;\n}\n.avatar[_ngcontent-%COMP%] {\n  width: 40px;\n  height: 40px;\n  border-radius: 50%;\n  background: #F1F5F9;\n  color: #0F172B;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-weight: 700;\n  font-size: 16px;\n}\n.cupper-name[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 14px;\n  font-weight: 700;\n  color: #0F172B;\n}\n.cupper-role[_ngcontent-%COMP%] {\n  font-size: 11px;\n  color: #62748E;\n}\n.cupper-score[_ngcontent-%COMP%] {\n  text-align: right;\n}\n.score-value[_ngcontent-%COMP%] {\n  display: block;\n  font-size: 20px;\n  font-weight: 800;\n  color: #0F172B;\n}\n.score-label[_ngcontent-%COMP%] {\n  font-size: 10px;\n  color: #62748E;\n  text-transform: uppercase;\n}\n.calibration-badge[_ngcontent-%COMP%] {\n  padding: 6px 12px;\n  border-radius: 6px;\n  font-size: 11px;\n  font-weight: 600;\n  text-align: center;\n  margin-bottom: 12px;\n}\n.calibration-badge.generoso[_ngcontent-%COMP%] {\n  background: #FEFCE8;\n  color: #A16207;\n}\n.calibration-badge.estricto[_ngcontent-%COMP%] {\n  background: #FFF7ED;\n  color: #C2410C;\n}\n.calibration-badge.calibrado[_ngcontent-%COMP%] {\n  background: #F0FDF4;\n  color: #15803D;\n}\n.cupper-stats[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  border-top: 1px solid #F1F5F9;\n  padding-top: 12px;\n}\n.stat[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 4px;\n}\n.stat-label[_ngcontent-%COMP%] {\n  font-size: 10px;\n  color: #62748E;\n  text-transform: uppercase;\n}\n.stat-value[_ngcontent-%COMP%] {\n  font-size: 13px;\n  font-weight: 600;\n  color: #0F172B;\n}\n.stat-value.success[_ngcontent-%COMP%] {\n  color: #15803D;\n}\n/*# sourceMappingURL=cupper-result-card.component.css.map */"] });
var CupperResultCardComponent = _CupperResultCardComponent;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(CupperResultCardComponent, [{
    type: Component,
    args: [{ selector: "app-cupper-result-card", standalone: true, imports: [CommonModule], template: `<div class="cupper-card">
  <div class="cupper-header">
    <div class="cupper-info">
      <div class="avatar">{{ catador.nombre.charAt(0).toUpperCase() }}</div>
      <div>
        <h4 class="cupper-name">{{ catador.nombre }}</h4>
        <span class="cupper-role">{{ catador.esOrganizador ? 'Organizador' : 'Catador' }}</span>
      </div>
    </div>
    <div class="cupper-score">
      <span class="score-value">{{ catador.puntajePromedio | number:'1.2-2' }}</span>
      <span class="score-label">Promedio</span>
    </div>
  </div>

   <div class="calibration-badge" 
       [ngClass]="{'generoso': esGeneroso, 'estricto': esEstricto, 'calibrado': estaCalibrado}">
    @if (esGeneroso) {
      <span>\u2191 +{{ catador.desviacionRespectoPanel | number:'1.2-2' }} (Generoso)</span>
    }
    @if (esEstricto) {
      <span>\u2193 {{ catador.desviacionRespectoPanel | number:'1.2-2' }} (Estricto)</span>
    }
    @if (estaCalibrado) {
      <span>\u2713 Calibrado con el panel</span>
    }
  
  </div>

  <div class="cupper-stats">
    <div class="stat">
      <span class="stat-label">Muestras Evaluadas</span>
      <span class="stat-value">{{ catador.muestrasEvaluadas }} / {{ catador.muestrasAsignadas }}</span>
    </div>
    <div class="stat">
      <span class="stat-label">Estado</span>
      <span class="stat-value" [class.success]="catador.estado === 'enviado'">
        {{ catador.estado === 'enviado' ? 'Enviado' : 'Pendiente' }}
      </span>
    </div>
  </div>
</div>`, styles: ["/* src/app/shared/components/cupper-result-card/cupper-result-card.component.scss */\n.cupper-card {\n  background: #FFFFFF;\n  border: 1px solid #E2E8F0;\n  border-radius: 12px;\n  padding: 16px;\n  margin-bottom: 12px;\n}\n.cupper-header {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  margin-bottom: 12px;\n}\n.cupper-info {\n  display: flex;\n  align-items: center;\n  gap: 12px;\n}\n.avatar {\n  width: 40px;\n  height: 40px;\n  border-radius: 50%;\n  background: #F1F5F9;\n  color: #0F172B;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-weight: 700;\n  font-size: 16px;\n}\n.cupper-name {\n  margin: 0;\n  font-size: 14px;\n  font-weight: 700;\n  color: #0F172B;\n}\n.cupper-role {\n  font-size: 11px;\n  color: #62748E;\n}\n.cupper-score {\n  text-align: right;\n}\n.score-value {\n  display: block;\n  font-size: 20px;\n  font-weight: 800;\n  color: #0F172B;\n}\n.score-label {\n  font-size: 10px;\n  color: #62748E;\n  text-transform: uppercase;\n}\n.calibration-badge {\n  padding: 6px 12px;\n  border-radius: 6px;\n  font-size: 11px;\n  font-weight: 600;\n  text-align: center;\n  margin-bottom: 12px;\n}\n.calibration-badge.generoso {\n  background: #FEFCE8;\n  color: #A16207;\n}\n.calibration-badge.estricto {\n  background: #FFF7ED;\n  color: #C2410C;\n}\n.calibration-badge.calibrado {\n  background: #F0FDF4;\n  color: #15803D;\n}\n.cupper-stats {\n  display: flex;\n  justify-content: space-between;\n  border-top: 1px solid #F1F5F9;\n  padding-top: 12px;\n}\n.stat {\n  display: flex;\n  flex-direction: column;\n  gap: 4px;\n}\n.stat-label {\n  font-size: 10px;\n  color: #62748E;\n  text-transform: uppercase;\n}\n.stat-value {\n  font-size: 13px;\n  font-weight: 600;\n  color: #0F172B;\n}\n.stat-value.success {\n  color: #15803D;\n}\n/*# sourceMappingURL=cupper-result-card.component.css.map */\n"] }]
  }], null, { catador: [{
    type: Input
  }] });
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(CupperResultCardComponent, { className: "CupperResultCardComponent", filePath: "src/app/shared/components/cupper-result-card/cupper-result-card.component.ts", lineNumber: 12 });
})();

// src/app/pages/session/results/results.page.ts
var _c02 = ["reporteImprimible"];
var _c1 = (a0, a1) => ({ valor: a0, aguja: a1, etiqueta: "Promedio puntaje del panel" });
var _c2 = (a0, a1, a2) => ({ valor: a0, aguja: a1, etiqueta: a2 });
var _c3 = (a0, a1) => ({ r: a0, detalle: a1 });
var _c4 = (a0) => ({ r: a0, detalle: "Escala hed\xF3nica de 9 puntos: 1 = extremadamente baja \xB7 5 = neutral \xB7 9 = extremadamente alta." });
var _c5 = (a0) => ({ r: a0 });
var _c6 = (a0) => ({ actual: a0 });
var _c7 = (a0) => ({ r: a0, detalle: "Perfil sensorial objetivo: intensidad f\xEDsica de 0 (ausente) a 15 (muy intensa), sin juicio de calidad." });
var _forTrack0 = ($index, $item) => $item.clase;
var _forTrack1 = ($index, $item) => $item.cupperId;
var _forTrack2 = ($index, $item) => $item.numeroMuestra;
var _forTrack3 = ($index, $item) => $item.clave;
var _forTrack4 = ($index, $item) => $item.valor;
var _forTrack5 = ($index, $item) => $item.numeroMuestra + "-" + $index;
var _forTrack6 = ($index, $item) => $item.titulo;
var _forTrack7 = ($index, $item) => $item.etiqueta;
function ResultsPage_ng_template_13_For_5_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275namespaceSVG();
    \u0275\u0275element(0, "path");
  }
  if (rf & 2) {
    const a_r1 = ctx.$implicit;
    \u0275\u0275attribute("d", a_r1.d)("class", "rc-gauge__arc " + a_r1.clase);
  }
}
function ResultsPage_ng_template_13_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-card", 20)(1, "ion-card-content");
    \u0275\u0275namespaceSVG();
    \u0275\u0275elementStart(2, "svg", 21);
    \u0275\u0275pipe(3, "number");
    \u0275\u0275repeaterCreate(4, ResultsPage_ng_template_13_For_5_Template, 1, 2, ":svg:path", null, _forTrack0);
    \u0275\u0275elementStart(6, "text", 22);
    \u0275\u0275text(7, "50");
    \u0275\u0275elementEnd();
    \u0275\u0275element(8, "line", 23)(9, "circle", 24);
    \u0275\u0275elementEnd();
    \u0275\u0275namespaceHTML();
    \u0275\u0275elementStart(10, "p", 25);
    \u0275\u0275text(11);
    \u0275\u0275pipe(12, "number");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(13, "p", 26);
    \u0275\u0275text(14);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const valor_r2 = ctx.valor;
    const aguja_r3 = ctx.aguja;
    const etiqueta_r4 = ctx.etiqueta;
    const ctx_r4 = \u0275\u0275nextContext();
    \u0275\u0275advance(2);
    \u0275\u0275attribute("aria-label", etiqueta_r4 + ": " + \u0275\u0275pipeBind2(3, 9, valor_r2, "1.2-2"));
    \u0275\u0275advance(2);
    \u0275\u0275repeater(ctx_r4.arcosMedidor);
    \u0275\u0275advance(4);
    \u0275\u0275attribute("x1", ctx_r4.centroMedidor.x)("y1", ctx_r4.centroMedidor.y)("x2", aguja_r3.x)("y2", aguja_r3.y);
    \u0275\u0275advance();
    \u0275\u0275attribute("cx", ctx_r4.centroMedidor.x)("cy", ctx_r4.centroMedidor.y);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind2(12, 12, valor_r2, "1.2-2"));
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(etiqueta_r4);
  }
}
function ResultsPage_ng_template_15_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-card", 27)(1, "ion-card-content", 28)(2, "div", 29)(3, "p", 30);
    \u0275\u0275element(4, "ion-icon", 31);
    \u0275\u0275text(5);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "p", 32);
    \u0275\u0275text(7);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(8, "div", 33)(9, "div")(10, "strong");
    \u0275\u0275text(11);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(12, "span");
    \u0275\u0275text(13, "Muestras");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(14, "div")(15, "strong");
    \u0275\u0275text(16);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(17, "span");
    \u0275\u0275text(18, "Catadores");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(19, "div")(20, "strong");
    \u0275\u0275text(21);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(22, "span");
    \u0275\u0275text(23, "Formato");
    \u0275\u0275elementEnd()()()()();
  }
  if (rf & 2) {
    const r_r6 = ctx.r;
    const detalle_r7 = ctx.detalle;
    const ctx_r4 = \u0275\u0275nextContext();
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate1(" Sesi\xF3n cerrada \xB7 ", ctx_r4.porcentajeCompletado(), "% completada ");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(detalle_r7);
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(r_r6.totalMuestras);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(r_r6.catadores.length);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(ctx_r4.tituloFormato());
  }
}
function ResultsPage_ng_template_17_For_8_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-item")(1, "span", 37);
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "ion-label")(4, "h3", 38);
    \u0275\u0275text(5);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "p");
    \u0275\u0275text(7);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(8, "ion-badge", 39);
    \u0275\u0275text(9);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const c_r8 = ctx.$implicit;
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(c_r8.nombre.charAt(0).toUpperCase());
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(c_r8.nombre);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate3("", c_r8.esOrganizador ? "Organizador" : "Catador", " \xB7 ", c_r8.muestrasEvaluadas, " / ", c_r8.muestrasAsignadas, " muestras");
    \u0275\u0275advance();
    \u0275\u0275classProp("rx-chip--ok", c_r8.estado === "enviado")("rx-chip--pending", c_r8.estado !== "enviado");
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", c_r8.estado === "enviado" ? "Enviado" : "Pendiente", " ");
  }
}
function ResultsPage_ng_template_17_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-card", 27)(1, "ion-card-content")(2, "h2", 34);
    \u0275\u0275text(3, "Participaci\xF3n del panel");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "p", 35);
    \u0275\u0275text(5, "Fichas enviadas por cada catador.");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "ion-list", 36);
    \u0275\u0275repeaterCreate(7, ResultsPage_ng_template_17_For_8_Template, 10, 10, "ion-item", null, _forTrack1);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const r_r9 = ctx.r;
    \u0275\u0275advance(7);
    \u0275\u0275repeater(r_r9.catadores);
  }
}
function ResultsPage_ng_template_19_For_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-segment-button", 41)(1, "ion-label");
    \u0275\u0275text(2);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const n_r11 = ctx.$implicit;
    \u0275\u0275property("value", n_r11);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1("Muestra ", n_r11);
  }
}
function ResultsPage_ng_template_19_Template(rf, ctx) {
  if (rf & 1) {
    const _r10 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "ion-segment", 40);
    \u0275\u0275listener("ionChange", function ResultsPage_ng_template_19_Template_ion_segment_ionChange_0_listener($event) {
      \u0275\u0275restoreView(_r10);
      const ctx_r4 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r4.seleccionarMuestraDetalle($event.detail.value));
    });
    \u0275\u0275repeaterCreate(1, ResultsPage_ng_template_19_For_2_Template, 3, 2, "ion-segment-button", 41, \u0275\u0275repeaterTrackByIdentity);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const actual_r12 = ctx.actual;
    const ctx_r4 = \u0275\u0275nextContext();
    \u0275\u0275property("value", actual_r12);
    \u0275\u0275advance();
    \u0275\u0275repeater(ctx_r4.numerosMuestra());
  }
}
function ResultsPage_Conditional_23_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 16);
    \u0275\u0275element(1, "ion-spinner", 42);
    \u0275\u0275elementEnd();
  }
}
function ResultsPage_Conditional_24_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-icon", 44);
    \u0275\u0275elementStart(1, "h2");
    \u0275\u0275text(2, "Resultados reservados al organizador");
    \u0275\u0275elementEnd();
  }
}
function ResultsPage_Conditional_24_Template(rf, ctx) {
  if (rf & 1) {
    const _r13 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "section", 17);
    \u0275\u0275conditionalCreate(1, ResultsPage_Conditional_24_Conditional_1_Template, 3, 0);
    \u0275\u0275elementStart(2, "p");
    \u0275\u0275text(3);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "ion-button", 43);
    \u0275\u0275listener("click", function ResultsPage_Conditional_24_Template_ion_button_click_4_listener() {
      \u0275\u0275restoreView(_r13);
      const ctx_r4 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r4.volverAlPanel());
    });
    \u0275\u0275text(5, "Volver al panel");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r4 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r4.accesoDenegado() ? 1 : -1);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(ctx);
  }
}
function ResultsPage_Conditional_25_Conditional_0_ng_container_3_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_Conditional_25_Conditional_0_ng_container_5_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_Conditional_25_Conditional_0_ng_container_6_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_Conditional_25_Conditional_0_For_31_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-badge", 65);
    \u0275\u0275text(1, "en el medidor");
    \u0275\u0275elementEnd();
  }
}
function ResultsPage_Conditional_25_Conditional_0_For_31_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 66);
    \u0275\u0275text(1, "cerrada");
    \u0275\u0275elementEnd();
  }
}
function ResultsPage_Conditional_25_Conditional_0_For_31_Conditional_18_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 68);
    \u0275\u0275pipe(1, "number");
    \u0275\u0275text(2, "recortado");
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const fila_r16 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275property("title", \u0275\u0275interpolate1("Promedio simple: ", \u0275\u0275pipeBind2(1, 2, fila_r16.puntajePromedioSimple, "1.2-2")));
  }
}
function ResultsPage_Conditional_25_Conditional_0_For_31_Template(rf, ctx) {
  if (rf & 1) {
    const _r15 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "tr", 61);
    \u0275\u0275listener("click", function ResultsPage_Conditional_25_Conditional_0_For_31_Template_tr_click_0_listener() {
      const fila_r16 = \u0275\u0275restoreView(_r15).$implicit;
      const ctx_r4 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r4.seleccionarMuestraMedidor(fila_r16.numeroMuestra));
    })("keydown.enter", function ResultsPage_Conditional_25_Conditional_0_For_31_Template_tr_keydown_enter_0_listener() {
      const fila_r16 = \u0275\u0275restoreView(_r15).$implicit;
      const ctx_r4 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r4.seleccionarMuestraMedidor(fila_r16.numeroMuestra));
    })("keydown.space", function ResultsPage_Conditional_25_Conditional_0_For_31_Template_tr_keydown_space_0_listener($event) {
      const fila_r16 = \u0275\u0275restoreView(_r15).$implicit;
      const ctx_r4 = \u0275\u0275nextContext(3);
      $event.preventDefault();
      return \u0275\u0275resetView(ctx_r4.seleccionarMuestraMedidor(fila_r16.numeroMuestra));
    });
    \u0275\u0275elementStart(1, "td", 62);
    \u0275\u0275element(2, "ion-icon", 63);
    \u0275\u0275text(3);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "td")(5, "span", 64);
    \u0275\u0275text(6);
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(7, ResultsPage_Conditional_25_Conditional_0_For_31_Conditional_7_Template, 2, 0, "ion-badge", 65);
    \u0275\u0275conditionalCreate(8, ResultsPage_Conditional_25_Conditional_0_For_31_Conditional_8_Template, 2, 0, "span", 66);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(9, "td");
    \u0275\u0275text(10);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(11, "td", 58);
    \u0275\u0275text(12);
    \u0275\u0275pipe(13, "number");
    \u0275\u0275pipe(14, "number");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(15, "td", 67);
    \u0275\u0275text(16);
    \u0275\u0275pipe(17, "number");
    \u0275\u0275conditionalCreate(18, ResultsPage_Conditional_25_Conditional_0_For_31_Conditional_18_Template, 3, 5, "span", 68);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(19, "td")(20, "ion-badge", 69);
    \u0275\u0275text(21);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const fila_r16 = ctx.$implicit;
    const activa_r17 = fila_r16.numeroMuestra === \u0275\u0275nextContext(3).muestraEnMedidor()?.numeroMuestra;
    \u0275\u0275classProp("rc-ranking__row--active", activa_r17);
    \u0275\u0275attribute("aria-selected", activa_r17);
    \u0275\u0275advance(2);
    \u0275\u0275classMap("rc-medal rc-medal--" + (fila_r16.posicion <= 3 ? fila_r16.posicion : "n"));
    \u0275\u0275property("name", fila_r16.posicion === 1 ? "trophy-outline" : "medal-outline");
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" #", fila_r16.posicion, " ");
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate1("Muestra ", fila_r16.numeroMuestra);
    \u0275\u0275advance();
    \u0275\u0275conditional(activa_r17 ? 7 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(fila_r16.cerradaForzada ? 8 : -1);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate2("", fila_r16.evaluacionesRecibidas, " / ", fila_r16.evaluacionesEsperadas);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate2("", \u0275\u0275pipeBind2(13, 21, fila_r16.puntajeMin, "1.2-2"), " \u2013 ", \u0275\u0275pipeBind2(14, 24, fila_r16.puntajeMax, "1.2-2"));
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate1(" ", \u0275\u0275pipeBind2(17, 27, fila_r16.puntajePromedioPanel, "1.2-2"), " ");
    \u0275\u0275advance(2);
    \u0275\u0275conditional(fila_r16.recortado ? 18 : -1);
    \u0275\u0275advance(2);
    \u0275\u0275styleProp("--%NS%background", fila_r16.clasificacion.fondo)("--%NS%color", fila_r16.clasificacion.color);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", fila_r16.clasificacion.etiqueta, " ");
  }
}
function ResultsPage_Conditional_25_Conditional_0_ForEmpty_32_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "tr")(1, "td", 70);
    \u0275\u0275text(2, "Ninguna muestra recibi\xF3 fichas.");
    \u0275\u0275elementEnd()();
  }
}
function ResultsPage_Conditional_25_Conditional_0_Conditional_33_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 52);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r4 = \u0275\u0275nextContext(3);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" Sin fichas: ", ctx_r4.muestrasSinFichas().length, " muestra(s) cerradas sin evaluaciones. ");
  }
}
function ResultsPage_Conditional_25_Conditional_0_For_42_Template(rf, ctx) {
  if (rf & 1) {
    const _r18 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "ion-col", 54)(1, "button", 71);
    \u0275\u0275listener("click", function ResultsPage_Conditional_25_Conditional_0_For_42_Template_button_click_1_listener() {
      const catador_r19 = \u0275\u0275restoreView(_r18).$implicit;
      const ctx_r4 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r4.seleccionarCatadorReporte(catador_r19.cupperId));
    });
    \u0275\u0275element(2, "app-cupper-result-card", 72);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const catador_r19 = ctx.$implicit;
    const ctx_r4 = \u0275\u0275nextContext(3);
    \u0275\u0275advance();
    \u0275\u0275classProp("rc-cupper-select--active", catador_r19.cupperId === ctx_r4.catadorReporte()?.cupperId);
    \u0275\u0275attribute("aria-pressed", catador_r19.cupperId === ctx_r4.catadorReporte()?.cupperId);
    \u0275\u0275advance();
    \u0275\u0275property("catador", catador_r19);
  }
}
function ResultsPage_Conditional_25_Conditional_0_Conditional_43_Conditional_19_For_4_Conditional_10_For_9_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 84)(1, "span");
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "span", 89)(4, "strong");
    \u0275\u0275text(5);
    \u0275\u0275pipe(6, "number");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "strong");
    \u0275\u0275text(8);
    \u0275\u0275pipe(9, "number");
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const a_r21 = ctx.$implicit;
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(a_r21.etiqueta);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(a_r21.intensidad === null ? "\u2014" : \u0275\u0275pipeBind2(6, 3, a_r21.intensidad, "1.0-2"));
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(a_r21.calidad === null ? "\u2014" : \u0275\u0275pipeBind2(9, 6, a_r21.calidad, "1.0-2"));
  }
}
function ResultsPage_Conditional_25_Conditional_0_Conditional_43_Conditional_19_For_4_Conditional_10_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 88)(1, "span");
    \u0275\u0275text(2, "Atributo");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "span", 89)(4, "em");
    \u0275\u0275text(5, "Intensidad");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "em");
    \u0275\u0275text(7, "Calidad");
    \u0275\u0275elementEnd()()();
    \u0275\u0275repeaterCreate(8, ResultsPage_Conditional_25_Conditional_0_Conditional_43_Conditional_19_For_4_Conditional_10_For_9_Template, 10, 9, "div", 84, _forTrack3);
  }
  if (rf & 2) {
    const ficha_r22 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275advance(8);
    \u0275\u0275repeater(ficha_r22.atributos);
  }
}
function ResultsPage_Conditional_25_Conditional_0_Conditional_43_Conditional_19_For_4_Conditional_11_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 84)(1, "span");
    \u0275\u0275text(2, "Impresi\xF3n global");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "strong");
    \u0275\u0275text(4);
    \u0275\u0275pipe(5, "number");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ficha_r22 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind2(5, 1, ficha_r22.impresionGlobal, "1.0-2"));
  }
}
function ResultsPage_Conditional_25_Conditional_0_Conditional_43_Conditional_19_For_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r20 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "ion-accordion", 80)(1, "ion-item", 81)(2, "ion-label");
    \u0275\u0275text(3);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "ion-badge", 39);
    \u0275\u0275text(5);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "span", 82);
    \u0275\u0275text(7);
    \u0275\u0275pipe(8, "number");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(9, "div", 83);
    \u0275\u0275conditionalCreate(10, ResultsPage_Conditional_25_Conditional_0_Conditional_43_Conditional_19_For_4_Conditional_10_Template, 10, 0);
    \u0275\u0275conditionalCreate(11, ResultsPage_Conditional_25_Conditional_0_Conditional_43_Conditional_19_For_4_Conditional_11_Template, 6, 4, "div", 84);
    \u0275\u0275elementStart(12, "div", 84)(13, "span");
    \u0275\u0275text(14, "Tazas no uniformes");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(15, "strong");
    \u0275\u0275text(16);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(17, "div", 84)(18, "span");
    \u0275\u0275text(19, "Tazas defectuosas");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(20, "strong");
    \u0275\u0275text(21);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(22, "div", 85)(23, "span");
    \u0275\u0275text(24, "Puntaje final");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(25, "strong");
    \u0275\u0275text(26);
    \u0275\u0275pipe(27, "number");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(28, "div", 86)(29, "ion-button", 87);
    \u0275\u0275listener("click", function ResultsPage_Conditional_25_Conditional_0_Conditional_43_Conditional_19_For_4_Template_ion_button_click_29_listener() {
      const ficha_r22 = \u0275\u0275restoreView(_r20).$implicit;
      const cat_r23 = \u0275\u0275nextContext(2);
      const ctx_r4 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r4.abrirExportar({ numeroMuestra: ficha_r22.numeroMuestra, cupperId: cat_r23.cupperId }));
    });
    \u0275\u0275text(30, " Exportar PDF ");
    \u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    const ficha_r22 = ctx.$implicit;
    const cat_r23 = \u0275\u0275nextContext(2);
    \u0275\u0275property("value", cat_r23.cupperId + "-" + ficha_r22.numeroMuestra);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate1("Muestra ", ficha_r22.numeroMuestra);
    \u0275\u0275advance();
    \u0275\u0275styleProp("--%NS%background", ficha_r22.clasificacion.fondo)("--%NS%color", ficha_r22.clasificacion.color);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", ficha_r22.clasificacion.etiqueta, " ");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind2(8, 13, ficha_r22.puntaje, "1.2-2"));
    \u0275\u0275advance(3);
    \u0275\u0275conditional(ficha_r22.atributos.length > 0 ? 10 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(ficha_r22.impresionGlobal !== null ? 11 : -1);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(ficha_r22.tazasNoUniformes);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(ficha_r22.tazasDefectuosas);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind2(27, 16, ficha_r22.puntaje, "1.2-2"));
  }
}
function ResultsPage_Conditional_25_Conditional_0_Conditional_43_Conditional_19_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 35);
    \u0275\u0275text(1, "Haz clic en una ficha para ver su detalle.");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(2, "ion-accordion-group", 79);
    \u0275\u0275repeaterCreate(3, ResultsPage_Conditional_25_Conditional_0_Conditional_43_Conditional_19_For_4_Template, 31, 19, "ion-accordion", 80, _forTrack2);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r4 = \u0275\u0275nextContext(4);
    \u0275\u0275advance(2);
    \u0275\u0275property("multiple", false);
    \u0275\u0275advance();
    \u0275\u0275repeater(ctx_r4.fichasReporte());
  }
}
function ResultsPage_Conditional_25_Conditional_0_Conditional_43_Conditional_20_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 35);
    \u0275\u0275text(1, "Este catador a\xFAn no tiene fichas enviadas.");
    \u0275\u0275elementEnd();
  }
}
function ResultsPage_Conditional_25_Conditional_0_Conditional_43_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-card", 27)(1, "ion-card-content")(2, "h2", 34);
    \u0275\u0275text(3, "Reporte de sesi\xF3n individual");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "div", 73)(5, "div", 74)(6, "span", 75);
    \u0275\u0275text(7);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "div")(9, "p", 76);
    \u0275\u0275text(10);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(11, "p", 77);
    \u0275\u0275text(12);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(13, "div", 78)(14, "strong");
    \u0275\u0275text(15);
    \u0275\u0275pipe(16, "number");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(17, "span");
    \u0275\u0275text(18, "Promedio");
    \u0275\u0275elementEnd()()();
    \u0275\u0275conditionalCreate(19, ResultsPage_Conditional_25_Conditional_0_Conditional_43_Conditional_19_Template, 5, 1)(20, ResultsPage_Conditional_25_Conditional_0_Conditional_43_Conditional_20_Template, 2, 0, "p", 35);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const cat_r23 = ctx;
    const ctx_r4 = \u0275\u0275nextContext(3);
    \u0275\u0275advance(7);
    \u0275\u0275textInterpolate(cat_r23.nombre.charAt(0).toUpperCase());
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(cat_r23.nombre);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate3(" ", cat_r23.muestrasEvaluadas, " de ", cat_r23.muestrasAsignadas, " muestras evaluadas \xB7 estado ", cat_r23.estado, " ");
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind2(16, 7, cat_r23.puntajePromedio, "1.2-2"));
    \u0275\u0275advance(4);
    \u0275\u0275conditional(ctx_r4.fichasReporte().length > 0 ? 19 : 20);
  }
}
function ResultsPage_Conditional_25_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r14 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "ion-grid", 45)(1, "ion-row")(2, "ion-col", 46);
    \u0275\u0275template(3, ResultsPage_Conditional_25_Conditional_0_ng_container_3_Template, 1, 0, "ng-container", 47);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "ion-col", 46);
    \u0275\u0275template(5, ResultsPage_Conditional_25_Conditional_0_ng_container_5_Template, 1, 0, "ng-container", 47);
    \u0275\u0275elementEnd()()();
    \u0275\u0275template(6, ResultsPage_Conditional_25_Conditional_0_ng_container_6_Template, 1, 0, "ng-container", 47);
    \u0275\u0275elementStart(7, "ion-card", 27)(8, "ion-card-content")(9, "h2", 34);
    \u0275\u0275text(10, "Ranking \u2014 promedio del panel");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(11, "p", 35);
    \u0275\u0275text(12, "Haz clic en una muestra para ver su promedio del panel en el medidor.");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(13, "div", 48)(14, "table", 49)(15, "thead")(16, "tr")(17, "th", 50);
    \u0275\u0275text(18, "#");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(19, "th", 50);
    \u0275\u0275text(20, "Muestra");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(21, "th", 50);
    \u0275\u0275text(22, "Fichas");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(23, "th", 50);
    \u0275\u0275text(24, "M\xEDn \u2013 M\xE1x");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(25, "th", 50);
    \u0275\u0275text(26, "Puntaje panel");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(27, "th", 50);
    \u0275\u0275text(28, "Clasificaci\xF3n");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(29, "tbody");
    \u0275\u0275repeaterCreate(30, ResultsPage_Conditional_25_Conditional_0_For_31_Template, 22, 30, "tr", 51, _forTrack2, false, ResultsPage_Conditional_25_Conditional_0_ForEmpty_32_Template, 3, 0, "tr");
    \u0275\u0275elementEnd()()();
    \u0275\u0275conditionalCreate(33, ResultsPage_Conditional_25_Conditional_0_Conditional_33_Template, 2, 1, "p", 52);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(34, "section", 53)(35, "h2", 34);
    \u0275\u0275text(36, "An\xE1lisis de catadores");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(37, "p", 35);
    \u0275\u0275text(38, "Participaci\xF3n y consistencia individual dentro del panel. Selecciona un catador para ver su reporte.");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(39, "ion-grid", 45)(40, "ion-row");
    \u0275\u0275repeaterCreate(41, ResultsPage_Conditional_25_Conditional_0_For_42_Template, 3, 4, "ion-col", 54, _forTrack1);
    \u0275\u0275elementEnd()()();
    \u0275\u0275conditionalCreate(43, ResultsPage_Conditional_25_Conditional_0_Conditional_43_Template, 21, 10, "ion-card", 27);
    \u0275\u0275elementStart(44, "section", 55)(45, "h2", 56);
    \u0275\u0275text(46, "F\xF3rmula CVA aplicada");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(47, "p", 57);
    \u0275\u0275text(48, "S = 0.65625 \xD7 \u03A3h\u1D62 + 52.75 \u2212 2u \u2212 4d");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(49, "p", 58);
    \u0275\u0275text(50, " El consolidado descarta el valor m\xE1s alto y el m\xE1s bajo por muestra cuando hay 5 o m\xE1s fichas. ");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(51, "div", 59)(52, "ion-button", 43);
    \u0275\u0275listener("click", function ResultsPage_Conditional_25_Conditional_0_Template_ion_button_click_52_listener() {
      \u0275\u0275restoreView(_r14);
      const ctx_r4 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r4.volverAlPanel());
    });
    \u0275\u0275text(53, "Volver al panel");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(54, "ion-button", 60);
    \u0275\u0275listener("click", function ResultsPage_Conditional_25_Conditional_0_Template_ion_button_click_54_listener() {
      \u0275\u0275restoreView(_r14);
      const ctx_r4 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r4.abrirExportar());
    });
    \u0275\u0275element(55, "ion-icon", 13);
    \u0275\u0275text(56, " Exportar a PDF (Formato SCA) ");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    let tmp_16_0;
    const r_r24 = \u0275\u0275nextContext();
    const ctx_r4 = \u0275\u0275nextContext();
    const medidor_r25 = \u0275\u0275reference(14);
    const metaSesion_r26 = \u0275\u0275reference(16);
    \u0275\u0275advance(3);
    \u0275\u0275property("ngTemplateOutlet", medidor_r25)("ngTemplateOutletContext", \u0275\u0275pureFunction2(10, _c1, ctx_r4.promedioPanel(), ctx_r4.agujaPanel()));
    \u0275\u0275advance(2);
    \u0275\u0275property("ngTemplateOutlet", medidor_r25)("ngTemplateOutletContext", \u0275\u0275pureFunction3(13, _c2, ctx_r4.muestraEnMedidor()?.puntajePromedioPanel ?? 0, ctx_r4.agujaMuestra(), "Promedio del panel por muestra \xB7 Muestra " + (ctx_r4.muestraEnMedidor()?.numeroMuestra ?? "\u2014")));
    \u0275\u0275advance();
    \u0275\u0275property("ngTemplateOutlet", metaSesion_r26)("ngTemplateOutletContext", \u0275\u0275pureFunction2(17, _c3, r_r24, ctx_r4.hayRecorte() ? "Consolidaci\xF3n mediante promedio recortado SCA (se descartan m\xE1ximo y m\xEDnimo con 5 o m\xE1s catadores)." : "Consolidaci\xF3n mediante promedio simple (menos de 5 fichas por muestra)."));
    \u0275\u0275advance(24);
    \u0275\u0275repeater(ctx_r4.ranking());
    \u0275\u0275advance(3);
    \u0275\u0275conditional(ctx_r4.muestrasSinFichas().length > 0 ? 33 : -1);
    \u0275\u0275advance(8);
    \u0275\u0275repeater(r_r24.catadores);
    \u0275\u0275advance(2);
    \u0275\u0275conditional((tmp_16_0 = ctx_r4.catadorReporte()) ? 43 : -1, tmp_16_0);
    \u0275\u0275advance(11);
    \u0275\u0275property("disabled", ctx_r4.imprimiendo());
  }
}
function ResultsPage_Conditional_25_Conditional_1_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_Conditional_25_Conditional_1_For_23_Template(rf, ctx) {
  if (rf & 1) {
    const _r28 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "tr", 61);
    \u0275\u0275listener("click", function ResultsPage_Conditional_25_Conditional_1_For_23_Template_tr_click_0_listener() {
      const fila_r29 = \u0275\u0275restoreView(_r28).$implicit;
      const ctx_r4 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r4.seleccionarMuestraDetalle(fila_r29.numeroMuestra));
    })("keydown.enter", function ResultsPage_Conditional_25_Conditional_1_For_23_Template_tr_keydown_enter_0_listener() {
      const fila_r29 = \u0275\u0275restoreView(_r28).$implicit;
      const ctx_r4 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r4.seleccionarMuestraDetalle(fila_r29.numeroMuestra));
    })("keydown.space", function ResultsPage_Conditional_25_Conditional_1_For_23_Template_tr_keydown_space_0_listener($event) {
      const fila_r29 = \u0275\u0275restoreView(_r28).$implicit;
      const ctx_r4 = \u0275\u0275nextContext(3);
      $event.preventDefault();
      return \u0275\u0275resetView(ctx_r4.seleccionarMuestraDetalle(fila_r29.numeroMuestra));
    });
    \u0275\u0275elementStart(1, "td", 62);
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "td")(4, "span", 64);
    \u0275\u0275text(5);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(6, "td");
    \u0275\u0275text(7);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "td", 91)(9, "div", 92)(10, "div", 93);
    \u0275\u0275element(11, "i");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(12, "strong", 67);
    \u0275\u0275text(13);
    \u0275\u0275pipe(14, "number");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(15, "td")(16, "ion-badge", 94);
    \u0275\u0275text(17);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const fila_r29 = ctx.$implicit;
    const activa_r30 = fila_r29.numeroMuestra === \u0275\u0275nextContext(3).hedonicoSeleccionado()?.numeroMuestra;
    \u0275\u0275classProp("rc-ranking__row--active", activa_r30);
    \u0275\u0275attribute("aria-selected", activa_r30);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(fila_r29.posicion ? "#" + fila_r29.posicion : "\u2014");
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate1("Muestra ", fila_r29.numeroMuestra);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(fila_r29.totalVotos);
    \u0275\u0275advance(4);
    \u0275\u0275styleProp("width", (fila_r29.promedio ?? 0) / 9 * 100, "%");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(fila_r29.promedio === null ? "\u2014" : \u0275\u0275pipeBind2(14, 10, fila_r29.promedio, "1.2-2"));
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(fila_r29.etiqueta);
  }
}
function ResultsPage_Conditional_25_Conditional_1_ForEmpty_24_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "tr")(1, "td", 95);
    \u0275\u0275text(2, "La sesi\xF3n no tiene muestras.");
    \u0275\u0275elementEnd()();
  }
}
function ResultsPage_Conditional_25_Conditional_1_Conditional_25_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_Conditional_25_Conditional_1_Conditional_25_Conditional_10_For_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "li", 101)(1, "span", 102);
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "span", 103);
    \u0275\u0275text(4);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "div", 93);
    \u0275\u0275element(6, "i");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "strong", 104);
    \u0275\u0275text(8);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const d_r31 = ctx.$implicit;
    \u0275\u0275classProp("ra-dist__row--empty", d_r31.votos === 0);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(d_r31.valor);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(d_r31.etiqueta);
    \u0275\u0275advance(2);
    \u0275\u0275styleProp("width", d_r31.porcentaje, "%");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(d_r31.votos);
  }
}
function ResultsPage_Conditional_25_Conditional_1_Conditional_25_Conditional_10_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ul", 98);
    \u0275\u0275repeaterCreate(1, ResultsPage_Conditional_25_Conditional_1_Conditional_25_Conditional_10_For_2_Template, 9, 7, "li", 99, _forTrack4);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "p", 100);
    \u0275\u0275text(4);
    \u0275\u0275elementStart(5, "strong");
    \u0275\u0275text(6);
    \u0275\u0275pipe(7, "number");
    \u0275\u0275elementEnd();
    \u0275\u0275text(8);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const sel_r32 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275repeater(sel_r32.distribucion);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate1(" ", sel_r32.totalVotos, " voto(s) \xB7 promedio ");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind2(7, 3, sel_r32.promedio, "1.2-2"));
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1(" (", sel_r32.etiqueta, ") ");
  }
}
function ResultsPage_Conditional_25_Conditional_1_Conditional_25_Conditional_11_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 35);
    \u0275\u0275text(1, "Esta muestra no recibi\xF3 votos de Impresi\xF3n Global.");
    \u0275\u0275elementEnd();
  }
}
function ResultsPage_Conditional_25_Conditional_1_Conditional_25_For_21_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "li", 97)(1, "span", 105);
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "div", 93);
    \u0275\u0275element(4, "i");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "strong", 106);
    \u0275\u0275text(6);
    \u0275\u0275pipe(7, "number");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const a_r33 = ctx.$implicit;
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(a_r33.etiqueta);
    \u0275\u0275advance(2);
    \u0275\u0275styleProp("width", a_r33.porcentaje, "%");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(a_r33.valor === null ? "\u2014" : \u0275\u0275pipeBind2(7, 4, a_r33.valor, "1.1-1"));
  }
}
function ResultsPage_Conditional_25_Conditional_1_Conditional_25_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275template(0, ResultsPage_Conditional_25_Conditional_1_Conditional_25_ng_container_0_Template, 1, 0, "ng-container", 47);
    \u0275\u0275elementStart(1, "ion-grid", 45)(2, "ion-row")(3, "ion-col", 46)(4, "ion-card", 27)(5, "ion-card-content")(6, "h2", 34);
    \u0275\u0275text(7);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "p", 35);
    \u0275\u0275text(9, "Cu\xE1ntos catadores eligieron cada punto de la escala (Impresi\xF3n Global).");
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(10, ResultsPage_Conditional_25_Conditional_1_Conditional_25_Conditional_10_Template, 9, 6)(11, ResultsPage_Conditional_25_Conditional_1_Conditional_25_Conditional_11_Template, 2, 0, "p", 35);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(12, "ion-col", 46)(13, "ion-card", 27)(14, "ion-card-content")(15, "h2", 34);
    \u0275\u0275text(16);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(17, "p", 35);
    \u0275\u0275text(18, "Promedio del panel en la escala hed\xF3nica (1 a 9).");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(19, "ul", 96);
    \u0275\u0275repeaterCreate(20, ResultsPage_Conditional_25_Conditional_1_Conditional_25_For_21_Template, 8, 7, "li", 97, _forTrack3);
    \u0275\u0275elementEnd()()()()()();
  }
  if (rf & 2) {
    const sel_r32 = ctx;
    \u0275\u0275nextContext(3);
    const selectorMuestra_r34 = \u0275\u0275reference(20);
    \u0275\u0275property("ngTemplateOutlet", selectorMuestra_r34)("ngTemplateOutletContext", \u0275\u0275pureFunction1(5, _c6, sel_r32.numeroMuestra));
    \u0275\u0275advance(7);
    \u0275\u0275textInterpolate1("Distribuci\xF3n de votos \xB7 Muestra ", sel_r32.numeroMuestra);
    \u0275\u0275advance(3);
    \u0275\u0275conditional(sel_r32.totalVotos > 0 ? 10 : 11);
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate1("Calidad por atributo \xB7 Muestra ", sel_r32.numeroMuestra);
    \u0275\u0275advance(4);
    \u0275\u0275repeater(sel_r32.atributos);
  }
}
function ResultsPage_Conditional_25_Conditional_1_ng_container_26_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_Conditional_25_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r27 = \u0275\u0275getCurrentView();
    \u0275\u0275template(0, ResultsPage_Conditional_25_Conditional_1_ng_container_0_Template, 1, 0, "ng-container", 47);
    \u0275\u0275elementStart(1, "ion-card", 27)(2, "ion-card-content")(3, "h2", 34);
    \u0275\u0275text(4, "Agrado del panel \u2014 escala hed\xF3nica (1 a 9)");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "p", 35);
    \u0275\u0275text(6, "Promedio de la Impresi\xF3n Global por muestra. Haz clic en una muestra para ver sus votos.");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "div", 48)(8, "table", 49)(9, "thead")(10, "tr")(11, "th", 50);
    \u0275\u0275text(12, "#");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(13, "th", 50);
    \u0275\u0275text(14, "Muestra");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(15, "th", 50);
    \u0275\u0275text(16, "Votos");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(17, "th", 90);
    \u0275\u0275text(18, "Promedio hed\xF3nico");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(19, "th", 50);
    \u0275\u0275text(20, "Valoraci\xF3n");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(21, "tbody");
    \u0275\u0275repeaterCreate(22, ResultsPage_Conditional_25_Conditional_1_For_23_Template, 18, 13, "tr", 51, _forTrack2, false, ResultsPage_Conditional_25_Conditional_1_ForEmpty_24_Template, 3, 0, "tr");
    \u0275\u0275elementEnd()()()()();
    \u0275\u0275conditionalCreate(25, ResultsPage_Conditional_25_Conditional_1_Conditional_25_Template, 22, 7);
    \u0275\u0275template(26, ResultsPage_Conditional_25_Conditional_1_ng_container_26_Template, 1, 0, "ng-container", 47);
    \u0275\u0275elementStart(27, "div", 59)(28, "ion-button", 43);
    \u0275\u0275listener("click", function ResultsPage_Conditional_25_Conditional_1_Template_ion_button_click_28_listener() {
      \u0275\u0275restoreView(_r27);
      const ctx_r4 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r4.volverAlPanel());
    });
    \u0275\u0275text(29, "Volver al panel");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(30, "ion-button", 60);
    \u0275\u0275listener("click", function ResultsPage_Conditional_25_Conditional_1_Template_ion_button_click_30_listener() {
      \u0275\u0275restoreView(_r27);
      const ctx_r4 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r4.exportarPDF());
    });
    \u0275\u0275element(31, "ion-icon", 13);
    \u0275\u0275text(32, " Exportar a PDF (Formato SCA) ");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    let tmp_10_0;
    const r_r24 = \u0275\u0275nextContext();
    const ctx_r4 = \u0275\u0275nextContext();
    const metaSesion_r26 = \u0275\u0275reference(16);
    const participacion_r35 = \u0275\u0275reference(18);
    \u0275\u0275property("ngTemplateOutlet", metaSesion_r26)("ngTemplateOutletContext", \u0275\u0275pureFunction1(7, _c4, r_r24));
    \u0275\u0275advance(22);
    \u0275\u0275repeater(ctx_r4.resultadosHedonicos());
    \u0275\u0275advance(3);
    \u0275\u0275conditional((tmp_10_0 = ctx_r4.hedonicoSeleccionado()) ? 25 : -1, tmp_10_0);
    \u0275\u0275advance();
    \u0275\u0275property("ngTemplateOutlet", participacion_r35)("ngTemplateOutletContext", \u0275\u0275pureFunction1(9, _c5, r_r24));
    \u0275\u0275advance(4);
    \u0275\u0275property("disabled", ctx_r4.imprimiendo());
  }
}
function ResultsPage_Conditional_25_Conditional_2_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_Conditional_25_Conditional_2_Conditional_1_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_Conditional_25_Conditional_2_Conditional_1_For_23_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "li", 97)(1, "span", 105);
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "div", 113);
    \u0275\u0275element(4, "i");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "strong", 106);
    \u0275\u0275text(6);
    \u0275\u0275pipe(7, "number");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const a_r37 = ctx.$implicit;
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(a_r37.etiqueta);
    \u0275\u0275advance(2);
    \u0275\u0275styleProp("width", a_r37.porcentaje, "%");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(a_r37.valor === null ? "\u2014" : \u0275\u0275pipeBind2(7, 4, a_r37.valor, "1.1-1"));
  }
}
function ResultsPage_Conditional_25_Conditional_2_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275template(0, ResultsPage_Conditional_25_Conditional_2_Conditional_1_ng_container_0_Template, 1, 0, "ng-container", 47);
    \u0275\u0275elementStart(1, "ion-card", 27)(2, "ion-card-content")(3, "div", 109)(4, "div")(5, "h2", 34);
    \u0275\u0275text(6);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "p", 35);
    \u0275\u0275text(8);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(9, "div", 110);
    \u0275\u0275element(10, "span");
    \u0275\u0275elementStart(11, "span", 111)(12, "em");
    \u0275\u0275text(13, "0");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(14, "em");
    \u0275\u0275text(15, "5");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(16, "em");
    \u0275\u0275text(17, "10");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(18, "em");
    \u0275\u0275text(19, "15");
    \u0275\u0275elementEnd()();
    \u0275\u0275element(20, "span");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(21, "ul", 112);
    \u0275\u0275repeaterCreate(22, ResultsPage_Conditional_25_Conditional_2_Conditional_1_For_23_Template, 8, 7, "li", 97, _forTrack3);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const perfil_r38 = ctx;
    \u0275\u0275nextContext(3);
    const selectorMuestra_r34 = \u0275\u0275reference(20);
    \u0275\u0275property("ngTemplateOutlet", selectorMuestra_r34)("ngTemplateOutletContext", \u0275\u0275pureFunction1(4, _c6, perfil_r38.numeroMuestra));
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate1("Perfil de intensidad \xB7 Muestra ", perfil_r38.numeroMuestra);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1("Promedio del panel por atributo (", perfil_r38.fichas, " ficha(s)).");
    \u0275\u0275advance(14);
    \u0275\u0275repeater(perfil_r38.atributos);
  }
}
function ResultsPage_Conditional_25_Conditional_2_For_15_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "th", 108);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const p_r39 = ctx.$implicit;
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1("M", p_r39.numeroMuestra);
  }
}
function ResultsPage_Conditional_25_Conditional_2_For_18_For_4_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "td", 115)(1, "span", 116);
    \u0275\u0275text(2);
    \u0275\u0275pipe(3, "number");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const p_r40 = ctx.$implicit;
    const \u0275$index_699_r41 = \u0275\u0275nextContext().$index;
    \u0275\u0275advance();
    \u0275\u0275styleProp("--%NS%rd-alpha", p_r40.atributos[\u0275$index_699_r41].porcentaje / 100);
    \u0275\u0275classProp("rd-cell--dark", p_r40.atributos[\u0275$index_699_r41].porcentaje > 55);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", p_r40.atributos[\u0275$index_699_r41].valor === null ? "\u2014" : \u0275\u0275pipeBind2(3, 5, p_r40.atributos[\u0275$index_699_r41].valor, "1.1-1"), " ");
  }
}
function ResultsPage_Conditional_25_Conditional_2_For_18_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "tr")(1, "th", 114);
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
    \u0275\u0275repeaterCreate(3, ResultsPage_Conditional_25_Conditional_2_For_18_For_4_Template, 4, 8, "td", 115, _forTrack2);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const atr_r42 = ctx.$implicit;
    const ctx_r4 = \u0275\u0275nextContext(3);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(atr_r42.etiqueta);
    \u0275\u0275advance();
    \u0275\u0275repeater(ctx_r4.perfilesDescriptivos());
  }
}
function ResultsPage_Conditional_25_Conditional_2_ng_container_19_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementContainer(0);
  }
}
function ResultsPage_Conditional_25_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r36 = \u0275\u0275getCurrentView();
    \u0275\u0275template(0, ResultsPage_Conditional_25_Conditional_2_ng_container_0_Template, 1, 0, "ng-container", 47);
    \u0275\u0275conditionalCreate(1, ResultsPage_Conditional_25_Conditional_2_Conditional_1_Template, 24, 6);
    \u0275\u0275elementStart(2, "ion-card", 27)(3, "ion-card-content")(4, "h2", 34);
    \u0275\u0275text(5, "Comparativa de intensidades");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "p", 35);
    \u0275\u0275text(7, "Promedio del panel (0\u201315). El tono de cada celda es proporcional a la intensidad.");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "div", 48)(9, "table", 107)(10, "thead")(11, "tr")(12, "th", 50);
    \u0275\u0275text(13, "Atributo");
    \u0275\u0275elementEnd();
    \u0275\u0275repeaterCreate(14, ResultsPage_Conditional_25_Conditional_2_For_15_Template, 2, 1, "th", 108, _forTrack2);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(16, "tbody");
    \u0275\u0275repeaterCreate(17, ResultsPage_Conditional_25_Conditional_2_For_18_Template, 5, 1, "tr", null, _forTrack3);
    \u0275\u0275elementEnd()()()()();
    \u0275\u0275template(19, ResultsPage_Conditional_25_Conditional_2_ng_container_19_Template, 1, 0, "ng-container", 47);
    \u0275\u0275elementStart(20, "div", 59)(21, "ion-button", 43);
    \u0275\u0275listener("click", function ResultsPage_Conditional_25_Conditional_2_Template_ion_button_click_21_listener() {
      \u0275\u0275restoreView(_r36);
      const ctx_r4 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r4.volverAlPanel());
    });
    \u0275\u0275text(22, "Volver al panel");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(23, "ion-button", 60);
    \u0275\u0275listener("click", function ResultsPage_Conditional_25_Conditional_2_Template_ion_button_click_23_listener() {
      \u0275\u0275restoreView(_r36);
      const ctx_r4 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r4.exportarPDF());
    });
    \u0275\u0275element(24, "ion-icon", 13);
    \u0275\u0275text(25, " Exportar perfil a PDF ");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    let tmp_9_0;
    const r_r24 = \u0275\u0275nextContext();
    const ctx_r4 = \u0275\u0275nextContext();
    const metaSesion_r26 = \u0275\u0275reference(16);
    const participacion_r35 = \u0275\u0275reference(18);
    \u0275\u0275property("ngTemplateOutlet", metaSesion_r26)("ngTemplateOutletContext", \u0275\u0275pureFunction1(6, _c7, r_r24));
    \u0275\u0275advance();
    \u0275\u0275conditional((tmp_9_0 = ctx_r4.perfilSeleccionado()) ? 1 : -1, tmp_9_0);
    \u0275\u0275advance(13);
    \u0275\u0275repeater(ctx_r4.perfilesDescriptivos());
    \u0275\u0275advance(3);
    \u0275\u0275repeater(ctx_r4.atributosCva);
    \u0275\u0275advance(2);
    \u0275\u0275property("ngTemplateOutlet", participacion_r35)("ngTemplateOutletContext", \u0275\u0275pureFunction1(8, _c5, r_r24));
    \u0275\u0275advance(4);
    \u0275\u0275property("disabled", ctx_r4.imprimiendo());
  }
}
function ResultsPage_Conditional_25_Conditional_3_For_1_Conditional_9_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275text(0);
  }
  if (rf & 2) {
    const ficha_r44 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275textInterpolate1(" Registrada por ", ficha_r44.registradaPor, " ");
  }
}
function ResultsPage_Conditional_25_Conditional_3_For_1_Conditional_10_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275text(0);
    \u0275\u0275pipe(1, "date");
  }
  if (rf & 2) {
    const ficha_r44 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275textInterpolate1(" \xB7 ", \u0275\u0275pipeBind2(1, 1, ficha_r44.registradaEn, "mediumDate"), " ");
  }
}
function ResultsPage_Conditional_25_Conditional_3_For_1_For_14_For_6_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "dt");
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(2, "dd");
    \u0275\u0275text(3);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const campo_r45 = ctx.$implicit;
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(campo_r45.etiqueta);
    \u0275\u0275advance();
    \u0275\u0275classProp("re-dl__empty", campo_r45.valor === "\u2014");
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(campo_r45.valor);
  }
}
function ResultsPage_Conditional_25_Conditional_3_For_1_For_14_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-col", 121)(1, "section", 122)(2, "h3", 56);
    \u0275\u0275text(3);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "dl", 124);
    \u0275\u0275repeaterCreate(5, ResultsPage_Conditional_25_Conditional_3_For_1_For_14_For_6_Template, 4, 4, null, null, _forTrack7);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const seccion_r46 = ctx.$implicit;
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(seccion_r46.titulo);
    \u0275\u0275advance(2);
    \u0275\u0275repeater(seccion_r46.campos);
  }
}
function ResultsPage_Conditional_25_Conditional_3_For_1_Conditional_18_For_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-badge", 125);
    \u0275\u0275element(1, "ion-icon", 126);
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const c_r47 = ctx.$implicit;
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1(" ", c_r47);
  }
}
function ResultsPage_Conditional_25_Conditional_3_For_1_Conditional_18_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 123);
    \u0275\u0275repeaterCreate(1, ResultsPage_Conditional_25_Conditional_3_For_1_Conditional_18_For_2_Template, 3, 1, "ion-badge", 125, \u0275\u0275repeaterTrackByIdentity);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ficha_r44 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275advance();
    \u0275\u0275repeater(ficha_r44.certificaciones);
  }
}
function ResultsPage_Conditional_25_Conditional_3_For_1_Conditional_19_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 35);
    \u0275\u0275text(1, "Sin certificaciones registradas.");
    \u0275\u0275elementEnd();
  }
}
function ResultsPage_Conditional_25_Conditional_3_For_1_Conditional_20_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "section", 122)(1, "h3", 56);
    \u0275\u0275text(2, "Notas");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "p", 127);
    \u0275\u0275text(4);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ficha_r44 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(ficha_r44.notas);
  }
}
function ResultsPage_Conditional_25_Conditional_3_For_1_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-card", 117)(1, "ion-card-content")(2, "div", 118)(3, "div", 119);
    \u0275\u0275element(4, "ion-icon", 120);
    \u0275\u0275elementStart(5, "div")(6, "h2");
    \u0275\u0275text(7);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "p", 58);
    \u0275\u0275conditionalCreate(9, ResultsPage_Conditional_25_Conditional_3_For_1_Conditional_9_Template, 1, 1);
    \u0275\u0275conditionalCreate(10, ResultsPage_Conditional_25_Conditional_3_For_1_Conditional_10_Template, 2, 4);
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(11, "ion-grid", 45)(12, "ion-row");
    \u0275\u0275repeaterCreate(13, ResultsPage_Conditional_25_Conditional_3_For_1_For_14_Template, 7, 1, "ion-col", 121, _forTrack6);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(15, "section", 122)(16, "h3", 56);
    \u0275\u0275text(17, "Certificaciones");
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(18, ResultsPage_Conditional_25_Conditional_3_For_1_Conditional_18_Template, 3, 0, "div", 123)(19, ResultsPage_Conditional_25_Conditional_3_For_1_Conditional_19_Template, 2, 0, "p", 35);
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(20, ResultsPage_Conditional_25_Conditional_3_For_1_Conditional_20_Template, 5, 1, "section", 122);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ficha_r44 = ctx.$implicit;
    \u0275\u0275advance(7);
    \u0275\u0275textInterpolate1("Ficha t\xE9cnica del caf\xE9 \xB7 Muestra ", ficha_r44.numeroMuestra);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ficha_r44.registradaPor ? 9 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(ficha_r44.registradaEn ? 10 : -1);
    \u0275\u0275advance(3);
    \u0275\u0275repeater(ficha_r44.secciones);
    \u0275\u0275advance(5);
    \u0275\u0275conditional(ficha_r44.certificaciones.length > 0 ? 18 : 19);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ficha_r44.notas ? 20 : -1);
  }
}
function ResultsPage_Conditional_25_Conditional_3_ForEmpty_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-card", 27)(1, "ion-card-content", 128);
    \u0275\u0275element(2, "ion-icon", 129);
    \u0275\u0275elementStart(3, "p");
    \u0275\u0275text(4, "Esta sesi\xF3n no tiene fichas t\xE9cnicas registradas.");
    \u0275\u0275elementEnd()()();
  }
}
function ResultsPage_Conditional_25_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r43 = \u0275\u0275getCurrentView();
    \u0275\u0275repeaterCreate(0, ResultsPage_Conditional_25_Conditional_3_For_1_Template, 21, 5, "ion-card", 117, _forTrack5, false, ResultsPage_Conditional_25_Conditional_3_ForEmpty_2_Template, 5, 0, "ion-card", 27);
    \u0275\u0275elementStart(3, "div", 59)(4, "ion-button", 43);
    \u0275\u0275listener("click", function ResultsPage_Conditional_25_Conditional_3_Template_ion_button_click_4_listener() {
      \u0275\u0275restoreView(_r43);
      const ctx_r4 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r4.volverAlPanel());
    });
    \u0275\u0275text(5, "Volver al panel");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "ion-button", 60);
    \u0275\u0275listener("click", function ResultsPage_Conditional_25_Conditional_3_Template_ion_button_click_6_listener() {
      \u0275\u0275restoreView(_r43);
      const ctx_r4 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r4.exportarPDF());
    });
    \u0275\u0275element(7, "ion-icon", 13);
    \u0275\u0275text(8, " Exportar Ficha T\xE9cnica a PDF ");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r4 = \u0275\u0275nextContext(2);
    \u0275\u0275repeater(ctx_r4.fichasTecnicas());
    \u0275\u0275advance(6);
    \u0275\u0275property("disabled", ctx_r4.imprimiendo() || ctx_r4.fichasTecnicas().length === 0);
  }
}
function ResultsPage_Conditional_25_Conditional_4_For_44_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-icon", 135);
  }
}
function ResultsPage_Conditional_25_Conditional_4_For_44_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 66);
    \u0275\u0275text(1, "cerrada");
    \u0275\u0275elementEnd();
  }
}
function ResultsPage_Conditional_25_Conditional_4_For_44_Conditional_16_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 68);
    \u0275\u0275pipe(1, "number");
    \u0275\u0275text(2, "recortado");
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const fila_r49 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275property("title", \u0275\u0275interpolate1("Promedio simple: ", \u0275\u0275pipeBind2(1, 2, fila_r49.puntajePromedioSimple, "1.2-2")));
  }
}
function ResultsPage_Conditional_25_Conditional_4_For_44_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "tr")(1, "td", 62);
    \u0275\u0275conditionalCreate(2, ResultsPage_Conditional_25_Conditional_4_For_44_Conditional_2_Template, 1, 0, "ion-icon", 135);
    \u0275\u0275text(3);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "td");
    \u0275\u0275text(5);
    \u0275\u0275conditionalCreate(6, ResultsPage_Conditional_25_Conditional_4_For_44_Conditional_6_Template, 2, 0, "span", 66);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "td");
    \u0275\u0275text(8);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(9, "td", 58);
    \u0275\u0275text(10);
    \u0275\u0275pipe(11, "number");
    \u0275\u0275pipe(12, "number");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(13, "td", 67);
    \u0275\u0275text(14);
    \u0275\u0275pipe(15, "number");
    \u0275\u0275conditionalCreate(16, ResultsPage_Conditional_25_Conditional_4_For_44_Conditional_16_Template, 3, 5, "span", 68);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(17, "td")(18, "span", 136);
    \u0275\u0275text(19);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const fila_r49 = ctx.$implicit;
    \u0275\u0275advance(2);
    \u0275\u0275conditional(fila_r49.posicion === 1 ? 2 : -1);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" #", fila_r49.posicion, " ");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1(" Muestra ", fila_r49.numeroMuestra, " ");
    \u0275\u0275advance();
    \u0275\u0275conditional(fila_r49.cerradaForzada ? 6 : -1);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate2("", fila_r49.evaluacionesRecibidas, " / ", fila_r49.evaluacionesEsperadas);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate2("", \u0275\u0275pipeBind2(11, 15, fila_r49.puntajeMin, "1.2-2"), " \u2013 ", \u0275\u0275pipeBind2(12, 18, fila_r49.puntajeMax, "1.2-2"));
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate1(" ", \u0275\u0275pipeBind2(15, 21, fila_r49.puntajePromedioPanel, "1.2-2"), " ");
    \u0275\u0275advance(2);
    \u0275\u0275conditional(fila_r49.recortado ? 16 : -1);
    \u0275\u0275advance(2);
    \u0275\u0275styleProp("color", fila_r49.clasificacion.color)("background", fila_r49.clasificacion.fondo);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", fila_r49.clasificacion.etiqueta, " ");
  }
}
function ResultsPage_Conditional_25_Conditional_4_ForEmpty_45_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "tr")(1, "td", 70);
    \u0275\u0275text(2, "Ninguna muestra recibi\xF3 fichas.");
    \u0275\u0275elementEnd()();
  }
}
function ResultsPage_Conditional_25_Conditional_4_Conditional_46_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "tfoot")(1, "tr")(2, "td", 137);
    \u0275\u0275text(3, "Promedio del panel");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "td", 67);
    \u0275\u0275text(5);
    \u0275\u0275pipe(6, "number");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "td")(8, "span", 136);
    \u0275\u0275text(9);
    \u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    const ctx_r4 = \u0275\u0275nextContext(3);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind2(6, 6, ctx_r4.promedioPanel(), "1.2-2"));
    \u0275\u0275advance(3);
    \u0275\u0275styleProp("color", ctx_r4.clasificacionPanel().color)("background", ctx_r4.clasificacionPanel().fondo);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", ctx_r4.clasificacionPanel().etiqueta, " ");
  }
}
function ResultsPage_Conditional_25_Conditional_4_Conditional_47_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 35);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r4 = \u0275\u0275nextContext(3);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" Sin fichas: ", ctx_r4.muestrasSinFichas().length, " muestra(s) cerradas sin evaluaciones. ");
  }
}
function ResultsPage_Conditional_25_Conditional_4_For_55_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "app-cupper-result-card", 72);
  }
  if (rf & 2) {
    const catador_r50 = ctx.$implicit;
    \u0275\u0275property("catador", catador_r50);
  }
}
function ResultsPage_Conditional_25_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r48 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "section", 130)(1, "div", 29)(2, "p", 30);
    \u0275\u0275element(3, "ion-icon", 31);
    \u0275\u0275text(4);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "p", 32);
    \u0275\u0275text(6);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(7, "div", 33)(8, "div")(9, "strong");
    \u0275\u0275text(10);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(11, "span");
    \u0275\u0275text(12, "Muestras");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(13, "div")(14, "strong");
    \u0275\u0275text(15);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(16, "span");
    \u0275\u0275text(17, "Catadores");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(18, "div")(19, "strong");
    \u0275\u0275text(20);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(21, "span");
    \u0275\u0275text(22, "Formato");
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(23, "section", 131)(24, "h2", 56);
    \u0275\u0275text(25, "Ranking \u2014 promedio del panel");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(26, "div", 48)(27, "table", 132)(28, "thead")(29, "tr")(30, "th", 50);
    \u0275\u0275text(31, "#");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(32, "th", 50);
    \u0275\u0275text(33, "Muestra");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(34, "th", 50);
    \u0275\u0275text(35, "Fichas");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(36, "th", 50);
    \u0275\u0275text(37, "M\xEDn \u2013 M\xE1x");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(38, "th", 50);
    \u0275\u0275text(39, "Puntaje panel");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(40, "th", 50);
    \u0275\u0275text(41, "Clasificaci\xF3n");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(42, "tbody");
    \u0275\u0275repeaterCreate(43, ResultsPage_Conditional_25_Conditional_4_For_44_Template, 20, 24, "tr", null, _forTrack2, false, ResultsPage_Conditional_25_Conditional_4_ForEmpty_45_Template, 3, 0, "tr");
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(46, ResultsPage_Conditional_25_Conditional_4_Conditional_46_Template, 10, 9, "tfoot");
    \u0275\u0275elementEnd()();
    \u0275\u0275conditionalCreate(47, ResultsPage_Conditional_25_Conditional_4_Conditional_47_Template, 2, 1, "p", 35);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(48, "section")(49, "h2", 56);
    \u0275\u0275text(50, "An\xE1lisis de catadores");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(51, "p", 35);
    \u0275\u0275text(52, "Participaci\xF3n y consistencia individual dentro del panel.");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(53, "div", 133);
    \u0275\u0275repeaterCreate(54, ResultsPage_Conditional_25_Conditional_4_For_55_Template, 1, 1, "app-cupper-result-card", 72, _forTrack1);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(56, "section", 55)(57, "h2", 56);
    \u0275\u0275text(58, "F\xF3rmula CVA aplicada");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(59, "p", 57);
    \u0275\u0275text(60, "S = 0.65625 \xD7 \u03A3h\u1D62 + 52.75 \u2212 2u \u2212 4d");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(61, "p", 58);
    \u0275\u0275text(62, " El consolidado descarta el valor m\xE1s alto y el m\xE1s bajo por muestra cuando hay 5 o m\xE1s fichas. ");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(63, "div", 59)(64, "ion-button", 43);
    \u0275\u0275listener("click", function ResultsPage_Conditional_25_Conditional_4_Template_ion_button_click_64_listener() {
      \u0275\u0275restoreView(_r48);
      const ctx_r4 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r4.volverAlPanel());
    });
    \u0275\u0275text(65, "Volver al panel");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(66, "ion-button", 134);
    \u0275\u0275listener("click", function ResultsPage_Conditional_25_Conditional_4_Template_ion_button_click_66_listener() {
      \u0275\u0275restoreView(_r48);
      const ctx_r4 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r4.exportarPDF());
    });
    \u0275\u0275element(67, "ion-icon", 13);
    \u0275\u0275text(68, " Exportar a PDF (Formato SCA) ");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const r_r24 = \u0275\u0275nextContext();
    const ctx_r4 = \u0275\u0275nextContext();
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate1(" Sesi\xF3n cerrada \xB7 ", ctx_r4.porcentajeCompletado(), "% completada ");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1(" ", ctx_r4.hayRecorte() ? "Consolidaci\xF3n mediante promedio recortado SCA (se descartan m\xE1ximo y m\xEDnimo con 5 o m\xE1s catadores)." : "Consolidaci\xF3n mediante promedio simple (menos de 5 fichas por muestra).", " ");
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(r_r24.totalMuestras);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(r_r24.catadores.length);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(ctx_r4.tituloFormato());
    \u0275\u0275advance(23);
    \u0275\u0275repeater(ctx_r4.ranking());
    \u0275\u0275advance(3);
    \u0275\u0275conditional(ctx_r4.ranking().length > 0 ? 46 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r4.muestrasSinFichas().length > 0 ? 47 : -1);
    \u0275\u0275advance(7);
    \u0275\u0275repeater(r_r24.catadores);
  }
}
function ResultsPage_Conditional_25_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275conditionalCreate(0, ResultsPage_Conditional_25_Conditional_0_Template, 57, 20)(1, ResultsPage_Conditional_25_Conditional_1_Template, 33, 11)(2, ResultsPage_Conditional_25_Conditional_2_Template, 26, 10)(3, ResultsPage_Conditional_25_Conditional_3_Template, 9, 2)(4, ResultsPage_Conditional_25_Conditional_4_Template, 69, 8);
  }
  if (rf & 2) {
    const ctx_r4 = \u0275\u0275nextContext();
    \u0275\u0275conditional(ctx_r4.esCombinado() ? 0 : ctx_r4.esAfectivo() ? 1 : ctx_r4.esDescriptivo() ? 2 : ctx_r4.esExtrinseco() ? 3 : 4);
  }
}
function ResultsPage_Conditional_26_ng_template_1_For_10_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-select-option", 41);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const fila_r53 = ctx.$implicit;
    \u0275\u0275property("value", fila_r53.numeroMuestra);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1("Muestra ", fila_r53.numeroMuestra);
  }
}
function ResultsPage_Conditional_26_ng_template_1_Conditional_18_For_4_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-select-option", 41);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const c_r55 = ctx.$implicit;
    \u0275\u0275property("value", c_r55.cupperId);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(c_r55.nombre);
  }
}
function ResultsPage_Conditional_26_ng_template_1_Conditional_18_Template(rf, ctx) {
  if (rf & 1) {
    const _r54 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "label", 150);
    \u0275\u0275text(1, "Selecciona el catador");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(2, "ion-select", 151);
    \u0275\u0275listener("ionChange", function ResultsPage_Conditional_26_ng_template_1_Conditional_18_Template_ion_select_ionChange_2_listener($event) {
      \u0275\u0275restoreView(_r54);
      const ctx_r4 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r4.cambiarCatadorExportar($event.detail.value));
    });
    \u0275\u0275repeaterCreate(3, ResultsPage_Conditional_26_ng_template_1_Conditional_18_For_4_Template, 2, 2, "ion-select-option", 41, _forTrack1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r4 = \u0275\u0275nextContext(3);
    \u0275\u0275advance(2);
    \u0275\u0275property("value", ctx_r4.catadorExportarId());
    \u0275\u0275advance();
    \u0275\u0275repeater(ctx_r4.catadoresExportables());
  }
}
function ResultsPage_Conditional_26_ng_template_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r52 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 139)(1, "div", 140)(2, "h2");
    \u0275\u0275text(3, "\xBFC\xF3mo quieres exportar tu PDF?");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "ion-button", 141);
    \u0275\u0275listener("click", function ResultsPage_Conditional_26_ng_template_1_Template_ion_button_click_4_listener() {
      \u0275\u0275restoreView(_r52);
      const ctx_r4 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r4.cerrarExportar());
    });
    \u0275\u0275element(5, "ion-icon", 142);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(6, "label", 143);
    \u0275\u0275text(7, "Muestra #");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "ion-select", 144);
    \u0275\u0275listener("ionChange", function ResultsPage_Conditional_26_ng_template_1_Template_ion_select_ionChange_8_listener($event) {
      \u0275\u0275restoreView(_r52);
      const ctx_r4 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r4.cambiarMuestraExportar($event.detail.value));
    });
    \u0275\u0275repeaterCreate(9, ResultsPage_Conditional_26_ng_template_1_For_10_Template, 2, 2, "ion-select-option", 41, _forTrack2);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(11, "ion-segment", 145);
    \u0275\u0275listener("ionChange", function ResultsPage_Conditional_26_ng_template_1_Template_ion_segment_ionChange_11_listener($event) {
      \u0275\u0275restoreView(_r52);
      const ctx_r4 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r4.cambiarModoExportacion($event.detail.value));
    });
    \u0275\u0275elementStart(12, "ion-segment-button", 146)(13, "ion-label");
    \u0275\u0275text(14, "Por catador");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(15, "ion-segment-button", 147)(16, "ion-label");
    \u0275\u0275text(17, "Panel");
    \u0275\u0275elementEnd()()();
    \u0275\u0275conditionalCreate(18, ResultsPage_Conditional_26_ng_template_1_Conditional_18_Template, 5, 1);
    \u0275\u0275elementStart(19, "ion-button", 148);
    \u0275\u0275listener("click", function ResultsPage_Conditional_26_ng_template_1_Template_ion_button_click_19_listener() {
      \u0275\u0275restoreView(_r52);
      const ctx_r4 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r4.confirmarExportar());
    });
    \u0275\u0275element(20, "ion-icon", 13);
    \u0275\u0275text(21, " Exportar a PDF (Formato SCA) ");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(22, "p", 149);
    \u0275\u0275text(23, 'En la ventana de impresi\xF3n elige "Guardar como PDF".');
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r4 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(8);
    \u0275\u0275property("value", ctx_r4.muestraExportar());
    \u0275\u0275advance();
    \u0275\u0275repeater(ctx_r4.ranking());
    \u0275\u0275advance(2);
    \u0275\u0275property("value", ctx_r4.modoExportacion());
    \u0275\u0275advance(7);
    \u0275\u0275conditional(ctx_r4.modoExportacion() === "catador" ? 18 : -1);
    \u0275\u0275advance();
    \u0275\u0275property("disabled", ctx_r4.imprimiendo() || ctx_r4.muestraExportar() === null || ctx_r4.modoExportacion() === "catador" && !ctx_r4.catadorExportarId());
  }
}
function ResultsPage_Conditional_26_Template(rf, ctx) {
  if (rf & 1) {
    const _r51 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "ion-modal", 138);
    \u0275\u0275listener("didDismiss", function ResultsPage_Conditional_26_Template_ion_modal_didDismiss_0_listener() {
      \u0275\u0275restoreView(_r51);
      const ctx_r4 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r4.cerrarExportar());
    });
    \u0275\u0275template(1, ResultsPage_Conditional_26_ng_template_1_Template, 24, 4, "ng-template");
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r4 = \u0275\u0275nextContext();
    \u0275\u0275property("isOpen", ctx_r4.modalExportarAbierto());
  }
}
function ResultsPage_Conditional_27_Conditional_15_Conditional_0_Conditional_0_Conditional_3_For_35_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "tr")(1, "td");
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "td", 159);
    \u0275\u0275text(4);
    \u0275\u0275pipe(5, "number");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "td", 159);
    \u0275\u0275text(7);
    \u0275\u0275pipe(8, "number");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const a_r56 = ctx.$implicit;
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(a_r56.etiqueta);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(a_r56.intensidad === null ? "\u2014" : \u0275\u0275pipeBind2(5, 3, a_r56.intensidad, "1.0-2"));
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(a_r56.calidad === null ? "\u2014" : \u0275\u0275pipeBind2(8, 6, a_r56.calidad, "1.0-2"));
  }
}
function ResultsPage_Conditional_27_Conditional_15_Conditional_0_Conditional_0_Conditional_3_ForEmpty_36_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "tr")(1, "td", 165);
    \u0275\u0275text(2, "Sin atributos registrados.");
    \u0275\u0275elementEnd()();
  }
}
function ResultsPage_Conditional_27_Conditional_15_Conditional_0_Conditional_0_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 162)(1, "div", 163)(2, "strong");
    \u0275\u0275text(3);
    \u0275\u0275pipe(4, "number");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "span");
    \u0275\u0275text(6, "Puntaje final");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(7, "div", 163)(8, "strong");
    \u0275\u0275text(9);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(10, "span");
    \u0275\u0275text(11, "Clasificaci\xF3n");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(12, "div", 163)(13, "strong");
    \u0275\u0275text(14);
    \u0275\u0275pipe(15, "number");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(16, "span");
    \u0275\u0275text(17, "Impresi\xF3n global");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(18, "div", 163)(19, "strong");
    \u0275\u0275text(20);
    \u0275\u0275pipe(21, "number");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(22, "span");
    \u0275\u0275text(23, "Promedio del panel");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(24, "table")(25, "thead")(26, "tr")(27, "th");
    \u0275\u0275text(28, "Atributo");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(29, "th", 159);
    \u0275\u0275text(30, "Intensidad (0\u201315)");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(31, "th", 159);
    \u0275\u0275text(32, "Calidad (1\u20139)");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(33, "tbody");
    \u0275\u0275repeaterCreate(34, ResultsPage_Conditional_27_Conditional_15_Conditional_0_Conditional_0_Conditional_3_For_35_Template, 9, 9, "tr", null, _forTrack3, false, ResultsPage_Conditional_27_Conditional_15_Conditional_0_Conditional_0_Conditional_3_ForEmpty_36_Template, 3, 0, "tr");
    \u0275\u0275elementStart(37, "tr")(38, "td");
    \u0275\u0275text(39, "Tazas no uniformes (u)");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(40, "td", 164);
    \u0275\u0275text(41);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(42, "tr")(43, "td");
    \u0275\u0275text(44, "Tazas defectuosas (d)");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(45, "td", 164);
    \u0275\u0275text(46);
    \u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    const f_r57 = ctx;
    const m_r58 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind2(4, 7, f_r57.puntaje, "1.2-2"));
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate(f_r57.clasificacion.etiqueta);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(f_r57.impresionGlobal === null ? "\u2014" : \u0275\u0275pipeBind2(15, 10, f_r57.impresionGlobal, "1.0-2"));
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind2(21, 13, m_r58.puntajePromedioPanel, "1.2-2"));
    \u0275\u0275advance(14);
    \u0275\u0275repeater(f_r57.atributos);
    \u0275\u0275advance(7);
    \u0275\u0275textInterpolate(f_r57.tazasNoUniformes);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(f_r57.tazasDefectuosas);
  }
}
function ResultsPage_Conditional_27_Conditional_15_Conditional_0_Conditional_0_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 161);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const m_r58 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1("Este catador no envi\xF3 ficha para la muestra ", m_r58.numeroMuestra, ".");
  }
}
function ResultsPage_Conditional_27_Conditional_15_Conditional_0_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "section", 158)(1, "h2");
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(3, ResultsPage_Conditional_27_Conditional_15_Conditional_0_Conditional_0_Conditional_3_Template, 47, 16)(4, ResultsPage_Conditional_27_Conditional_15_Conditional_0_Conditional_0_Conditional_4_Template, 2, 1, "p", 161);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    let tmp_12_0;
    const m_r58 = \u0275\u0275nextContext();
    const ctx_r4 = \u0275\u0275nextContext(3);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate2("Ficha individual \xB7 ", ctx_r4.catadorExportar()?.nombre, " \xB7 Muestra ", m_r58.numeroMuestra);
    \u0275\u0275advance();
    \u0275\u0275conditional((tmp_12_0 = ctx_r4.fichaCatadorReporte()) ? 3 : 4, tmp_12_0);
  }
}
function ResultsPage_Conditional_27_Conditional_15_Conditional_0_Conditional_1_Conditional_29_For_14_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "tr")(1, "td");
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "td", 159);
    \u0275\u0275text(4);
    \u0275\u0275pipe(5, "number");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "td", 159);
    \u0275\u0275text(7);
    \u0275\u0275pipe(8, "number");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const a_r59 = ctx.$implicit;
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(a_r59.etiqueta);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(a_r59.intensidad === null ? "\u2014" : \u0275\u0275pipeBind2(5, 3, a_r59.intensidad, "1.0-2"));
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(a_r59.calidad === null ? "\u2014" : \u0275\u0275pipeBind2(8, 6, a_r59.calidad, "1.0-2"));
  }
}
function ResultsPage_Conditional_27_Conditional_15_Conditional_0_Conditional_1_Conditional_29_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "section", 158)(1, "h2");
    \u0275\u0275text(2, "Promedio del panel por atributo");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "table")(4, "thead")(5, "tr")(6, "th");
    \u0275\u0275text(7, "Atributo");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "th", 159);
    \u0275\u0275text(9, "Intensidad (0\u201315)");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(10, "th", 159);
    \u0275\u0275text(11, "Calidad (1\u20139)");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(12, "tbody");
    \u0275\u0275repeaterCreate(13, ResultsPage_Conditional_27_Conditional_15_Conditional_0_Conditional_1_Conditional_29_For_14_Template, 9, 9, "tr", null, _forTrack3);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const ctx_r4 = \u0275\u0275nextContext(5);
    \u0275\u0275advance(13);
    \u0275\u0275repeater(ctx_r4.atributosPanelReporte());
  }
}
function ResultsPage_Conditional_27_Conditional_15_Conditional_0_Conditional_1_For_46_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "tr")(1, "td");
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "td", 159);
    \u0275\u0275text(4);
    \u0275\u0275pipe(5, "number");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "td", 159);
    \u0275\u0275text(7);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "td", 159);
    \u0275\u0275text(9);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const c_r60 = ctx.$implicit;
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(c_r60.nombre);
    \u0275\u0275advance();
    \u0275\u0275classProp("rp-score", c_r60.ficha)("rp-muted", !c_r60.ficha);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(c_r60.ficha ? \u0275\u0275pipeBind2(5, 8, c_r60.ficha.puntaje, "1.2-2") : "Pendiente");
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(c_r60.ficha?.tazasNoUniformes ?? "\u2014");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(c_r60.ficha?.tazasDefectuosas ?? "\u2014");
  }
}
function ResultsPage_Conditional_27_Conditional_15_Conditional_0_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "section", 158)(1, "h2");
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "div", 162)(4, "div", 163)(5, "strong");
    \u0275\u0275text(6);
    \u0275\u0275pipe(7, "number");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "span");
    \u0275\u0275text(9, "Puntaje panel");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(10, "div", 163)(11, "strong");
    \u0275\u0275text(12);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(13, "span");
    \u0275\u0275text(14, "Clasificaci\xF3n");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(15, "div", 163)(16, "strong");
    \u0275\u0275text(17);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(18, "span");
    \u0275\u0275text(19, "Fichas");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(20, "div", 163)(21, "strong");
    \u0275\u0275text(22);
    \u0275\u0275pipe(23, "number");
    \u0275\u0275pipe(24, "number");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(25, "span");
    \u0275\u0275text(26, "M\xEDn \u2013 M\xE1x");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(27, "p", 161);
    \u0275\u0275text(28);
    \u0275\u0275elementEnd()();
    \u0275\u0275conditionalCreate(29, ResultsPage_Conditional_27_Conditional_15_Conditional_0_Conditional_1_Conditional_29_Template, 15, 0, "section", 158);
    \u0275\u0275elementStart(30, "section", 158)(31, "h2");
    \u0275\u0275text(32);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(33, "table")(34, "thead")(35, "tr")(36, "th");
    \u0275\u0275text(37, "Catador");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(38, "th", 159);
    \u0275\u0275text(39, "Puntaje");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(40, "th", 159);
    \u0275\u0275text(41, "u");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(42, "th", 159);
    \u0275\u0275text(43, "d");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(44, "tbody");
    \u0275\u0275repeaterCreate(45, ResultsPage_Conditional_27_Conditional_15_Conditional_0_Conditional_1_For_46_Template, 10, 11, "tr", null, \u0275\u0275repeaterTrackByIndex);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const m_r58 = \u0275\u0275nextContext();
    const ctx_r4 = \u0275\u0275nextContext(3);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1("Consolidado del panel \xB7 Muestra ", m_r58.numeroMuestra);
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind2(7, 10, m_r58.puntajePromedioPanel, "1.2-2"));
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate(m_r58.clasificacion.etiqueta);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate2("", m_r58.evaluacionesRecibidas, " / ", m_r58.evaluacionesEsperadas);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate2("", \u0275\u0275pipeBind2(23, 13, m_r58.puntajeMin, "1.2-2"), " \u2013 ", \u0275\u0275pipeBind2(24, 16, m_r58.puntajeMax, "1.2-2"));
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate(m_r58.recortado ? "Promedio recortado SCA (se descartan m\xE1ximo y m\xEDnimo)." : "Promedio simple (menos de 5 fichas).");
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r4.atributosPanelReporte().length > 0 ? 29 : -1);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate1("Puntaje por catador \xB7 Muestra ", m_r58.numeroMuestra);
    \u0275\u0275advance(13);
    \u0275\u0275repeater(ctx_r4.puntajesCatadoresReporte());
  }
}
function ResultsPage_Conditional_27_Conditional_15_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275conditionalCreate(0, ResultsPage_Conditional_27_Conditional_15_Conditional_0_Conditional_0_Template, 5, 3, "section", 158)(1, ResultsPage_Conditional_27_Conditional_15_Conditional_0_Conditional_1_Template, 47, 19);
  }
  if (rf & 2) {
    const ctx_r4 = \u0275\u0275nextContext(3);
    \u0275\u0275conditional(ctx_r4.modoExportacion() === "catador" && ctx_r4.catadorExportar() ? 0 : 1);
  }
}
function ResultsPage_Conditional_27_Conditional_15_For_19_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "tr")(1, "td");
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "td");
    \u0275\u0275text(4);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "td", 159);
    \u0275\u0275text(6);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "td", 166);
    \u0275\u0275text(8);
    \u0275\u0275pipe(9, "number");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(10, "td")(11, "span", 167);
    \u0275\u0275text(12);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const f_r61 = ctx.$implicit;
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(f_r61.posicion);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1("Muestra ", f_r61.numeroMuestra);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate2("", f_r61.evaluacionesRecibidas, " / ", f_r61.evaluacionesEsperadas);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind2(9, 10, f_r61.puntajePromedioPanel, "1.2-2"));
    \u0275\u0275advance(3);
    \u0275\u0275styleProp("color", f_r61.clasificacion.color)("background", f_r61.clasificacion.fondo);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(f_r61.clasificacion.etiqueta);
  }
}
function ResultsPage_Conditional_27_Conditional_15_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275conditionalCreate(0, ResultsPage_Conditional_27_Conditional_15_Conditional_0_Template, 2, 1);
    \u0275\u0275elementStart(1, "section", 158)(2, "h2");
    \u0275\u0275text(3, "Ranking de la sesi\xF3n");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "table")(5, "thead")(6, "tr")(7, "th");
    \u0275\u0275text(8, "#");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(9, "th");
    \u0275\u0275text(10, "Muestra");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(11, "th", 159);
    \u0275\u0275text(12, "Fichas");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(13, "th", 159);
    \u0275\u0275text(14, "Puntaje panel");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(15, "th");
    \u0275\u0275text(16, "Clasificaci\xF3n");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(17, "tbody");
    \u0275\u0275repeaterCreate(18, ResultsPage_Conditional_27_Conditional_15_For_19_Template, 13, 13, "tr", null, _forTrack2);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(20, "p", 160);
    \u0275\u0275text(21, "S = 0.65625 \xD7 \u03A3h\u1D62 + 52.75 \u2212 2u \u2212 4d");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    let tmp_8_0;
    const ctx_r4 = \u0275\u0275nextContext(2);
    \u0275\u0275conditional((tmp_8_0 = ctx_r4.muestraReporteCombinado()) ? 0 : -1, tmp_8_0);
    \u0275\u0275advance(18);
    \u0275\u0275repeater(ctx_r4.ranking());
  }
}
function ResultsPage_Conditional_27_Conditional_16_For_18_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "tr")(1, "td");
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "td");
    \u0275\u0275text(4);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "td", 159);
    \u0275\u0275text(6);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "td", 166);
    \u0275\u0275text(8);
    \u0275\u0275pipe(9, "number");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(10, "td");
    \u0275\u0275text(11);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const f_r62 = ctx.$implicit;
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(f_r62.posicion || "\u2014");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1("Muestra ", f_r62.numeroMuestra);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(f_r62.totalVotos);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(f_r62.promedio === null ? "\u2014" : \u0275\u0275pipeBind2(9, 5, f_r62.promedio, "1.2-2"));
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(f_r62.etiqueta);
  }
}
function ResultsPage_Conditional_27_Conditional_16_For_21_For_6_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "tr")(1, "td", 170);
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "td", 171);
    \u0275\u0275text(4);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "td")(6, "div", 172);
    \u0275\u0275element(7, "i");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(8, "td", 173);
    \u0275\u0275text(9);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const d_r63 = ctx.$implicit;
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(d_r63.valor);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(d_r63.etiqueta);
    \u0275\u0275advance(3);
    \u0275\u0275styleProp("width", d_r63.porcentaje, "%");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(d_r63.votos);
  }
}
function ResultsPage_Conditional_27_Conditional_16_For_21_For_16_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "tr")(1, "td");
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "td", 159);
    \u0275\u0275text(4);
    \u0275\u0275pipe(5, "number");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const a_r64 = ctx.$implicit;
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(a_r64.etiqueta);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(a_r64.valor === null ? "\u2014" : \u0275\u0275pipeBind2(5, 2, a_r64.valor, "1.1-1"));
  }
}
function ResultsPage_Conditional_27_Conditional_16_For_21_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "section", 158)(1, "h2");
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "table")(4, "tbody");
    \u0275\u0275repeaterCreate(5, ResultsPage_Conditional_27_Conditional_16_For_21_For_6_Template, 10, 5, "tr", null, _forTrack4);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(7, "table", 169)(8, "thead")(9, "tr")(10, "th");
    \u0275\u0275text(11, "Atributo");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(12, "th", 159);
    \u0275\u0275text(13, "Calidad (1\u20139)");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(14, "tbody");
    \u0275\u0275repeaterCreate(15, ResultsPage_Conditional_27_Conditional_16_For_21_For_16_Template, 6, 5, "tr", null, _forTrack3);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const f_r65 = ctx.$implicit;
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1("Muestra ", f_r65.numeroMuestra, " \xB7 distribuci\xF3n de votos");
    \u0275\u0275advance(3);
    \u0275\u0275repeater(f_r65.distribucion);
    \u0275\u0275advance(10);
    \u0275\u0275repeater(f_r65.atributos);
  }
}
function ResultsPage_Conditional_27_Conditional_16_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "section", 158)(1, "h2");
    \u0275\u0275text(2, "Promedio hed\xF3nico por muestra (escala 1\u20139)");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "table")(4, "thead")(5, "tr")(6, "th");
    \u0275\u0275text(7, "#");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "th");
    \u0275\u0275text(9, "Muestra");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(10, "th", 159);
    \u0275\u0275text(11, "Votos");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(12, "th", 159);
    \u0275\u0275text(13, "Promedio");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(14, "th");
    \u0275\u0275text(15, "Valoraci\xF3n");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(16, "tbody");
    \u0275\u0275repeaterCreate(17, ResultsPage_Conditional_27_Conditional_16_For_18_Template, 12, 8, "tr", null, _forTrack2);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(19, "div", 168);
    \u0275\u0275repeaterCreate(20, ResultsPage_Conditional_27_Conditional_16_For_21_Template, 17, 1, "section", 158, _forTrack2);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r4 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(17);
    \u0275\u0275repeater(ctx_r4.resultadosHedonicos());
    \u0275\u0275advance(3);
    \u0275\u0275repeater(ctx_r4.resultadosHedonicos());
  }
}
function ResultsPage_Conditional_27_Conditional_17_For_9_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "th", 159);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const p_r66 = ctx.$implicit;
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1("Muestra ", p_r66.numeroMuestra);
  }
}
function ResultsPage_Conditional_27_Conditional_17_For_12_For_4_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "td", 159);
    \u0275\u0275text(1);
    \u0275\u0275pipe(2, "number");
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const p_r67 = ctx.$implicit;
    const \u0275$index_1469_r68 = \u0275\u0275nextContext().$index;
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(p_r67.atributos[\u0275$index_1469_r68].valor === null ? "\u2014" : \u0275\u0275pipeBind2(2, 1, p_r67.atributos[\u0275$index_1469_r68].valor, "1.1-1"));
  }
}
function ResultsPage_Conditional_27_Conditional_17_For_12_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "tr")(1, "td");
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
    \u0275\u0275repeaterCreate(3, ResultsPage_Conditional_27_Conditional_17_For_12_For_4_Template, 3, 4, "td", 159, _forTrack2);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const atr_r69 = ctx.$implicit;
    const ctx_r4 = \u0275\u0275nextContext(3);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(atr_r69.etiqueta);
    \u0275\u0275advance();
    \u0275\u0275repeater(ctx_r4.perfilesDescriptivos());
  }
}
function ResultsPage_Conditional_27_Conditional_17_For_17_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "td", 174);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const p_r70 = ctx.$implicit;
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(p_r70.fichas);
  }
}
function ResultsPage_Conditional_27_Conditional_17_For_20_For_6_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "tr")(1, "td", 175);
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "td")(4, "div", 172);
    \u0275\u0275element(5, "i");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(6, "td", 176);
    \u0275\u0275text(7);
    \u0275\u0275pipe(8, "number");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const a_r71 = ctx.$implicit;
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(a_r71.etiqueta);
    \u0275\u0275advance(3);
    \u0275\u0275styleProp("width", a_r71.porcentaje, "%");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(a_r71.valor === null ? "\u2014" : \u0275\u0275pipeBind2(8, 4, a_r71.valor, "1.1-1"));
  }
}
function ResultsPage_Conditional_27_Conditional_17_For_20_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "section", 158)(1, "h2");
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "table")(4, "tbody");
    \u0275\u0275repeaterCreate(5, ResultsPage_Conditional_27_Conditional_17_For_20_For_6_Template, 9, 7, "tr", null, _forTrack3);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const p_r72 = ctx.$implicit;
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1("Muestra ", p_r72.numeroMuestra);
    \u0275\u0275advance(3);
    \u0275\u0275repeater(p_r72.atributos);
  }
}
function ResultsPage_Conditional_27_Conditional_17_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "section", 158)(1, "h2");
    \u0275\u0275text(2, "Perfil de intensidades del panel (escala 0\u201315)");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "table")(4, "thead")(5, "tr")(6, "th");
    \u0275\u0275text(7, "Atributo");
    \u0275\u0275elementEnd();
    \u0275\u0275repeaterCreate(8, ResultsPage_Conditional_27_Conditional_17_For_9_Template, 2, 1, "th", 159, _forTrack2);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(10, "tbody");
    \u0275\u0275repeaterCreate(11, ResultsPage_Conditional_27_Conditional_17_For_12_Template, 5, 1, "tr", null, _forTrack3);
    \u0275\u0275elementStart(13, "tr")(14, "td", 161);
    \u0275\u0275text(15, "Fichas recibidas");
    \u0275\u0275elementEnd();
    \u0275\u0275repeaterCreate(16, ResultsPage_Conditional_27_Conditional_17_For_17_Template, 2, 1, "td", 174, _forTrack2);
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(18, "div", 168);
    \u0275\u0275repeaterCreate(19, ResultsPage_Conditional_27_Conditional_17_For_20_Template, 7, 1, "section", 158, _forTrack2);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r4 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(8);
    \u0275\u0275repeater(ctx_r4.perfilesDescriptivos());
    \u0275\u0275advance(3);
    \u0275\u0275repeater(ctx_r4.atributosCva);
    \u0275\u0275advance(5);
    \u0275\u0275repeater(ctx_r4.perfilesDescriptivos());
    \u0275\u0275advance(3);
    \u0275\u0275repeater(ctx_r4.perfilesDescriptivos());
  }
}
function ResultsPage_Conditional_27_Conditional_18_For_1_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275text(0);
  }
  if (rf & 2) {
    const ficha_r73 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275textInterpolate1(" \xB7 registrada por ", ficha_r73.registradaPor, " ");
  }
}
function ResultsPage_Conditional_27_Conditional_18_For_1_For_7_For_5_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "dt");
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(2, "dd");
    \u0275\u0275text(3);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const campo_r74 = ctx.$implicit;
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(campo_r74.etiqueta);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(campo_r74.valor);
  }
}
function ResultsPage_Conditional_27_Conditional_18_For_1_For_7_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "section", 158)(1, "h2");
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "dl", 179);
    \u0275\u0275repeaterCreate(4, ResultsPage_Conditional_27_Conditional_18_For_1_For_7_For_5_Template, 4, 2, null, null, _forTrack7);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const seccion_r75 = ctx.$implicit;
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(seccion_r75.titulo);
    \u0275\u0275advance(2);
    \u0275\u0275repeater(seccion_r75.campos);
  }
}
function ResultsPage_Conditional_27_Conditional_18_For_1_Conditional_11_For_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span");
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const c_r76 = ctx.$implicit;
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(c_r76);
  }
}
function ResultsPage_Conditional_27_Conditional_18_For_1_Conditional_11_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 178);
    \u0275\u0275repeaterCreate(1, ResultsPage_Conditional_27_Conditional_18_For_1_Conditional_11_For_2_Template, 2, 1, "span", null, \u0275\u0275repeaterTrackByIdentity);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ficha_r73 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275advance();
    \u0275\u0275repeater(ficha_r73.certificaciones);
  }
}
function ResultsPage_Conditional_27_Conditional_18_For_1_Conditional_12_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 161);
    \u0275\u0275text(1, "Sin certificaciones registradas.");
    \u0275\u0275elementEnd();
  }
}
function ResultsPage_Conditional_27_Conditional_18_For_1_Conditional_13_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "section", 158)(1, "h2");
    \u0275\u0275text(2, "Notas");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "p");
    \u0275\u0275text(4);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ficha_r73 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(ficha_r73.notas);
  }
}
function ResultsPage_Conditional_27_Conditional_18_For_1_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "article")(1, "section", 158)(2, "h2");
    \u0275\u0275text(3);
    \u0275\u0275conditionalCreate(4, ResultsPage_Conditional_27_Conditional_18_For_1_Conditional_4_Template, 1, 1);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(5, "div", 168);
    \u0275\u0275repeaterCreate(6, ResultsPage_Conditional_27_Conditional_18_For_1_For_7_Template, 6, 1, "section", 158, _forTrack6);
    \u0275\u0275elementStart(8, "section", 158)(9, "h2");
    \u0275\u0275text(10, "Certificaciones");
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(11, ResultsPage_Conditional_27_Conditional_18_For_1_Conditional_11_Template, 3, 0, "div", 178)(12, ResultsPage_Conditional_27_Conditional_18_For_1_Conditional_12_Template, 2, 0, "p", 161);
    \u0275\u0275elementEnd()();
    \u0275\u0275conditionalCreate(13, ResultsPage_Conditional_27_Conditional_18_For_1_Conditional_13_Template, 5, 1, "section", 158);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ficha_r73 = ctx.$implicit;
    const \u0275$index_1518_r77 = ctx.$index;
    \u0275\u0275classProp("rp-page-break", !(\u0275$index_1518_r77 === 0));
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate1("Muestra ", ficha_r73.numeroMuestra);
    \u0275\u0275advance();
    \u0275\u0275conditional(ficha_r73.registradaPor ? 4 : -1);
    \u0275\u0275advance(2);
    \u0275\u0275repeater(ficha_r73.secciones);
    \u0275\u0275advance(5);
    \u0275\u0275conditional(ficha_r73.certificaciones.length > 0 ? 11 : 12);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ficha_r73.notas ? 13 : -1);
  }
}
function ResultsPage_Conditional_27_Conditional_18_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275repeaterCreate(0, ResultsPage_Conditional_27_Conditional_18_For_1_Template, 14, 6, "article", 177, \u0275\u0275repeaterTrackByIndex);
  }
  if (rf & 2) {
    const ctx_r4 = \u0275\u0275nextContext(2);
    \u0275\u0275repeater(ctx_r4.fichasTecnicas());
  }
}
function ResultsPage_Conditional_27_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 19, 4)(2, "header", 152)(3, "div")(4, "p", 153);
    \u0275\u0275text(5, "PacamaraQs \xB7 Evaluaci\xF3n sensorial SCA CVA");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "h1", 154);
    \u0275\u0275text(7);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "p", 155);
    \u0275\u0275text(9);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(10, "p", 156);
    \u0275\u0275text(11);
    \u0275\u0275pipe(12, "date");
    \u0275\u0275element(13, "br");
    \u0275\u0275text(14);
    \u0275\u0275elementEnd()();
    \u0275\u0275conditionalCreate(15, ResultsPage_Conditional_27_Conditional_15_Template, 22, 1)(16, ResultsPage_Conditional_27_Conditional_16_Template, 22, 0)(17, ResultsPage_Conditional_27_Conditional_17_Template, 21, 0)(18, ResultsPage_Conditional_27_Conditional_18_Template, 2, 0);
    \u0275\u0275elementStart(19, "p", 157);
    \u0275\u0275text(20, "Metodolog\xEDa SCA Coffee Value Assessment (CVA) \xB7 Documento generado por PacamaraQs.");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const r_r78 = ctx;
    const ctx_r4 = \u0275\u0275nextContext();
    \u0275\u0275advance(7);
    \u0275\u0275textInterpolate(ctx_r4.esExtrinseco() ? "Ficha t\xE9cnica del caf\xE9" : "Reporte de cataci\xF3n");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate2("", r_r78.nombreSesion, " \xB7 Formato ", ctx_r4.tituloFormato());
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1("Generado: ", \u0275\u0275pipeBind2(12, 7, ctx_r4.fechaReporte(), "medium"));
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate2("", r_r78.totalMuestras, " muestra(s) \xB7 ", r_r78.catadores.length, " catador(es)");
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r4.esCombinado() ? 15 : ctx_r4.esAfectivo() ? 16 : ctx_r4.esDescriptivo() ? 17 : ctx_r4.esExtrinseco() ? 18 : -1);
  }
}
var ATRIBUTOS_CVA = [
  { clave: "fragancia", etiqueta: "Fragancia" },
  { clave: "aroma", etiqueta: "Aroma" },
  { clave: "sabor", etiqueta: "Sabor" },
  { clave: "sabor_residual", etiqueta: "Sabor residual" },
  { clave: "acidez", etiqueta: "Acidez" },
  { clave: "dulzor", etiqueta: "Dulzor" },
  { clave: "sensacion_boca", etiqueta: "Sensaci\xF3n en boca" }
];
var ESCALA_HEDONICA_DESC = [9, 8, 7, 6, 5, 4, 3, 2, 1];
var INTENSIDAD_MAX = 15;
var HEDONICA_MAX = 9;
function clasificarPuntaje(puntaje) {
  if (puntaje >= 90)
    return { etiqueta: "Excepcional", color: "#15803d", fondo: "#f0fdf4" };
  if (puntaje >= 85)
    return { etiqueta: "Excelente", color: "#1d4ed8", fondo: "#eff6ff" };
  if (puntaje >= 80)
    return { etiqueta: "Muy bueno", color: "#a16207", fondo: "#fefce8" };
  if (puntaje >= 75)
    return { etiqueta: "Bueno", color: "#c2410c", fondo: "#fff7ed" };
  return { etiqueta: "Regular", color: "#6c757d", fondo: "#f8f9fa" };
}
function etiquetaHedonica(promedio) {
  if (promedio === null)
    return "Sin votos";
  const valor = Math.min(HEDONICA_MAX, Math.max(1, Math.round(promedio)));
  return ETIQUETAS_HEDONICAS[valor] ?? "";
}
var redondear2 = (n) => Math.round(n * 100) / 100;
var porcentajeDe = (valor, maximo) => valor === null || maximo <= 0 ? 0 : Math.min(100, Math.max(0, Math.round(valor / maximo * 1e3) / 10));
var MEDIDOR_CX = 100;
var MEDIDOR_CY = 100;
var MEDIDOR_RADIO = 72;
var AGUJA_RADIO = 60;
function puntoEnMedidor(valor, radio) {
  const v = Math.min(100, Math.max(0, Number.isFinite(valor) ? valor : 0));
  const angulo = Math.PI * (1 - v / 100);
  return {
    x: Math.round((MEDIDOR_CX + radio * Math.cos(angulo)) * 100) / 100,
    y: Math.round((MEDIDOR_CY - radio * Math.sin(angulo)) * 100) / 100
  };
}
function arco(desde, hasta, clase) {
  const a = puntoEnMedidor(desde, MEDIDOR_RADIO);
  const b = puntoEnMedidor(hasta, MEDIDOR_RADIO);
  return { d: `M ${a.x} ${a.y} A ${MEDIDOR_RADIO} ${MEDIDOR_RADIO} 0 0 1 ${b.x} ${b.y}`, clase };
}
function atributosDeFicha(atributos) {
  return ATRIBUTOS_CVA.map(({ clave, etiqueta }) => ({
    clave,
    etiqueta,
    intensidad: atributos[clave]?.intensidad ?? null,
    calidad: atributos[clave]?.calidad ?? null
  })).filter((a) => a.intensidad !== null || a.calidad !== null);
}
var _ResultsPage = class _ResultsPage {
  constructor() {
    this.route = inject(ActivatedRoute);
    this.resultsService = inject(ResultsService);
    this.impresion = inject(ImpresionService);
    this.navCtrl = inject(NavController);
    this.toastCtrl = inject(ToastController);
    this.injector = inject(Injector);
    this.resultados = signal(
      null,
      ...ngDevMode ? [{ debugName: "resultados" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.cargando = signal(
      true,
      ...ngDevMode ? [{ debugName: "cargando" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.error = signal(
      null,
      ...ngDevMode ? [{ debugName: "error" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.accesoDenegado = signal(
      false,
      ...ngDevMode ? [{ debugName: "accesoDenegado" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.imprimiendo = signal(
      false,
      ...ngDevMode ? [{ debugName: "imprimiendo" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.fechaReporte = signal(
      /* @__PURE__ */ new Date(),
      ...ngDevMode ? [{ debugName: "fechaReporte" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.reporteImprimible = viewChild(
      "reporteImprimible",
      ...ngDevMode ? [{ debugName: "reporteImprimible" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.atributosCva = ATRIBUTOS_CVA;
    this.tituloFormato = computed(
      () => {
        const formato = this.resultados()?.formatoCva;
        return formato ? getFormatoById(formato).titulo : "";
      },
      ...ngDevMode ? [{ debugName: "tituloFormato" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.formato = computed(
      () => this.resultados()?.formatoCva ?? "",
      ...ngDevMode ? [{ debugName: "formato" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.esCombinado = computed(
      () => this.formato() === FormatoCva.COMBINADO.id,
      ...ngDevMode ? [{ debugName: "esCombinado" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.esAfectivo = computed(
      () => this.formato() === FormatoCva.AFECTIVO.id,
      ...ngDevMode ? [{ debugName: "esAfectivo" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.esDescriptivo = computed(
      () => this.formato() === FormatoCva.DESCRIPTIVO.id,
      ...ngDevMode ? [{ debugName: "esDescriptivo" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.esExtrinseco = computed(
      () => this.formato() === FormatoCva.EXTRINSECA.id,
      ...ngDevMode ? [{ debugName: "esExtrinseco" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.ranking = computed(
      () => {
        const muestras = this.resultados()?.muestras ?? [];
        return [...muestras].filter((m) => m.evaluacionesRecibidas > 0).sort((a, b) => b.puntajePromedioPanel - a.puntajePromedioPanel).map((m, indice) => __spreadProps(__spreadValues({}, m), { posicion: indice + 1, clasificacion: clasificarPuntaje(m.puntajePromedioPanel) }));
      },
      ...ngDevMode ? [{ debugName: "ranking" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.muestrasSinFichas = computed(
      () => this.resultados()?.muestras.filter((m) => m.evaluacionesRecibidas === 0) ?? [],
      ...ngDevMode ? [{ debugName: "muestrasSinFichas" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.promedioPanel = computed(
      () => {
        const filas = this.ranking();
        if (filas.length === 0)
          return 0;
        return Math.round(filas.reduce((total, f) => total + f.puntajePromedioPanel, 0) / filas.length * 100) / 100;
      },
      ...ngDevMode ? [{ debugName: "promedioPanel" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.clasificacionPanel = computed(
      () => clasificarPuntaje(this.promedioPanel()),
      ...ngDevMode ? [{ debugName: "clasificacionPanel" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.catadoresCompletos = computed(
      () => this.resultados()?.catadores.filter((c) => c.estado === "enviado").length ?? 0,
      ...ngDevMode ? [{ debugName: "catadoresCompletos" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.porcentajeCompletado = computed(
      () => {
        const total = this.resultados()?.catadores.length ?? 0;
        return total === 0 ? 0 : Math.round(this.catadoresCompletos() / total * 100);
      },
      ...ngDevMode ? [{ debugName: "porcentajeCompletado" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.hayRecorte = computed(
      () => this.ranking().some((f) => f.recortado),
      ...ngDevMode ? [{ debugName: "hayRecorte" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.numerosMuestra = computed(
      () => [...new Set((this.resultados()?.muestras ?? []).map((m) => m.numeroMuestra))].sort((a, b) => a - b),
      ...ngDevMode ? [{ debugName: "numerosMuestra" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.fichasPorMuestra = computed(
      () => {
        const conteo = /* @__PURE__ */ new Map();
        for (const catador of this.resultados()?.catadores ?? []) {
          for (const ficha of catador.puntajesPorMuestra) {
            conteo.set(ficha.numeroMuestra, (conteo.get(ficha.numeroMuestra) ?? 0) + 1);
          }
        }
        return conteo;
      },
      ...ngDevMode ? [{ debugName: "fichasPorMuestra" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.arcosMedidor = [
      arco(0, 30, "rc-gauge__arc--bajo"),
      arco(30, 50, "rc-gauge__arc--medio"),
      arco(50, 75, "rc-gauge__arc--alto"),
      arco(75, 100, "rc-gauge__arc--top")
    ];
    this.centroMedidor = { x: MEDIDOR_CX, y: MEDIDOR_CY };
    this.muestraMedidorNumero = signal(
      null,
      ...ngDevMode ? [{ debugName: "muestraMedidorNumero" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.muestraEnMedidor = computed(
      () => {
        const filas = this.ranking();
        const elegida = this.muestraMedidorNumero();
        return filas.find((f) => f.numeroMuestra === elegida) ?? filas[0] ?? null;
      },
      ...ngDevMode ? [{ debugName: "muestraEnMedidor" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.agujaPanel = computed(
      () => puntoEnMedidor(this.promedioPanel(), AGUJA_RADIO),
      ...ngDevMode ? [{ debugName: "agujaPanel" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.agujaMuestra = computed(
      () => puntoEnMedidor(this.muestraEnMedidor()?.puntajePromedioPanel ?? 0, AGUJA_RADIO),
      ...ngDevMode ? [{ debugName: "agujaMuestra" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.catadorReporteId = signal(
      null,
      ...ngDevMode ? [{ debugName: "catadorReporteId" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.catadorReporte = computed(
      () => {
        const catadores = this.resultados()?.catadores ?? [];
        const elegido = this.catadorReporteId();
        return catadores.find((c) => c.cupperId === elegido) ?? catadores.find((c) => c.estado === "enviado") ?? catadores[0] ?? null;
      },
      ...ngDevMode ? [{ debugName: "catadorReporte" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.fichasReporte = computed(
      () => this.fichasDe(this.catadorReporte()).filter((f) => f.puntaje > 0),
      ...ngDevMode ? [{ debugName: "fichasReporte" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.muestraDetalleNumero = signal(
      null,
      ...ngDevMode ? [{ debugName: "muestraDetalleNumero" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.resultadosHedonicos = computed(
      () => {
        const r = this.resultados();
        if (!r)
          return [];
        const filas = this.numerosMuestra().map((numeroMuestra) => {
          const votos = r.votosHedonicos.filter((v) => v.numeroMuestra === numeroMuestra);
          const totalVotos = votos.reduce((t, v) => t + v.votos, 0);
          const promedio = totalVotos === 0 ? null : redondear2(votos.reduce((t, v) => t + v.valor * v.votos, 0) / totalVotos);
          const distribucion = ESCALA_HEDONICA_DESC.map((valor) => {
            const n = votos.find((v) => v.valor === valor)?.votos ?? 0;
            return { valor, votos: n, porcentaje: porcentajeDe(n, totalVotos), etiqueta: ETIQUETAS_HEDONICAS[valor] ?? "" };
          });
          const atributos = ATRIBUTOS_CVA.map(({ clave, etiqueta }) => {
            const valor = r.atributosPorMuestra.find((a) => a.numeroMuestra === numeroMuestra && a.atributo === clave)?.calidadPromedio ?? null;
            return { clave, etiqueta, valor, porcentaje: porcentajeDe(valor, HEDONICA_MAX) };
          });
          return { numeroMuestra, posicion: 0, totalVotos, promedio, etiqueta: etiquetaHedonica(promedio), distribucion, atributos };
        });
        return filas.sort((a, b) => (b.promedio ?? -1) - (a.promedio ?? -1) || a.numeroMuestra - b.numeroMuestra).map((f, i) => __spreadProps(__spreadValues({}, f), { posicion: f.promedio === null ? 0 : i + 1 }));
      },
      ...ngDevMode ? [{ debugName: "resultadosHedonicos" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.hedonicoSeleccionado = computed(
      () => {
        const filas = this.resultadosHedonicos();
        const elegida = this.muestraDetalleNumero();
        return filas.find((f) => f.numeroMuestra === elegida) ?? filas[0] ?? null;
      },
      ...ngDevMode ? [{ debugName: "hedonicoSeleccionado" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.perfilesDescriptivos = computed(
      () => {
        const r = this.resultados();
        if (!r)
          return [];
        return this.numerosMuestra().map((numeroMuestra) => ({
          numeroMuestra,
          fichas: this.fichasPorMuestra().get(numeroMuestra) ?? 0,
          atributos: ATRIBUTOS_CVA.map(({ clave, etiqueta }) => {
            const fila = r.atributosPorMuestra.find((a) => a.numeroMuestra === numeroMuestra && a.atributo === clave);
            const valor = fila?.intensidadPromedio ?? null;
            return { clave, etiqueta, valor, porcentaje: porcentajeDe(valor, INTENSIDAD_MAX), respuestas: fila?.respuestas ?? 0 };
          })
        }));
      },
      ...ngDevMode ? [{ debugName: "perfilesDescriptivos" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.perfilSeleccionado = computed(
      () => {
        const perfiles = this.perfilesDescriptivos();
        const elegida = this.muestraDetalleNumero();
        return perfiles.find((p) => p.numeroMuestra === elegida) ?? perfiles[0] ?? null;
      },
      ...ngDevMode ? [{ debugName: "perfilSeleccionado" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.fichasTecnicas = computed(
      () => this.resultados()?.fichasTecnicas ?? [],
      ...ngDevMode ? [{ debugName: "fichasTecnicas" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.modalExportarAbierto = signal(
      false,
      ...ngDevMode ? [{ debugName: "modalExportarAbierto" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.modoExportacion = signal(
      "panel",
      ...ngDevMode ? [{ debugName: "modoExportacion" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.muestraExportar = signal(
      null,
      ...ngDevMode ? [{ debugName: "muestraExportar" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.catadorExportarId = signal(
      null,
      ...ngDevMode ? [{ debugName: "catadorExportarId" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.catadoresExportables = computed(
      () => this.resultados()?.catadores.filter((c) => c.muestrasEvaluadas > 0) ?? [],
      ...ngDevMode ? [{ debugName: "catadoresExportables" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.muestraReporteCombinado = computed(
      () => this.ranking().find((f) => f.numeroMuestra === this.muestraExportar()) ?? this.muestraEnMedidor(),
      ...ngDevMode ? [{ debugName: "muestraReporteCombinado" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.atributosPanelReporte = computed(
      () => {
        const numero = this.muestraReporteCombinado()?.numeroMuestra;
        const filas = this.resultados()?.atributosPorMuestra.filter((a) => a.numeroMuestra === numero) ?? [];
        return atributosDeFicha(Object.fromEntries(filas.map((f) => [f.atributo, { intensidad: f.intensidadPromedio, calidad: f.calidadPromedio }])));
      },
      ...ngDevMode ? [{ debugName: "atributosPanelReporte" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.puntajesCatadoresReporte = computed(
      () => {
        const numero = this.muestraReporteCombinado()?.numeroMuestra;
        return (this.resultados()?.catadores ?? []).map((c) => ({
          nombre: c.nombre,
          ficha: c.puntajesPorMuestra.find((p) => p.numeroMuestra === numero) ?? null
        }));
      },
      ...ngDevMode ? [{ debugName: "puntajesCatadoresReporte" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.catadorExportar = computed(
      () => this.resultados()?.catadores.find((c) => c.cupperId === this.catadorExportarId()) ?? null,
      ...ngDevMode ? [{ debugName: "catadorExportar" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.fichaCatadorReporte = computed(
      () => {
        const numero = this.muestraReporteCombinado()?.numeroMuestra;
        return this.fichasDe(this.catadorExportar()).find((f) => f.numeroMuestra === numero) ?? null;
      },
      ...ngDevMode ? [{ debugName: "fichaCatadorReporte" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.tituloReporte = computed(
      () => {
        const r = this.resultados();
        if (!r)
          return "Reporte PacamaraQs";
        const partes = [this.esExtrinseco() ? "Ficha t\xE9cnica" : "Reporte SCA", r.nombreSesion, this.tituloFormato()];
        if (this.esCombinado()) {
          const muestra = this.muestraReporteCombinado()?.numeroMuestra;
          if (muestra)
            partes.push(`Muestra ${muestra}`);
          if (this.modoExportacion() === "catador" && this.catadorExportar())
            partes.push(this.catadorExportar().nombre);
        }
        return partes.filter(Boolean).join(" - ");
      },
      ...ngDevMode ? [{ debugName: "tituloReporte" }] : (
        /* istanbul ignore next */
        []
      )
    );
    addIcons({
      checkmarkCircleOutline,
      closeOutline,
      documentTextOutline,
      downloadOutline,
      lockClosedOutline,
      medalOutline,
      ribbonOutline,
      trophyOutline
    });
  }
  async ngOnInit() {
    const sesionId = this.route.snapshot.paramMap.get("id")?.trim() ?? "";
    if (!sesionId) {
      this.error.set("No se encontr\xF3 el ID de la sesi\xF3n.");
      this.cargando.set(false);
      return;
    }
    try {
      const resultados = await this.resultsService.obtenerResultadosSesion(sesionId);
      this.resultados.set(resultados);
      if (!resultados)
        this.error.set("No se encontraron resultados para esta sesi\xF3n.");
    } catch (error) {
      if (codigoDeError(error) === "42501")
        this.accesoDenegado.set(true);
      this.error.set(mensajeDeError(error, "No se pudieron cargar los resultados."));
    } finally {
      this.cargando.set(false);
    }
  }
  seleccionarMuestraMedidor(numeroMuestra) {
    this.muestraMedidorNumero.set(numeroMuestra);
  }
  seleccionarCatadorReporte(cupperId) {
    this.catadorReporteId.set(cupperId);
  }
  seleccionarMuestraDetalle(valor) {
    const n = Number(valor);
    if (Number.isFinite(n))
      this.muestraDetalleNumero.set(n);
  }
  /** Abre el modal; opcionalmente pre-seleccionado desde una ficha individual. */
  abrirExportar(opciones) {
    if (opciones) {
      this.muestraExportar.set(opciones.numeroMuestra);
      this.catadorExportarId.set(opciones.cupperId);
      this.modoExportacion.set("catador");
    } else {
      this.muestraExportar.set(this.muestraExportar() ?? this.muestraEnMedidor()?.numeroMuestra ?? null);
      this.catadorExportarId.set(this.catadorExportarId() ?? this.catadorReporte()?.cupperId ?? null);
    }
    this.modalExportarAbierto.set(true);
  }
  cerrarExportar() {
    this.modalExportarAbierto.set(false);
  }
  cambiarModoExportacion(valor) {
    if (valor === "panel" || valor === "catador")
      this.modoExportacion.set(valor);
  }
  cambiarMuestraExportar(valor) {
    const n = Number(valor);
    this.muestraExportar.set(Number.isFinite(n) ? n : null);
  }
  cambiarCatadorExportar(valor) {
    this.catadorExportarId.set(typeof valor === "string" ? valor : null);
  }
  async confirmarExportar() {
    this.cerrarExportar();
    await this.exportarPDF();
  }
  /**
   * Imprime el reporte del formato activo. El usuario elige "Guardar como
   * PDF" en el diálogo del navegador. Se espera un render para que la
   * plantilla oculta refleje la muestra / catador elegidos en el modal.
   */
  async exportarPDF() {
    if (!this.resultados() || this.imprimiendo())
      return;
    this.imprimiendo.set(true);
    this.fechaReporte.set(/* @__PURE__ */ new Date());
    try {
      await this.esperarRender();
      const contenedor = this.reporteImprimible()?.nativeElement;
      if (!contenedor)
        throw new Error("No se pudo preparar el reporte para imprimir.");
      await this.impresion.imprimir(this.tituloReporte(), contenedor.innerHTML);
    } catch (error) {
      const toast = await this.toastCtrl.create({
        message: mensajeDeError(error, "No se pudo generar el PDF."),
        duration: 3e3,
        color: "danger"
      });
      await toast.present();
    } finally {
      this.imprimiendo.set(false);
    }
  }
  volverAlPanel() {
    void this.navCtrl.navigateRoot("/dashboard");
  }
  fichasDe(catador) {
    return [...catador?.puntajesPorMuestra ?? []].sort((a, b) => a.numeroMuestra - b.numeroMuestra).map((p) => ({
      numeroMuestra: p.numeroMuestra,
      puntaje: p.puntaje,
      tazasNoUniformes: p.tazasNoUniformes,
      tazasDefectuosas: p.tazasDefectuosas,
      impresionGlobal: p.impresionGlobal,
      atributos: atributosDeFicha(p.atributos),
      clasificacion: clasificarPuntaje(p.puntaje)
    }));
  }
  esperarRender() {
    return new Promise((resolve) => afterNextRender(() => resolve(), { injector: this.injector }));
  }
};
_ResultsPage.\u0275fac = function ResultsPage_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _ResultsPage)();
};
_ResultsPage.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _ResultsPage, selectors: [["app-results"]], viewQuery: function ResultsPage_Query(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275viewQuerySignal(ctx.reporteImprimible, _c02, 5);
  }
  if (rf & 2) {
    \u0275\u0275queryAdvance();
  }
}, decls: 28, vars: 7, consts: [["medidor", ""], ["metaSesion", ""], ["participacion", ""], ["selectorMuestra", ""], ["reporteImprimible", ""], [1, "ion-no-border"], [1, "rs-toolbar"], ["slot", "start"], ["defaultHref", "/dashboard", "text", ""], [1, "rs-title"], [1, "rs-subtitle"], ["slot", "end"], ["fill", "outline", "size", "small", 3, "click", "disabled"], ["name", "download-outline", "slot", "start"], [1, "ion-padding", "rs-content"], [1, "rs-container"], ["role", "status", 1, "rs-center"], ["role", "alert", 1, "cupping-card", "rs-center"], [1, "rc-export-modal", 3, "isOpen"], ["hidden", "", "aria-hidden", "true"], [1, "rc-card", "rc-gauge"], ["viewBox", "0 0 200 112", "role", "img", 1, "rc-gauge__svg"], ["x", "100", "y", "22", "text-anchor", "middle", 1, "rc-gauge__tick"], [1, "rc-gauge__needle"], ["r", "6", 1, "rc-gauge__hub"], [1, "rc-gauge__value"], [1, "rc-gauge__label"], [1, "rc-card"], [1, "rs-meta"], [1, "rs-meta__status"], [1, "rs-meta__headline"], ["name", "checkmark-circle-outline", "aria-hidden", "true"], [1, "rs-meta__detail"], [1, "rs-meta__stats"], [1, "rs-section-title", "rc-section-title--tight"], [1, "rs-muted", "rs-note"], ["lines", "full", 1, "rx-list"], ["slot", "start", "aria-hidden", "true", 1, "rc-avatar"], [1, "rx-list__name"], ["slot", "end", 1, "rc-chip"], ["scrollable", "true", 1, "rx-samples", 3, "ionChange", "value"], [3, "value"], ["name", "crescent"], ["fill", "outline", 3, "click"], ["name", "lock-closed-outline", "aria-hidden", "true", 1, "rs-lock"], [1, "rc-grid-flush"], ["size", "12", "size-md", "6"], [4, "ngTemplateOutlet", "ngTemplateOutletContext"], [1, "rs-table-wrap"], [1, "rs-table", "rc-ranking"], ["scope", "col"], ["tabindex", "0", 1, "rc-ranking__row", 3, "rc-ranking__row--active"], [1, "rs-muted", "rs-note", "rc-note-bottom"], [1, "rc-block"], ["size", "12", "size-sm", "6", "size-lg", "4"], [1, "rs-formula"], [1, "rs-section-title"], [1, "rs-formula__expr"], [1, "rs-muted"], [1, "rs-actions"], [1, "primary-btn", 3, "click", "disabled"], ["tabindex", "0", 1, "rc-ranking__row", 3, "click", "keydown.enter", "keydown.space"], [1, "rs-rank"], ["aria-hidden", "true", 3, "name"], [1, "rc-ranking__name"], [1, "rc-chip", "rc-chip--live"], [1, "rs-tag"], [1, "rs-score"], [1, "rs-tag", 3, "title"], [1, "rc-chip"], ["colspan", "6", 1, "rs-muted"], ["type", "button", 1, "rc-cupper-select", 3, "click"], [3, "catador"], [1, "rc-report__head"], [1, "rc-report__who"], ["aria-hidden", "true", 1, "rc-avatar"], [1, "rc-report__name"], [1, "rc-report__meta"], [1, "rc-report__score"], [1, "rc-fichas", 3, "multiple"], [1, "rc-ficha", 3, "value"], ["slot", "header", "lines", "none", 1, "rc-ficha__header"], ["slot", "end", 1, "rc-ficha__score"], ["slot", "content", 1, "rc-ficha__body"], [1, "rc-ficha__row"], [1, "rc-ficha__row", "rc-ficha__row--total"], [1, "rc-ficha__actions"], ["size", "small", "fill", "outline", 3, "click"], [1, "rc-ficha__row", "rc-ficha__row--head"], [1, "rc-ficha__cols"], ["scope", "col", 1, "ra-col-bar"], [1, "ra-col-bar"], [1, "rx-bar-line"], [1, "rx-bar", "rx-bar--hedonic"], [1, "rc-chip", "ra-chip"], ["colspan", "5", 1, "rs-muted"], ["role", "list", 1, "rx-bars"], [1, "rx-bars__row"], ["role", "list", 1, "ra-dist"], [1, "ra-dist__row", 3, "ra-dist__row--empty"], [1, "ra-dist__total"], [1, "ra-dist__row"], [1, "ra-dist__value"], [1, "ra-dist__label"], [1, "ra-dist__count"], [1, "rx-bars__label"], [1, "rx-bars__value"], [1, "rs-table", "rd-matrix"], ["scope", "col", 1, "rd-matrix__num"], [1, "rd-head"], ["aria-hidden", "true", 1, "rd-scale"], [1, "rd-scale__ticks"], ["role", "list", 1, "rx-bars", "rd-bars"], [1, "rx-bar", "rx-bar--intensity", "rd-bar"], ["scope", "row"], [1, "rd-matrix__num"], [1, "rd-cell"], [1, "rc-card", "re-card"], [1, "re-head"], [1, "re-head__title"], ["name", "document-text-outline", "aria-hidden", "true"], ["size", "12", "size-md", "6", "size-xl", "4"], [1, "re-section"], [1, "re-certs"], [1, "re-dl"], [1, "rc-chip", "re-cert"], ["name", "ribbon-outline", "aria-hidden", "true"], [1, "re-notes"], [1, "rs-center"], ["name", "document-text-outline", "aria-hidden", "true", 1, "rs-lock"], [1, "cupping-card", "rs-meta"], [1, "cupping-card"], [1, "rs-table"], [1, "rs-grid"], [1, "primary-btn", 3, "click"], ["name", "trophy-outline", "aria-label", "Primer lugar"], [1, "rs-badge"], ["colspan", "4"], [1, "rc-export-modal", 3, "didDismiss", "isOpen"], [1, "rc-export"], [1, "rc-export__head"], ["fill", "clear", "size", "small", "aria-label", "Cerrar", 3, "click"], ["name", "close-outline", "slot", "icon-only"], ["for", "rc-export-muestra", 1, "rc-export__label"], ["id", "rc-export-muestra", "interface", "popover", "placeholder", "Selecciona una muestra", 1, "rc-export__select", 3, "ionChange", "value"], [1, "rc-export__segment", 3, "ionChange", "value"], ["value", "catador"], ["value", "panel"], ["expand", "block", 1, "primary-btn", "rc-export__go", 3, "click", "disabled"], [1, "rc-export__hint"], ["for", "rc-export-catador", 1, "rc-export__label"], ["id", "rc-export-catador", "interface", "popover", "placeholder", "Selecciona un catador", 1, "rc-export__select", 3, "ionChange", "value"], [1, "rp-head"], [1, "rp-brand"], [1, "rp-title"], [1, "rp-sub"], [1, "rp-meta"], [1, "rp-foot"], [1, "rp-section"], [1, "num"], [1, "rp-formula"], [1, "rp-muted"], [1, "rp-kpis"], [1, "rp-kpi"], ["colspan", "2", 1, "num"], ["colspan", "3", 1, "rp-muted"], [1, "num", "rp-score"], [1, "rp-badge"], [1, "rp-grid"], [2, "margin-top", "6px"], [2, "width", "8%"], [1, "rp-muted", 2, "width", "38%"], [1, "rp-bar"], [1, "num", 2, "width", "8%"], [1, "num", "rp-muted"], [2, "width", "38%"], [1, "num", 2, "width", "12%"], [3, "rp-page-break"], [1, "rp-chips"], [1, "rp-dl"]], template: function ResultsPage_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-header", 5)(1, "ion-toolbar", 6)(2, "ion-buttons", 7);
    \u0275\u0275element(3, "ion-back-button", 8);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "ion-title")(5, "div", 9);
    \u0275\u0275text(6);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "div", 10);
    \u0275\u0275text(8);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(9, "ion-buttons", 11)(10, "ion-button", 12);
    \u0275\u0275listener("click", function ResultsPage_Template_ion_button_click_10_listener() {
      return ctx.esCombinado() ? ctx.abrirExportar() : ctx.exportarPDF();
    });
    \u0275\u0275element(11, "ion-icon", 13);
    \u0275\u0275text(12, " Exportar PDF ");
    \u0275\u0275elementEnd()()()();
    \u0275\u0275template(13, ResultsPage_ng_template_13_Template, 15, 15, "ng-template", null, 0, \u0275\u0275templateRefExtractor)(15, ResultsPage_ng_template_15_Template, 24, 5, "ng-template", null, 1, \u0275\u0275templateRefExtractor)(17, ResultsPage_ng_template_17_Template, 9, 0, "ng-template", null, 2, \u0275\u0275templateRefExtractor)(19, ResultsPage_ng_template_19_Template, 3, 1, "ng-template", null, 3, \u0275\u0275templateRefExtractor);
    \u0275\u0275elementStart(21, "ion-content", 14)(22, "main", 15);
    \u0275\u0275conditionalCreate(23, ResultsPage_Conditional_23_Template, 2, 0, "div", 16)(24, ResultsPage_Conditional_24_Template, 6, 2, "section", 17)(25, ResultsPage_Conditional_25_Template, 5, 1);
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(26, ResultsPage_Conditional_26_Template, 2, 1, "ion-modal", 18);
    \u0275\u0275conditionalCreate(27, ResultsPage_Conditional_27_Template, 21, 10, "div", 19);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    let tmp_7_0;
    let tmp_9_0;
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate(ctx.esExtrinseco() ? "Ficha t\xE9cnica" : "Resultados finales");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate2("", ctx.resultados()?.nombreSesion, " \xB7 ", ctx.tituloFormato());
    \u0275\u0275advance(2);
    \u0275\u0275property("disabled", !ctx.resultados() || ctx.imprimiendo());
    \u0275\u0275advance(13);
    \u0275\u0275conditional(ctx.cargando() ? 23 : (tmp_7_0 = ctx.error()) ? 24 : (tmp_7_0 = ctx.resultados()) ? 25 : -1, tmp_7_0);
    \u0275\u0275advance(3);
    \u0275\u0275conditional(ctx.esCombinado() ? 26 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional((tmp_9_0 = ctx.resultados()) ? 27 : -1, tmp_9_0);
  }
}, dependencies: [
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonButton,
  IonBackButton,
  IonButtons,
  IonIcon,
  IonSpinner,
  IonCard,
  IonCardContent,
  IonGrid,
  IonRow,
  IonCol,
  IonBadge,
  IonList,
  IonAccordionGroup,
  IonAccordion,
  IonItem,
  IonLabel,
  IonModal,
  IonSegment,
  IonSegmentButton,
  IonSelect,
  IonSelectOption,
  CupperResultCardComponent,
  CommonModule,
  NgTemplateOutlet,
  DecimalPipe,
  DatePipe
], styles: ['@charset "UTF-8";\n\n\n.rs-toolbar[_ngcontent-%COMP%] {\n  --%NS%background: var(--%NS%app-bg-card);\n}\n.rs-title[_ngcontent-%COMP%] {\n  color: var(--%NS%app-text-main);\n  font-size: 15px;\n  font-weight: 700;\n}\n.rs-subtitle[_ngcontent-%COMP%] {\n  color: var(--%NS%app-text-muted);\n  font-size: 12px;\n  font-weight: 400;\n}\n.rs-content[_ngcontent-%COMP%] {\n  --%NS%background: var(--%NS%app-bg-screen);\n}\n.rs-container[_ngcontent-%COMP%] {\n  width: min(100%, 960px);\n  margin: 0 auto;\n  padding-bottom: 24px;\n}\n.rs-center[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  gap: 12px;\n  padding: 32px 16px;\n  text-align: center;\n}\n.rs-lock[_ngcontent-%COMP%] {\n  color: var(--%NS%app-text-muted);\n  font-size: 32px;\n}\n.rs-section-title[_ngcontent-%COMP%] {\n  margin: 0 0 12px;\n  color: var(--%NS%app-text-muted);\n  font-size: 11px;\n  font-weight: 700;\n  letter-spacing: 0.05em;\n  text-transform: uppercase;\n}\n.rs-muted[_ngcontent-%COMP%] {\n  color: var(--%NS%app-text-muted);\n}\n.rs-note[_ngcontent-%COMP%] {\n  margin: 0 0 12px;\n  font-size: 12px;\n}\n.rs-meta[_ngcontent-%COMP%] {\n  display: flex;\n  flex-wrap: wrap;\n  align-items: center;\n  justify-content: space-between;\n  gap: 16px;\n}\n.rs-meta__headline[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  margin: 0;\n  color: var(--%NS%app-text-main);\n  font-weight: 600;\n}\n.rs-meta__detail[_ngcontent-%COMP%] {\n  margin: 6px 0 0;\n  color: var(--%NS%app-text-muted);\n  font-size: 13px;\n}\n.rs-meta__stats[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 24px;\n  text-align: center;\n}\n.rs-meta__stats[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%] {\n  display: block;\n  color: var(--%NS%app-text-main);\n  font-size: 16px;\n}\n.rs-meta__stats[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  color: var(--%NS%app-text-muted);\n  font-size: 11px;\n}\n.rs-table-wrap[_ngcontent-%COMP%] {\n  overflow-x: auto;\n}\n.rs-table[_ngcontent-%COMP%] {\n  width: 100%;\n  border-collapse: collapse;\n  font-size: 13px;\n}\n.rs-table[_ngcontent-%COMP%]   th[_ngcontent-%COMP%], \n.rs-table[_ngcontent-%COMP%]   td[_ngcontent-%COMP%] {\n  padding: 10px 8px;\n  border-bottom: 1px solid var(--%NS%app-border);\n  text-align: left;\n  white-space: nowrap;\n}\n.rs-table[_ngcontent-%COMP%]   thead[_ngcontent-%COMP%]   th[_ngcontent-%COMP%] {\n  color: var(--%NS%app-text-muted);\n  font-size: 11px;\n  font-weight: 600;\n  text-transform: uppercase;\n}\n.rs-table[_ngcontent-%COMP%]   tfoot[_ngcontent-%COMP%]   td[_ngcontent-%COMP%] {\n  color: var(--%NS%app-text-muted);\n  font-weight: 600;\n}\n.rs-rank[_ngcontent-%COMP%] {\n  color: var(--%NS%app-text-muted);\n}\n.rs-rank[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  color: #ca8a04;\n  vertical-align: middle;\n}\n.rs-score[_ngcontent-%COMP%] {\n  color: var(--%NS%app-score);\n  font-size: 15px;\n  font-weight: 700;\n}\n.rs-tag[_ngcontent-%COMP%] {\n  margin-left: 6px;\n  padding: 2px 6px;\n  border-radius: 4px;\n  background: var(--%NS%app-bg-subtle);\n  color: var(--%NS%app-text-muted);\n  font-size: 10px;\n  font-weight: 500;\n}\n.rs-badge[_ngcontent-%COMP%] {\n  display: inline-block;\n  padding: 3px 8px;\n  border-radius: 6px;\n  font-size: 11px;\n  font-weight: 600;\n}\n.rs-grid[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));\n  gap: 12px;\n  margin-bottom: 16px;\n}\n.rs-formula[_ngcontent-%COMP%] {\n  margin-bottom: 16px;\n  padding: 16px;\n  border-radius: var(--%NS%app-radius-card);\n  background: var(--%NS%app-bg-subtle);\n}\n.rs-formula__expr[_ngcontent-%COMP%] {\n  margin: 0 0 8px;\n  color: var(--%NS%app-text-main);\n  font-family: var(--%NS%app-font-mono);\n  font-size: 14px;\n}\n.rs-actions[_ngcontent-%COMP%] {\n  display: flex;\n  flex-wrap: wrap;\n  justify-content: flex-end;\n  gap: 12px;\n}\n[_nghost-%COMP%] {\n  --%NS%rc-gauge-bajo: #e53935;\n  --%NS%rc-gauge-medio: #f5b400;\n  --%NS%rc-gauge-alto: #8fdc6a;\n  --%NS%rc-gauge-top: #12a150;\n  --%NS%rc-row-active: #fbe9e4;\n  --%NS%rc-medal-1: #ca8a04;\n  --%NS%rc-medal-2: #94a3b8;\n  --%NS%rc-medal-3: #b45309;\n}\n.rc-card[_ngcontent-%COMP%] {\n  margin: 0 0 16px;\n  border: 1px solid var(--%NS%app-border);\n  border-radius: var(--%NS%app-radius-card);\n  background: var(--%NS%app-bg-card);\n  box-shadow: none;\n}\n.rc-card[_ngcontent-%COMP%]   ion-card-content[_ngcontent-%COMP%] {\n  padding: 16px;\n}\n.rc-grid-flush[_ngcontent-%COMP%] {\n  --%NS%ion-grid-padding: 0;\n  margin: 0 -5px;\n}\n.rc-grid-flush[_ngcontent-%COMP%]   ion-col[_ngcontent-%COMP%] {\n  --%NS%ion-grid-column-padding: 5px;\n}\n.rc-grid-flush[_ngcontent-%COMP%]   .rc-card[_ngcontent-%COMP%] {\n  height: calc(100% - 10px);\n  margin-bottom: 10px;\n}\n.rc-section-title--tight[_ngcontent-%COMP%] {\n  margin-bottom: 4px;\n}\n.rc-note-bottom[_ngcontent-%COMP%] {\n  margin: 12px 0 0;\n}\n.rc-block[_ngcontent-%COMP%] {\n  margin-bottom: 16px;\n}\n.rc-gauge[_ngcontent-%COMP%]   ion-card-content[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  padding: 16px 16px 12px;\n}\n.rc-gauge__svg[_ngcontent-%COMP%] {\n  width: min(100%, 220px);\n  height: auto;\n  overflow: visible;\n}\n.rc-gauge__arc[_ngcontent-%COMP%] {\n  fill: none;\n  stroke-width: 22;\n}\n.rc-gauge__arc--bajo[_ngcontent-%COMP%] {\n  stroke: var(--%NS%rc-gauge-bajo);\n}\n.rc-gauge__arc--medio[_ngcontent-%COMP%] {\n  stroke: var(--%NS%rc-gauge-medio);\n}\n.rc-gauge__arc--alto[_ngcontent-%COMP%] {\n  stroke: var(--%NS%rc-gauge-alto);\n}\n.rc-gauge__arc--top[_ngcontent-%COMP%] {\n  stroke: var(--%NS%rc-gauge-top);\n}\n.rc-gauge__tick[_ngcontent-%COMP%] {\n  fill: var(--%NS%app-text-muted);\n  font-size: 9px;\n}\n.rc-gauge__needle[_ngcontent-%COMP%] {\n  stroke: var(--%NS%app-text-main);\n  stroke-width: 4;\n  stroke-linecap: round;\n  transition: all 0.4s ease;\n}\n.rc-gauge__hub[_ngcontent-%COMP%] {\n  fill: var(--%NS%app-text-main);\n}\n.rc-gauge__value[_ngcontent-%COMP%] {\n  margin: 8px 0 2px;\n  color: var(--%NS%app-score);\n  font-size: 22px;\n  font-weight: 700;\n}\n.rc-gauge__label[_ngcontent-%COMP%] {\n  margin: 0;\n  color: var(--%NS%app-text-muted);\n  font-size: 10px;\n  letter-spacing: 0.04em;\n  text-align: center;\n  text-transform: uppercase;\n}\n.rc-ranking__row[_ngcontent-%COMP%] {\n  cursor: pointer;\n  transition: background-color 0.15s ease;\n}\n.rc-ranking__row[_ngcontent-%COMP%]:hover {\n  background: var(--%NS%app-bg-subtle);\n}\n.rc-ranking__row[_ngcontent-%COMP%]:focus-visible {\n  outline: 2px solid var(--%NS%app-primary-dark);\n  outline-offset: -2px;\n}\n.rc-ranking__row--active[_ngcontent-%COMP%], \n.rc-ranking__row--%NS%active[_ngcontent-%COMP%]:hover {\n  background: var(--%NS%rc-row-active);\n}\n.rc-ranking__name[_ngcontent-%COMP%] {\n  color: var(--%NS%app-text-main);\n  font-weight: 600;\n}\n.rc-medal[_ngcontent-%COMP%] {\n  margin-right: 2px;\n  vertical-align: middle;\n}\n.rc-medal--1[_ngcontent-%COMP%] {\n  color: var(--%NS%rc-medal-1);\n}\n.rc-medal--2[_ngcontent-%COMP%] {\n  color: var(--%NS%rc-medal-2);\n}\n.rc-medal--3[_ngcontent-%COMP%] {\n  color: var(--%NS%rc-medal-3);\n}\n.rc-medal--n[_ngcontent-%COMP%] {\n  color: var(--%NS%app-text-faint);\n}\n.rc-chip[_ngcontent-%COMP%] {\n  --%NS%padding-top: 3px;\n  --%NS%padding-bottom: 3px;\n  --%NS%padding-start: 8px;\n  --%NS%padding-end: 8px;\n  border-radius: 6px;\n  font-size: 11px;\n  font-weight: 600;\n}\n.rc-chip--live[_ngcontent-%COMP%] {\n  --%NS%background: #dcfce7;\n  --%NS%color: var(--%NS%app-success);\n  margin-left: 6px;\n  font-size: 10px;\n  font-weight: 500;\n}\n.rc-cupper-select[_ngcontent-%COMP%] {\n  display: block;\n  width: 100%;\n  height: 100%;\n  padding: 0;\n  border: 2px solid transparent;\n  border-radius: calc(var(--%NS%app-radius-card) + 2px);\n  background: none;\n  font: inherit;\n  text-align: inherit;\n  cursor: pointer;\n  transition: border-color 0.15s ease;\n}\n.rc-cupper-select[_ngcontent-%COMP%]:hover {\n  border-color: var(--%NS%app-border);\n}\n.rc-cupper-select[_ngcontent-%COMP%]:focus-visible {\n  outline: 2px solid var(--%NS%app-primary-dark);\n  outline-offset: 2px;\n}\n.rc-cupper-select--active[_ngcontent-%COMP%], \n.rc-cupper-select--%NS%active[_ngcontent-%COMP%]:hover {\n  border-color: var(--%NS%app-primary-dark);\n}\n.rc-report__head[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  gap: 12px;\n  margin: 8px 0 12px;\n  padding-bottom: 12px;\n  border-bottom: 1px solid var(--%NS%app-border);\n}\n.rc-report__who[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  min-width: 0;\n}\n.rc-avatar[_ngcontent-%COMP%] {\n  display: inline-flex;\n  flex: 0 0 32px;\n  align-items: center;\n  justify-content: center;\n  width: 32px;\n  height: 32px;\n  border: 1px solid var(--%NS%app-border);\n  border-radius: 50%;\n  background: var(--%NS%app-bg-subtle);\n  color: var(--%NS%app-text-main);\n  font-size: 13px;\n  font-weight: 700;\n}\n.rc-report__name[_ngcontent-%COMP%] {\n  margin: 0;\n  color: var(--%NS%app-text-main);\n  font-weight: 600;\n}\n.rc-report__meta[_ngcontent-%COMP%] {\n  margin: 2px 0 0;\n  color: var(--%NS%app-text-muted);\n  font-size: 11px;\n}\n.rc-report__score[_ngcontent-%COMP%] {\n  text-align: right;\n}\n.rc-report__score[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%] {\n  display: block;\n  color: var(--%NS%app-text-main);\n  font-size: 20px;\n}\n.rc-report__score[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  color: var(--%NS%app-text-muted);\n  font-size: 9px;\n  text-transform: uppercase;\n}\n.rc-fichas[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 8px;\n}\n.rc-ficha[_ngcontent-%COMP%] {\n  overflow: hidden;\n  border-radius: var(--%NS%app-radius-control);\n  background: var(--%NS%app-bg-subtle);\n}\n.rc-ficha__header[_ngcontent-%COMP%] {\n  --%NS%background: var(--%NS%app-bg-subtle);\n  --%NS%min-height: 40px;\n  font-size: 13px;\n  font-weight: 600;\n}\n.rc-ficha__header[_ngcontent-%COMP%]   ion-badge[_ngcontent-%COMP%] {\n  margin-inline-end: 8px;\n}\n.rc-ficha__score[_ngcontent-%COMP%] {\n  color: var(--%NS%app-score);\n  font-size: 13px;\n  font-weight: 700;\n}\n.rc-ficha__body[_ngcontent-%COMP%] {\n  padding: 4px 16px 12px;\n  background: var(--%NS%app-bg-subtle);\n}\n.rc-ficha__row[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  padding: 6px 0;\n  border-bottom: 1px solid var(--%NS%app-border);\n  color: var(--%NS%app-text-main);\n  font-size: 13px;\n}\n.rc-ficha__row--total[_ngcontent-%COMP%] {\n  border-bottom: none;\n}\n.rc-ficha__row--total[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  font-weight: 600;\n}\n.rc-ficha__row--total[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%] {\n  color: var(--%NS%app-score);\n}\n.rc-ficha__actions[_ngcontent-%COMP%] {\n  display: flex;\n  flex-wrap: wrap;\n  gap: 8px;\n  margin-top: 4px;\n}\n.rc-export-modal[_ngcontent-%COMP%] {\n  --%NS%width: min(92vw, 360px);\n  --%NS%height: auto;\n  --%NS%border-radius: var(--%NS%app-radius-card);\n}\n.rc-export[_ngcontent-%COMP%] {\n  padding: 16px;\n}\n.rc-export__head[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  margin-bottom: 12px;\n}\n.rc-export__head[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n  margin: 0;\n  color: var(--%NS%app-text-main);\n  font-size: 15px;\n  font-weight: 700;\n}\n.rc-export__label[_ngcontent-%COMP%] {\n  display: block;\n  margin: 0 0 6px;\n  color: var(--%NS%app-text-main);\n  font-size: 12px;\n  font-weight: 600;\n}\n.rc-export__select[_ngcontent-%COMP%] {\n  margin-bottom: 12px;\n  padding: 0 12px;\n  border: 1px solid var(--%NS%app-border-input);\n  border-radius: var(--%NS%app-radius-control);\n  font-size: 13px;\n}\n.rc-export__segment[_ngcontent-%COMP%] {\n  --%NS%background: transparent;\n  gap: 8px;\n  margin-bottom: 12px;\n}\n.rc-export__segment[_ngcontent-%COMP%]   ion-segment-button[_ngcontent-%COMP%] {\n  --%NS%background: var(--%NS%app-bg-subtle);\n  --%NS%background-checked: var(--%NS%app-primary-dark);\n  --%NS%color: var(--%NS%app-text-main);\n  --%NS%color-checked: #ffffff;\n  --%NS%indicator-color: transparent;\n  --%NS%border-radius: var(--%NS%app-radius-control);\n  min-height: 38px;\n  border: 1px solid var(--%NS%app-border);\n  border-radius: var(--%NS%app-radius-control);\n  font-size: 13px;\n  text-transform: none;\n}\n.rc-export__go[_ngcontent-%COMP%] {\n  margin: 4px 0 0;\n}\n@media (max-width: 576px) {\n  .rs-meta__stats[_ngcontent-%COMP%] {\n    gap: 16px;\n  }\n  .rc-report__score[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%] {\n    font-size: 18px;\n  }\n}\n.rc-export__hint[_ngcontent-%COMP%] {\n  margin: 8px 0 0;\n  color: var(--%NS%app-text-muted);\n  font-size: 11px;\n  text-align: center;\n}\n.rc-ficha__row--head[_ngcontent-%COMP%] {\n  color: var(--%NS%app-text-muted);\n  font-size: 11px;\n  text-transform: uppercase;\n}\n.rc-ficha__cols[_ngcontent-%COMP%] {\n  display: inline-grid;\n  grid-template-columns: 72px 64px;\n  text-align: right;\n}\n.rc-ficha__cols[_ngcontent-%COMP%]   em[_ngcontent-%COMP%] {\n  font-style: normal;\n}\n[_nghost-%COMP%] {\n  --%NS%rx-hedonic: #b45309;\n  --%NS%rx-intensity: var(--%NS%app-primary-dark);\n  --%NS%rx-track: var(--%NS%app-bg-subtle);\n}\n.rx-bar[_ngcontent-%COMP%] {\n  position: relative;\n  flex: 1 1 auto;\n  min-width: 40px;\n  height: 10px;\n  overflow: hidden;\n  border-radius: 999px;\n  background: var(--%NS%rx-track);\n}\n.rx-bar[_ngcontent-%COMP%]   i[_ngcontent-%COMP%] {\n  position: absolute;\n  inset: 0 auto 0 0;\n  border-radius: inherit;\n  transition: width 0.35s ease;\n}\n.rx-bar--hedonic[_ngcontent-%COMP%]   i[_ngcontent-%COMP%] {\n  background: var(--%NS%rx-hedonic);\n}\n.rx-bar--intensity[_ngcontent-%COMP%]   i[_ngcontent-%COMP%] {\n  background: var(--%NS%rx-intensity);\n}\n.rx-bars[_ngcontent-%COMP%] {\n  margin: 0;\n  padding: 0;\n  list-style: none;\n}\n.rx-bars__row[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: minmax(96px, 34%) 1fr 40px;\n  align-items: center;\n  gap: 10px;\n  padding: 7px 0;\n  border-bottom: 1px solid var(--%NS%app-border);\n  font-size: 13px;\n}\n.rx-bars__row[_ngcontent-%COMP%]:last-child {\n  border-bottom: none;\n}\n.rx-bars__label[_ngcontent-%COMP%] {\n  color: var(--%NS%app-text-main);\n}\n.rx-bars__value[_ngcontent-%COMP%] {\n  color: var(--%NS%app-text-main);\n  font-variant-numeric: tabular-nums;\n  text-align: right;\n}\n.rx-bar-line[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  min-width: 160px;\n}\n.rx-samples[_ngcontent-%COMP%] {\n  --%NS%background: transparent;\n  margin: 0 0 12px;\n}\n.rx-samples[_ngcontent-%COMP%]   ion-segment-button[_ngcontent-%COMP%] {\n  --%NS%background: var(--%NS%app-bg-card);\n  --%NS%background-checked: var(--%NS%app-primary-dark);\n  --%NS%color: var(--%NS%app-text-main);\n  --%NS%color-checked: #ffffff;\n  --%NS%indicator-color: transparent;\n  --%NS%border-radius: 999px;\n  flex: 0 0 auto;\n  min-width: 104px;\n  min-height: 32px;\n  margin-right: 6px;\n  border: 1px solid var(--%NS%app-border);\n  border-radius: 999px;\n  font-size: 12px;\n  text-transform: none;\n}\n.rx-list[_ngcontent-%COMP%] {\n  margin: 0 -16px -16px;\n  background: transparent;\n}\n.rx-list[_ngcontent-%COMP%]   ion-item[_ngcontent-%COMP%] {\n  --%NS%background: transparent;\n  --%NS%padding-start: 16px;\n  --%NS%inner-padding-end: 16px;\n}\n.rx-list[_ngcontent-%COMP%]   .rc-avatar[_ngcontent-%COMP%] {\n  margin-inline-end: 12px;\n}\n.rx-list__name[_ngcontent-%COMP%] {\n  color: var(--%NS%app-text-main);\n  font-size: 14px;\n  font-weight: 600;\n}\n.rx-list[_ngcontent-%COMP%]   ion-label[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  color: var(--%NS%app-text-muted);\n  font-size: 12px;\n}\n.rx-chip--ok[_ngcontent-%COMP%] {\n  --%NS%background: #dcfce7;\n  --%NS%color: var(--%NS%app-success);\n}\n.rx-chip--pending[_ngcontent-%COMP%] {\n  --%NS%background: var(--%NS%app-bg-subtle);\n  --%NS%color: var(--%NS%app-text-muted);\n}\n.ra-col-bar[_ngcontent-%COMP%] {\n  width: 38%;\n}\n.ra-chip[_ngcontent-%COMP%] {\n  --%NS%background: #fef3c7;\n  --%NS%color: #92400e;\n}\n.ra-dist[_ngcontent-%COMP%] {\n  margin: 0;\n  padding: 0;\n  list-style: none;\n}\n.ra-dist__row[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: 22px minmax(110px, 40%) 1fr 28px;\n  align-items: center;\n  gap: 8px;\n  padding: 5px 0;\n  font-size: 13px;\n}\n.ra-dist__row--empty[_ngcontent-%COMP%] {\n  opacity: 0.55;\n}\n.ra-dist__value[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  width: 22px;\n  height: 22px;\n  border-radius: 6px;\n  background: var(--%NS%app-bg-subtle);\n  color: var(--%NS%app-text-main);\n  font-size: 12px;\n  font-weight: 700;\n}\n.ra-dist__label[_ngcontent-%COMP%] {\n  color: var(--%NS%app-text-muted);\n  font-size: 12px;\n}\n.ra-dist__count[_ngcontent-%COMP%] {\n  color: var(--%NS%app-text-main);\n  text-align: right;\n  font-variant-numeric: tabular-nums;\n}\n.ra-dist__total[_ngcontent-%COMP%] {\n  margin: 10px 0 0;\n  padding-top: 10px;\n  border-top: 1px solid var(--%NS%app-border);\n  color: var(--%NS%app-text-muted);\n  font-size: 12px;\n}\n.rd-scale[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: minmax(96px, 34%) 1fr 40px;\n  gap: 10px;\n  color: var(--%NS%app-text-faint);\n  font-size: 10px;\n}\n.rd-scale__ticks[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n}\n.rd-scale__ticks[_ngcontent-%COMP%]   em[_ngcontent-%COMP%] {\n  font-style: normal;\n}\n.rd-bar[_ngcontent-%COMP%] {\n  height: 12px;\n  background-image:\n    linear-gradient(\n      90deg,\n      transparent calc(33.33% - 1px),\n      var(--%NS%app-border) calc(33.33% - 1px),\n      var(--%NS%app-border) 33.33%,\n      transparent 33.33%,\n      transparent calc(66.66% - 1px),\n      var(--%NS%app-border) calc(66.66% - 1px),\n      var(--%NS%app-border) 66.66%,\n      transparent 66.66%);\n}\n.rd-matrix[_ngcontent-%COMP%]   th[scope=row][_ngcontent-%COMP%] {\n  color: var(--%NS%app-text-main);\n  font-size: 13px;\n  font-weight: 500;\n  text-transform: none;\n}\n.rd-matrix__num[_ngcontent-%COMP%] {\n  text-align: center !important;\n}\n.rd-cell[_ngcontent-%COMP%] {\n  --%NS%rd-alpha: 0;\n  display: inline-block;\n  min-width: 44px;\n  padding: 3px 8px;\n  border-radius: 6px;\n  background: rgba(47, 62, 70, calc(var(--%NS%rd-alpha) * 0.85));\n  color: var(--%NS%app-text-main);\n  font-variant-numeric: tabular-nums;\n  font-weight: 600;\n}\n.rd-cell--dark[_ngcontent-%COMP%] {\n  color: #ffffff;\n}\n.re-head[_ngcontent-%COMP%] {\n  margin-bottom: 12px;\n  padding-bottom: 12px;\n  border-bottom: 1px solid var(--%NS%app-border);\n}\n.re-head__title[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: flex-start;\n  gap: 10px;\n}\n.re-head__title[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  flex: 0 0 auto;\n  margin-top: 2px;\n  color: var(--%NS%app-primary-dark);\n  font-size: 22px;\n}\n.re-head__title[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n  margin: 0;\n  color: var(--%NS%app-text-main);\n  font-size: 16px;\n  font-weight: 700;\n}\n.re-head__title[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  margin: 2px 0 0;\n  font-size: 12px;\n}\n.re-section[_ngcontent-%COMP%] {\n  margin-bottom: 12px;\n}\n.re-dl[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: minmax(110px, 42%) 1fr;\n  margin: 0;\n  font-size: 13px;\n}\n.re-dl[_ngcontent-%COMP%]   dt[_ngcontent-%COMP%], \n.re-dl[_ngcontent-%COMP%]   dd[_ngcontent-%COMP%] {\n  margin: 0;\n  padding: 6px 0;\n  border-bottom: 1px solid var(--%NS%app-border);\n}\n.re-dl[_ngcontent-%COMP%]   dt[_ngcontent-%COMP%] {\n  padding-right: 8px;\n  color: var(--%NS%app-text-muted);\n}\n.re-dl[_ngcontent-%COMP%]   dd[_ngcontent-%COMP%] {\n  color: var(--%NS%app-text-main);\n  font-weight: 500;\n  overflow-wrap: anywhere;\n}\n.re-dl__empty[_ngcontent-%COMP%] {\n  color: var(--%NS%app-text-faint) !important;\n  font-weight: 400 !important;\n}\n.re-certs[_ngcontent-%COMP%] {\n  display: flex;\n  flex-wrap: wrap;\n  gap: 6px;\n}\n.re-cert[_ngcontent-%COMP%] {\n  --%NS%background: #ecfdf5;\n  --%NS%color: #047857;\n  display: inline-flex;\n  align-items: center;\n  gap: 4px;\n  font-size: 12px;\n}\n.re-notes[_ngcontent-%COMP%] {\n  margin: 0;\n  color: var(--%NS%app-text-main);\n  font-size: 13px;\n  white-space: pre-line;\n}\n@media (max-width: 576px) {\n  .rx-bars__row[_ngcontent-%COMP%], \n   .rd-scale[_ngcontent-%COMP%] {\n    grid-template-columns: minmax(84px, 38%) 1fr 34px;\n    gap: 8px;\n  }\n  .ra-dist__row[_ngcontent-%COMP%] {\n    grid-template-columns: 22px 1fr 34px;\n  }\n  .ra-dist__label[_ngcontent-%COMP%] {\n    display: none;\n  }\n  .rx-bar-line[_ngcontent-%COMP%] {\n    min-width: 120px;\n  }\n  .re-dl[_ngcontent-%COMP%] {\n    grid-template-columns: 1fr;\n  }\n  .re-dl[_ngcontent-%COMP%]   dt[_ngcontent-%COMP%] {\n    padding-bottom: 0;\n    border-bottom: none;\n    font-size: 11px;\n  }\n}\n/*# sourceMappingURL=results.page.css.map */'] });
var ResultsPage = _ResultsPage;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ResultsPage, [{
    type: Component,
    args: [{ selector: "app-results", standalone: true, imports: [
      IonHeader,
      IonToolbar,
      IonTitle,
      IonContent,
      IonButton,
      IonBackButton,
      IonButtons,
      IonIcon,
      IonSpinner,
      IonCard,
      IonCardContent,
      IonGrid,
      IonRow,
      IonCol,
      IonBadge,
      IonList,
      IonAccordionGroup,
      IonAccordion,
      IonItem,
      IonLabel,
      IonModal,
      IonSegment,
      IonSegmentButton,
      IonSelect,
      IonSelectOption,
      CupperResultCardComponent,
      CommonModule
    ], template: `<ion-header class="ion-no-border">
  <ion-toolbar class="rs-toolbar">
    <ion-buttons slot="start">
      <ion-back-button defaultHref="/dashboard" text=""></ion-back-button>
    </ion-buttons>
    <ion-title>
      <div class="rs-title">{{ esExtrinseco() ? 'Ficha t\xE9cnica' : 'Resultados finales' }}</div>
      <div class="rs-subtitle">{{ resultados()?.nombreSesion }} \xB7 {{ tituloFormato() }}</div>
    </ion-title>
    <ion-buttons slot="end">
      <ion-button fill="outline" size="small" [disabled]="!resultados() || imprimiendo()"
        (click)="esCombinado() ? abrirExportar() : exportarPDF()">
        <ion-icon name="download-outline" slot="start"></ion-icon>
        Exportar PDF
      </ion-button>
    </ion-buttons>
  </ion-toolbar>
</ion-header>

<!-- Medidor semicircular reutilizable (escala 0\u2013100) -->
<ng-template #medidor let-valor="valor" let-aguja="aguja" let-etiqueta="etiqueta">
  <ion-card class="rc-card rc-gauge">
    <ion-card-content>
      <svg class="rc-gauge__svg" viewBox="0 0 200 112" role="img" [attr.aria-label]="etiqueta + ': ' + (valor | number:'1.2-2')">
        @for (a of arcosMedidor; track a.clase) {
          <path [attr.d]="a.d" [attr.class]="'rc-gauge__arc ' + a.clase"></path>
        }
        <text x="100" y="22" text-anchor="middle" class="rc-gauge__tick">50</text>
        <line class="rc-gauge__needle" [attr.x1]="centroMedidor.x" [attr.y1]="centroMedidor.y"
          [attr.x2]="aguja.x" [attr.y2]="aguja.y"></line>
        <circle class="rc-gauge__hub" [attr.cx]="centroMedidor.x" [attr.cy]="centroMedidor.y" r="6"></circle>
      </svg>
      <p class="rc-gauge__value">{{ valor | number:'1.2-2' }}</p>
      <p class="rc-gauge__label">{{ etiqueta }}</p>
    </ion-card-content>
  </ion-card>
</ng-template>

<!-- Estado de la sesi\xF3n (Afectivo / Descriptivo) -->
<ng-template #metaSesion let-r="r" let-detalle="detalle">
  <ion-card class="rc-card">
    <ion-card-content class="rs-meta">
      <div class="rs-meta__status">
        <p class="rs-meta__headline">
          <ion-icon name="checkmark-circle-outline" aria-hidden="true"></ion-icon>
          Sesi\xF3n cerrada \xB7 {{ porcentajeCompletado() }}% completada
        </p>
        <p class="rs-meta__detail">{{ detalle }}</p>
      </div>
      <div class="rs-meta__stats">
        <div><strong>{{ r.totalMuestras }}</strong><span>Muestras</span></div>
        <div><strong>{{ r.catadores.length }}</strong><span>Catadores</span></div>
        <div><strong>{{ tituloFormato() }}</strong><span>Formato</span></div>
      </div>
    </ion-card-content>
  </ion-card>
</ng-template>

<!-- Participaci\xF3n sin puntajes (Afectivo / Descriptivo) -->
<ng-template #participacion let-r="r">
  <ion-card class="rc-card">
    <ion-card-content>
      <h2 class="rs-section-title rc-section-title--tight">Participaci\xF3n del panel</h2>
      <p class="rs-muted rs-note">Fichas enviadas por cada catador.</p>
      <ion-list lines="full" class="rx-list">
        @for (c of r.catadores; track c.cupperId) {
          <ion-item>
            <span slot="start" class="rc-avatar" aria-hidden="true">{{ c.nombre.charAt(0).toUpperCase() }}</span>
            <ion-label>
              <h3 class="rx-list__name">{{ c.nombre }}</h3>
              <p>{{ c.esOrganizador ? 'Organizador' : 'Catador' }} \xB7 {{ c.muestrasEvaluadas }} / {{ c.muestrasAsignadas }} muestras</p>
            </ion-label>
            <ion-badge slot="end" class="rc-chip" [class.rx-chip--ok]="c.estado === 'enviado'" [class.rx-chip--pending]="c.estado !== 'enviado'">
              {{ c.estado === 'enviado' ? 'Enviado' : 'Pendiente' }}
            </ion-badge>
          </ion-item>
        }
      </ion-list>
    </ion-card-content>
  </ion-card>
</ng-template>

<!-- Selector de muestra (Afectivo / Descriptivo) -->
<ng-template #selectorMuestra let-actual="actual">
  <ion-segment class="rx-samples" scrollable="true" [value]="actual" (ionChange)="seleccionarMuestraDetalle($event.detail.value)">
    @for (n of numerosMuestra(); track n) {
      <ion-segment-button [value]="n"><ion-label>Muestra {{ n }}</ion-label></ion-segment-button>
    }
  </ion-segment>
</ng-template>

<ion-content class="ion-padding rs-content">
  <main class="rs-container">
    @if (cargando()) {
      <div class="rs-center" role="status"><ion-spinner name="crescent"></ion-spinner></div>
    } @else if (error(); as mensaje) {
      <section class="cupping-card rs-center" role="alert">
        @if (accesoDenegado()) {
          <ion-icon name="lock-closed-outline" class="rs-lock" aria-hidden="true"></ion-icon>
          <h2>Resultados reservados al organizador</h2>
        }
        <p>{{ mensaje }}</p>
        <ion-button fill="outline" (click)="volverAlPanel()">Volver al panel</ion-button>
      </section>
    } @else if (resultados(); as r) {
      @if (esCombinado()) {
        <!-- \u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550 FORMATO COMBINADO \u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550 -->

        <!-- Medidores -->
        <ion-grid class="rc-grid-flush">
          <ion-row>
            <ion-col size="12" size-md="6">
              <ng-container *ngTemplateOutlet="medidor; context: {
                valor: promedioPanel(), aguja: agujaPanel(), etiqueta: 'Promedio puntaje del panel' }"></ng-container>
            </ion-col>
            <ion-col size="12" size-md="6">
              <ng-container *ngTemplateOutlet="medidor; context: {
                valor: muestraEnMedidor()?.puntajePromedioPanel ?? 0,
                aguja: agujaMuestra(),
                etiqueta: 'Promedio del panel por muestra \xB7 Muestra ' + (muestraEnMedidor()?.numeroMuestra ?? '\u2014') }"></ng-container>
            </ion-col>
          </ion-row>
        </ion-grid>

        <!-- Estado de la sesi\xF3n -->
        <ng-container *ngTemplateOutlet="metaSesion; context: { r: r, detalle: hayRecorte()
          ? 'Consolidaci\xF3n mediante promedio recortado SCA (se descartan m\xE1ximo y m\xEDnimo con 5 o m\xE1s catadores).'
          : 'Consolidaci\xF3n mediante promedio simple (menos de 5 fichas por muestra).' }"></ng-container>

        <!-- Ranking -->
        <ion-card class="rc-card">
          <ion-card-content>
            <h2 class="rs-section-title rc-section-title--tight">Ranking \u2014 promedio del panel</h2>
            <p class="rs-muted rs-note">Haz clic en una muestra para ver su promedio del panel en el medidor.</p>
            <div class="rs-table-wrap">
              <table class="rs-table rc-ranking">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Muestra</th>
                    <th scope="col">Fichas</th>
                    <th scope="col">M\xEDn \u2013 M\xE1x</th>
                    <th scope="col">Puntaje panel</th>
                    <th scope="col">Clasificaci\xF3n</th>
                  </tr>
                </thead>
                <tbody>
                  @for (fila of ranking(); track fila.numeroMuestra) {
                    @let activa = fila.numeroMuestra === muestraEnMedidor()?.numeroMuestra;
                    <tr class="rc-ranking__row" [class.rc-ranking__row--active]="activa"
                      tabindex="0" [attr.aria-selected]="activa"
                      (click)="seleccionarMuestraMedidor(fila.numeroMuestra)"
                      (keydown.enter)="seleccionarMuestraMedidor(fila.numeroMuestra)"
                      (keydown.space)="$event.preventDefault(); seleccionarMuestraMedidor(fila.numeroMuestra)">
                      <td class="rs-rank">
                        <ion-icon [name]="fila.posicion === 1 ? 'trophy-outline' : 'medal-outline'"
                          [class]="'rc-medal rc-medal--' + (fila.posicion <= 3 ? fila.posicion : 'n')" aria-hidden="true"></ion-icon>
                        #{{ fila.posicion }}
                      </td>
                      <td>
                        <span class="rc-ranking__name">Muestra {{ fila.numeroMuestra }}</span>
                        @if (activa) { <ion-badge class="rc-chip rc-chip--live">en el medidor</ion-badge> }
                        @if (fila.cerradaForzada) { <span class="rs-tag">cerrada</span> }
                      </td>
                      <td>{{ fila.evaluacionesRecibidas }} / {{ fila.evaluacionesEsperadas }}</td>
                      <td class="rs-muted">{{ fila.puntajeMin | number:'1.2-2' }} \u2013 {{ fila.puntajeMax | number:'1.2-2' }}</td>
                      <td class="rs-score">
                        {{ fila.puntajePromedioPanel | number:'1.2-2' }}
                        @if (fila.recortado) {
                          <span class="rs-tag" title="Promedio simple: {{ fila.puntajePromedioSimple | number:'1.2-2' }}">recortado</span>
                        }
                      </td>
                      <td>
                        <ion-badge class="rc-chip" [style.--background]="fila.clasificacion.fondo" [style.--color]="fila.clasificacion.color">
                          {{ fila.clasificacion.etiqueta }}
                        </ion-badge>
                      </td>
                    </tr>
                  } @empty {
                    <tr><td colspan="6" class="rs-muted">Ninguna muestra recibi\xF3 fichas.</td></tr>
                  }
                </tbody>
              </table>
            </div>
            @if (muestrasSinFichas().length > 0) {
              <p class="rs-muted rs-note rc-note-bottom">
                Sin fichas: {{ muestrasSinFichas().length }} muestra(s) cerradas sin evaluaciones.
              </p>
            }
          </ion-card-content>
        </ion-card>

        <!-- An\xE1lisis de catadores -->
        <section class="rc-block">
          <h2 class="rs-section-title rc-section-title--tight">An\xE1lisis de catadores</h2>
          <p class="rs-muted rs-note">Participaci\xF3n y consistencia individual dentro del panel. Selecciona un catador para ver su reporte.</p>
          <ion-grid class="rc-grid-flush">
            <ion-row>
              @for (catador of r.catadores; track catador.cupperId) {
                <ion-col size="12" size-sm="6" size-lg="4">
                  <button type="button" class="rc-cupper-select"
                    [class.rc-cupper-select--active]="catador.cupperId === catadorReporte()?.cupperId"
                    [attr.aria-pressed]="catador.cupperId === catadorReporte()?.cupperId"
                    (click)="seleccionarCatadorReporte(catador.cupperId)">
                    <app-cupper-result-card [catador]="catador"></app-cupper-result-card>
                  </button>
                </ion-col>
              }
            </ion-row>
          </ion-grid>
        </section>

        <!-- Reporte de sesi\xF3n individual -->
        @if (catadorReporte(); as cat) {
          <ion-card class="rc-card">
            <ion-card-content>
              <h2 class="rs-section-title rc-section-title--tight">Reporte de sesi\xF3n individual</h2>
              <div class="rc-report__head">
                <div class="rc-report__who">
                  <span class="rc-avatar" aria-hidden="true">{{ cat.nombre.charAt(0).toUpperCase() }}</span>
                  <div>
                    <p class="rc-report__name">{{ cat.nombre }}</p>
                    <p class="rc-report__meta">
                      {{ cat.muestrasEvaluadas }} de {{ cat.muestrasAsignadas }} muestras evaluadas \xB7 estado {{ cat.estado }}
                    </p>
                  </div>
                </div>
                <div class="rc-report__score">
                  <strong>{{ cat.puntajePromedio | number:'1.2-2' }}</strong>
                  <span>Promedio</span>
                </div>
              </div>

              @if (fichasReporte().length > 0) {
                <p class="rs-muted rs-note">Haz clic en una ficha para ver su detalle.</p>
                <ion-accordion-group class="rc-fichas" [multiple]="false">
                  @for (ficha of fichasReporte(); track ficha.numeroMuestra) {
                    <ion-accordion [value]="cat.cupperId + '-' + ficha.numeroMuestra" class="rc-ficha">
                      <ion-item slot="header" lines="none" class="rc-ficha__header">
                        <ion-label>Muestra {{ ficha.numeroMuestra }}</ion-label>
                        <ion-badge slot="end" class="rc-chip" [style.--background]="ficha.clasificacion.fondo" [style.--color]="ficha.clasificacion.color">
                          {{ ficha.clasificacion.etiqueta }}
                        </ion-badge>
                        <span slot="end" class="rc-ficha__score">{{ ficha.puntaje | number:'1.2-2' }}</span>
                      </ion-item>
                      <div slot="content" class="rc-ficha__body">
                        @if (ficha.atributos.length > 0) {
                          <div class="rc-ficha__row rc-ficha__row--head">
                            <span>Atributo</span><span class="rc-ficha__cols"><em>Intensidad</em><em>Calidad</em></span>
                          </div>
                          @for (a of ficha.atributos; track a.clave) {
                            <div class="rc-ficha__row">
                              <span>{{ a.etiqueta }}</span>
                              <span class="rc-ficha__cols">
                                <strong>{{ a.intensidad === null ? '\u2014' : (a.intensidad | number:'1.0-2') }}</strong>
                                <strong>{{ a.calidad === null ? '\u2014' : (a.calidad | number:'1.0-2') }}</strong>
                              </span>
                            </div>
                          }
                        }
                        @if (ficha.impresionGlobal !== null) {
                          <div class="rc-ficha__row"><span>Impresi\xF3n global</span><strong>{{ ficha.impresionGlobal | number:'1.0-2' }}</strong></div>
                        }
                        <div class="rc-ficha__row"><span>Tazas no uniformes</span><strong>{{ ficha.tazasNoUniformes }}</strong></div>
                        <div class="rc-ficha__row"><span>Tazas defectuosas</span><strong>{{ ficha.tazasDefectuosas }}</strong></div>
                        <div class="rc-ficha__row rc-ficha__row--total">
                          <span>Puntaje final</span><strong>{{ ficha.puntaje | number:'1.2-2' }}</strong>
                        </div>
                        <div class="rc-ficha__actions">
                          <ion-button size="small" fill="outline"
                            (click)="abrirExportar({ numeroMuestra: ficha.numeroMuestra, cupperId: cat.cupperId })">
                            Exportar PDF
                          </ion-button>
                        </div>
                      </div>
                    </ion-accordion>
                  }
                </ion-accordion-group>
              } @else {
                <p class="rs-muted rs-note">Este catador a\xFAn no tiene fichas enviadas.</p>
              }
            </ion-card-content>
          </ion-card>
        }

        <!-- F\xF3rmula -->
        <section class="rs-formula">
          <h2 class="rs-section-title">F\xF3rmula CVA aplicada</h2>
          <p class="rs-formula__expr">S = 0.65625 \xD7 \u03A3h\u1D62 + 52.75 \u2212 2u \u2212 4d</p>
          <p class="rs-muted">
            El consolidado descarta el valor m\xE1s alto y el m\xE1s bajo por muestra cuando hay 5 o m\xE1s fichas.
          </p>
        </section>

        <div class="rs-actions">
          <ion-button fill="outline" (click)="volverAlPanel()">Volver al panel</ion-button>
          <ion-button class="primary-btn" [disabled]="imprimiendo()" (click)="abrirExportar()">
            <ion-icon name="download-outline" slot="start"></ion-icon>
            Exportar a PDF (Formato SCA)
          </ion-button>
        </div>
      } @else if (esAfectivo()) {
        <!-- \u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550 FORMATO AFECTIVO \u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550 -->
        <ng-container *ngTemplateOutlet="metaSesion; context: { r: r,
          detalle: 'Escala hed\xF3nica de 9 puntos: 1 = extremadamente baja \xB7 5 = neutral \xB7 9 = extremadamente alta.' }"></ng-container>

        <!-- Promedio hed\xF3nico por muestra -->
        <ion-card class="rc-card">
          <ion-card-content>
            <h2 class="rs-section-title rc-section-title--tight">Agrado del panel \u2014 escala hed\xF3nica (1 a 9)</h2>
            <p class="rs-muted rs-note">Promedio de la Impresi\xF3n Global por muestra. Haz clic en una muestra para ver sus votos.</p>
            <div class="rs-table-wrap">
              <table class="rs-table rc-ranking">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Muestra</th>
                    <th scope="col">Votos</th>
                    <th scope="col" class="ra-col-bar">Promedio hed\xF3nico</th>
                    <th scope="col">Valoraci\xF3n</th>
                  </tr>
                </thead>
                <tbody>
                  @for (fila of resultadosHedonicos(); track fila.numeroMuestra) {
                    @let activa = fila.numeroMuestra === hedonicoSeleccionado()?.numeroMuestra;
                    <tr class="rc-ranking__row" [class.rc-ranking__row--active]="activa" tabindex="0" [attr.aria-selected]="activa"
                      (click)="seleccionarMuestraDetalle(fila.numeroMuestra)"
                      (keydown.enter)="seleccionarMuestraDetalle(fila.numeroMuestra)"
                      (keydown.space)="$event.preventDefault(); seleccionarMuestraDetalle(fila.numeroMuestra)">
                      <td class="rs-rank">{{ fila.posicion ? '#' + fila.posicion : '\u2014' }}</td>
                      <td><span class="rc-ranking__name">Muestra {{ fila.numeroMuestra }}</span></td>
                      <td>{{ fila.totalVotos }}</td>
                      <td class="ra-col-bar">
                        <div class="rx-bar-line">
                          <div class="rx-bar rx-bar--hedonic"><i [style.width.%]="(fila.promedio ?? 0) / 9 * 100"></i></div>
                          <strong class="rs-score">{{ fila.promedio === null ? '\u2014' : (fila.promedio | number:'1.2-2') }}</strong>
                        </div>
                      </td>
                      <td><ion-badge class="rc-chip ra-chip">{{ fila.etiqueta }}</ion-badge></td>
                    </tr>
                  } @empty {
                    <tr><td colspan="5" class="rs-muted">La sesi\xF3n no tiene muestras.</td></tr>
                  }
                </tbody>
              </table>
            </div>
          </ion-card-content>
        </ion-card>

        @if (hedonicoSeleccionado(); as sel) {
          <ng-container *ngTemplateOutlet="selectorMuestra; context: { actual: sel.numeroMuestra }"></ng-container>
          <ion-grid class="rc-grid-flush">
            <ion-row>
              <!-- Distribuci\xF3n de votos -->
              <ion-col size="12" size-md="6">
                <ion-card class="rc-card">
                  <ion-card-content>
                    <h2 class="rs-section-title rc-section-title--tight">Distribuci\xF3n de votos \xB7 Muestra {{ sel.numeroMuestra }}</h2>
                    <p class="rs-muted rs-note">Cu\xE1ntos catadores eligieron cada punto de la escala (Impresi\xF3n Global).</p>
                    @if (sel.totalVotos > 0) {
                      <ul class="ra-dist" role="list">
                        @for (d of sel.distribucion; track d.valor) {
                          <li class="ra-dist__row" [class.ra-dist__row--empty]="d.votos === 0">
                            <span class="ra-dist__value">{{ d.valor }}</span>
                            <span class="ra-dist__label">{{ d.etiqueta }}</span>
                            <div class="rx-bar rx-bar--hedonic"><i [style.width.%]="d.porcentaje"></i></div>
                            <strong class="ra-dist__count">{{ d.votos }}</strong>
                          </li>
                        }
                      </ul>
                      <p class="ra-dist__total">
                        {{ sel.totalVotos }} voto(s) \xB7 promedio <strong>{{ sel.promedio | number:'1.2-2' }}</strong> ({{ sel.etiqueta }})
                      </p>
                    } @else {
                      <p class="rs-muted rs-note">Esta muestra no recibi\xF3 votos de Impresi\xF3n Global.</p>
                    }
                  </ion-card-content>
                </ion-card>
              </ion-col>
              <!-- Calidad por atributo -->
              <ion-col size="12" size-md="6">
                <ion-card class="rc-card">
                  <ion-card-content>
                    <h2 class="rs-section-title rc-section-title--tight">Calidad por atributo \xB7 Muestra {{ sel.numeroMuestra }}</h2>
                    <p class="rs-muted rs-note">Promedio del panel en la escala hed\xF3nica (1 a 9).</p>
                    <ul class="rx-bars" role="list">
                      @for (a of sel.atributos; track a.clave) {
                        <li class="rx-bars__row">
                          <span class="rx-bars__label">{{ a.etiqueta }}</span>
                          <div class="rx-bar rx-bar--hedonic"><i [style.width.%]="a.porcentaje"></i></div>
                          <strong class="rx-bars__value">{{ a.valor === null ? '\u2014' : (a.valor | number:'1.1-1') }}</strong>
                        </li>
                      }
                    </ul>
                  </ion-card-content>
                </ion-card>
              </ion-col>
            </ion-row>
          </ion-grid>
        }

        <ng-container *ngTemplateOutlet="participacion; context: { r: r }"></ng-container>

        <div class="rs-actions">
          <ion-button fill="outline" (click)="volverAlPanel()">Volver al panel</ion-button>
          <ion-button class="primary-btn" [disabled]="imprimiendo()" (click)="exportarPDF()">
            <ion-icon name="download-outline" slot="start"></ion-icon>
            Exportar a PDF (Formato SCA)
          </ion-button>
        </div>
      } @else if (esDescriptivo()) {
        <!-- \u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550 FORMATO DESCRIPTIVO \u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550 -->
        <ng-container *ngTemplateOutlet="metaSesion; context: { r: r,
          detalle: 'Perfil sensorial objetivo: intensidad f\xEDsica de 0 (ausente) a 15 (muy intensa), sin juicio de calidad.' }"></ng-container>

        @if (perfilSeleccionado(); as perfil) {
          <ng-container *ngTemplateOutlet="selectorMuestra; context: { actual: perfil.numeroMuestra }"></ng-container>

          <ion-card class="rc-card">
            <ion-card-content>
              <div class="rd-head">
                <div>
                  <h2 class="rs-section-title rc-section-title--tight">Perfil de intensidad \xB7 Muestra {{ perfil.numeroMuestra }}</h2>
                  <p class="rs-muted rs-note">Promedio del panel por atributo ({{ perfil.fichas }} ficha(s)).</p>
                </div>
              </div>
              <div class="rd-scale" aria-hidden="true">
                <span></span><span class="rd-scale__ticks"><em>0</em><em>5</em><em>10</em><em>15</em></span><span></span>
              </div>
              <ul class="rx-bars rd-bars" role="list">
                @for (a of perfil.atributos; track a.clave) {
                  <li class="rx-bars__row">
                    <span class="rx-bars__label">{{ a.etiqueta }}</span>
                    <div class="rx-bar rx-bar--intensity rd-bar"><i [style.width.%]="a.porcentaje"></i></div>
                    <strong class="rx-bars__value">{{ a.valor === null ? '\u2014' : (a.valor | number:'1.1-1') }}</strong>
                  </li>
                }
              </ul>
            </ion-card-content>
          </ion-card>
        }

        <!-- Comparativa entre muestras -->
        <ion-card class="rc-card">
          <ion-card-content>
            <h2 class="rs-section-title rc-section-title--tight">Comparativa de intensidades</h2>
            <p class="rs-muted rs-note">Promedio del panel (0\u201315). El tono de cada celda es proporcional a la intensidad.</p>
            <div class="rs-table-wrap">
              <table class="rs-table rd-matrix">
                <thead>
                  <tr>
                    <th scope="col">Atributo</th>
                    @for (p of perfilesDescriptivos(); track p.numeroMuestra) {
                      <th scope="col" class="rd-matrix__num">M{{ p.numeroMuestra }}</th>
                    }
                  </tr>
                </thead>
                <tbody>
                  @for (atr of atributosCva; track atr.clave; let i = $index) {
                    <tr>
                      <th scope="row">{{ atr.etiqueta }}</th>
                      @for (p of perfilesDescriptivos(); track p.numeroMuestra) {
                        <td class="rd-matrix__num">
                          <span class="rd-cell" [class.rd-cell--dark]="p.atributos[i].porcentaje > 55" [style.--rd-alpha]="p.atributos[i].porcentaje / 100">
                            {{ p.atributos[i].valor === null ? '\u2014' : (p.atributos[i].valor | number:'1.1-1') }}
                          </span>
                        </td>
                      }
                    </tr>
                  }
                </tbody>
              </table>
            </div>
          </ion-card-content>
        </ion-card>

        <ng-container *ngTemplateOutlet="participacion; context: { r: r }"></ng-container>

        <div class="rs-actions">
          <ion-button fill="outline" (click)="volverAlPanel()">Volver al panel</ion-button>
          <ion-button class="primary-btn" [disabled]="imprimiendo()" (click)="exportarPDF()">
            <ion-icon name="download-outline" slot="start"></ion-icon>
            Exportar perfil a PDF
          </ion-button>
        </div>
      } @else if (esExtrinseco()) {
        <!-- \u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550 FORMATO EXTR\xCDNSECO \u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550 -->
        @for (ficha of fichasTecnicas(); track ficha.numeroMuestra + '-' + $index) {
          <ion-card class="rc-card re-card">
            <ion-card-content>
              <div class="re-head">
                <div class="re-head__title">
                  <ion-icon name="document-text-outline" aria-hidden="true"></ion-icon>
                  <div>
                    <h2>Ficha t\xE9cnica del caf\xE9 \xB7 Muestra {{ ficha.numeroMuestra }}</h2>
                    <p class="rs-muted">
                      @if (ficha.registradaPor) { Registrada por {{ ficha.registradaPor }} }
                      @if (ficha.registradaEn) { \xB7 {{ ficha.registradaEn | date:'mediumDate' }} }
                    </p>
                  </div>
                </div>
              </div>

              <ion-grid class="rc-grid-flush">
                <ion-row>
                  @for (seccion of ficha.secciones; track seccion.titulo) {
                    <ion-col size="12" size-md="6" size-xl="4">
                      <section class="re-section">
                        <h3 class="rs-section-title">{{ seccion.titulo }}</h3>
                        <dl class="re-dl">
                          @for (campo of seccion.campos; track campo.etiqueta) {
                            <dt>{{ campo.etiqueta }}</dt>
                            <dd [class.re-dl__empty]="campo.valor === '\u2014'">{{ campo.valor }}</dd>
                          }
                        </dl>
                      </section>
                    </ion-col>
                  }
                </ion-row>
              </ion-grid>

              <section class="re-section">
                <h3 class="rs-section-title">Certificaciones</h3>
                @if (ficha.certificaciones.length > 0) {
                  <div class="re-certs">
                    @for (c of ficha.certificaciones; track c) {
                      <ion-badge class="rc-chip re-cert"><ion-icon name="ribbon-outline" aria-hidden="true"></ion-icon> {{ c }}</ion-badge>
                    }
                  </div>
                } @else {
                  <p class="rs-muted rs-note">Sin certificaciones registradas.</p>
                }
              </section>

              @if (ficha.notas) {
                <section class="re-section">
                  <h3 class="rs-section-title">Notas</h3>
                  <p class="re-notes">{{ ficha.notas }}</p>
                </section>
              }
            </ion-card-content>
          </ion-card>
        } @empty {
          <ion-card class="rc-card">
            <ion-card-content class="rs-center">
              <ion-icon name="document-text-outline" class="rs-lock" aria-hidden="true"></ion-icon>
              <p>Esta sesi\xF3n no tiene fichas t\xE9cnicas registradas.</p>
            </ion-card-content>
          </ion-card>
        }

        <div class="rs-actions">
          <ion-button fill="outline" (click)="volverAlPanel()">Volver al panel</ion-button>
          <ion-button class="primary-btn" [disabled]="imprimiendo() || fichasTecnicas().length === 0" (click)="exportarPDF()">
            <ion-icon name="download-outline" slot="start"></ion-icon>
            Exportar Ficha T\xE9cnica a PDF
          </ion-button>
        </div>
      } @else {
        <!-- \u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550 FORMATO NO RECONOCIDO (vista original) \u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550 -->
        <section class="cupping-card rs-meta">
          <div class="rs-meta__status">
            <p class="rs-meta__headline">
              <ion-icon name="checkmark-circle-outline" aria-hidden="true"></ion-icon>
              Sesi\xF3n cerrada \xB7 {{ porcentajeCompletado() }}% completada
            </p>
            <p class="rs-meta__detail">
              {{ hayRecorte()
                ? 'Consolidaci\xF3n mediante promedio recortado SCA (se descartan m\xE1ximo y m\xEDnimo con 5 o m\xE1s catadores).'
                : 'Consolidaci\xF3n mediante promedio simple (menos de 5 fichas por muestra).' }}
            </p>
          </div>
          <div class="rs-meta__stats">
            <div><strong>{{ r.totalMuestras }}</strong><span>Muestras</span></div>
            <div><strong>{{ r.catadores.length }}</strong><span>Catadores</span></div>
            <div><strong>{{ tituloFormato() }}</strong><span>Formato</span></div>
          </div>
        </section>
  
        <section class="cupping-card">
          <h2 class="rs-section-title">Ranking \u2014 promedio del panel</h2>
          <div class="rs-table-wrap">
            <table class="rs-table">
              <thead>
                <tr>
                  <th scope="col">#</th>
                  <th scope="col">Muestra</th>
                  <th scope="col">Fichas</th>
                  <th scope="col">M\xEDn \u2013 M\xE1x</th>
                  <th scope="col">Puntaje panel</th>
                  <th scope="col">Clasificaci\xF3n</th>
                </tr>
              </thead>
              <tbody>
                @for (fila of ranking(); track fila.numeroMuestra) {
                  <tr>
                    <td class="rs-rank">
                      @if (fila.posicion === 1) {
                        <ion-icon name="trophy-outline" aria-label="Primer lugar"></ion-icon>
                      }
                      #{{ fila.posicion }}
                    </td>
                    <td>
                      Muestra {{ fila.numeroMuestra }}
                      @if (fila.cerradaForzada) { <span class="rs-tag">cerrada</span> }
                    </td>
                    <td>{{ fila.evaluacionesRecibidas }} / {{ fila.evaluacionesEsperadas }}</td>
                    <td class="rs-muted">{{ fila.puntajeMin | number:'1.2-2' }} \u2013 {{ fila.puntajeMax | number:'1.2-2' }}</td>
                    <td class="rs-score">
                      {{ fila.puntajePromedioPanel | number:'1.2-2' }}
                      @if (fila.recortado) {
                        <span class="rs-tag" title="Promedio simple: {{ fila.puntajePromedioSimple | number:'1.2-2' }}">recortado</span>
                      }
                    </td>
                    <td>
                      <span class="rs-badge" [style.color]="fila.clasificacion.color" [style.background]="fila.clasificacion.fondo">
                        {{ fila.clasificacion.etiqueta }}
                      </span>
                    </td>
                  </tr>
                } @empty {
                  <tr><td colspan="6" class="rs-muted">Ninguna muestra recibi\xF3 fichas.</td></tr>
                }
              </tbody>
              @if (ranking().length > 0) {
                <tfoot>
                  <tr>
                    <td colspan="4">Promedio del panel</td>
                    <td class="rs-score">{{ promedioPanel() | number:'1.2-2' }}</td>
                    <td>
                      <span class="rs-badge" [style.color]="clasificacionPanel().color" [style.background]="clasificacionPanel().fondo">
                        {{ clasificacionPanel().etiqueta }}
                      </span>
                    </td>
                  </tr>
                </tfoot>
              }
            </table>
          </div>
          @if (muestrasSinFichas().length > 0) {
            <p class="rs-muted rs-note">
              Sin fichas: {{ muestrasSinFichas().length }} muestra(s) cerradas sin evaluaciones.
            </p>
          }
        </section>
  
        <section>
          <h2 class="rs-section-title">An\xE1lisis de catadores</h2>
          <p class="rs-muted rs-note">Participaci\xF3n y consistencia individual dentro del panel.</p>
          <div class="rs-grid">
            @for (catador of r.catadores; track catador.cupperId) {
              <app-cupper-result-card [catador]="catador"></app-cupper-result-card>
            }
          </div>
        </section>
  
        <section class="rs-formula">
          <h2 class="rs-section-title">F\xF3rmula CVA aplicada</h2>
          <p class="rs-formula__expr">S = 0.65625 \xD7 \u03A3h\u1D62 + 52.75 \u2212 2u \u2212 4d</p>
          <p class="rs-muted">
            El consolidado descarta el valor m\xE1s alto y el m\xE1s bajo por muestra cuando hay 5 o m\xE1s fichas.
          </p>
        </section>
  
        <div class="rs-actions">
          <ion-button fill="outline" (click)="volverAlPanel()">Volver al panel</ion-button>
          <ion-button class="primary-btn" (click)="exportarPDF()">
            <ion-icon name="download-outline" slot="start"></ion-icon>
            Exportar a PDF (Formato SCA)
          </ion-button>
        </div>
      }
    }
  </main>

  <!-- Modal de exportaci\xF3n (solo Combinado) -->
  @if (esCombinado()) {
    <ion-modal class="rc-export-modal" [isOpen]="modalExportarAbierto()" (didDismiss)="cerrarExportar()">
      <ng-template>
        <div class="rc-export">
          <div class="rc-export__head">
            <h2>\xBFC\xF3mo quieres exportar tu PDF?</h2>
            <ion-button fill="clear" size="small" aria-label="Cerrar" (click)="cerrarExportar()">
              <ion-icon name="close-outline" slot="icon-only"></ion-icon>
            </ion-button>
          </div>

          <label class="rc-export__label" for="rc-export-muestra">Muestra #</label>
          <ion-select id="rc-export-muestra" class="rc-export__select" interface="popover" placeholder="Selecciona una muestra"
            [value]="muestraExportar()" (ionChange)="cambiarMuestraExportar($event.detail.value)">
            @for (fila of ranking(); track fila.numeroMuestra) {
              <ion-select-option [value]="fila.numeroMuestra">Muestra {{ fila.numeroMuestra }}</ion-select-option>
            }
          </ion-select>

          <ion-segment class="rc-export__segment" [value]="modoExportacion()" (ionChange)="cambiarModoExportacion($event.detail.value)">
            <ion-segment-button value="catador"><ion-label>Por catador</ion-label></ion-segment-button>
            <ion-segment-button value="panel"><ion-label>Panel</ion-label></ion-segment-button>
          </ion-segment>

          @if (modoExportacion() === 'catador') {
            <label class="rc-export__label" for="rc-export-catador">Selecciona el catador</label>
            <ion-select id="rc-export-catador" class="rc-export__select" interface="popover" placeholder="Selecciona un catador"
              [value]="catadorExportarId()" (ionChange)="cambiarCatadorExportar($event.detail.value)">
              @for (c of catadoresExportables(); track c.cupperId) {
                <ion-select-option [value]="c.cupperId">{{ c.nombre }}</ion-select-option>
              }
            </ion-select>
          }

          <ion-button expand="block" class="primary-btn rc-export__go"
            [disabled]="imprimiendo() || muestraExportar() === null || (modoExportacion() === 'catador' && !catadorExportarId())"
            (click)="confirmarExportar()">
            <ion-icon name="download-outline" slot="start"></ion-icon>
            Exportar a PDF (Formato SCA)
          </ion-button>
          <p class="rc-export__hint">En la ventana de impresi\xF3n elige "Guardar como PDF".</p>
        </div>
      </ng-template>
    </ion-modal>
  }

  <!--
    Reporte imprimible: HTML plano (sin componentes Ionic) que ImpresionService
    copia a un iframe aislado con su propia hoja de estilos (clases rp-*).
  -->
  @if (resultados(); as r) {
    <div #reporteImprimible hidden aria-hidden="true">
      <header class="rp-head">
        <div>
          <p class="rp-brand">PacamaraQs \xB7 Evaluaci\xF3n sensorial SCA CVA</p>
          <h1 class="rp-title">{{ esExtrinseco() ? 'Ficha t\xE9cnica del caf\xE9' : 'Reporte de cataci\xF3n' }}</h1>
          <p class="rp-sub">{{ r.nombreSesion }} \xB7 Formato {{ tituloFormato() }}</p>
        </div>
        <p class="rp-meta">Generado: {{ fechaReporte() | date:'medium' }}<br>{{ r.totalMuestras }} muestra(s) \xB7 {{ r.catadores.length }} catador(es)</p>
      </header>

      @if (esCombinado()) {
        @if (muestraReporteCombinado(); as m) {
          @if (modoExportacion() === 'catador' && catadorExportar()) {
            <!-- Combinado \xB7 ficha individual -->
            <section class="rp-section">
              <h2>Ficha individual \xB7 {{ catadorExportar()?.nombre }} \xB7 Muestra {{ m.numeroMuestra }}</h2>
              @if (fichaCatadorReporte(); as f) {
                <div class="rp-kpis">
                  <div class="rp-kpi"><strong>{{ f.puntaje | number:'1.2-2' }}</strong><span>Puntaje final</span></div>
                  <div class="rp-kpi"><strong>{{ f.clasificacion.etiqueta }}</strong><span>Clasificaci\xF3n</span></div>
                  <div class="rp-kpi"><strong>{{ f.impresionGlobal === null ? '\u2014' : (f.impresionGlobal | number:'1.0-2') }}</strong><span>Impresi\xF3n global</span></div>
                  <div class="rp-kpi"><strong>{{ m.puntajePromedioPanel | number:'1.2-2' }}</strong><span>Promedio del panel</span></div>
                </div>
                <table>
                  <thead><tr><th>Atributo</th><th class="num">Intensidad (0\u201315)</th><th class="num">Calidad (1\u20139)</th></tr></thead>
                  <tbody>
                    @for (a of f.atributos; track a.clave) {
                      <tr>
                        <td>{{ a.etiqueta }}</td>
                        <td class="num">{{ a.intensidad === null ? '\u2014' : (a.intensidad | number:'1.0-2') }}</td>
                        <td class="num">{{ a.calidad === null ? '\u2014' : (a.calidad | number:'1.0-2') }}</td>
                      </tr>
                    } @empty {
                      <tr><td colspan="3" class="rp-muted">Sin atributos registrados.</td></tr>
                    }
                    <tr><td>Tazas no uniformes (u)</td><td class="num" colspan="2">{{ f.tazasNoUniformes }}</td></tr>
                    <tr><td>Tazas defectuosas (d)</td><td class="num" colspan="2">{{ f.tazasDefectuosas }}</td></tr>
                  </tbody>
                </table>
              } @else {
                <p class="rp-muted">Este catador no envi\xF3 ficha para la muestra {{ m.numeroMuestra }}.</p>
              }
            </section>
          } @else {
            <!-- Combinado \xB7 panel -->
            <section class="rp-section">
              <h2>Consolidado del panel \xB7 Muestra {{ m.numeroMuestra }}</h2>
              <div class="rp-kpis">
                <div class="rp-kpi"><strong>{{ m.puntajePromedioPanel | number:'1.2-2' }}</strong><span>Puntaje panel</span></div>
                <div class="rp-kpi"><strong>{{ m.clasificacion.etiqueta }}</strong><span>Clasificaci\xF3n</span></div>
                <div class="rp-kpi"><strong>{{ m.evaluacionesRecibidas }} / {{ m.evaluacionesEsperadas }}</strong><span>Fichas</span></div>
                <div class="rp-kpi"><strong>{{ m.puntajeMin | number:'1.2-2' }} \u2013 {{ m.puntajeMax | number:'1.2-2' }}</strong><span>M\xEDn \u2013 M\xE1x</span></div>
              </div>
              <p class="rp-muted">{{ m.recortado ? 'Promedio recortado SCA (se descartan m\xE1ximo y m\xEDnimo).' : 'Promedio simple (menos de 5 fichas).' }}</p>
            </section>
            @if (atributosPanelReporte().length > 0) {
              <section class="rp-section">
                <h2>Promedio del panel por atributo</h2>
                <table>
                  <thead><tr><th>Atributo</th><th class="num">Intensidad (0\u201315)</th><th class="num">Calidad (1\u20139)</th></tr></thead>
                  <tbody>
                    @for (a of atributosPanelReporte(); track a.clave) {
                      <tr>
                        <td>{{ a.etiqueta }}</td>
                        <td class="num">{{ a.intensidad === null ? '\u2014' : (a.intensidad | number:'1.0-2') }}</td>
                        <td class="num">{{ a.calidad === null ? '\u2014' : (a.calidad | number:'1.0-2') }}</td>
                      </tr>
                    }
                  </tbody>
                </table>
              </section>
            }
            <section class="rp-section">
              <h2>Puntaje por catador \xB7 Muestra {{ m.numeroMuestra }}</h2>
              <table>
                <thead><tr><th>Catador</th><th class="num">Puntaje</th><th class="num">u</th><th class="num">d</th></tr></thead>
                <tbody>
                  @for (c of puntajesCatadoresReporte(); track $index) {
                    <tr>
                      <td>{{ c.nombre }}</td>
                      <td class="num" [class.rp-score]="c.ficha" [class.rp-muted]="!c.ficha">{{ c.ficha ? (c.ficha.puntaje | number:'1.2-2') : 'Pendiente' }}</td>
                      <td class="num">{{ c.ficha?.tazasNoUniformes ?? '\u2014' }}</td>
                      <td class="num">{{ c.ficha?.tazasDefectuosas ?? '\u2014' }}</td>
                    </tr>
                  }
                </tbody>
              </table>
            </section>
          }
        }
        <section class="rp-section">
          <h2>Ranking de la sesi\xF3n</h2>
          <table>
            <thead><tr><th>#</th><th>Muestra</th><th class="num">Fichas</th><th class="num">Puntaje panel</th><th>Clasificaci\xF3n</th></tr></thead>
            <tbody>
              @for (f of ranking(); track f.numeroMuestra) {
                <tr>
                  <td>{{ f.posicion }}</td>
                  <td>Muestra {{ f.numeroMuestra }}</td>
                  <td class="num">{{ f.evaluacionesRecibidas }} / {{ f.evaluacionesEsperadas }}</td>
                  <td class="num rp-score">{{ f.puntajePromedioPanel | number:'1.2-2' }}</td>
                  <td><span class="rp-badge" [style.color]="f.clasificacion.color" [style.background]="f.clasificacion.fondo">{{ f.clasificacion.etiqueta }}</span></td>
                </tr>
              }
            </tbody>
          </table>
          <p class="rp-formula">S = 0.65625 \xD7 \u03A3h\u1D62 + 52.75 \u2212 2u \u2212 4d</p>
        </section>
      } @else if (esAfectivo()) {
        <section class="rp-section">
          <h2>Promedio hed\xF3nico por muestra (escala 1\u20139)</h2>
          <table>
            <thead><tr><th>#</th><th>Muestra</th><th class="num">Votos</th><th class="num">Promedio</th><th>Valoraci\xF3n</th></tr></thead>
            <tbody>
              @for (f of resultadosHedonicos(); track f.numeroMuestra) {
                <tr>
                  <td>{{ f.posicion || '\u2014' }}</td>
                  <td>Muestra {{ f.numeroMuestra }}</td>
                  <td class="num">{{ f.totalVotos }}</td>
                  <td class="num rp-score">{{ f.promedio === null ? '\u2014' : (f.promedio | number:'1.2-2') }}</td>
                  <td>{{ f.etiqueta }}</td>
                </tr>
              }
            </tbody>
          </table>
        </section>
        <div class="rp-grid">
          @for (f of resultadosHedonicos(); track f.numeroMuestra) {
            <section class="rp-section">
              <h2>Muestra {{ f.numeroMuestra }} \xB7 distribuci\xF3n de votos</h2>
              <table>
                <tbody>
                  @for (d of f.distribucion; track d.valor) {
                    <tr>
                      <td style="width: 8%">{{ d.valor }}</td>
                      <td style="width: 38%" class="rp-muted">{{ d.etiqueta }}</td>
                      <td><div class="rp-bar"><i [style.width.%]="d.porcentaje"></i></div></td>
                      <td class="num" style="width: 8%">{{ d.votos }}</td>
                    </tr>
                  }
                </tbody>
              </table>
              <table style="margin-top: 6px">
                <thead><tr><th>Atributo</th><th class="num">Calidad (1\u20139)</th></tr></thead>
                <tbody>
                  @for (a of f.atributos; track a.clave) {
                    <tr><td>{{ a.etiqueta }}</td><td class="num">{{ a.valor === null ? '\u2014' : (a.valor | number:'1.1-1') }}</td></tr>
                  }
                </tbody>
              </table>
            </section>
          }
        </div>
      } @else if (esDescriptivo()) {
        <section class="rp-section">
          <h2>Perfil de intensidades del panel (escala 0\u201315)</h2>
          <table>
            <thead>
              <tr>
                <th>Atributo</th>
                @for (p of perfilesDescriptivos(); track p.numeroMuestra) { <th class="num">Muestra {{ p.numeroMuestra }}</th> }
              </tr>
            </thead>
            <tbody>
              @for (atr of atributosCva; track atr.clave; let i = $index) {
                <tr>
                  <td>{{ atr.etiqueta }}</td>
                  @for (p of perfilesDescriptivos(); track p.numeroMuestra) {
                    <td class="num">{{ p.atributos[i].valor === null ? '\u2014' : (p.atributos[i].valor | number:'1.1-1') }}</td>
                  }
                </tr>
              }
              <tr>
                <td class="rp-muted">Fichas recibidas</td>
                @for (p of perfilesDescriptivos(); track p.numeroMuestra) { <td class="num rp-muted">{{ p.fichas }}</td> }
              </tr>
            </tbody>
          </table>
        </section>
        <div class="rp-grid">
          @for (p of perfilesDescriptivos(); track p.numeroMuestra) {
            <section class="rp-section">
              <h2>Muestra {{ p.numeroMuestra }}</h2>
              <table>
                <tbody>
                  @for (a of p.atributos; track a.clave) {
                    <tr>
                      <td style="width: 38%">{{ a.etiqueta }}</td>
                      <td><div class="rp-bar"><i [style.width.%]="a.porcentaje"></i></div></td>
                      <td class="num" style="width: 12%">{{ a.valor === null ? '\u2014' : (a.valor | number:'1.1-1') }}</td>
                    </tr>
                  }
                </tbody>
              </table>
            </section>
          }
        </div>
      } @else if (esExtrinseco()) {
        @for (ficha of fichasTecnicas(); track $index; let primera = $first) {
          <article [class.rp-page-break]="!primera">
            <section class="rp-section">
              <h2>Muestra {{ ficha.numeroMuestra }}@if (ficha.registradaPor) { \xB7 registrada por {{ ficha.registradaPor }} }</h2>
            </section>
            <div class="rp-grid">
              @for (seccion of ficha.secciones; track seccion.titulo) {
                <section class="rp-section">
                  <h2>{{ seccion.titulo }}</h2>
                  <dl class="rp-dl">
                    @for (campo of seccion.campos; track campo.etiqueta) {
                      <dt>{{ campo.etiqueta }}</dt><dd>{{ campo.valor }}</dd>
                    }
                  </dl>
                </section>
              }
              <section class="rp-section">
                <h2>Certificaciones</h2>
                @if (ficha.certificaciones.length > 0) {
                  <div class="rp-chips">@for (c of ficha.certificaciones; track c) { <span>{{ c }}</span> }</div>
                } @else {
                  <p class="rp-muted">Sin certificaciones registradas.</p>
                }
              </section>
            </div>
            @if (ficha.notas) {
              <section class="rp-section"><h2>Notas</h2><p>{{ ficha.notas }}</p></section>
            }
          </article>
        }
      }

      <p class="rp-foot">Metodolog\xEDa SCA Coffee Value Assessment (CVA) \xB7 Documento generado por PacamaraQs.</p>
    </div>
  }
</ion-content>
`, styles: ['@charset "UTF-8";\n\n/* src/app/pages/session/results/results.page.scss */\n.rs-toolbar {\n  --background: var(--app-bg-card);\n}\n.rs-title {\n  color: var(--app-text-main);\n  font-size: 15px;\n  font-weight: 700;\n}\n.rs-subtitle {\n  color: var(--app-text-muted);\n  font-size: 12px;\n  font-weight: 400;\n}\n.rs-content {\n  --background: var(--app-bg-screen);\n}\n.rs-container {\n  width: min(100%, 960px);\n  margin: 0 auto;\n  padding-bottom: 24px;\n}\n.rs-center {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  gap: 12px;\n  padding: 32px 16px;\n  text-align: center;\n}\n.rs-lock {\n  color: var(--app-text-muted);\n  font-size: 32px;\n}\n.rs-section-title {\n  margin: 0 0 12px;\n  color: var(--app-text-muted);\n  font-size: 11px;\n  font-weight: 700;\n  letter-spacing: 0.05em;\n  text-transform: uppercase;\n}\n.rs-muted {\n  color: var(--app-text-muted);\n}\n.rs-note {\n  margin: 0 0 12px;\n  font-size: 12px;\n}\n.rs-meta {\n  display: flex;\n  flex-wrap: wrap;\n  align-items: center;\n  justify-content: space-between;\n  gap: 16px;\n}\n.rs-meta__headline {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  margin: 0;\n  color: var(--app-text-main);\n  font-weight: 600;\n}\n.rs-meta__detail {\n  margin: 6px 0 0;\n  color: var(--app-text-muted);\n  font-size: 13px;\n}\n.rs-meta__stats {\n  display: flex;\n  gap: 24px;\n  text-align: center;\n}\n.rs-meta__stats strong {\n  display: block;\n  color: var(--app-text-main);\n  font-size: 16px;\n}\n.rs-meta__stats span {\n  color: var(--app-text-muted);\n  font-size: 11px;\n}\n.rs-table-wrap {\n  overflow-x: auto;\n}\n.rs-table {\n  width: 100%;\n  border-collapse: collapse;\n  font-size: 13px;\n}\n.rs-table th,\n.rs-table td {\n  padding: 10px 8px;\n  border-bottom: 1px solid var(--app-border);\n  text-align: left;\n  white-space: nowrap;\n}\n.rs-table thead th {\n  color: var(--app-text-muted);\n  font-size: 11px;\n  font-weight: 600;\n  text-transform: uppercase;\n}\n.rs-table tfoot td {\n  color: var(--app-text-muted);\n  font-weight: 600;\n}\n.rs-rank {\n  color: var(--app-text-muted);\n}\n.rs-rank ion-icon {\n  color: #ca8a04;\n  vertical-align: middle;\n}\n.rs-score {\n  color: var(--app-score);\n  font-size: 15px;\n  font-weight: 700;\n}\n.rs-tag {\n  margin-left: 6px;\n  padding: 2px 6px;\n  border-radius: 4px;\n  background: var(--app-bg-subtle);\n  color: var(--app-text-muted);\n  font-size: 10px;\n  font-weight: 500;\n}\n.rs-badge {\n  display: inline-block;\n  padding: 3px 8px;\n  border-radius: 6px;\n  font-size: 11px;\n  font-weight: 600;\n}\n.rs-grid {\n  display: grid;\n  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));\n  gap: 12px;\n  margin-bottom: 16px;\n}\n.rs-formula {\n  margin-bottom: 16px;\n  padding: 16px;\n  border-radius: var(--app-radius-card);\n  background: var(--app-bg-subtle);\n}\n.rs-formula__expr {\n  margin: 0 0 8px;\n  color: var(--app-text-main);\n  font-family: var(--app-font-mono);\n  font-size: 14px;\n}\n.rs-actions {\n  display: flex;\n  flex-wrap: wrap;\n  justify-content: flex-end;\n  gap: 12px;\n}\n:host {\n  --rc-gauge-bajo: #e53935;\n  --rc-gauge-medio: #f5b400;\n  --rc-gauge-alto: #8fdc6a;\n  --rc-gauge-top: #12a150;\n  --rc-row-active: #fbe9e4;\n  --rc-medal-1: #ca8a04;\n  --rc-medal-2: #94a3b8;\n  --rc-medal-3: #b45309;\n}\n.rc-card {\n  margin: 0 0 16px;\n  border: 1px solid var(--app-border);\n  border-radius: var(--app-radius-card);\n  background: var(--app-bg-card);\n  box-shadow: none;\n}\n.rc-card ion-card-content {\n  padding: 16px;\n}\n.rc-grid-flush {\n  --ion-grid-padding: 0;\n  margin: 0 -5px;\n}\n.rc-grid-flush ion-col {\n  --ion-grid-column-padding: 5px;\n}\n.rc-grid-flush .rc-card {\n  height: calc(100% - 10px);\n  margin-bottom: 10px;\n}\n.rc-section-title--tight {\n  margin-bottom: 4px;\n}\n.rc-note-bottom {\n  margin: 12px 0 0;\n}\n.rc-block {\n  margin-bottom: 16px;\n}\n.rc-gauge ion-card-content {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  padding: 16px 16px 12px;\n}\n.rc-gauge__svg {\n  width: min(100%, 220px);\n  height: auto;\n  overflow: visible;\n}\n.rc-gauge__arc {\n  fill: none;\n  stroke-width: 22;\n}\n.rc-gauge__arc--bajo {\n  stroke: var(--rc-gauge-bajo);\n}\n.rc-gauge__arc--medio {\n  stroke: var(--rc-gauge-medio);\n}\n.rc-gauge__arc--alto {\n  stroke: var(--rc-gauge-alto);\n}\n.rc-gauge__arc--top {\n  stroke: var(--rc-gauge-top);\n}\n.rc-gauge__tick {\n  fill: var(--app-text-muted);\n  font-size: 9px;\n}\n.rc-gauge__needle {\n  stroke: var(--app-text-main);\n  stroke-width: 4;\n  stroke-linecap: round;\n  transition: all 0.4s ease;\n}\n.rc-gauge__hub {\n  fill: var(--app-text-main);\n}\n.rc-gauge__value {\n  margin: 8px 0 2px;\n  color: var(--app-score);\n  font-size: 22px;\n  font-weight: 700;\n}\n.rc-gauge__label {\n  margin: 0;\n  color: var(--app-text-muted);\n  font-size: 10px;\n  letter-spacing: 0.04em;\n  text-align: center;\n  text-transform: uppercase;\n}\n.rc-ranking__row {\n  cursor: pointer;\n  transition: background-color 0.15s ease;\n}\n.rc-ranking__row:hover {\n  background: var(--app-bg-subtle);\n}\n.rc-ranking__row:focus-visible {\n  outline: 2px solid var(--app-primary-dark);\n  outline-offset: -2px;\n}\n.rc-ranking__row--active,\n.rc-ranking__row--active:hover {\n  background: var(--rc-row-active);\n}\n.rc-ranking__name {\n  color: var(--app-text-main);\n  font-weight: 600;\n}\n.rc-medal {\n  margin-right: 2px;\n  vertical-align: middle;\n}\n.rc-medal--1 {\n  color: var(--rc-medal-1);\n}\n.rc-medal--2 {\n  color: var(--rc-medal-2);\n}\n.rc-medal--3 {\n  color: var(--rc-medal-3);\n}\n.rc-medal--n {\n  color: var(--app-text-faint);\n}\n.rc-chip {\n  --padding-top: 3px;\n  --padding-bottom: 3px;\n  --padding-start: 8px;\n  --padding-end: 8px;\n  border-radius: 6px;\n  font-size: 11px;\n  font-weight: 600;\n}\n.rc-chip--live {\n  --background: #dcfce7;\n  --color: var(--app-success);\n  margin-left: 6px;\n  font-size: 10px;\n  font-weight: 500;\n}\n.rc-cupper-select {\n  display: block;\n  width: 100%;\n  height: 100%;\n  padding: 0;\n  border: 2px solid transparent;\n  border-radius: calc(var(--app-radius-card) + 2px);\n  background: none;\n  font: inherit;\n  text-align: inherit;\n  cursor: pointer;\n  transition: border-color 0.15s ease;\n}\n.rc-cupper-select:hover {\n  border-color: var(--app-border);\n}\n.rc-cupper-select:focus-visible {\n  outline: 2px solid var(--app-primary-dark);\n  outline-offset: 2px;\n}\n.rc-cupper-select--active,\n.rc-cupper-select--active:hover {\n  border-color: var(--app-primary-dark);\n}\n.rc-report__head {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  gap: 12px;\n  margin: 8px 0 12px;\n  padding-bottom: 12px;\n  border-bottom: 1px solid var(--app-border);\n}\n.rc-report__who {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  min-width: 0;\n}\n.rc-avatar {\n  display: inline-flex;\n  flex: 0 0 32px;\n  align-items: center;\n  justify-content: center;\n  width: 32px;\n  height: 32px;\n  border: 1px solid var(--app-border);\n  border-radius: 50%;\n  background: var(--app-bg-subtle);\n  color: var(--app-text-main);\n  font-size: 13px;\n  font-weight: 700;\n}\n.rc-report__name {\n  margin: 0;\n  color: var(--app-text-main);\n  font-weight: 600;\n}\n.rc-report__meta {\n  margin: 2px 0 0;\n  color: var(--app-text-muted);\n  font-size: 11px;\n}\n.rc-report__score {\n  text-align: right;\n}\n.rc-report__score strong {\n  display: block;\n  color: var(--app-text-main);\n  font-size: 20px;\n}\n.rc-report__score span {\n  color: var(--app-text-muted);\n  font-size: 9px;\n  text-transform: uppercase;\n}\n.rc-fichas {\n  display: flex;\n  flex-direction: column;\n  gap: 8px;\n}\n.rc-ficha {\n  overflow: hidden;\n  border-radius: var(--app-radius-control);\n  background: var(--app-bg-subtle);\n}\n.rc-ficha__header {\n  --background: var(--app-bg-subtle);\n  --min-height: 40px;\n  font-size: 13px;\n  font-weight: 600;\n}\n.rc-ficha__header ion-badge {\n  margin-inline-end: 8px;\n}\n.rc-ficha__score {\n  color: var(--app-score);\n  font-size: 13px;\n  font-weight: 700;\n}\n.rc-ficha__body {\n  padding: 4px 16px 12px;\n  background: var(--app-bg-subtle);\n}\n.rc-ficha__row {\n  display: flex;\n  justify-content: space-between;\n  padding: 6px 0;\n  border-bottom: 1px solid var(--app-border);\n  color: var(--app-text-main);\n  font-size: 13px;\n}\n.rc-ficha__row--total {\n  border-bottom: none;\n}\n.rc-ficha__row--total span {\n  font-weight: 600;\n}\n.rc-ficha__row--total strong {\n  color: var(--app-score);\n}\n.rc-ficha__actions {\n  display: flex;\n  flex-wrap: wrap;\n  gap: 8px;\n  margin-top: 4px;\n}\n.rc-export-modal {\n  --width: min(92vw, 360px);\n  --height: auto;\n  --border-radius: var(--app-radius-card);\n}\n.rc-export {\n  padding: 16px;\n}\n.rc-export__head {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  margin-bottom: 12px;\n}\n.rc-export__head h2 {\n  margin: 0;\n  color: var(--app-text-main);\n  font-size: 15px;\n  font-weight: 700;\n}\n.rc-export__label {\n  display: block;\n  margin: 0 0 6px;\n  color: var(--app-text-main);\n  font-size: 12px;\n  font-weight: 600;\n}\n.rc-export__select {\n  margin-bottom: 12px;\n  padding: 0 12px;\n  border: 1px solid var(--app-border-input);\n  border-radius: var(--app-radius-control);\n  font-size: 13px;\n}\n.rc-export__segment {\n  --background: transparent;\n  gap: 8px;\n  margin-bottom: 12px;\n}\n.rc-export__segment ion-segment-button {\n  --background: var(--app-bg-subtle);\n  --background-checked: var(--app-primary-dark);\n  --color: var(--app-text-main);\n  --color-checked: #ffffff;\n  --indicator-color: transparent;\n  --border-radius: var(--app-radius-control);\n  min-height: 38px;\n  border: 1px solid var(--app-border);\n  border-radius: var(--app-radius-control);\n  font-size: 13px;\n  text-transform: none;\n}\n.rc-export__go {\n  margin: 4px 0 0;\n}\n@media (max-width: 576px) {\n  .rs-meta__stats {\n    gap: 16px;\n  }\n  .rc-report__score strong {\n    font-size: 18px;\n  }\n}\n.rc-export__hint {\n  margin: 8px 0 0;\n  color: var(--app-text-muted);\n  font-size: 11px;\n  text-align: center;\n}\n.rc-ficha__row--head {\n  color: var(--app-text-muted);\n  font-size: 11px;\n  text-transform: uppercase;\n}\n.rc-ficha__cols {\n  display: inline-grid;\n  grid-template-columns: 72px 64px;\n  text-align: right;\n}\n.rc-ficha__cols em {\n  font-style: normal;\n}\n:host {\n  --rx-hedonic: #b45309;\n  --rx-intensity: var(--app-primary-dark);\n  --rx-track: var(--app-bg-subtle);\n}\n.rx-bar {\n  position: relative;\n  flex: 1 1 auto;\n  min-width: 40px;\n  height: 10px;\n  overflow: hidden;\n  border-radius: 999px;\n  background: var(--rx-track);\n}\n.rx-bar i {\n  position: absolute;\n  inset: 0 auto 0 0;\n  border-radius: inherit;\n  transition: width 0.35s ease;\n}\n.rx-bar--hedonic i {\n  background: var(--rx-hedonic);\n}\n.rx-bar--intensity i {\n  background: var(--rx-intensity);\n}\n.rx-bars {\n  margin: 0;\n  padding: 0;\n  list-style: none;\n}\n.rx-bars__row {\n  display: grid;\n  grid-template-columns: minmax(96px, 34%) 1fr 40px;\n  align-items: center;\n  gap: 10px;\n  padding: 7px 0;\n  border-bottom: 1px solid var(--app-border);\n  font-size: 13px;\n}\n.rx-bars__row:last-child {\n  border-bottom: none;\n}\n.rx-bars__label {\n  color: var(--app-text-main);\n}\n.rx-bars__value {\n  color: var(--app-text-main);\n  font-variant-numeric: tabular-nums;\n  text-align: right;\n}\n.rx-bar-line {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  min-width: 160px;\n}\n.rx-samples {\n  --background: transparent;\n  margin: 0 0 12px;\n}\n.rx-samples ion-segment-button {\n  --background: var(--app-bg-card);\n  --background-checked: var(--app-primary-dark);\n  --color: var(--app-text-main);\n  --color-checked: #ffffff;\n  --indicator-color: transparent;\n  --border-radius: 999px;\n  flex: 0 0 auto;\n  min-width: 104px;\n  min-height: 32px;\n  margin-right: 6px;\n  border: 1px solid var(--app-border);\n  border-radius: 999px;\n  font-size: 12px;\n  text-transform: none;\n}\n.rx-list {\n  margin: 0 -16px -16px;\n  background: transparent;\n}\n.rx-list ion-item {\n  --background: transparent;\n  --padding-start: 16px;\n  --inner-padding-end: 16px;\n}\n.rx-list .rc-avatar {\n  margin-inline-end: 12px;\n}\n.rx-list__name {\n  color: var(--app-text-main);\n  font-size: 14px;\n  font-weight: 600;\n}\n.rx-list ion-label p {\n  color: var(--app-text-muted);\n  font-size: 12px;\n}\n.rx-chip--ok {\n  --background: #dcfce7;\n  --color: var(--app-success);\n}\n.rx-chip--pending {\n  --background: var(--app-bg-subtle);\n  --color: var(--app-text-muted);\n}\n.ra-col-bar {\n  width: 38%;\n}\n.ra-chip {\n  --background: #fef3c7;\n  --color: #92400e;\n}\n.ra-dist {\n  margin: 0;\n  padding: 0;\n  list-style: none;\n}\n.ra-dist__row {\n  display: grid;\n  grid-template-columns: 22px minmax(110px, 40%) 1fr 28px;\n  align-items: center;\n  gap: 8px;\n  padding: 5px 0;\n  font-size: 13px;\n}\n.ra-dist__row--empty {\n  opacity: 0.55;\n}\n.ra-dist__value {\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  width: 22px;\n  height: 22px;\n  border-radius: 6px;\n  background: var(--app-bg-subtle);\n  color: var(--app-text-main);\n  font-size: 12px;\n  font-weight: 700;\n}\n.ra-dist__label {\n  color: var(--app-text-muted);\n  font-size: 12px;\n}\n.ra-dist__count {\n  color: var(--app-text-main);\n  text-align: right;\n  font-variant-numeric: tabular-nums;\n}\n.ra-dist__total {\n  margin: 10px 0 0;\n  padding-top: 10px;\n  border-top: 1px solid var(--app-border);\n  color: var(--app-text-muted);\n  font-size: 12px;\n}\n.rd-scale {\n  display: grid;\n  grid-template-columns: minmax(96px, 34%) 1fr 40px;\n  gap: 10px;\n  color: var(--app-text-faint);\n  font-size: 10px;\n}\n.rd-scale__ticks {\n  display: flex;\n  justify-content: space-between;\n}\n.rd-scale__ticks em {\n  font-style: normal;\n}\n.rd-bar {\n  height: 12px;\n  background-image:\n    linear-gradient(\n      90deg,\n      transparent calc(33.33% - 1px),\n      var(--app-border) calc(33.33% - 1px),\n      var(--app-border) 33.33%,\n      transparent 33.33%,\n      transparent calc(66.66% - 1px),\n      var(--app-border) calc(66.66% - 1px),\n      var(--app-border) 66.66%,\n      transparent 66.66%);\n}\n.rd-matrix th[scope=row] {\n  color: var(--app-text-main);\n  font-size: 13px;\n  font-weight: 500;\n  text-transform: none;\n}\n.rd-matrix__num {\n  text-align: center !important;\n}\n.rd-cell {\n  --rd-alpha: 0;\n  display: inline-block;\n  min-width: 44px;\n  padding: 3px 8px;\n  border-radius: 6px;\n  background: rgba(47, 62, 70, calc(var(--rd-alpha) * 0.85));\n  color: var(--app-text-main);\n  font-variant-numeric: tabular-nums;\n  font-weight: 600;\n}\n.rd-cell--dark {\n  color: #ffffff;\n}\n.re-head {\n  margin-bottom: 12px;\n  padding-bottom: 12px;\n  border-bottom: 1px solid var(--app-border);\n}\n.re-head__title {\n  display: flex;\n  align-items: flex-start;\n  gap: 10px;\n}\n.re-head__title ion-icon {\n  flex: 0 0 auto;\n  margin-top: 2px;\n  color: var(--app-primary-dark);\n  font-size: 22px;\n}\n.re-head__title h2 {\n  margin: 0;\n  color: var(--app-text-main);\n  font-size: 16px;\n  font-weight: 700;\n}\n.re-head__title p {\n  margin: 2px 0 0;\n  font-size: 12px;\n}\n.re-section {\n  margin-bottom: 12px;\n}\n.re-dl {\n  display: grid;\n  grid-template-columns: minmax(110px, 42%) 1fr;\n  margin: 0;\n  font-size: 13px;\n}\n.re-dl dt,\n.re-dl dd {\n  margin: 0;\n  padding: 6px 0;\n  border-bottom: 1px solid var(--app-border);\n}\n.re-dl dt {\n  padding-right: 8px;\n  color: var(--app-text-muted);\n}\n.re-dl dd {\n  color: var(--app-text-main);\n  font-weight: 500;\n  overflow-wrap: anywhere;\n}\n.re-dl__empty {\n  color: var(--app-text-faint) !important;\n  font-weight: 400 !important;\n}\n.re-certs {\n  display: flex;\n  flex-wrap: wrap;\n  gap: 6px;\n}\n.re-cert {\n  --background: #ecfdf5;\n  --color: #047857;\n  display: inline-flex;\n  align-items: center;\n  gap: 4px;\n  font-size: 12px;\n}\n.re-notes {\n  margin: 0;\n  color: var(--app-text-main);\n  font-size: 13px;\n  white-space: pre-line;\n}\n@media (max-width: 576px) {\n  .rx-bars__row,\n  .rd-scale {\n    grid-template-columns: minmax(84px, 38%) 1fr 34px;\n    gap: 8px;\n  }\n  .ra-dist__row {\n    grid-template-columns: 22px 1fr 34px;\n  }\n  .ra-dist__label {\n    display: none;\n  }\n  .rx-bar-line {\n    min-width: 120px;\n  }\n  .re-dl {\n    grid-template-columns: 1fr;\n  }\n  .re-dl dt {\n    padding-bottom: 0;\n    border-bottom: none;\n    font-size: 11px;\n  }\n}\n/*# sourceMappingURL=results.page.css.map */\n'] }]
  }], () => [], { reporteImprimible: [{ type: ViewChild, args: ["reporteImprimible", { isSignal: true }] }] });
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(ResultsPage, { className: "ResultsPage", filePath: "src/app/pages/session/results/results.page.ts", lineNumber: 177 });
})();
export {
  ATRIBUTOS_CVA,
  ResultsPage,
  clasificarPuntaje,
  etiquetaHedonica,
  puntoEnMedidor
};
//# debugId=37a2b7fb-c63a-5698-9eb5-5c9629f3028d
//# sourceMappingURL=results.page-OILATQX6.js.map
