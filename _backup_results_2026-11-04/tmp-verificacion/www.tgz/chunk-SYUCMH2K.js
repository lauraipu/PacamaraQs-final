import {
  Injectable,
  SupabaseService,
  computed,
  inject,
  setClassMetadata,
  signal,
  ɵɵdefineInjectable
} from "./chunk-ELFI4Z7L.js";

// src/app/core/services/auth.ts
var VERSION_POLITICA = "1.0";
var _AuthService = class _AuthService {
  constructor() {
    this.supabase = inject(SupabaseService);
    this._usuario = signal(
      null,
      ...ngDevMode ? [{ debugName: "_usuario" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this._rol = signal(
      null,
      ...ngDevMode ? [{ debugName: "_rol" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this._inicializado = signal(
      false,
      ...ngDevMode ? [{ debugName: "_inicializado" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.usuario = this._usuario.asReadonly();
    this.rol = this._rol.asReadonly();
    this.inicializado = this._inicializado.asReadonly();
    this.autenticado = computed(
      () => this._usuario() !== null,
      ...ngDevMode ? [{ debugName: "autenticado" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.esAdmin = computed(
      () => this._rol() === "administrador",
      ...ngDevMode ? [{ debugName: "esAdmin" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.rutaInicio = computed(
      () => this.rutaInicioPorRol(this._rol()),
      ...ngDevMode ? [{ debugName: "rutaInicio" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.inicializacion = null;
    this.cargaRol = null;
    this.supabase.client.auth.onAuthStateChange((evento, sesion) => {
      this.aplicarCambioSesion(evento, sesion);
    });
  }
  /** Garantiza que el estado inicial (sesión persistida + rol) esté cargado. */
  asegurarInicializado() {
    this.inicializacion ??= this.inicializar();
    return this.inicializacion;
  }
  async login(email, password) {
    const { data, error } = await this.supabase.client.auth.signInWithPassword({
      email: email.trim(),
      password
    });
    if (error)
      throw error;
    if (!data.user || data.user.is_anonymous) {
      throw new Error("No se pudo validar tu usuario autenticado.");
    }
    this._usuario.set(this.mapearUsuario(data.user));
    this._rol.set(null);
    this.cargaRol = null;
    return this.obtenerRol(true);
  }
  async registro(email, password, nombre) {
    const correo = email.trim();
    const nombreCompleto = nombre.trim();
    if (!correo || !password || !nombreCompleto) {
      throw new Error("El nombre, el correo y la contrase\xF1a son obligatorios.");
    }
    const { data, error } = await this.supabase.client.auth.signUp({
      email: correo,
      password,
      options: { data: { nombre: nombreCompleto, version_politica: VERSION_POLITICA } }
    });
    if (error)
      throw error;
    if (data.session?.user) {
      this._usuario.set(this.mapearUsuario(data.session.user));
      await this.obtenerRol(true);
    }
    return data;
  }
  async signOut() {
    const { error } = await this.supabase.client.auth.signOut();
    this.limpiarEstado();
    if (error)
      throw error;
  }
  /**
   * Devuelve el rol del usuario actual (cacheado). `forzar` vuelve a leerlo
   * de la base de datos, p. ej. tras un login o un ascenso a administrador.
   */
  async obtenerRol(forzar = false) {
    const usuario = this._usuario();
    if (!usuario)
      throw new Error("No hay un usuario autenticado.");
    const enCache = this._rol();
    if (enCache && !forzar)
      return enCache;
    if (!this.cargaRol || forzar) {
      this.cargaRol = this.leerRol(usuario.id).finally(() => {
        this.cargaRol = null;
      });
    }
    return this.cargaRol;
  }
  rutaInicioPorRol(rol) {
    if (rol === "administrador")
      return "/admin-dashboard";
    if (rol === "catador")
      return "/dashboard";
    return "/login";
  }
  /** Ruta de inicio del usuario actual o null si no hay sesión válida. */
  async obtenerRutaInicio() {
    await this.asegurarInicializado();
    if (!this._usuario())
      return null;
    const rol = await this.obtenerRol();
    return this.rutaInicioPorRol(rol);
  }
  /** Token vigente (lectura local, sin red). */
  async getSession() {
    const { data, error } = await this.supabase.client.auth.getSession();
    if (error)
      throw error;
    return data;
  }
  /** Valida el token contra el servidor de Auth (petición de red). */
  async getUser() {
    const { data, error } = await this.supabase.client.auth.getUser();
    if (error)
      throw error;
    return data;
  }
  async inicializar() {
    try {
      const { session } = await this.getSession();
      const user = session?.user;
      if (user && !user.is_anonymous) {
        this._usuario.set(this.mapearUsuario(user));
        try {
          await this.obtenerRol();
        } catch (error) {
          console.error("[AuthService] No se pudo leer el rol:", error);
        }
      } else {
        this.limpiarEstado();
      }
    } finally {
      this._inicializado.set(true);
    }
  }
  aplicarCambioSesion(evento, sesion) {
    if (evento === "SIGNED_OUT" || !sesion?.user || sesion.user.is_anonymous) {
      this.limpiarEstado();
      return;
    }
    const anterior = this._usuario();
    this._usuario.set(this.mapearUsuario(sesion.user));
    if (evento === "USER_UPDATED" || anterior?.id !== sesion.user.id) {
      this._rol.set(null);
      setTimeout(() => {
        void this.obtenerRol(true).catch((error) => console.error("[AuthService] No se pudo refrescar el rol:", error));
      }, 0);
    }
  }
  async leerRol(usuarioId) {
    const { data, error } = await this.supabase.client.from("usuarios").select("rol_global").eq("id", usuarioId).maybeSingle();
    if (error)
      throw error;
    const rol = typeof data?.rol_global === "string" ? data.rol_global.trim().toLowerCase() : "";
    if (rol !== "catador" && rol !== "administrador") {
      throw new Error("La cuenta no tiene un rol asignado. Contacta al administrador.");
    }
    if (this._usuario()?.id === usuarioId)
      this._rol.set(rol);
    return rol;
  }
  limpiarEstado() {
    this._usuario.set(null);
    this._rol.set(null);
    this.cargaRol = null;
  }
  mapearUsuario(user) {
    const nombreMetadata = user.user_metadata?.["nombre"];
    const email = user.email ?? "";
    return {
      id: user.id,
      email,
      nombre: typeof nombreMetadata === "string" && nombreMetadata.trim() ? nombreMetadata.trim() : email.split("@")[0] || "Catador"
    };
  }
};
_AuthService.\u0275fac = function AuthService_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _AuthService)();
};
_AuthService.\u0275prov = /* @__PURE__ */ \u0275\u0275defineInjectable({ token: _AuthService, factory: _AuthService.\u0275fac, providedIn: "root" });
var AuthService = _AuthService;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(AuthService, [{
    type: Injectable,
    args: [{ providedIn: "root" }]
  }], () => [], null);
})();

export {
  AuthService
};
//# debugId=c31180f8-5997-5c12-93d3-cc4b5b7d9908
//# sourceMappingURL=chunk-SYUCMH2K.js.map
