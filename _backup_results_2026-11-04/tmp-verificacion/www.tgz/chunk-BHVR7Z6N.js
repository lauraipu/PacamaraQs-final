import {
  participanteDtoToDomain,
  sesionDtoToDomain
} from "./chunk-IN4O4X7H.js";
import {
  Injectable,
  SupabaseService,
  inject,
  setClassMetadata,
  ɵɵdefineInjectable
} from "./chunk-DEQWXDMW.js";
import {
  __spreadProps,
  __spreadValues
} from "./chunk-PAXKX5KU.js";

// src/app/core/services/sesion.ts
var _SesionService = class _SesionService {
  constructor() {
    this.supabase = inject(SupabaseService);
  }
  async crearSesion(sesion) {
    if (!sesion.nombre?.trim()) {
      throw new Error("El nombre de la sesi\xF3n no puede estar vac\xEDo");
    }
    const { data, error } = await this.supabase.client.rpc("crear_sesion", {
      p_nombre: sesion.nombre.trim(),
      p_formato: sesion.formato.toLowerCase(),
      p_numero_muestras: sesion.numeroMuestras,
      p_catadores_objetivo: sesion.catadoresObjetivo,
      p_organizador_participa: sesion.organizadorParticipa,
      p_notas: sesion.notas?.trim() || null
    });
    if (error)
      throw error;
    if (!data)
      throw new Error("Supabase no devolvi\xF3 la sesi\xF3n creada.");
    return sesionDtoToDomain(data);
  }
  async obtenerSesionPorId(sesionId) {
    const { data, error } = await this.supabase.client.from("sesiones").select("*").eq("id", sesionId).maybeSingle();
    if (error)
      throw error;
    return data ? sesionDtoToDomain(data) : null;
  }
  async esOrganizadorDeSesion(sesionId, usuarioId) {
    const { data, error } = await this.supabase.client.from("sesiones").select("organizador_id").eq("id", sesionId).maybeSingle();
    if (error)
      throw error;
    return data?.organizador_id === usuarioId;
  }
  async obtenerMisSesiones(usuarioId) {
    if (!usuarioId.trim())
      throw new Error("El ID de usuario es inv\xE1lido");
    const { data: participaciones, error: errorParticipaciones } = await this.supabase.client.from("participantes").select("sesion_id, es_organizador").eq("usuario_id", usuarioId);
    if (errorParticipaciones)
      throw errorParticipaciones;
    const rolesPorSesion = /* @__PURE__ */ new Map();
    for (const participacion of participaciones ?? []) {
      if (!participacion.sesion_id)
        continue;
      rolesPorSesion.set(participacion.sesion_id, (rolesPorSesion.get(participacion.sesion_id) ?? false) || participacion.es_organizador === true);
    }
    const idsParticipacion = [...rolesPorSesion.keys()];
    const [organizadas, participadas] = await Promise.all([
      this.supabase.client.from("sesiones").select("*").eq("organizador_id", usuarioId).order("creado_en", { ascending: false }),
      idsParticipacion.length > 0 ? this.supabase.client.from("sesiones").select("*").in("id", idsParticipacion) : Promise.resolve({ data: [], error: null })
    ]);
    if (organizadas.error)
      throw organizadas.error;
    if (participadas.error)
      throw participadas.error;
    const sesiones = /* @__PURE__ */ new Map();
    for (const dto of organizadas.data ?? []) {
      const sesion = sesionDtoToDomain(dto);
      if (sesion.id)
        sesiones.set(sesion.id, __spreadProps(__spreadValues({}, sesion), { esOrganizador: true }));
    }
    for (const dto of participadas.data ?? []) {
      const sesion = sesionDtoToDomain(dto);
      if (!sesion.id)
        continue;
      const existente = sesiones.get(sesion.id);
      sesiones.set(sesion.id, __spreadProps(__spreadValues({}, sesion), {
        esOrganizador: existente?.esOrganizador ?? rolesPorSesion.get(sesion.id) ?? false
      }));
    }
    return [...sesiones.values()].sort((a, b) => (b.creadaEn ?? "").localeCompare(a.creadaEn ?? ""));
  }
  async eliminarSesion(sesionId) {
    if (!sesionId.trim())
      throw new Error("El ID de sesi\xF3n es inv\xE1lido");
    const { data, error } = await this.supabase.client.from("sesiones").delete().eq("id", sesionId).select("id").maybeSingle();
    if (error)
      throw error;
    if (!data)
      throw new Error("No se elimin\xF3 la sesi\xF3n. Verifica que tengas permisos para eliminarla.");
  }
  async unirseASesion(codigo) {
    const codigoNormalizado = codigo.trim().toUpperCase();
    if (!codigoNormalizado)
      throw new Error("El c\xF3digo es obligatorio");
    const { data: sesionId, error } = await this.supabase.client.rpc("unirse_sesion", {
      p_codigo: codigoNormalizado
    });
    if (error)
      throw error;
    if (typeof sesionId !== "string" || !sesionId)
      throw new Error("No se pudo unir a la sesi\xF3n.");
    const sesion = await this.obtenerSesionPorId(sesionId);
    if (!sesion?.id) {
      throw new Error("Te uniste, pero no se pudo cargar la sesi\xF3n. Intenta actualizar el panel.");
    }
    return { sesion };
  }
  /** Lista autoritativa de participantes (resincronización REST). */
  async obtenerParticipantes(sesionId) {
    const { data, error } = await this.supabase.client.from("participantes").select("*").eq("sesion_id", sesionId).order("unido_en", { ascending: true });
    if (error)
      throw error;
    return this.normalizarParticipantes(data ?? []);
  }
  async obtenerMuestrasCerradas(sesionId) {
    const { data, error } = await this.supabase.client.from("cierres_muestra").select("numero_muestra").eq("sesion_id", sesionId);
    if (error)
      throw error;
    return (data ?? []).map((fila) => Number(fila.numero_muestra)).filter((numero) => Number.isInteger(numero)).sort((a, b) => a - b);
  }
  async marcarComoListo(sesionId, listo = true) {
    const { error } = await this.supabase.client.rpc("marcar_listo", {
      p_sesion_id: sesionId,
      p_listo: listo
    });
    if (error)
      throw error;
  }
  /**
   * Sin `usuarioId`: el usuario actual abandona la sesión.
   * Con `usuarioId`: el organizador retira a un catador (Grace Period vencido).
   */
  async abandonarSesion(sesionId, usuarioId) {
    const { error } = await this.supabase.client.rpc("abandonar_sesion", {
      p_sesion_id: sesionId,
      p_usuario_id: usuarioId ?? null
    });
    if (error)
      throw error;
  }
  async iniciarSesion(sesionId) {
    const { error } = await this.supabase.client.rpc("iniciar_sesion", { p_sesion_id: sesionId });
    if (error)
      throw error;
  }
  async forzarCierreMuestra(sesionId, numeroMuestra, motivo) {
    const { data, error } = await this.supabase.client.rpc("forzar_cierre_muestra", {
      p_sesion_id: sesionId,
      p_numero_muestra: numeroMuestra,
      p_motivo: motivo?.trim() || null
    });
    if (error)
      throw error;
    const dto = data;
    return {
      numeroMuestra: Number(dto?.numero_muestra ?? numeroMuestra),
      fichasPendientesDescartadas: Number(dto?.fichas_pendientes_descartadas ?? 0),
      sesionCompletada: dto?.sesion_completada === true
    };
  }
  async finalizarSesionForzado(sesionId, motivo) {
    const { error } = await this.supabase.client.rpc("finalizar_sesion_forzado", {
      p_sesion_id: sesionId,
      p_motivo: motivo?.trim() || null
    });
    if (error)
      throw error;
  }
  async obtenerProgresoPanel(sesionId) {
    const { data, error } = await this.supabase.client.rpc("get_progreso_panel", { p_sesion_id: sesionId });
    if (error)
      throw error;
    const dto = data;
    return {
      estado: dto?.estado ?? "",
      numeroMuestras: Number(dto?.numero_muestras ?? 0),
      muestrasCerradas: (dto?.muestras_cerradas ?? []).map(Number),
      catadores: (dto?.catadores ?? []).map((c) => ({
        usuarioId: c.usuario_id,
        nombre: c.nombre,
        esOrganizador: c.es_organizador === true,
        listo: c.listo === true,
        muestrasEnviadas: (c.muestras_enviadas ?? []).map(Number)
      }))
    };
  }
  /** Descarta filas sin usuario real y deduplica por usuario (defensa en profundidad). */
  normalizarParticipantes(filas) {
    const porUsuario = /* @__PURE__ */ new Map();
    for (const fila of filas) {
      const participante = participanteDtoToDomain(fila);
      if (participante.usuarioId && !porUsuario.has(participante.usuarioId)) {
        porUsuario.set(participante.usuarioId, participante);
      }
    }
    return [...porUsuario.values()];
  }
};
_SesionService.\u0275fac = function SesionService_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _SesionService)();
};
_SesionService.\u0275prov = /* @__PURE__ */ \u0275\u0275defineInjectable({ token: _SesionService, factory: _SesionService.\u0275fac, providedIn: "root" });
var SesionService = _SesionService;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(SesionService, [{
    type: Injectable,
    args: [{ providedIn: "root" }]
  }], null, null);
})();

export {
  SesionService
};
//# debugId=e6636f0b-a213-5e74-aaa4-49228453a829
//# sourceMappingURL=chunk-BHVR7Z6N.js.map
