import {
  SesionService
} from "./chunk-BHVR7Z6N.js";
import {
  EstadoSesion,
  FormatoCva,
  checkmarkCircleOutline,
  documentTextOutline,
  getFormatoById,
  hourglassOutline,
  lockClosedOutline
} from "./chunk-IN4O4X7H.js";
import {
  addIcons
} from "./chunk-4JFQPQWK.js";
import {
  AuthService
} from "./chunk-JH4CNQSM.js";
import {
  ActivatedRoute,
  CommonModule,
  Component,
  IonButton,
  IonContent,
  IonIcon,
  NavController,
  Router,
  computed,
  inject,
  setClassMetadata,
  signal,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵconditional,
  ɵɵconditionalCreate,
  ɵɵdefineComponent,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵlistener,
  ɵɵnextContext,
  ɵɵproperty,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1
} from "./chunk-DEQWXDMW.js";
import "./chunk-BMQUG2PJ.js";
import "./chunk-3OZZMUVI.js";
import "./chunk-3GAB7GSC.js";
import "./chunk-B7Y4FMY7.js";
import "./chunk-NQCL7WZ3.js";
import "./chunk-4BTEZGN2.js";
import "./chunk-XTVSKRH4.js";
import "./chunk-ETZFPO3Y.js";
import "./chunk-LLS636HS.js";
import "./chunk-KQQH3YTO.js";
import "./chunk-DI3VEDFV.js";
import "./chunk-PAXKX5KU.js";

// src/app/pages/session/evaluation-complete/evaluation-complete.page.ts
function EvaluationCompletePage_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "h1", 12);
    \u0275\u0275text(1, "Ficha t\xE9cnica registrada");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(2, "p", 13);
    \u0275\u0275text(3, "La evaluaci\xF3n extr\xEDnseca es individual: tus datos de origen, proceso y comercializaci\xF3n quedaron guardados.");
    \u0275\u0275elementEnd();
  }
}
function EvaluationCompletePage_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "h1", 12);
    \u0275\u0275text(1, "Cata finalizada");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(2, "p", 13);
    \u0275\u0275text(3, "Gracias por completar la sesi\xF3n. Consulta al organizador si necesitas confirmar el registro de tu evaluaci\xF3n.");
    \u0275\u0275elementEnd();
  }
}
function EvaluationCompletePage_Conditional_6_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 4);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx);
  }
}
function EvaluationCompletePage_Conditional_13_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 6)(1, "span", 7);
    \u0275\u0275text(2, "Formato");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "span", 8);
    \u0275\u0275text(4);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(ctx_r0.tituloFormato());
  }
}
function EvaluationCompletePage_Conditional_14_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 6)(1, "span", 7);
    \u0275\u0275text(2, "Estado del panel");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "span", 8);
    \u0275\u0275text(4);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(ctx_r0.panelCerrado() ? "Cerrado" : "Abierto");
  }
}
function EvaluationCompletePage_Conditional_15_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 9);
    \u0275\u0275element(1, "ion-icon", 14);
    \u0275\u0275elementStart(2, "div")(3, "h4");
    \u0275\u0275text(4, "A\xFAn hay catadores evaluando");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "p");
    \u0275\u0275text(6, "Los resultados se consolidan cuando todos env\xEDan sus fichas. Desde el monitoreo puedes ver el avance o finalizar el panel.");
    \u0275\u0275elementEnd()()();
  }
}
function EvaluationCompletePage_Conditional_16_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 9);
    \u0275\u0275element(1, "ion-icon", 15);
    \u0275\u0275elementStart(2, "div")(3, "h4");
    \u0275\u0275text(4, "Los resultados permanecen reservados");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "p");
    \u0275\u0275text(6, "Para proteger la evaluaci\xF3n ciega, los catadores no tienen acceso a los puntajes hasta que el organizador consolide el panel.");
    \u0275\u0275elementEnd()()();
  }
}
function EvaluationCompletePage_Conditional_17_Template(rf, ctx) {
  if (rf & 1) {
    const _r2 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "ion-button", 16);
    \u0275\u0275listener("click", function EvaluationCompletePage_Conditional_17_Template_ion_button_click_0_listener() {
      \u0275\u0275restoreView(_r2);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.irAResultados());
    });
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", ctx_r0.esExtrinseco() ? "Ver ficha t\xE9cnica \u2192" : "Ver resultados del panel \u2192", " ");
  }
}
function EvaluationCompletePage_Conditional_18_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "ion-button", 16);
    \u0275\u0275listener("click", function EvaluationCompletePage_Conditional_18_Template_ion_button_click_0_listener() {
      \u0275\u0275restoreView(_r3);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.irAMonitoreo());
    });
    \u0275\u0275text(1, " Monitorear y finalizar panel \u2192 ");
    \u0275\u0275elementEnd();
  }
}
addIcons({ checkmarkCircleOutline, documentTextOutline, hourglassOutline, lockClosedOutline });
var _EvaluationCompletePage = class _EvaluationCompletePage {
  constructor() {
    this.route = inject(ActivatedRoute);
    this.router = inject(Router);
    this.navCtrl = inject(NavController);
    this.authService = inject(AuthService);
    this.sesionService = inject(SesionService);
    this.esOrganizador = signal(
      false,
      ...ngDevMode ? [{ debugName: "esOrganizador" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.nombreSesion = signal(
      "",
      ...ngDevMode ? [{ debugName: "nombreSesion" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.formato = signal(
      "",
      ...ngDevMode ? [{ debugName: "formato" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.estado = signal(
      null,
      ...ngDevMode ? [{ debugName: "estado" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.error = signal(
      null,
      ...ngDevMode ? [{ debugName: "error" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.cargando = signal(
      true,
      ...ngDevMode ? [{ debugName: "cargando" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.esExtrinseco = computed(
      () => this.formato() === FormatoCva.EXTRINSECA.id,
      ...ngDevMode ? [{ debugName: "esExtrinseco" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.tituloFormato = computed(
      () => this.formato() ? getFormatoById(this.formato()).titulo : "",
      ...ngDevMode ? [{ debugName: "tituloFormato" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.panelCerrado = computed(
      () => this.estado() === EstadoSesion.FINALIZADA,
      ...ngDevMode ? [{ debugName: "panelCerrado" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.puedeVerResultados = computed(
      () => this.esOrganizador() && this.panelCerrado(),
      ...ngDevMode ? [{ debugName: "puedeVerResultados" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.debeFinalizarPanel = computed(
      () => this.esOrganizador() && !this.panelCerrado() && !this.esExtrinseco() && this.estado() === EstadoSesion.INICIADA,
      ...ngDevMode ? [{ debugName: "debeFinalizarPanel" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.sesionId = "";
  }
  async ngOnInit() {
    this.sesionId = this.route.snapshot.paramMap.get("id")?.trim() ?? "";
    if (!this.sesionId) {
      this.error.set("No se encontr\xF3 el ID de la sesi\xF3n.");
      this.cargando.set(false);
      return;
    }
    try {
      const { session } = await this.authService.getSession();
      const user = session?.user;
      if (!user) {
        await this.router.navigateByUrl("/login", { replaceUrl: true });
        return;
      }
      const sesion = await this.sesionService.obtenerSesionPorId(this.sesionId);
      if (!sesion)
        throw new Error("No se encontr\xF3 la sesi\xF3n.");
      this.nombreSesion.set(sesion.nombre);
      this.formato.set(getFormatoById(sesion.formato).id);
      this.estado.set(sesion.estado);
      this.esOrganizador.set(sesion.organizadorId === user.id);
    } catch (error) {
      this.error.set(error instanceof Error ? error.message : "No se pudo cargar la sesi\xF3n.");
    } finally {
      this.cargando.set(false);
    }
  }
  async irAResultados() {
    if (!this.puedeVerResultados() || !this.sesionId)
      return;
    await this.router.navigateByUrl(`/session/${this.sesionId}/results`);
  }
  async irAMonitoreo() {
    if (!this.esOrganizador() || !this.sesionId)
      return;
    await this.router.navigateByUrl(`/session/${this.sesionId}/organizer-dashboard`);
  }
  volverAlPanel() {
    void this.navCtrl.navigateRoot("/dashboard");
  }
};
_EvaluationCompletePage.\u0275fac = function EvaluationCompletePage_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _EvaluationCompletePage)();
};
_EvaluationCompletePage.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _EvaluationCompletePage, selectors: [["app-evaluation-complete"]], decls: 21, vars: 8, consts: [[1, "ion-padding", 2, "--background", "#F8FAFC"], [1, "complete-container"], [1, "icon-wrapper"], [3, "name"], ["role", "alert", 1, "subtitle"], [1, "info-card"], [1, "info-row"], [1, "info-label"], [1, "info-value"], [1, "privacy-card"], ["expand", "block", 1, "primary-btn"], ["expand", "block", "fill", "outline", 2, "--border-color", "#E2E8F0", "--color", "#0F172B", 3, "click"], [1, "title"], [1, "subtitle"], ["name", "hourglass-outline"], ["name", "lock-closed-outline"], ["expand", "block", 1, "primary-btn", 3, "click"]], template: function EvaluationCompletePage_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-content", 0)(1, "div", 1)(2, "div", 2);
    \u0275\u0275element(3, "ion-icon", 3);
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(4, EvaluationCompletePage_Conditional_4_Template, 4, 0)(5, EvaluationCompletePage_Conditional_5_Template, 4, 0);
    \u0275\u0275conditionalCreate(6, EvaluationCompletePage_Conditional_6_Template, 2, 1, "p", 4);
    \u0275\u0275elementStart(7, "div", 5)(8, "div", 6)(9, "span", 7);
    \u0275\u0275text(10, "Sesi\xF3n");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(11, "span", 8);
    \u0275\u0275text(12);
    \u0275\u0275elementEnd()();
    \u0275\u0275conditionalCreate(13, EvaluationCompletePage_Conditional_13_Template, 5, 1, "div", 6);
    \u0275\u0275conditionalCreate(14, EvaluationCompletePage_Conditional_14_Template, 5, 1, "div", 6);
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(15, EvaluationCompletePage_Conditional_15_Template, 7, 0, "div", 9)(16, EvaluationCompletePage_Conditional_16_Template, 7, 0, "div", 9);
    \u0275\u0275conditionalCreate(17, EvaluationCompletePage_Conditional_17_Template, 2, 1, "ion-button", 10)(18, EvaluationCompletePage_Conditional_18_Template, 2, 0, "ion-button", 10);
    \u0275\u0275elementStart(19, "ion-button", 11);
    \u0275\u0275listener("click", function EvaluationCompletePage_Template_ion_button_click_19_listener() {
      return ctx.volverAlPanel();
    });
    \u0275\u0275text(20, " Volver al panel principal ");
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    let tmp_2_0;
    \u0275\u0275advance(3);
    \u0275\u0275property("name", ctx.esExtrinseco() ? "document-text-outline" : "checkmark-circle-outline");
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx.esExtrinseco() ? 4 : 5);
    \u0275\u0275advance(2);
    \u0275\u0275conditional((tmp_2_0 = ctx.error()) ? 6 : -1, tmp_2_0);
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate(ctx.nombreSesion());
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx.tituloFormato() ? 13 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(!ctx.cargando() && !ctx.esExtrinseco() ? 14 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx.debeFinalizarPanel() ? 15 : !ctx.esExtrinseco() ? 16 : -1);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx.puedeVerResultados() ? 17 : ctx.debeFinalizarPanel() ? 18 : -1);
  }
}, dependencies: [CommonModule, IonContent, IonIcon, IonButton], styles: ["\n.complete-container[_ngcontent-%COMP%] {\n  max-width: 500px;\n  margin: 0 auto;\n  padding-top: 40px;\n  text-align: center;\n}\n.icon-wrapper[_ngcontent-%COMP%] {\n  width: 64px;\n  height: 64px;\n  background: #F1F5F9;\n  border-radius: 50%;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  margin: 0 auto 16px;\n}\n.icon-wrapper[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 32px;\n  color: #2F3E46;\n}\n.title[_ngcontent-%COMP%] {\n  font-size: 22px;\n  font-weight: 700;\n  color: #0F172B;\n  margin-bottom: 8px;\n}\n.subtitle[_ngcontent-%COMP%] {\n  font-size: 14px;\n  color: #62748E;\n  margin-bottom: 24px;\n  line-height: 1.5;\n}\n.info-card[_ngcontent-%COMP%] {\n  background: #FFFFFF;\n  border: 1px solid #E2E8F0;\n  border-radius: 12px;\n  padding: 16px;\n  margin-bottom: 16px;\n  text-align: left;\n}\n.info-row[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  margin-bottom: 8px;\n  font-size: 13px;\n}\n.info-row[_ngcontent-%COMP%]:last-child {\n  margin-bottom: 0;\n}\n.info-label[_ngcontent-%COMP%] {\n  color: #62748E;\n}\n.info-value[_ngcontent-%COMP%] {\n  font-weight: 600;\n  color: #0F172B;\n}\n.privacy-card[_ngcontent-%COMP%] {\n  background: #FFFFFF;\n  border: 1px solid #E2E8F0;\n  border-radius: 12px;\n  padding: 16px;\n  display: flex;\n  gap: 12px;\n  text-align: left;\n  margin-bottom: 24px;\n}\n.privacy-card[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 20px;\n  color: #2F3E46;\n  flex-shrink: 0;\n}\n.privacy-card[_ngcontent-%COMP%]   h4[_ngcontent-%COMP%] {\n  margin: 0 0 4px;\n  font-size: 13px;\n  font-weight: 700;\n  color: #0F172B;\n}\n.privacy-card[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 11px;\n  color: #62748E;\n  line-height: 1.4;\n}\n.primary-btn[_ngcontent-%COMP%] {\n  --%NS%background: #2F3E46;\n  --%NS%color: #FFF;\n  --%NS%border-radius: 8px;\n  height: 48px;\n  font-weight: 600;\n  text-transform: none;\n  margin-bottom: 12px;\n}\n/*# sourceMappingURL=evaluation-complete.page.css.map */"] });
var EvaluationCompletePage = _EvaluationCompletePage;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(EvaluationCompletePage, [{
    type: Component,
    args: [{ selector: "app-evaluation-complete", standalone: true, imports: [CommonModule, IonContent, IonIcon, IonButton], template: `<ion-content class="ion-padding" style="--background: #F8FAFC;">
  <div class="complete-container">

    <div class="icon-wrapper">
      <ion-icon [name]="esExtrinseco() ? 'document-text-outline' : 'checkmark-circle-outline'"></ion-icon>
    </div>

    @if (esExtrinseco()) {
      <h1 class="title">Ficha t\xE9cnica registrada</h1>
      <p class="subtitle">La evaluaci\xF3n extr\xEDnseca es individual: tus datos de origen, proceso y comercializaci\xF3n quedaron guardados.</p>
    } @else {
      <h1 class="title">Cata finalizada</h1>
      <p class="subtitle">Gracias por completar la sesi\xF3n. Consulta al organizador si necesitas confirmar el registro de tu evaluaci\xF3n.</p>
    }

    @if (error(); as mensaje) {
      <p class="subtitle" role="alert">{{ mensaje }}</p>
    }

    <div class="info-card">
      <div class="info-row">
        <span class="info-label">Sesi\xF3n</span>
        <span class="info-value">{{ nombreSesion() }}</span>
      </div>
      @if (tituloFormato()) {
        <div class="info-row">
          <span class="info-label">Formato</span>
          <span class="info-value">{{ tituloFormato() }}</span>
        </div>
      }
      @if (!cargando() && !esExtrinseco()) {
        <div class="info-row">
          <span class="info-label">Estado del panel</span>
          <span class="info-value">{{ panelCerrado() ? 'Cerrado' : 'Abierto' }}</span>
        </div>
      }
    </div>

    @if (debeFinalizarPanel()) {
      <div class="privacy-card">
        <ion-icon name="hourglass-outline"></ion-icon>
        <div>
          <h4>A\xFAn hay catadores evaluando</h4>
          <p>Los resultados se consolidan cuando todos env\xEDan sus fichas. Desde el monitoreo puedes ver el avance o finalizar el panel.</p>
        </div>
      </div>
    } @else if (!esExtrinseco()) {
      <div class="privacy-card">
        <ion-icon name="lock-closed-outline"></ion-icon>
        <div>
          <h4>Los resultados permanecen reservados</h4>
          <p>Para proteger la evaluaci\xF3n ciega, los catadores no tienen acceso a los puntajes hasta que el organizador consolide el panel.</p>
        </div>
      </div>
    }

    @if (puedeVerResultados()) {
      <ion-button expand="block" class="primary-btn" (click)="irAResultados()">
        {{ esExtrinseco() ? 'Ver ficha t\xE9cnica \u2192' : 'Ver resultados del panel \u2192' }}
      </ion-button>
    } @else if (debeFinalizarPanel()) {
      <ion-button expand="block" class="primary-btn" (click)="irAMonitoreo()">
        Monitorear y finalizar panel \u2192
      </ion-button>
    }

    <ion-button expand="block" fill="outline" style="--border-color: #E2E8F0; --color: #0F172B;" (click)="volverAlPanel()">
      Volver al panel principal
    </ion-button>

  </div>
</ion-content>
`, styles: ["/* src/app/pages/session/evaluation-complete/evaluation-complete.page.scss */\n.complete-container {\n  max-width: 500px;\n  margin: 0 auto;\n  padding-top: 40px;\n  text-align: center;\n}\n.icon-wrapper {\n  width: 64px;\n  height: 64px;\n  background: #F1F5F9;\n  border-radius: 50%;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  margin: 0 auto 16px;\n}\n.icon-wrapper ion-icon {\n  font-size: 32px;\n  color: #2F3E46;\n}\n.title {\n  font-size: 22px;\n  font-weight: 700;\n  color: #0F172B;\n  margin-bottom: 8px;\n}\n.subtitle {\n  font-size: 14px;\n  color: #62748E;\n  margin-bottom: 24px;\n  line-height: 1.5;\n}\n.info-card {\n  background: #FFFFFF;\n  border: 1px solid #E2E8F0;\n  border-radius: 12px;\n  padding: 16px;\n  margin-bottom: 16px;\n  text-align: left;\n}\n.info-row {\n  display: flex;\n  justify-content: space-between;\n  margin-bottom: 8px;\n  font-size: 13px;\n}\n.info-row:last-child {\n  margin-bottom: 0;\n}\n.info-label {\n  color: #62748E;\n}\n.info-value {\n  font-weight: 600;\n  color: #0F172B;\n}\n.privacy-card {\n  background: #FFFFFF;\n  border: 1px solid #E2E8F0;\n  border-radius: 12px;\n  padding: 16px;\n  display: flex;\n  gap: 12px;\n  text-align: left;\n  margin-bottom: 24px;\n}\n.privacy-card ion-icon {\n  font-size: 20px;\n  color: #2F3E46;\n  flex-shrink: 0;\n}\n.privacy-card h4 {\n  margin: 0 0 4px;\n  font-size: 13px;\n  font-weight: 700;\n  color: #0F172B;\n}\n.privacy-card p {\n  margin: 0;\n  font-size: 11px;\n  color: #62748E;\n  line-height: 1.4;\n}\n.primary-btn {\n  --background: #2F3E46;\n  --color: #FFF;\n  --border-radius: 8px;\n  height: 48px;\n  font-weight: 600;\n  text-transform: none;\n  margin-bottom: 12px;\n}\n/*# sourceMappingURL=evaluation-complete.page.css.map */\n"] }]
  }], null, null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(EvaluationCompletePage, { className: "EvaluationCompletePage", filePath: "src/app/pages/session/evaluation-complete/evaluation-complete.page.ts", lineNumber: 30 });
})();
export {
  EvaluationCompletePage
};
//# debugId=07421348-1bcd-57d6-8ae5-6942ab53e04f
//# sourceMappingURL=evaluation-complete.page-WHNVXURP.js.map
