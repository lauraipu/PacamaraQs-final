import {
  AuthService
} from "./chunk-JH4CNQSM.js";
import {
  CommonModule,
  Component,
  FormsModule,
  IonButton,
  IonCheckbox,
  IonContent,
  IonInput,
  IonItem,
  IonLabel,
  IonSpinner,
  NgControlStatus,
  NgControlStatusGroup,
  NgForm,
  NgModel,
  RequiredValidator,
  Router,
  RouterLink,
  ToastController,
  inject,
  setClassMetadata,
  signal,
  ɵNgNoValidate,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵattribute,
  ɵɵconditional,
  ɵɵconditionalCreate,
  ɵɵcontrol,
  ɵɵcontrolCreate,
  ɵɵdefineComponent,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵlistener,
  ɵɵproperty,
  ɵɵtext,
  ɵɵtextInterpolate1,
  ɵɵtwoWayBindingSet,
  ɵɵtwoWayListener,
  ɵɵtwoWayProperty
} from "./chunk-DEQWXDMW.js";
import "./chunk-BMQUG2PJ.js";
import "./chunk-3OZZMUVI.js";
import "./chunk-3GAB7GSC.js";
import "./chunk-B7Y4FMY7.js";
import "./chunk-NQCL7WZ3.js";
import "./chunk-4BTEZGN2.js";
import "./chunk-XTVSKRH4.js";
import "./chunk-ETZFPO3Y.js";
import "./chunk-LLS636HS.js";
import "./chunk-KQQH3YTO.js";
import "./chunk-DI3VEDFV.js";
import "./chunk-PAXKX5KU.js";

// src/app/pages/auth/registro/registro.page.ts
function RegistroPage_Conditional_22_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-spinner", 17);
  }
}
function RegistroPage_Conditional_23_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span");
    \u0275\u0275text(1, "Crear cuenta");
    \u0275\u0275elementEnd();
  }
}
var _RegistroPage = class _RegistroPage {
  constructor() {
    this.nombre = "";
    this.email = "";
    this.password = "";
    this.confirmPassword = "";
    this.showPassword = false;
    this.politicaAceptada = false;
    this.isLoading = signal(
      false,
      ...ngDevMode ? [{ debugName: "isLoading" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.authService = inject(AuthService);
    this.router = inject(Router);
    this.toastController = inject(ToastController);
  }
  async registro() {
    if (!this.nombre.trim() || !this.email.trim() || !this.password || !this.confirmPassword) {
      await this.mostrarToast("Completa todos los campos.");
      return;
    }
    if (this.password.length < 6) {
      await this.mostrarToast("La contrase\xF1a debe tener al menos 6 caracteres.");
      return;
    }
    if (this.password !== this.confirmPassword) {
      await this.mostrarToast("Las contrase\xF1as no coinciden.");
      return;
    }
    if (!this.politicaAceptada) {
      await this.mostrarToast("Debes aceptar la pol\xEDtica de privacidad para continuar.");
      return;
    }
    this.isLoading.set(true);
    try {
      const result = await this.authService.registro(this.email, this.password, this.nombre);
      if (result.session) {
        const destino = await this.authService.obtenerRutaInicio();
        await this.router.navigateByUrl(destino ?? "/login", { replaceUrl: true });
      } else {
        await this.mostrarToast("Cuenta creada. Revisa tu correo para confirmar el registro.", "success");
        await this.router.navigateByUrl("/login", { replaceUrl: true });
      }
    } catch (error) {
      await this.mostrarToast(error instanceof Error ? error.message : "No se pudo completar el registro.");
    } finally {
      this.isLoading.set(false);
    }
  }
  async mostrarToast(message, color = "danger") {
    const toast = await this.toastController.create({
      message,
      duration: 3500,
      position: "bottom",
      color
    });
    await toast.present();
  }
};
_RegistroPage.\u0275fac = function RegistroPage_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _RegistroPage)();
};
_RegistroPage.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _RegistroPage, selectors: [["app-registro"]], decls: 28, vars: 11, consts: [[1, "ion-padding", "register-content"], [1, "register-container"], [1, "logo-box"], ["src", "assets/icon/logopacamara.png", "alt", "Logo de Pacamara"], ["routerLink", "/login", 1, "back-link"], [1, "title"], [1, "subtitle"], [1, "register-form", 3, "ngSubmit"], ["name", "nombre", "label", "Nombre", "labelPlacement", "stacked", "autocomplete", "name", "fill", "outline", "required", "", 1, "custom-input", 3, "ngModelChange", "ngModel"], ["name", "email", "label", "Correo", "labelPlacement", "stacked", "type", "email", "autocomplete", "email", "inputmode", "email", "fill", "outline", "required", "", 1, "custom-input", 3, "ngModelChange", "ngModel"], ["name", "password", "label", "Contrase\xF1a", "labelPlacement", "stacked", "autocomplete", "new-password", "fill", "outline", "required", "", 1, "custom-input", 3, "ngModelChange", "ngModel", "type"], ["type", "button", "fill", "clear", 1, "password-toggle", 3, "click"], ["name", "confirmPassword", "label", "Confirmar contrase\xF1a", "labelPlacement", "stacked", "autocomplete", "new-password", "fill", "outline", "required", "", 1, "custom-input", 3, "ngModelChange", "ngModel", "type"], ["lines", "none", 1, "privacy-consent"], ["slot", "start", "name", "politicaAceptada", 3, "ngModelChange", "ngModel"], [1, "ion-text-wrap"], ["expand", "block", "type", "submit", 1, "primary-btn", 3, "disabled"], ["name", "crescent"], [1, "register-link"], ["routerLink", "/login"]], template: function RegistroPage_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-content", 0)(1, "main", 1)(2, "div", 2);
    \u0275\u0275element(3, "img", 3);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "a", 4);
    \u0275\u0275text(5, "Volver al inicio de sesi\xF3n");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "h1", 5);
    \u0275\u0275text(7, "Crear cuenta");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "p", 6);
    \u0275\u0275text(9, "Reg\xEDstrate para comenzar a catar.");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(10, "form", 7);
    \u0275\u0275listener("ngSubmit", function RegistroPage_Template_form_ngSubmit_10_listener() {
      return ctx.registro();
    });
    \u0275\u0275elementStart(11, "ion-input", 8);
    \u0275\u0275twoWayListener("ngModelChange", function RegistroPage_Template_ion_input_ngModelChange_11_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.nombre, $event) || (ctx.nombre = $event);
      return $event;
    });
    \u0275\u0275elementEnd();
    \u0275\u0275controlCreate();
    \u0275\u0275elementStart(12, "ion-input", 9);
    \u0275\u0275twoWayListener("ngModelChange", function RegistroPage_Template_ion_input_ngModelChange_12_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.email, $event) || (ctx.email = $event);
      return $event;
    });
    \u0275\u0275elementEnd();
    \u0275\u0275controlCreate();
    \u0275\u0275elementStart(13, "ion-input", 10);
    \u0275\u0275twoWayListener("ngModelChange", function RegistroPage_Template_ion_input_ngModelChange_13_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.password, $event) || (ctx.password = $event);
      return $event;
    });
    \u0275\u0275elementEnd();
    \u0275\u0275controlCreate();
    \u0275\u0275elementStart(14, "ion-button", 11);
    \u0275\u0275listener("click", function RegistroPage_Template_ion_button_click_14_listener() {
      return ctx.showPassword = !ctx.showPassword;
    });
    \u0275\u0275text(15);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(16, "ion-input", 12);
    \u0275\u0275twoWayListener("ngModelChange", function RegistroPage_Template_ion_input_ngModelChange_16_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.confirmPassword, $event) || (ctx.confirmPassword = $event);
      return $event;
    });
    \u0275\u0275elementEnd();
    \u0275\u0275controlCreate();
    \u0275\u0275elementStart(17, "ion-item", 13)(18, "ion-checkbox", 14);
    \u0275\u0275twoWayListener("ngModelChange", function RegistroPage_Template_ion_checkbox_ngModelChange_18_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.politicaAceptada, $event) || (ctx.politicaAceptada = $event);
      return $event;
    });
    \u0275\u0275elementEnd();
    \u0275\u0275controlCreate();
    \u0275\u0275elementStart(19, "ion-label", 15);
    \u0275\u0275text(20, " Acepto los t\xE9rminos y la pol\xEDtica de privacidad para crear y usar mi cuenta. ");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(21, "ion-button", 16);
    \u0275\u0275conditionalCreate(22, RegistroPage_Conditional_22_Template, 1, 0, "ion-spinner", 17)(23, RegistroPage_Conditional_23_Template, 2, 0, "span");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(24, "p", 18);
    \u0275\u0275text(25, " \xBFYa tienes cuenta? ");
    \u0275\u0275elementStart(26, "a", 19);
    \u0275\u0275text(27, "Inicia sesi\xF3n");
    \u0275\u0275elementEnd()()()();
  }
  if (rf & 2) {
    \u0275\u0275advance(11);
    \u0275\u0275twoWayProperty("ngModel", ctx.nombre);
    \u0275\u0275control();
    \u0275\u0275advance();
    \u0275\u0275twoWayProperty("ngModel", ctx.email);
    \u0275\u0275control();
    \u0275\u0275advance();
    \u0275\u0275twoWayProperty("ngModel", ctx.password);
    \u0275\u0275property("type", ctx.showPassword ? "text" : "password");
    \u0275\u0275control();
    \u0275\u0275advance();
    \u0275\u0275attribute("aria-label", ctx.showPassword ? "Ocultar contrase\xF1a" : "Mostrar contrase\xF1a");
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", ctx.showPassword ? "Ocultar" : "Mostrar", " ");
    \u0275\u0275advance();
    \u0275\u0275twoWayProperty("ngModel", ctx.confirmPassword);
    \u0275\u0275property("type", ctx.showPassword ? "text" : "password");
    \u0275\u0275control();
    \u0275\u0275advance(2);
    \u0275\u0275twoWayProperty("ngModel", ctx.politicaAceptada);
    \u0275\u0275control();
    \u0275\u0275advance(3);
    \u0275\u0275property("disabled", ctx.isLoading());
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx.isLoading() ? 22 : 23);
  }
}, dependencies: [
  IonContent,
  IonInput,
  IonButton,
  IonSpinner,
  IonItem,
  IonCheckbox,
  IonLabel,
  CommonModule,
  FormsModule,
  \u0275NgNoValidate,
  NgControlStatus,
  NgControlStatusGroup,
  RequiredValidator,
  NgModel,
  NgForm,
  RouterLink
], styles: ["\n[_nghost-%COMP%] {\n  display: block;\n}\n.register-content[_ngcontent-%COMP%] {\n  --%NS%background: var(--%NS%app-bg-screen);\n}\n.register-container[_ngcontent-%COMP%] {\n  width: min(100%, 460px);\n  min-height: 100%;\n  margin: 0 auto;\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n  padding: 32px 8px;\n}\n.logo-box[_ngcontent-%COMP%] {\n  display: grid;\n  width: 68px;\n  height: 68px;\n  place-items: center;\n  margin: 0 auto 20px;\n  overflow: hidden;\n  border-radius: 20px;\n  background: var(--%NS%app-primary-dark);\n}\n.logo-box[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 100%;\n  object-fit: cover;\n}\n.back-link[_ngcontent-%COMP%] {\n  margin-bottom: 24px;\n  color: var(--%NS%app-primary-dark);\n  text-decoration: none;\n}\n.title[_ngcontent-%COMP%] {\n  margin: 0;\n  color: var(--%NS%app-text-main);\n}\n.subtitle[_ngcontent-%COMP%] {\n  margin: 8px 0 24px;\n  color: var(--%NS%app-text-muted);\n}\n.register-form[_ngcontent-%COMP%] {\n  display: grid;\n  gap: 18px;\n}\n.password-toggle[_ngcontent-%COMP%] {\n  justify-self: end;\n  min-height: 28px;\n  margin: -14px 0 -12px;\n  color: var(--%NS%app-text-muted);\n  text-transform: none;\n}\n.privacy-consent[_ngcontent-%COMP%] {\n  --%NS%background: transparent;\n  --%NS%padding-start: 0;\n  color: var(--%NS%app-text-muted);\n}\n.register-link[_ngcontent-%COMP%] {\n  margin-top: 20px;\n  color: var(--%NS%app-text-muted);\n  text-align: center;\n}\n.register-link[_ngcontent-%COMP%]   a[_ngcontent-%COMP%] {\n  color: var(--%NS%app-primary-dark);\n  font-weight: 600;\n}\n/*# sourceMappingURL=registro.page.css.map */"] });
var RegistroPage = _RegistroPage;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(RegistroPage, [{
    type: Component,
    args: [{ selector: "app-registro", standalone: true, imports: [
      IonContent,
      IonInput,
      IonButton,
      IonSpinner,
      IonItem,
      IonCheckbox,
      IonLabel,
      CommonModule,
      FormsModule,
      RouterLink
    ], template: `<ion-content class="ion-padding register-content">
  <main class="register-container">
    <div class="logo-box">
      <img src="assets/icon/logopacamara.png" alt="Logo de Pacamara">
    </div>
    <a class="back-link" routerLink="/login">Volver al inicio de sesi\xF3n</a>
    <h1 class="title">Crear cuenta</h1>
    <p class="subtitle">Reg\xEDstrate para comenzar a catar.</p>

    <form class="register-form" (ngSubmit)="registro()">
      <ion-input
        [(ngModel)]="nombre"
        name="nombre"
        label="Nombre"
        labelPlacement="stacked"
        autocomplete="name"
        fill="outline"
        class="custom-input"
        required
      ></ion-input>
      <ion-input
        [(ngModel)]="email"
        name="email"
        label="Correo"
        labelPlacement="stacked"
        type="email"
        autocomplete="email"
        inputmode="email"
        fill="outline"
        class="custom-input"
        required
      ></ion-input>
      <ion-input
        [(ngModel)]="password"
        name="password"
        label="Contrase\xF1a"
        labelPlacement="stacked"
        [type]="showPassword ? 'text' : 'password'"
        autocomplete="new-password"
        fill="outline"
        class="custom-input"
        required
      ></ion-input>
      <ion-button
        type="button"
        fill="clear"
        class="password-toggle"
        [attr.aria-label]="showPassword ? 'Ocultar contrase\xF1a' : 'Mostrar contrase\xF1a'"
        (click)="showPassword = !showPassword"
      >
        {{ showPassword ? 'Ocultar' : 'Mostrar' }}
      </ion-button>
      <ion-input
        [(ngModel)]="confirmPassword"
        name="confirmPassword"
        label="Confirmar contrase\xF1a"
        labelPlacement="stacked"
        [type]="showPassword ? 'text' : 'password'"
        autocomplete="new-password"
        fill="outline"
        class="custom-input"
        required
      ></ion-input>

      <ion-item lines="none" class="privacy-consent">
        <ion-checkbox
          slot="start"
          [(ngModel)]="politicaAceptada"
          name="politicaAceptada"
        ></ion-checkbox>
        <ion-label class="ion-text-wrap">
          Acepto los t\xE9rminos y la pol\xEDtica de privacidad para crear y usar mi cuenta.
        </ion-label>
      </ion-item>

      <ion-button expand="block" type="submit" class="primary-btn" [disabled]="isLoading()">
        @if (isLoading()) {
          <ion-spinner name="crescent"></ion-spinner>
        } @else {
          <span>Crear cuenta</span>
        }
      </ion-button>
    </form>
    <p class="register-link">
      \xBFYa tienes cuenta?
      <a routerLink="/login">Inicia sesi\xF3n</a>
    </p>
  </main>
</ion-content>
`, styles: ["/* src/app/pages/auth/registro/registro.page.scss */\n:host {\n  display: block;\n}\n.register-content {\n  --background: var(--app-bg-screen);\n}\n.register-container {\n  width: min(100%, 460px);\n  min-height: 100%;\n  margin: 0 auto;\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n  padding: 32px 8px;\n}\n.logo-box {\n  display: grid;\n  width: 68px;\n  height: 68px;\n  place-items: center;\n  margin: 0 auto 20px;\n  overflow: hidden;\n  border-radius: 20px;\n  background: var(--app-primary-dark);\n}\n.logo-box img {\n  width: 100%;\n  height: 100%;\n  object-fit: cover;\n}\n.back-link {\n  margin-bottom: 24px;\n  color: var(--app-primary-dark);\n  text-decoration: none;\n}\n.title {\n  margin: 0;\n  color: var(--app-text-main);\n}\n.subtitle {\n  margin: 8px 0 24px;\n  color: var(--app-text-muted);\n}\n.register-form {\n  display: grid;\n  gap: 18px;\n}\n.password-toggle {\n  justify-self: end;\n  min-height: 28px;\n  margin: -14px 0 -12px;\n  color: var(--app-text-muted);\n  text-transform: none;\n}\n.privacy-consent {\n  --background: transparent;\n  --padding-start: 0;\n  color: var(--app-text-muted);\n}\n.register-link {\n  margin-top: 20px;\n  color: var(--app-text-muted);\n  text-align: center;\n}\n.register-link a {\n  color: var(--app-primary-dark);\n  font-weight: 600;\n}\n/*# sourceMappingURL=registro.page.css.map */\n"] }]
  }], null, null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(RegistroPage, { className: "RegistroPage", filePath: "src/app/pages/auth/registro/registro.page.ts", lineNumber: 35 });
})();
export {
  RegistroPage
};
//# debugId=38e0a242-db31-5801-82bf-76a306db4d0d
//# sourceMappingURL=registro.page-RHQ7KSYG.js.map
