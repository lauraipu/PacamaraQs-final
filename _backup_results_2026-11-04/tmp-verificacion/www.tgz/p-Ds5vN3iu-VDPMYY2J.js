import {
  r,
  w
} from "./chunk-4BTEZGN2.js";
import {
  n
} from "./chunk-XTVSKRH4.js";
import "./chunk-ETZFPO3Y.js";
import "./chunk-DI3VEDFV.js";
import "./chunk-PAXKX5KU.js";

// node_modules/@ionic/core/components/p-Ds5vN3iu.js
/*!
 * (C) Ionic http://ionicframework.com - MIT License
 */
var s = (s2, e, n2, a, c) => {
  const i = s2.ownerDocument.defaultView;
  let p = r(s2);
  const m = (t) => p ? -t.deltaX : t.deltaX;
  return n({ el: s2, gestureName: "goback-swipe", gesturePriority: 101, threshold: 10, canStart: (t) => (p = r(s2), ((t2) => {
    const { startX: o } = t2;
    return p ? o >= i.innerWidth - 50 : o <= 50;
  })(t) && e()), onStart: n2, onMove: (t) => {
    const o = m(t);
    a(o / i.innerWidth);
  }, onEnd: (o) => {
    const r2 = m(o), s3 = i.innerWidth, e2 = r2 / s3, n3 = ((t) => p ? -t.velocityX : t.velocityX)(o), a2 = n3 >= 0 && (n3 > 0.2 || r2 > s3 / 2), j = (a2 ? 1 - e2 : e2) * s3;
    let f = 0;
    if (j > 5) {
      const t = j / Math.abs(n3);
      f = Math.min(t, 540);
    }
    c(a2, e2 <= 0 ? 0.01 : w(0, e2, 0.9999), f);
  } });
};
export {
  s as createSwipeBackGesture
};
//# debugId=77d72ed6-825f-558b-911a-d44bae55b66e
//# sourceMappingURL=p-Ds5vN3iu-VDPMYY2J.js.map
