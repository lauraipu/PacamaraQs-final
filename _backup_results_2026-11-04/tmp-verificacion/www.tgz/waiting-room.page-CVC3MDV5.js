import {
  Clipboard
} from "./chunk-KXKZQCE7.js";
import {
  GRACE_PERIOD_MS,
  RealtimeService
} from "./chunk-7SA6TBRT.js";
import {
  mensajeDeError
} from "./chunk-OFWJO6PD.js";
import {
  SesionService
} from "./chunk-KN5DCTIK.js";
import {
  EstadoSesion,
  checkmarkCircleOutline,
  cloudOfflineOutline,
  copyOutline,
  exitOutline,
  getFormatoById,
  lockClosedOutline,
  peopleOutline,
  refreshOutline
} from "./chunk-ISYXHPYK.js";
import {
  addIcons
} from "./chunk-4JFQPQWK.js";
import {
  AuthService
} from "./chunk-SYUCMH2K.js";
import {
  ActivatedRoute,
  AlertController,
  CommonModule,
  Component,
  IonBackButton,
  IonBadge,
  IonButton,
  IonButtons,
  IonContent,
  IonHeader,
  IonIcon,
  IonItem,
  IonLabel,
  IonList,
  IonSpinner,
  IonTitle,
  IonToolbar,
  Router,
  TitleCasePipe,
  ToastController,
  computed,
  inject,
  setClassMetadata,
  signal,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵattribute,
  ɵɵclassProp,
  ɵɵconditional,
  ɵɵconditionalCreate,
  ɵɵdefineComponent,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵlistener,
  ɵɵnextContext,
  ɵɵpipe,
  ɵɵpipeBind1,
  ɵɵproperty,
  ɵɵrepeater,
  ɵɵrepeaterCreate,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1,
  ɵɵtextInterpolate2
} from "./chunk-ELFI4Z7L.js";
import "./chunk-BMQUG2PJ.js";
import "./chunk-3OZZMUVI.js";
import "./chunk-3GAB7GSC.js";
import "./chunk-B7Y4FMY7.js";
import "./chunk-NQCL7WZ3.js";
import "./chunk-4BTEZGN2.js";
import "./chunk-XTVSKRH4.js";
import "./chunk-ETZFPO3Y.js";
import "./chunk-LLS636HS.js";
import "./chunk-KQQH3YTO.js";
import "./chunk-DI3VEDFV.js";
import {
  __spreadProps,
  __spreadValues
} from "./chunk-PAXKX5KU.js";

// src/app/pages/session/waiting-room/waiting-room.page.ts
var _forTrack0 = ($index, $item) => $item.usuarioId;
function WaitingRoomPage_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 4);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx.nombre);
  }
}
function WaitingRoomPage_Conditional_14_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 10);
    \u0275\u0275element(1, "ion-icon", 13);
    \u0275\u0275text(2, " Reconectando con la sala\u2026 los cambios se sincronizar\xE1n al volver la conexi\xF3n. ");
    \u0275\u0275elementEnd();
  }
}
function WaitingRoomPage_Conditional_15_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 11)(1, "span");
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "ion-button", 14);
    \u0275\u0275listener("click", function WaitingRoomPage_Conditional_15_Template_ion_button_click_3_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.reintentar());
    });
    \u0275\u0275element(4, "ion-icon", 15);
    \u0275\u0275text(5, " Reintentar ");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(ctx);
  }
}
function WaitingRoomPage_Conditional_16_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 12);
    \u0275\u0275element(1, "ion-spinner", 16);
    \u0275\u0275elementStart(2, "span");
    \u0275\u0275text(3, "Cargando sala de espera\u2026");
    \u0275\u0275elementEnd()();
  }
}
function WaitingRoomPage_Conditional_17_Conditional_17_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "section", 21)(1, "h3", 24);
    \u0275\u0275text(2, "COMPARTIR ACCESO");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "div", 31)(4, "div", 32);
    \u0275\u0275text(5);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "ion-button", 33);
    \u0275\u0275listener("click", function WaitingRoomPage_Conditional_17_Conditional_17_Template_ion_button_click_6_listener() {
      \u0275\u0275restoreView(_r3);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.copiarCodigo());
    });
    \u0275\u0275element(7, "ion-icon", 34);
    \u0275\u0275text(8);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(9, "p", 35);
    \u0275\u0275text(10, "El c\xF3digo expira cuando inicies la cata.");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const s_r4 = \u0275\u0275nextContext();
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(s_r4.codigoAcceso);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate1(" ", ctx_r1.copiado() ? "Copiado" : "C\xF3digo", " ");
  }
}
function WaitingRoomPage_Conditional_17_Conditional_25_For_2_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 40);
    \u0275\u0275text(1, "organizador");
    \u0275\u0275elementEnd();
  }
}
function WaitingRoomPage_Conditional_17_Conditional_25_For_2_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 40);
    \u0275\u0275text(1, "t\xFA");
    \u0275\u0275elementEnd();
  }
}
function WaitingRoomPage_Conditional_17_Conditional_25_For_2_Conditional_9_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 41);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const p_r5 = \u0275\u0275nextContext().$implicit;
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1("Conexi\xF3n inestable \xB7 se retira en ", p_r5.segundosGracia, " s");
  }
}
function WaitingRoomPage_Conditional_17_Conditional_25_For_2_Conditional_10_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p");
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const p_r5 = \u0275\u0275nextContext().$implicit;
    const ctx_r1 = \u0275\u0275nextContext(3);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1("Desconectado \xB7 ", ctx_r1.tiempoDesde(p_r5.unidoEn));
  }
}
function WaitingRoomPage_Conditional_17_Conditional_25_For_2_Conditional_11_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p");
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const p_r5 = \u0275\u0275nextContext().$implicit;
    const ctx_r1 = \u0275\u0275nextContext(3);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx_r1.tiempoDesde(p_r5.unidoEn));
  }
}
function WaitingRoomPage_Conditional_17_Conditional_25_For_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-item", 37)(1, "div", 38);
    \u0275\u0275text(2);
    \u0275\u0275element(3, "span", 39);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "ion-label")(5, "h2");
    \u0275\u0275text(6);
    \u0275\u0275conditionalCreate(7, WaitingRoomPage_Conditional_17_Conditional_25_For_2_Conditional_7_Template, 2, 0, "span", 40);
    \u0275\u0275conditionalCreate(8, WaitingRoomPage_Conditional_17_Conditional_25_For_2_Conditional_8_Template, 2, 0, "span", 40);
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(9, WaitingRoomPage_Conditional_17_Conditional_25_For_2_Conditional_9_Template, 2, 1, "p", 41)(10, WaitingRoomPage_Conditional_17_Conditional_25_For_2_Conditional_10_Template, 2, 1, "p")(11, WaitingRoomPage_Conditional_17_Conditional_25_For_2_Conditional_11_Template, 2, 1, "p");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(12, "div", 42);
    \u0275\u0275element(13, "span", 43);
    \u0275\u0275text(14);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const p_r5 = ctx.$implicit;
    const ctx_r1 = \u0275\u0275nextContext(3);
    \u0275\u0275classProp("taster-item--inestable", p_r5.conexion === "inestable");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1(" ", (p_r5.nombre.charAt(0) || "?").toUpperCase(), " ");
    \u0275\u0275advance();
    \u0275\u0275classProp("presence-dot--online", p_r5.conexion === "en_linea")("presence-dot--unstable", p_r5.conexion === "inestable");
    \u0275\u0275attribute("aria-label", p_r5.conexion === "en_linea" ? "En l\xEDnea" : p_r5.conexion === "inestable" ? "Conexi\xF3n inestable" : "Desconectado");
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate1(" ", p_r5.nombre, " ");
    \u0275\u0275advance();
    \u0275\u0275conditional(p_r5.esOrganizador ? 7 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(p_r5.usuarioId === ctx_r1.usuarioActualId() ? 8 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(p_r5.conexion === "inestable" ? 9 : p_r5.conexion === "desconectado" ? 10 : 11);
    \u0275\u0275advance(4);
    \u0275\u0275classProp("ready", p_r5.listo);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", p_r5.listo ? "Listo" : "Conectado", " ");
  }
}
function WaitingRoomPage_Conditional_17_Conditional_25_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-list", 27);
    \u0275\u0275repeaterCreate(1, WaitingRoomPage_Conditional_17_Conditional_25_For_2_Template, 15, 15, "ion-item", 36, _forTrack0);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275repeater(ctx_r1.participantesEnSala());
  }
}
function WaitingRoomPage_Conditional_17_Conditional_26_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 28);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" Esperando que se unan al menos ", ctx_r1.MINIMO_CATADORES, " catadores. ");
  }
}
function WaitingRoomPage_Conditional_17_Conditional_33_Conditional_0_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-spinner", 16);
  }
}
function WaitingRoomPage_Conditional_17_Conditional_33_Conditional_0_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-icon", 49);
    \u0275\u0275text(1, " Estoy listo \xB7 tocar para cancelar ");
  }
}
function WaitingRoomPage_Conditional_17_Conditional_33_Conditional_0_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275text(0, " Estoy listo para catar ");
  }
}
function WaitingRoomPage_Conditional_17_Conditional_33_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r6 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 30)(1, "ion-button", 44);
    \u0275\u0275listener("click", function WaitingRoomPage_Conditional_17_Conditional_33_Conditional_0_Template_ion_button_click_1_listener() {
      \u0275\u0275restoreView(_r6);
      const ctx_r1 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r1.alternarListo());
    });
    \u0275\u0275conditionalCreate(2, WaitingRoomPage_Conditional_17_Conditional_33_Conditional_0_Conditional_2_Template, 1, 0, "ion-spinner", 16)(3, WaitingRoomPage_Conditional_17_Conditional_33_Conditional_0_Conditional_3_Template, 2, 0)(4, WaitingRoomPage_Conditional_17_Conditional_33_Conditional_0_Conditional_4_Template, 1, 0);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "p", 45);
    \u0275\u0275element(6, "span", 46);
    \u0275\u0275text(7, " Esperando que el organizador inicie la cata\u2026");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "ion-button", 47);
    \u0275\u0275listener("click", function WaitingRoomPage_Conditional_17_Conditional_33_Conditional_0_Template_ion_button_click_8_listener() {
      \u0275\u0275restoreView(_r6);
      const ctx_r1 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r1.salirDeSala());
    });
    \u0275\u0275element(9, "ion-icon", 48);
    \u0275\u0275text(10, " Salir de la sesi\xF3n ");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const yo_r7 = \u0275\u0275nextContext();
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275classProp("primary-btn", !yo_r7.listo);
    \u0275\u0275property("fill", yo_r7.listo ? "outline" : "solid")("disabled", ctx_r1.cambiandoListo());
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.cambiandoListo() ? 2 : yo_r7.listo ? 3 : 4);
    \u0275\u0275advance(6);
    \u0275\u0275property("disabled", ctx_r1.saliendo());
  }
}
function WaitingRoomPage_Conditional_17_Conditional_33_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275conditionalCreate(0, WaitingRoomPage_Conditional_17_Conditional_33_Conditional_0_Template, 11, 6, "div", 30);
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275conditional(!ctx_r1.esOrganizador() ? 0 : -1);
  }
}
function WaitingRoomPage_Conditional_17_Conditional_34_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275text(0, " Iniciando\u2026 ");
  }
}
function WaitingRoomPage_Conditional_17_Conditional_34_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275text(0);
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(3);
    \u0275\u0275textInterpolate1(" Faltan ", ctx_r1.faltanListos(), " catador(es) listo(s) ");
  }
}
function WaitingRoomPage_Conditional_17_Conditional_34_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275text(0);
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(3);
    \u0275\u0275textInterpolate1(" Iniciar cata \xB7 ", ctx_r1.participantesListos(), " catadores listos ");
  }
}
function WaitingRoomPage_Conditional_17_Conditional_34_Conditional_5_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275text(0);
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(3);
    \u0275\u0275textInterpolate1(" Iniciar y monitorear \xB7 ", ctx_r1.participantesListos(), " catadores listos ");
  }
}
function WaitingRoomPage_Conditional_17_Conditional_34_Template(rf, ctx) {
  if (rf & 1) {
    const _r8 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 30)(1, "ion-button", 50);
    \u0275\u0275listener("click", function WaitingRoomPage_Conditional_17_Conditional_34_Template_ion_button_click_1_listener() {
      \u0275\u0275restoreView(_r8);
      const ctx_r1 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r1.iniciarCata());
    });
    \u0275\u0275conditionalCreate(2, WaitingRoomPage_Conditional_17_Conditional_34_Conditional_2_Template, 1, 0)(3, WaitingRoomPage_Conditional_17_Conditional_34_Conditional_3_Template, 1, 1)(4, WaitingRoomPage_Conditional_17_Conditional_34_Conditional_4_Template, 1, 1)(5, WaitingRoomPage_Conditional_17_Conditional_34_Conditional_5_Template, 1, 1);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275property("disabled", !ctx_r1.puedeIniciar());
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.iniciando() ? 2 : ctx_r1.faltanListos() > 0 ? 3 : ctx_r1.organizadorParticipaComoCatador() ? 4 : 5);
  }
}
function WaitingRoomPage_Conditional_17_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "section", 17)(1, "div", 18)(2, "span", 19);
    \u0275\u0275text(3, "Formato");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "span", 20);
    \u0275\u0275text(5);
    \u0275\u0275pipe(6, "titlecase");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(7, "div", 18)(8, "span", 19);
    \u0275\u0275text(9, "Muestras");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(10, "span", 20);
    \u0275\u0275text(11);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(12, "div", 18)(13, "span", 19);
    \u0275\u0275text(14, "Catadores");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(15, "span", 20);
    \u0275\u0275text(16);
    \u0275\u0275elementEnd()()();
    \u0275\u0275conditionalCreate(17, WaitingRoomPage_Conditional_17_Conditional_17_Template, 11, 2, "section", 21);
    \u0275\u0275elementStart(18, "section", 22)(19, "div", 23)(20, "h3", 24);
    \u0275\u0275element(21, "ion-icon", 25);
    \u0275\u0275text(22, " CATADORES CONECTADOS ");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(23, "span", 26);
    \u0275\u0275text(24);
    \u0275\u0275elementEnd()();
    \u0275\u0275conditionalCreate(25, WaitingRoomPage_Conditional_17_Conditional_25_Template, 3, 0, "ion-list", 27)(26, WaitingRoomPage_Conditional_17_Conditional_26_Template, 2, 1, "div", 28);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(27, "section", 29);
    \u0275\u0275element(28, "ion-icon", 7);
    \u0275\u0275elementStart(29, "p")(30, "strong");
    \u0275\u0275text(31, "Evaluaci\xF3n 100% ciega.");
    \u0275\u0275elementEnd();
    \u0275\u0275text(32, " No ver\xE1s puntajes ni evaluaciones de otros catadores. El panel se cierra autom\xE1ticamente cuando el \xFAltimo catador termina. ");
    \u0275\u0275elementEnd()();
    \u0275\u0275conditionalCreate(33, WaitingRoomPage_Conditional_17_Conditional_33_Template, 1, 1);
    \u0275\u0275conditionalCreate(34, WaitingRoomPage_Conditional_17_Conditional_34_Template, 6, 2, "div", 30);
  }
  if (rf & 2) {
    let tmp_8_0;
    const s_r4 = ctx;
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind1(6, 10, s_r4.formato));
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate(s_r4.numeroMuestras);
    \u0275\u0275advance(5);
    \u0275\u0275textInterpolate2("", ctx_r1.participantes().length, " / ", s_r4.catadoresObjetivo);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.esOrganizador() ? 17 : -1);
    \u0275\u0275advance(7);
    \u0275\u0275textInterpolate2("", ctx_r1.participantesListos(), " listos \xB7 m\xEDn. ", ctx_r1.MINIMO_CATADORES, " para iniciar");
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.participantesEnSala().length > 0 ? 25 : 26);
    \u0275\u0275advance(8);
    \u0275\u0275conditional((tmp_8_0 = ctx_r1.miParticipacion()) ? 33 : -1, tmp_8_0);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.esOrganizador() && s_r4.estado === ctx_r1.EstadoSesion.EN_ESPERA ? 34 : -1);
  }
}
var MINIMO_CATADORES = 3;
var TIEMPO_MAXIMO_CARGA_MS = 15e3;
var SONDEO_SIN_SOCKET_MS = 1e4;
var RUTAS_FORMULARIO = {
  combinado: "combined-form",
  afectivo: "affective-form",
  descriptivo: "descriptive-form",
  extrinseca: "extrinsic-form"
};
function conTiempoLimite(promesa, ms) {
  return new Promise((resolve, reject) => {
    const id = setTimeout(() => reject(new Error("La conexi\xF3n est\xE1 tardando demasiado. Revisa tu red e intenta de nuevo.")), ms);
    promesa.then((valor) => {
      clearTimeout(id);
      resolve(valor);
    }, (error) => {
      clearTimeout(id);
      reject(error);
    });
  });
}
var _WaitingRoomPage = class _WaitingRoomPage {
  constructor() {
    this.MINIMO_CATADORES = MINIMO_CATADORES;
    this.EstadoSesion = EstadoSesion;
    this.route = inject(ActivatedRoute);
    this.router = inject(Router);
    this.authService = inject(AuthService);
    this.sesionService = inject(SesionService);
    this.realtimeService = inject(RealtimeService);
    this.toastController = inject(ToastController);
    this.alertController = inject(AlertController);
    this.sesion = signal(
      null,
      ...ngDevMode ? [{ debugName: "sesion" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.participantes = signal(
      [],
      ...ngDevMode ? [{ debugName: "participantes" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.cargando = signal(
      true,
      ...ngDevMode ? [{ debugName: "cargando" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.iniciando = signal(
      false,
      ...ngDevMode ? [{ debugName: "iniciando" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.cambiandoListo = signal(
      false,
      ...ngDevMode ? [{ debugName: "cambiandoListo" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.saliendo = signal(
      false,
      ...ngDevMode ? [{ debugName: "saliendo" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.copiado = signal(
      false,
      ...ngDevMode ? [{ debugName: "copiado" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.error = signal(
      null,
      ...ngDevMode ? [{ debugName: "error" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.sala = signal(
      null,
      ...ngDevMode ? [{ debugName: "sala" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.ahora = signal(
      Date.now(),
      ...ngDevMode ? [{ debugName: "ahora" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.usuarioActualId = computed(
      () => this.authService.usuario()?.id ?? null,
      ...ngDevMode ? [{ debugName: "usuarioActualId" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.estadoConexion = computed(
      () => this.sala()?.estadoConexion() ?? "desconectado",
      ...ngDevMode ? [{ debugName: "estadoConexion" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.sinConexion = computed(
      () => this.sala() !== null && this.estadoConexion() !== "conectado",
      ...ngDevMode ? [{ debugName: "sinConexion" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.esOrganizador = computed(
      () => {
        const uid = this.usuarioActualId();
        const sesion = this.sesion();
        return Boolean(uid && sesion && sesion.organizadorId === uid);
      },
      ...ngDevMode ? [{ debugName: "esOrganizador" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.miParticipacion = computed(
      () => {
        const uid = this.usuarioActualId();
        return uid ? this.participantes().find((p) => p.usuarioId === uid) ?? null : null;
      },
      ...ngDevMode ? [{ debugName: "miParticipacion" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.participantesEnSala = computed(
      () => {
        const presencia = this.sala()?.presencia() ?? /* @__PURE__ */ new Map();
        const uid = this.usuarioActualId();
        const ahora = this.ahora();
        return this.participantes().map((participante) => {
          const registro = presencia.get(participante.usuarioId);
          let conexion = "desconectado";
          if (participante.usuarioId === uid && this.estadoConexion() === "conectado")
            conexion = "en_linea";
          else if (registro)
            conexion = registro.estado;
          const segundosGracia = conexion === "inestable" && registro ? Math.max(0, Math.ceil((registro.desde + GRACE_PERIOD_MS - ahora) / 1e3)) : null;
          return __spreadProps(__spreadValues({}, participante), { conexion, segundosGracia });
        });
      },
      ...ngDevMode ? [{ debugName: "participantesEnSala" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.participantesListos = computed(
      () => this.participantes().filter((p) => p.listo).length,
      ...ngDevMode ? [{ debugName: "participantesListos" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.faltanListos = computed(
      () => Math.max(0, MINIMO_CATADORES - this.participantesListos()),
      ...ngDevMode ? [{ debugName: "faltanListos" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.puedeIniciar = computed(
      () => this.faltanListos() === 0 && !this.iniciando(),
      ...ngDevMode ? [{ debugName: "puedeIniciar" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.organizadorParticipaComoCatador = computed(
      () => this.esOrganizador() && this.miParticipacion() !== null,
      ...ngDevMode ? [{ debugName: "organizadorParticipaComoCatador" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.hayInestables = computed(
      () => this.participantesEnSala().some((p) => p.conexion === "inestable"),
      ...ngDevMode ? [{ debugName: "hayInestables" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.sesionId = "";
    this.conectado = false;
    this.redirigiendo = false;
    this.version = 0;
    addIcons({
      checkmarkCircleOutline,
      cloudOfflineOutline,
      copyOutline,
      exitOutline,
      lockClosedOutline,
      peopleOutline,
      refreshOutline
    });
  }
  ionViewWillEnter() {
    void this.conectar();
  }
  ionViewWillLeave() {
    this.desconectar();
  }
  ngOnDestroy() {
    this.desconectar();
    clearTimeout(this.copiadoId);
  }
  reintentar() {
    this.desconectar();
    void this.conectar();
  }
  async conectar() {
    if (this.conectado)
      return;
    this.conectado = true;
    const version = ++this.version;
    const vigente = () => this.conectado && version === this.version;
    this.redirigiendo = false;
    this.sesion.set(null);
    this.participantes.set([]);
    this.error.set(null);
    this.iniciando.set(false);
    this.cargando.set(true);
    this.sesionId = this.route.snapshot.paramMap.get("sesionId")?.trim() ?? "";
    if (!this.sesionId) {
      this.fallar("No se especific\xF3 una sesi\xF3n.");
      return;
    }
    try {
      await conTiempoLimite(this.authService.asegurarInicializado(), TIEMPO_MAXIMO_CARGA_MS);
      const usuario = this.authService.usuario();
      if (!vigente())
        return;
      if (!usuario)
        throw new Error("Debes iniciar sesi\xF3n para ver esta sesi\xF3n.");
      const [sesion, participantes] = await conTiempoLimite(Promise.all([
        this.sesionService.obtenerSesionPorId(this.sesionId),
        this.sesionService.obtenerParticipantes(this.sesionId)
      ]), TIEMPO_MAXIMO_CARGA_MS);
      if (!vigente())
        return;
      if (!sesion)
        throw new Error("No se encontr\xF3 la sesi\xF3n o no perteneces a ella.");
      this.sesion.set(sesion);
      this.participantes.set(participantes);
      if (getFormatoById(sesion.formato).id === "extrinseca") {
        await this.navegar(`/extrinsic-form/${sesion.id}`);
        return;
      }
      if (await this.redirigirSegunEstado(sesion))
        return;
      const esOrganizador = sesion.organizadorId === usuario.id;
      if (!esOrganizador && !participantes.some((p) => p.usuarioId === usuario.id)) {
        throw new Error("Ya no formas parte de esta sesi\xF3n.");
      }
      const sala = this.realtimeService.abrirSala({
        sesionId: sesion.id,
        usuarioId: usuario.id,
        nombre: usuario.nombre,
        rol: esOrganizador ? "organizador" : "catador"
      });
      this.sala.set(sala);
      this.eventosSub = sala.eventos$.subscribe((evento) => void this.manejarEvento(evento, version));
      this.relojId = setInterval(() => {
        if (this.hayInestables())
          this.ahora.set(Date.now());
      }, 1e3);
      this.sondeoId = setInterval(() => {
        if (this.sinConexion())
          void this.resincronizar(version);
      }, SONDEO_SIN_SOCKET_MS);
    } catch (error) {
      if (vigente())
        this.fallar(mensajeDeError(error, "No se pudo cargar la sala de espera."));
    } finally {
      if (version === this.version)
        this.cargando.set(false);
    }
  }
  desconectar() {
    this.conectado = false;
    this.version++;
    this.eventosSub?.unsubscribe();
    this.eventosSub = void 0;
    clearInterval(this.relojId);
    clearInterval(this.sondeoId);
    const sala = this.sala();
    if (sala)
      this.realtimeService.liberarSala(sala);
    this.sala.set(null);
  }
  fallar(mensaje) {
    this.error.set(mensaje);
    this.cargando.set(false);
    this.conectado = false;
  }
  async manejarEvento(evento, version) {
    if (version !== this.version)
      return;
    switch (evento.tipo) {
      case "LISTO":
        this.participantes.update((lista) => lista.map((p) => p.usuarioId === evento.usuarioId ? __spreadProps(__spreadValues({}, p), { listo: evento.listo }) : p));
        break;
      case "PARTICIPANTE_RETIRADO":
        if (evento.usuarioId === this.usuarioActualId()) {
          await this.expulsado();
          return;
        }
        this.participantes.update((lista) => lista.filter((p) => p.usuarioId !== evento.usuarioId));
        break;
      case "INICIAR_CATA":
      case "SESION_FINALIZADA":
      case "RESYNC":
        await this.resincronizar(version);
        break;
      default:
        break;
    }
  }
  /** Recarga sesión + participantes desde la BD (fuente de verdad). */
  async resincronizar(version) {
    try {
      const [sesion, participantes] = await Promise.all([
        this.sesionService.obtenerSesionPorId(this.sesionId),
        this.sesionService.obtenerParticipantes(this.sesionId)
      ]);
      if (version !== this.version)
        return;
      if (!sesion) {
        this.error.set("La sesi\xF3n ya no est\xE1 disponible.");
        return;
      }
      this.sesion.set(sesion);
      this.participantes.set(participantes);
      const uid = this.usuarioActualId();
      if (!this.esOrganizador() && uid && !participantes.some((p) => p.usuarioId === uid)) {
        await this.expulsado();
        return;
      }
      await this.redirigirSegunEstado(sesion);
    } catch (error) {
      if (version === this.version) {
        console.warn("[WaitingRoom] Resincronizaci\xF3n fallida:", error);
      }
    }
  }
  async expulsado() {
    const toast = await this.toastController.create({
      message: "Saliste de la sesi\xF3n (desconexi\xF3n prolongada o retiro del organizador).",
      duration: 3500,
      color: "warning"
    });
    await toast.present();
    await this.navegar("/dashboard");
  }
  async alternarListo() {
    const yo = this.miParticipacion();
    const sala = this.sala();
    if (!yo || this.cambiandoListo())
      return;
    const nuevoEstado = !yo.listo;
    this.cambiandoListo.set(true);
    this.error.set(null);
    this.participantes.update((lista) => lista.map((p) => p.usuarioId === yo.usuarioId ? __spreadProps(__spreadValues({}, p), { listo: nuevoEstado }) : p));
    try {
      await this.sesionService.marcarComoListo(this.sesionId, nuevoEstado);
      await sala?.enviar({ tipo: "LISTO", usuarioId: yo.usuarioId, listo: nuevoEstado });
    } catch (error) {
      this.participantes.update((lista) => lista.map((p) => p.usuarioId === yo.usuarioId ? __spreadProps(__spreadValues({}, p), { listo: yo.listo }) : p));
      this.error.set(mensajeDeError(error, "No se pudo actualizar tu estado."));
    } finally {
      this.cambiandoListo.set(false);
    }
  }
  async iniciarCata() {
    const sesion = this.sesion();
    if (!this.esOrganizador() || !sesion || !this.puedeIniciar())
      return;
    this.iniciando.set(true);
    this.error.set(null);
    try {
      await this.sesionService.iniciarSesion(this.sesionId);
      await this.sala()?.enviar({ tipo: "INICIAR_CATA" });
      const iniciada = __spreadProps(__spreadValues({}, sesion), { estado: EstadoSesion.INICIADA });
      this.sesion.set(iniciada);
      await this.redirigirSegunEstado(iniciada);
    } catch (error) {
      this.error.set(mensajeDeError(error, "No se pudo iniciar la cata."));
      this.iniciando.set(false);
    }
  }
  async salirDeSala() {
    if (this.esOrganizador() || this.saliendo())
      return;
    const alerta = await this.alertController.create({
      header: "Salir de la sesi\xF3n",
      message: "Dejar\xE1s de figurar como catador. Podr\xE1s volver a unirte con el c\xF3digo mientras la cata no haya iniciado.",
      buttons: [
        { text: "Cancelar", role: "cancel" },
        { text: "Salir", role: "confirm" }
      ]
    });
    await alerta.present();
    const { role } = await alerta.onDidDismiss();
    if (role !== "confirm")
      return;
    this.saliendo.set(true);
    try {
      await this.sesionService.abandonarSesion(this.sesionId);
      await this.navegar("/dashboard");
    } catch (error) {
      this.error.set(mensajeDeError(error, "No se pudo salir de la sesi\xF3n."));
    } finally {
      this.saliendo.set(false);
    }
  }
  async copiarCodigo() {
    const codigo = this.sesion()?.codigoAcceso;
    if (!codigo)
      return;
    try {
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(codigo);
      } else {
        await Clipboard.write({ string: codigo });
      }
      this.copiado.set(true);
      clearTimeout(this.copiadoId);
      this.copiadoId = setTimeout(() => this.copiado.set(false), 2e3);
      const toast = await this.toastController.create({ message: "\xA1C\xF3digo copiado!", duration: 2e3, color: "dark" });
      await toast.present();
    } catch {
      this.error.set("No se pudo copiar el c\xF3digo.");
    }
  }
  /** Devuelve true si inició una navegación fuera de la sala. */
  async redirigirSegunEstado(sesion) {
    switch (sesion.estado) {
      case EstadoSesion.INICIADA: {
        if (this.esOrganizador() && !sesion.organizadorParticipa) {
          return this.navegar(`/session/${sesion.id}/organizer-dashboard`);
        }
        const ruta = RUTAS_FORMULARIO[getFormatoById(sesion.formato).id];
        return this.navegar(`/${ruta}/${sesion.id}`);
      }
      case EstadoSesion.FINALIZADA:
        return this.navegar(this.esOrganizador() ? `/session/${sesion.id}/results` : `/session/${sesion.id}/evaluation-complete`);
      case EstadoSesion.CANCELADA:
        this.error.set("Esta sesi\xF3n fue cancelada por el organizador.");
        return false;
      default:
        return false;
    }
  }
  async navegar(url) {
    if (this.redirigiendo)
      return true;
    this.redirigiendo = true;
    try {
      const ok = await this.router.navigateByUrl(url, { replaceUrl: true });
      if (!ok)
        throw new Error("Navegaci\xF3n cancelada");
      return true;
    } catch {
      this.redirigiendo = false;
      this.error.set("No se pudo abrir la pantalla de la sesi\xF3n.");
      return false;
    }
  }
  tiempoDesde(fechaIso) {
    if (!fechaIso)
      return "Se uni\xF3 ahora";
    const minutos = Math.floor((Date.now() - new Date(fechaIso).getTime()) / 6e4);
    if (minutos < 1)
      return "Se uni\xF3 ahora";
    if (minutos < 60)
      return `Se uni\xF3 hace ${minutos} min`;
    return `Se uni\xF3 hace ${Math.floor(minutos / 60)} h`;
  }
};
_WaitingRoomPage.\u0275fac = function WaitingRoomPage_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _WaitingRoomPage)();
};
_WaitingRoomPage.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _WaitingRoomPage, selectors: [["app-waiting-room"]], decls: 18, vars: 4, consts: [[1, "ion-no-border"], ["slot", "start"], ["defaultHref", "/dashboard", "text", ""], [1, "page-title"], [1, "page-subtitle"], ["slot", "end"], ["color", "dark", 1, "blind-badge"], ["name", "lock-closed-outline", "aria-hidden", "true"], [1, "ion-padding", "waiting-content"], [1, "waiting-container"], ["role", "status", 1, "connection-banner"], ["role", "alert", 1, "waiting-error"], ["role", "status", 1, "empty-state", "loading-state"], ["name", "cloud-offline-outline", "aria-hidden", "true"], ["size", "small", "fill", "outline", 3, "click"], ["name", "refresh-outline", "slot", "start"], ["name", "crescent"], [1, "cupping-card", "metrics-card"], [1, "metric-item"], [1, "metric-label"], [1, "metric-value"], [1, "cupping-card", "share-card"], [1, "cupping-card"], [1, "list-header"], [1, "section-title"], ["name", "people-outline", "aria-hidden", "true"], [1, "list-subtitle"], ["lines", "none", 1, "tasters-list"], [1, "empty-state"], [1, "privacy-card"], [1, "start-button-container"], [1, "share-box"], [1, "code-display"], ["fill", "outline", "size", "small", 3, "click"], ["name", "copy-outline", "slot", "start"], [1, "share-hint"], [1, "taster-item", 3, "taster-item--inestable"], [1, "taster-item"], ["slot", "start", 1, "avatar"], [1, "presence-dot"], [1, "org-tag"], [1, "unstable-text"], ["slot", "end", 1, "status-indicator"], [1, "dot"], ["expand", "block", 3, "click", "fill", "disabled"], [1, "waiting-hint"], [1, "pulse-dot"], ["expand", "block", "fill", "clear", "color", "medium", 3, "click", "disabled"], ["name", "exit-outline", "slot", "start"], ["name", "checkmark-circle-outline", "slot", "start"], ["expand", "block", 1, "primary-btn", 3, "click", "disabled"]], template: function WaitingRoomPage_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-header", 0)(1, "ion-toolbar")(2, "ion-buttons", 1);
    \u0275\u0275element(3, "ion-back-button", 2);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "ion-title")(5, "div", 3);
    \u0275\u0275text(6, "Sala de espera");
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(7, WaitingRoomPage_Conditional_7_Template, 2, 1, "div", 4);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "ion-buttons", 5)(9, "ion-badge", 6);
    \u0275\u0275element(10, "ion-icon", 7);
    \u0275\u0275text(11, " Evaluaci\xF3n ciega ");
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(12, "ion-content", 8)(13, "main", 9);
    \u0275\u0275conditionalCreate(14, WaitingRoomPage_Conditional_14_Template, 3, 0, "div", 10);
    \u0275\u0275conditionalCreate(15, WaitingRoomPage_Conditional_15_Template, 6, 1, "div", 11);
    \u0275\u0275conditionalCreate(16, WaitingRoomPage_Conditional_16_Template, 4, 0, "div", 12)(17, WaitingRoomPage_Conditional_17_Template, 35, 12);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    let tmp_0_0;
    let tmp_2_0;
    let tmp_3_0;
    \u0275\u0275advance(7);
    \u0275\u0275conditional((tmp_0_0 = ctx.sesion()) ? 7 : -1, tmp_0_0);
    \u0275\u0275advance(7);
    \u0275\u0275conditional(ctx.sinConexion() ? 14 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional((tmp_2_0 = ctx.error()) ? 15 : -1, tmp_2_0);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx.cargando() ? 16 : (tmp_3_0 = ctx.sesion()) ? 17 : -1, tmp_3_0);
  }
}, dependencies: [
  IonBackButton,
  IonBadge,
  IonButton,
  IonButtons,
  IonContent,
  IonHeader,
  IonIcon,
  IonItem,
  IonLabel,
  IonList,
  IonSpinner,
  IonTitle,
  IonToolbar,
  CommonModule,
  TitleCasePipe
], styles: ['@charset "UTF-8";\n\n\n[_nghost-%COMP%] {\n  display: block;\n}\nion-toolbar[_ngcontent-%COMP%] {\n  --%NS%background: #ffffff;\n}\nion-back-button[_ngcontent-%COMP%] {\n  --%NS%color: #0f344c;\n}\n.blind-badge[_ngcontent-%COMP%] {\n  --%NS%background: #2f3e46;\n  font-size: 11px;\n  padding: 6px 10px;\n  border-radius: 6px;\n  display: flex;\n  align-items: center;\n}\n.waiting-content[_ngcontent-%COMP%] {\n  --%NS%background: #f8fafc;\n}\n.waiting-container[_ngcontent-%COMP%] {\n  width: min(100%, 500px);\n  margin: 0 auto;\n}\n.cupping-card[_ngcontent-%COMP%] {\n  background: #ffffff;\n  border: 1px solid #e2e8f0;\n  border-radius: 12px;\n  padding: 16px;\n  margin-bottom: 16px;\n  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.02);\n}\n.metrics-card[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  text-align: center;\n}\n.metric-item[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n}\n.metric-label[_ngcontent-%COMP%] {\n  font-size: 11px;\n  color: #62748e;\n  margin-bottom: 4px;\n}\n.metric-value[_ngcontent-%COMP%] {\n  font-size: 15px;\n  font-weight: bold;\n  color: #0f172b;\n}\n.section-title[_ngcontent-%COMP%] {\n  font-size: 11px;\n  font-weight: bold;\n  color: #62748e;\n  text-transform: uppercase;\n  margin: 0 0 12px;\n  display: flex;\n  align-items: center;\n  gap: 6px;\n}\n.share-box[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  background: #f8fafc;\n  border: 1px solid #e2e8f0;\n  border-radius: 8px;\n  padding: 12px;\n}\n.code-display[_ngcontent-%COMP%] {\n  font-size: 20px;\n  font-weight: bold;\n  letter-spacing: 2px;\n  color: #0f172b;\n}\n.share-hint[_ngcontent-%COMP%] {\n  font-size: 11px;\n  color: #94a3b8;\n  margin: 8px 0 0;\n}\n.list-header[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  align-items: flex-start;\n  margin-bottom: 12px;\n}\n.list-header[_ngcontent-%COMP%]   .section-title[_ngcontent-%COMP%] {\n  margin: 0;\n}\n.list-subtitle[_ngcontent-%COMP%] {\n  font-size: 11px;\n  color: #62748e;\n  text-align: right;\n  max-width: 100px;\n}\n.tasters-list[_ngcontent-%COMP%] {\n  padding: 0;\n  background: transparent;\n}\n.taster-item[_ngcontent-%COMP%] {\n  --%NS%background: transparent;\n  --%NS%padding-start: 0;\n  --%NS%inner-padding-end: 0;\n  --%NS%border-style: none;\n  margin-bottom: 12px;\n}\n.avatar[_ngcontent-%COMP%] {\n  width: 40px;\n  height: 40px;\n  border-radius: 50%;\n  background: #f1f5f9;\n  color: #0f172b;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-weight: bold;\n  font-size: 16px;\n  margin-right: 12px;\n}\n.taster-item[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n  font-size: 14px;\n  font-weight: bold;\n  color: #0f172b;\n  margin: 0 0 2px;\n  display: flex;\n  align-items: center;\n  gap: 6px;\n}\n.org-tag[_ngcontent-%COMP%] {\n  font-size: 10px;\n  font-weight: normal;\n  color: #62748e;\n}\n.taster-item[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  font-size: 11px;\n  color: #62748e;\n  margin: 0;\n}\n.status-indicator[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 6px;\n  font-size: 12px;\n  color: #62748e;\n}\n.dot[_ngcontent-%COMP%] {\n  width: 8px;\n  height: 8px;\n  border-radius: 50%;\n  background: #cbd5e1;\n}\n.dot.ready[_ngcontent-%COMP%] {\n  background: #009956;\n}\n.empty-state[_ngcontent-%COMP%] {\n  background: #f8fafc;\n  border-radius: 8px;\n  padding: 20px;\n  text-align: center;\n  font-size: 12px;\n  color: #62748e;\n}\n.privacy-card[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: flex-start;\n  gap: 10px;\n  background: #ffffff;\n  border: 1px solid #e2e8f0;\n  border-radius: 12px;\n  padding: 16px;\n}\n.privacy-card[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  color: #62748e;\n  font-size: 18px;\n  flex-shrink: 0;\n}\n.privacy-card[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  font-size: 11px;\n  color: #62748e;\n  margin: 0;\n  line-height: 1.4;\n}\n.start-button-container[_ngcontent-%COMP%] {\n  margin-top: 24px;\n  padding-bottom: 24px;\n}\n.primary-btn[_ngcontent-%COMP%] {\n  --%NS%background: #283840;\n  --%NS%background-hover: #1a2328;\n  --%NS%background-activated: #1a2328;\n  --%NS%color: #ffffff;\n  --%NS%border-radius: 8px;\n  --%NS%box-shadow: none;\n  height: 50px;\n  margin: 0;\n  font-weight: 600;\n  text-transform: none;\n}\n.waiting-error[_ngcontent-%COMP%] {\n  margin-bottom: 16px;\n  padding: 12px;\n  border-radius: 8px;\n  background: #ffe4e6;\n  color: #991b1b;\n  font-size: 13px;\n}\n.page-title[_ngcontent-%COMP%] {\n  color: var(--%NS%app-text-main);\n  font-size: 15px;\n  font-weight: 700;\n}\n.page-subtitle[_ngcontent-%COMP%] {\n  margin-top: 2px;\n  color: var(--%NS%app-text-muted);\n  font-size: 12px;\n  font-weight: 400;\n}\n.blind-badge[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  margin-right: 4px;\n}\n.loading-state[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  gap: 12px;\n  margin-top: 32px;\n}\n.waiting-error[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  gap: 12px;\n}\n.waiting-hint[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  gap: 8px;\n  margin: 16px 0 0;\n  color: var(--%NS%app-text-muted);\n  font-size: 12px;\n}\n.pulse-dot[_ngcontent-%COMP%] {\n  width: 6px;\n  height: 6px;\n  border-radius: 50%;\n  background: var(--%NS%app-text-muted);\n  animation: _ngcontent-%COMP%_pulse 1.6s ease-in-out infinite;\n}\n@keyframes _ngcontent-%COMP%_pulse {\n  0%, 100% {\n    opacity: 0.3;\n  }\n  50% {\n    opacity: 1;\n  }\n}\n@media (prefers-reduced-motion: reduce) {\n  .pulse-dot[_ngcontent-%COMP%] {\n    animation: none;\n  }\n}\n.connection-banner[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  margin-bottom: 16px;\n  padding: 10px 12px;\n  border-radius: 8px;\n  background: #fef9c3;\n  color: #854d0e;\n  font-size: 12px;\n}\n.avatar[_ngcontent-%COMP%] {\n  position: relative;\n}\n.presence-dot[_ngcontent-%COMP%] {\n  position: absolute;\n  right: -2px;\n  bottom: -2px;\n  width: 10px;\n  height: 10px;\n  border: 2px solid var(--%NS%app-bg-card);\n  border-radius: 50%;\n  background: var(--%NS%app-text-faint);\n}\n.presence-dot--online[_ngcontent-%COMP%] {\n  background: var(--%NS%app-success);\n}\n.presence-dot--unstable[_ngcontent-%COMP%] {\n  background: #eab308;\n}\n.taster-item--inestable[_ngcontent-%COMP%] {\n  --%NS%background: #fefce8;\n}\n.unstable-text[_ngcontent-%COMP%] {\n  color: #a16207 !important;\n  font-weight: 600;\n}\n/*# sourceMappingURL=waiting-room.page.css.map */'] });
var WaitingRoomPage = _WaitingRoomPage;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(WaitingRoomPage, [{
    type: Component,
    args: [{ selector: "app-waiting-room", standalone: true, imports: [
      IonBackButton,
      IonBadge,
      IonButton,
      IonButtons,
      IonContent,
      IonHeader,
      IonIcon,
      IonItem,
      IonLabel,
      IonList,
      IonSpinner,
      IonTitle,
      IonToolbar,
      CommonModule
    ], template: `<ion-header class="ion-no-border">
  <ion-toolbar>
    <ion-buttons slot="start">
      <ion-back-button defaultHref="/dashboard" text=""></ion-back-button>
    </ion-buttons>
    <ion-title>
      <div class="page-title">Sala de espera</div>
      @if (sesion(); as s) {
        <div class="page-subtitle">{{ s.nombre }}</div>
      }
    </ion-title>
    <ion-buttons slot="end">
      <ion-badge color="dark" class="blind-badge">
        <ion-icon name="lock-closed-outline" aria-hidden="true"></ion-icon>
        Evaluaci\xF3n ciega
      </ion-badge>
    </ion-buttons>
  </ion-toolbar>
</ion-header>

<ion-content class="ion-padding waiting-content">
  <main class="waiting-container">
    @if (sinConexion()) {
      <div class="connection-banner" role="status">
        <ion-icon name="cloud-offline-outline" aria-hidden="true"></ion-icon>
        Reconectando con la sala\u2026 los cambios se sincronizar\xE1n al volver la conexi\xF3n.
      </div>
    }

    @if (error(); as mensaje) {
      <div class="waiting-error" role="alert">
        <span>{{ mensaje }}</span>
        <ion-button size="small" fill="outline" (click)="reintentar()">
          <ion-icon name="refresh-outline" slot="start"></ion-icon>
          Reintentar
        </ion-button>
      </div>
    }

    @if (cargando()) {
      <div class="empty-state loading-state" role="status">
        <ion-spinner name="crescent"></ion-spinner>
        <span>Cargando sala de espera\u2026</span>
      </div>
    } @else if (sesion(); as s) {
      <section class="cupping-card metrics-card">
        <div class="metric-item">
          <span class="metric-label">Formato</span>
          <span class="metric-value">{{ s.formato | titlecase }}</span>
        </div>
        <div class="metric-item">
          <span class="metric-label">Muestras</span>
          <span class="metric-value">{{ s.numeroMuestras }}</span>
        </div>
        <div class="metric-item">
          <span class="metric-label">Catadores</span>
          <span class="metric-value">{{ participantes().length }} / {{ s.catadoresObjetivo }}</span>
        </div>
      </section>

      @if (esOrganizador()) {
        <section class="cupping-card share-card">
          <h3 class="section-title">COMPARTIR ACCESO</h3>
          <div class="share-box">
            <div class="code-display">{{ s.codigoAcceso }}</div>
            <ion-button fill="outline" size="small" (click)="copiarCodigo()">
              <ion-icon name="copy-outline" slot="start"></ion-icon>
              {{ copiado() ? 'Copiado' : 'C\xF3digo' }}
            </ion-button>
          </div>
          <p class="share-hint">El c\xF3digo expira cuando inicies la cata.</p>
        </section>
      }

      <section class="cupping-card">
        <div class="list-header">
          <h3 class="section-title">
            <ion-icon name="people-outline" aria-hidden="true"></ion-icon> CATADORES CONECTADOS
          </h3>
          <span class="list-subtitle">{{ participantesListos() }} listos \xB7 m\xEDn. {{ MINIMO_CATADORES }} para iniciar</span>
        </div>

        @if (participantesEnSala().length > 0) {
          <ion-list lines="none" class="tasters-list">
            @for (p of participantesEnSala(); track p.usuarioId) {
              <ion-item class="taster-item" [class.taster-item--inestable]="p.conexion === 'inestable'">
                <div class="avatar" slot="start">
                  {{ (p.nombre.charAt(0) || '?').toUpperCase() }}
                  <span
                    class="presence-dot"
                    [class.presence-dot--online]="p.conexion === 'en_linea'"
                    [class.presence-dot--unstable]="p.conexion === 'inestable'"
                    [attr.aria-label]="p.conexion === 'en_linea' ? 'En l\xEDnea' : p.conexion === 'inestable' ? 'Conexi\xF3n inestable' : 'Desconectado'">
                  </span>
                </div>
                <ion-label>
                  <h2>
                    {{ p.nombre }}
                    @if (p.esOrganizador) { <span class="org-tag">organizador</span> }
                    @if (p.usuarioId === usuarioActualId()) { <span class="org-tag">t\xFA</span> }
                  </h2>
                  @if (p.conexion === 'inestable') {
                    <p class="unstable-text">Conexi\xF3n inestable \xB7 se retira en {{ p.segundosGracia }} s</p>
                  } @else if (p.conexion === 'desconectado') {
                    <p>Desconectado \xB7 {{ tiempoDesde(p.unidoEn) }}</p>
                  } @else {
                    <p>{{ tiempoDesde(p.unidoEn) }}</p>
                  }
                </ion-label>
                <div slot="end" class="status-indicator">
                  <span class="dot" [class.ready]="p.listo"></span>
                  {{ p.listo ? 'Listo' : 'Conectado' }}
                </div>
              </ion-item>
            }
          </ion-list>
        } @else {
          <div class="empty-state">
            Esperando que se unan al menos {{ MINIMO_CATADORES }} catadores.
          </div>
        }
      </section>

      <section class="privacy-card">
        <ion-icon name="lock-closed-outline" aria-hidden="true"></ion-icon>
        <p>
          <strong>Evaluaci\xF3n 100% ciega.</strong>
          No ver\xE1s puntajes ni evaluaciones de otros catadores. El panel se cierra
          autom\xE1ticamente cuando el \xFAltimo catador termina.
        </p>
      </section>

      @if (miParticipacion(); as yo) {
        @if (!esOrganizador()) {
          <div class="start-button-container">
            <ion-button
              expand="block"
              [class.primary-btn]="!yo.listo"
              [fill]="yo.listo ? 'outline' : 'solid'"
              [disabled]="cambiandoListo()"
              (click)="alternarListo()">
              @if (cambiandoListo()) {
                <ion-spinner name="crescent"></ion-spinner>
              } @else if (yo.listo) {
                <ion-icon name="checkmark-circle-outline" slot="start"></ion-icon>
                Estoy listo \xB7 tocar para cancelar
              } @else {
                Estoy listo para catar
              }
            </ion-button>
            <p class="waiting-hint"><span class="pulse-dot"></span> Esperando que el organizador inicie la cata\u2026</p>
            <ion-button expand="block" fill="clear" color="medium" [disabled]="saliendo()" (click)="salirDeSala()">
              <ion-icon name="exit-outline" slot="start"></ion-icon>
              Salir de la sesi\xF3n
            </ion-button>
          </div>
        }
      }

      @if (esOrganizador() && s.estado === EstadoSesion.EN_ESPERA) {
        <div class="start-button-container">
          <ion-button expand="block" class="primary-btn" (click)="iniciarCata()" [disabled]="!puedeIniciar()">
            @if (iniciando()) {
              Iniciando\u2026
            } @else if (faltanListos() > 0) {
              Faltan {{ faltanListos() }} catador(es) listo(s)
            } @else if (organizadorParticipaComoCatador()) {
              Iniciar cata \xB7 {{ participantesListos() }} catadores listos
            } @else {
              Iniciar y monitorear \xB7 {{ participantesListos() }} catadores listos
            }
          </ion-button>
        </div>
      }
    }
  </main>
</ion-content>
`, styles: ['@charset "UTF-8";\n\n/* src/app/pages/session/waiting-room/waiting-room.page.scss */\n:host {\n  display: block;\n}\nion-toolbar {\n  --background: #ffffff;\n}\nion-back-button {\n  --color: #0f344c;\n}\n.blind-badge {\n  --background: #2f3e46;\n  font-size: 11px;\n  padding: 6px 10px;\n  border-radius: 6px;\n  display: flex;\n  align-items: center;\n}\n.waiting-content {\n  --background: #f8fafc;\n}\n.waiting-container {\n  width: min(100%, 500px);\n  margin: 0 auto;\n}\n.cupping-card {\n  background: #ffffff;\n  border: 1px solid #e2e8f0;\n  border-radius: 12px;\n  padding: 16px;\n  margin-bottom: 16px;\n  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.02);\n}\n.metrics-card {\n  display: flex;\n  justify-content: space-between;\n  text-align: center;\n}\n.metric-item {\n  display: flex;\n  flex-direction: column;\n}\n.metric-label {\n  font-size: 11px;\n  color: #62748e;\n  margin-bottom: 4px;\n}\n.metric-value {\n  font-size: 15px;\n  font-weight: bold;\n  color: #0f172b;\n}\n.section-title {\n  font-size: 11px;\n  font-weight: bold;\n  color: #62748e;\n  text-transform: uppercase;\n  margin: 0 0 12px;\n  display: flex;\n  align-items: center;\n  gap: 6px;\n}\n.share-box {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  background: #f8fafc;\n  border: 1px solid #e2e8f0;\n  border-radius: 8px;\n  padding: 12px;\n}\n.code-display {\n  font-size: 20px;\n  font-weight: bold;\n  letter-spacing: 2px;\n  color: #0f172b;\n}\n.share-hint {\n  font-size: 11px;\n  color: #94a3b8;\n  margin: 8px 0 0;\n}\n.list-header {\n  display: flex;\n  justify-content: space-between;\n  align-items: flex-start;\n  margin-bottom: 12px;\n}\n.list-header .section-title {\n  margin: 0;\n}\n.list-subtitle {\n  font-size: 11px;\n  color: #62748e;\n  text-align: right;\n  max-width: 100px;\n}\n.tasters-list {\n  padding: 0;\n  background: transparent;\n}\n.taster-item {\n  --background: transparent;\n  --padding-start: 0;\n  --inner-padding-end: 0;\n  --border-style: none;\n  margin-bottom: 12px;\n}\n.avatar {\n  width: 40px;\n  height: 40px;\n  border-radius: 50%;\n  background: #f1f5f9;\n  color: #0f172b;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-weight: bold;\n  font-size: 16px;\n  margin-right: 12px;\n}\n.taster-item h2 {\n  font-size: 14px;\n  font-weight: bold;\n  color: #0f172b;\n  margin: 0 0 2px;\n  display: flex;\n  align-items: center;\n  gap: 6px;\n}\n.org-tag {\n  font-size: 10px;\n  font-weight: normal;\n  color: #62748e;\n}\n.taster-item p {\n  font-size: 11px;\n  color: #62748e;\n  margin: 0;\n}\n.status-indicator {\n  display: flex;\n  align-items: center;\n  gap: 6px;\n  font-size: 12px;\n  color: #62748e;\n}\n.dot {\n  width: 8px;\n  height: 8px;\n  border-radius: 50%;\n  background: #cbd5e1;\n}\n.dot.ready {\n  background: #009956;\n}\n.empty-state {\n  background: #f8fafc;\n  border-radius: 8px;\n  padding: 20px;\n  text-align: center;\n  font-size: 12px;\n  color: #62748e;\n}\n.privacy-card {\n  display: flex;\n  align-items: flex-start;\n  gap: 10px;\n  background: #ffffff;\n  border: 1px solid #e2e8f0;\n  border-radius: 12px;\n  padding: 16px;\n}\n.privacy-card ion-icon {\n  color: #62748e;\n  font-size: 18px;\n  flex-shrink: 0;\n}\n.privacy-card p {\n  font-size: 11px;\n  color: #62748e;\n  margin: 0;\n  line-height: 1.4;\n}\n.start-button-container {\n  margin-top: 24px;\n  padding-bottom: 24px;\n}\n.primary-btn {\n  --background: #283840;\n  --background-hover: #1a2328;\n  --background-activated: #1a2328;\n  --color: #ffffff;\n  --border-radius: 8px;\n  --box-shadow: none;\n  height: 50px;\n  margin: 0;\n  font-weight: 600;\n  text-transform: none;\n}\n.waiting-error {\n  margin-bottom: 16px;\n  padding: 12px;\n  border-radius: 8px;\n  background: #ffe4e6;\n  color: #991b1b;\n  font-size: 13px;\n}\n.page-title {\n  color: var(--app-text-main);\n  font-size: 15px;\n  font-weight: 700;\n}\n.page-subtitle {\n  margin-top: 2px;\n  color: var(--app-text-muted);\n  font-size: 12px;\n  font-weight: 400;\n}\n.blind-badge ion-icon {\n  margin-right: 4px;\n}\n.loading-state {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  gap: 12px;\n  margin-top: 32px;\n}\n.waiting-error {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  gap: 12px;\n}\n.waiting-hint {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  gap: 8px;\n  margin: 16px 0 0;\n  color: var(--app-text-muted);\n  font-size: 12px;\n}\n.pulse-dot {\n  width: 6px;\n  height: 6px;\n  border-radius: 50%;\n  background: var(--app-text-muted);\n  animation: pulse 1.6s ease-in-out infinite;\n}\n@keyframes pulse {\n  0%, 100% {\n    opacity: 0.3;\n  }\n  50% {\n    opacity: 1;\n  }\n}\n@media (prefers-reduced-motion: reduce) {\n  .pulse-dot {\n    animation: none;\n  }\n}\n.connection-banner {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  margin-bottom: 16px;\n  padding: 10px 12px;\n  border-radius: 8px;\n  background: #fef9c3;\n  color: #854d0e;\n  font-size: 12px;\n}\n.avatar {\n  position: relative;\n}\n.presence-dot {\n  position: absolute;\n  right: -2px;\n  bottom: -2px;\n  width: 10px;\n  height: 10px;\n  border: 2px solid var(--app-bg-card);\n  border-radius: 50%;\n  background: var(--app-text-faint);\n}\n.presence-dot--online {\n  background: var(--app-success);\n}\n.presence-dot--unstable {\n  background: #eab308;\n}\n.taster-item--inestable {\n  --background: #fefce8;\n}\n.unstable-text {\n  color: #a16207 !important;\n  font-weight: 600;\n}\n/*# sourceMappingURL=waiting-room.page.css.map */\n'] }]
  }], () => [], null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(WaitingRoomPage, { className: "WaitingRoomPage", filePath: "src/app/pages/session/waiting-room/waiting-room.page.ts", lineNumber: 71 });
})();
export {
  WaitingRoomPage
};
//# debugId=46fa038a-a945-57b5-9667-a21b8d2edf6b
//# sourceMappingURL=waiting-room.page-CVC3MDV5.js.map
