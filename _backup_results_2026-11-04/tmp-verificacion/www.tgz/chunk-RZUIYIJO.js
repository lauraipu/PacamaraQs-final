import {
  RealtimeService
} from "./chunk-7SA6TBRT.js";
import {
  esErrorPermanente,
  mensajeDeError
} from "./chunk-OFWJO6PD.js";
import {
  SesionService
} from "./chunk-KN5DCTIK.js";
import {
  EstadoSesion,
  getFormatoById
} from "./chunk-ISYXHPYK.js";
import {
  AuthService
} from "./chunk-SYUCMH2K.js";
import {
  ActivatedRoute,
  AlertController,
  ChangeDetectorRef,
  Component,
  DestroyRef,
  Directive,
  HostListener,
  Injectable,
  Input,
  NavController,
  Output,
  Subject,
  SupabaseService,
  ToastController,
  computed,
  effect,
  filter,
  inject,
  input,
  output,
  setClassMetadata,
  signal,
  untracked,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵconditional,
  ɵɵconditionalCreate,
  ɵɵdefineComponent,
  ɵɵdefineDirective,
  ɵɵdefineInjectable,
  ɵɵdomElementEnd,
  ɵɵdomElementStart,
  ɵɵdomListener,
  ɵɵgetCurrentView,
  ɵɵlistener,
  ɵɵnextContext,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate3
} from "./chunk-ELFI4Z7L.js";
import {
  __spreadProps,
  __spreadValues
} from "./chunk-PAXKX5KU.js";

// src/app/core/services/offline-sync.ts
var CLAVE_COLA = "pacamara_cola_sync_v1";
var BACKOFF_BASE_MS = 2e3;
var BACKOFF_MAX_MS = 6e4;
var ATRIBUTO_DB = {
  fragancia: "fragancia",
  aroma: "aroma",
  sabor: "sabor",
  saborResidual: "sabor_residual",
  sabor_residual: "sabor_residual",
  acidez: "acidez",
  dulzor: "dulzor",
  sensacionEnBoca: "sensacion_boca",
  sensacion_boca: "sensacion_boca"
};
function claveBorrador(sesionId, numeroMuestra) {
  return `borrador_sesion_${sesionId}_${numeroMuestra}`;
}
function claveFicha(ficha) {
  return `${ficha.sesionId}:${ficha.catadorId}:${ficha.numeroMuestra}`;
}
var _OfflineSyncService = class _OfflineSyncService {
  constructor() {
    this.supabase = inject(SupabaseService);
    this.authService = inject(AuthService);
    this._enLinea = signal(
      typeof navigator === "undefined" ? true : navigator.onLine,
      ...ngDevMode ? [{ debugName: "_enLinea" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this._cola = signal(
      this.leerColaPersistida(),
      ...ngDevMode ? [{ debugName: "_cola" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this._rechazos = signal(
      /* @__PURE__ */ new Map(),
      ...ngDevMode ? [{ debugName: "_rechazos" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this._sincronizando = signal(
      false,
      ...ngDevMode ? [{ debugName: "_sincronizando" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.sincronizadasSubject = new Subject();
    this.enLinea = this._enLinea.asReadonly();
    this.cola = this._cola.asReadonly();
    this.rechazos = this._rechazos.asReadonly();
    this.sincronizando = this._sincronizando.asReadonly();
    this.cantidadPendientes = computed(
      () => this._cola().length,
      ...ngDevMode ? [{ debugName: "cantidadPendientes" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.sincronizadas$ = this.sincronizadasSubject.asObservable();
    this.procesando = false;
    this.enVuelo = /* @__PURE__ */ new Map();
    const alConectar = () => {
      this._enLinea.set(true);
      this.adelantarReintentos();
    };
    const alDesconectar = () => this._enLinea.set(false);
    const alVolverPrimerPlano = () => {
      if (document.visibilityState === "visible")
        this.adelantarReintentos();
    };
    window.addEventListener("online", alConectar);
    window.addEventListener("offline", alDesconectar);
    document.addEventListener("visibilitychange", alVolverPrimerPlano);
    inject(DestroyRef).onDestroy(() => {
      window.removeEventListener("online", alConectar);
      window.removeEventListener("offline", alDesconectar);
      document.removeEventListener("visibilitychange", alVolverPrimerPlano);
      clearTimeout(this.temporizador);
    });
    effect(() => {
      const usuario = this.authService.usuario();
      if (usuario && untracked(() => this._cola().length) > 0) {
        queueMicrotask(() => void this.procesarCola());
      }
    });
  }
  /** Fichas pendientes de una sesión concreta. */
  pendientesDeSesion(sesionId) {
    return this._cola().filter((item) => item.ficha.sesionId === sesionId);
  }
  /**
   * Fichas que el servidor ya tiene del catador actual (RLS: solo las propias).
   * `notas` guarda el formulario serializado y permite retomar en otro dispositivo.
   */
  async obtenerFichasEnviadas(sesionId) {
    const usuarioId = this.authService.usuario()?.id;
    if (!usuarioId)
      return [];
    const { data, error } = await this.supabase.client.from("evaluaciones").select("numero_muestra, notas").eq("sesion_id", sesionId).eq("catador_id", usuarioId);
    if (error)
      throw error;
    return (data ?? []).map((fila) => ({
      numeroMuestra: Number(fila.numero_muestra),
      notas: typeof fila.notas === "string" ? fila.notas : null
    }));
  }
  // ---------------------------------------------------------------------------
  // Borradores
  // ---------------------------------------------------------------------------
  guardarBorrador(sesionId, numeroMuestra, datos) {
    const usuarioId = this.authService.usuario()?.id;
    if (!usuarioId)
      return;
    const registro = { usuarioId, actualizadoEn: Date.now(), datos };
    try {
      localStorage.setItem(claveBorrador(sesionId, numeroMuestra), JSON.stringify(registro));
    } catch (error) {
      console.warn("[OfflineSync] No se pudo guardar el borrador:", error);
    }
  }
  /** Devuelve el borrador SOLO si pertenece al usuario actual (dispositivos compartidos). */
  leerBorrador(sesionId, numeroMuestra) {
    const usuarioId = this.authService.usuario()?.id;
    if (!usuarioId)
      return null;
    try {
      const crudo = localStorage.getItem(claveBorrador(sesionId, numeroMuestra));
      if (!crudo)
        return null;
      const registro = JSON.parse(crudo);
      return registro.usuarioId === usuarioId && registro.datos !== void 0 ? registro.datos : null;
    } catch {
      return null;
    }
  }
  eliminarBorrador(sesionId, numeroMuestra) {
    try {
      localStorage.removeItem(claveBorrador(sesionId, numeroMuestra));
    } catch {
    }
  }
  // ---------------------------------------------------------------------------
  // Envío
  // ---------------------------------------------------------------------------
  /**
   * Encola la ficha y la intenta enviar de inmediato.
   * - 'sincronizada': confirmada por el servidor.
   * - 'pendiente': sin red o error transitorio; queda en cola con backoff.
   * - 'rechazada': el servidor la rechazó (p. ej. muestra cerrada). No se reintenta.
   */
  async enviar(ficha) {
    const clave = claveFicha(ficha);
    this.quitarRechazo(clave);
    this.ponerEnCola({ clave, ficha, intentos: 0, proximoIntentoEn: Date.now(), encoladaEn: Date.now() });
    if (!this._enLinea()) {
      return { estado: "pendiente", mensaje: "Guardado localmente. Reintentando\u2026" };
    }
    await this.enVuelo.get(clave)?.catch(() => void 0);
    const item = this._cola().find((i) => i.clave === clave);
    if (!item)
      return { estado: "sincronizada" };
    const resultado = await this.intentar(item);
    this.programarSiguiente();
    if (resultado === "ok")
      return { estado: "sincronizada" };
    if (resultado === "rechazado") {
      return { estado: "rechazada", mensaje: this._rechazos().get(clave) };
    }
    return { estado: "pendiente", mensaje: "Guardado localmente. Reintentando\u2026" };
  }
  /** Fuerza un reintento inmediato de toda la cola (botón "Reintentar"). */
  reintentarAhora() {
    this.adelantarReintentos();
  }
  async procesarCola() {
    if (this.procesando || !this._enLinea()) {
      this.programarSiguiente();
      return;
    }
    this.procesando = true;
    this._sincronizando.set(true);
    try {
      const ahora = Date.now();
      const vencidos = this._cola().filter((item) => item.proximoIntentoEn <= ahora);
      for (const item of vencidos) {
        if (!this._enLinea())
          break;
        const vigente = this._cola().find((i) => i.clave === item.clave);
        if (vigente)
          await this.intentar(vigente);
      }
    } finally {
      this.procesando = false;
      this._sincronizando.set(false);
      this.programarSiguiente();
    }
  }
  intentar(item) {
    const existente = this.enVuelo.get(item.clave);
    if (existente)
      return existente;
    const intento = this.ejecutarIntento(item).finally(() => this.enVuelo.delete(item.clave));
    this.enVuelo.set(item.clave, intento);
    return intento;
  }
  async ejecutarIntento(item) {
    const usuarioId = this.authService.usuario()?.id;
    if (!usuarioId || usuarioId !== item.ficha.catadorId) {
      this.reprogramar(item, "Esperando la sesi\xF3n del catador.");
      return "reintentar";
    }
    try {
      await this.persistir(item.ficha);
      const reemplazada = this._cola().some((i) => i.clave === item.clave && i.encoladaEn !== item.encoladaEn);
      if (!reemplazada) {
        this.quitarDeCola(item.clave);
        this.eliminarBorrador(item.ficha.sesionId, item.ficha.numeroMuestra);
      }
      this.sincronizadasSubject.next(item.ficha);
      return "ok";
    } catch (error) {
      if (esErrorPermanente(error)) {
        this.actualizarCola((cola) => cola.filter((i) => !(i.clave === item.clave && i.encoladaEn === item.encoladaEn)));
        this.registrarRechazo(item.clave, this.mensajeRechazo(error));
        return "rechazado";
      }
      this.reprogramar(item, mensajeDeError(error, "Error de red."));
      return "reintentar";
    }
  }
  async persistir(ficha) {
    const { data, error } = await this.supabase.client.from("evaluaciones").upsert({
      sesion_id: ficha.sesionId,
      catador_id: ficha.catadorId,
      numero_muestra: ficha.numeroMuestra,
      impresion_global: ficha.impresionGlobal,
      tazas_no_uniformes: ficha.tazasNoUniformes,
      tazas_defectuosas: ficha.tazasDefectuosas,
      puntaje_final: ficha.puntajeFinal,
      notas: ficha.notas
    }, { onConflict: "sesion_id,catador_id,numero_muestra" }).select("id").single();
    if (error)
      throw error;
    const evaluacionId = data?.id;
    if (!evaluacionId)
      throw new Error("Supabase no devolvi\xF3 el ID de la evaluaci\xF3n.");
    const filas = ficha.atributos.map((atributo) => this.normalizarAtributo(atributo)).filter((fila) => fila !== null).map((fila) => __spreadValues({ evaluacion_id: evaluacionId }, fila));
    if (filas.length === 0)
      return;
    const { error: errorAtributos } = await this.supabase.client.from("evaluacion_atributos").upsert(filas, { onConflict: "evaluacion_id,atributo" });
    if (errorAtributos)
      throw errorAtributos;
  }
  normalizarAtributo(atributo) {
    const nombreDb = ATRIBUTO_DB[atributo.atributo];
    if (!nombreDb)
      return null;
    const intensidad = this.enRango(atributo.intensidad, 0, 15);
    const calidad = this.enRango(atributo.calidad, 1, 9);
    if (intensidad === null && calidad === null)
      return null;
    return { atributo: nombreDb, intensidad, calidad };
  }
  enRango(valor, min, max) {
    return typeof valor === "number" && Number.isFinite(valor) && valor >= min && valor <= max ? valor : null;
  }
  mensajeRechazo(error) {
    const texto = mensajeDeError(error, "");
    if (/row-level security/i.test(texto)) {
      return "El servidor ya no acepta esta ficha: la muestra fue cerrada o la sesi\xF3n termin\xF3.";
    }
    return texto || "El servidor rechaz\xF3 la ficha.";
  }
  // ---------------------------------------------------------------------------
  // Cola y backoff
  // ---------------------------------------------------------------------------
  calcularEspera(intentos) {
    const base = Math.min(BACKOFF_MAX_MS, BACKOFF_BASE_MS * 2 ** Math.max(0, intentos - 1));
    const jitter = base * 0.2 * (Math.random() * 2 - 1);
    return Math.round(base + jitter);
  }
  reprogramar(item, mensaje) {
    const intentos = item.intentos + 1;
    this.actualizarCola((cola) => cola.map((i) => i.clave === item.clave ? __spreadProps(__spreadValues({}, i), { intentos, ultimoError: mensaje, proximoIntentoEn: Date.now() + this.calcularEspera(intentos) }) : i));
  }
  adelantarReintentos() {
    const ahora = Date.now();
    this.actualizarCola((cola) => cola.map((i) => __spreadProps(__spreadValues({}, i), { proximoIntentoEn: Math.min(i.proximoIntentoEn, ahora) })));
    void this.procesarCola();
  }
  programarSiguiente() {
    clearTimeout(this.temporizador);
    const cola = this._cola();
    if (cola.length === 0 || !this._enLinea())
      return;
    const proximo = Math.min(...cola.map((i) => i.proximoIntentoEn));
    const espera = Math.max(250, proximo - Date.now());
    this.temporizador = setTimeout(() => void this.procesarCola(), espera);
  }
  /** Una ficha nueva reemplaza a la pendiente de la misma (sesión, catador, muestra). */
  ponerEnCola(item) {
    this.actualizarCola((cola) => [...cola.filter((i) => i.clave !== item.clave), item]);
  }
  quitarDeCola(clave) {
    this.actualizarCola((cola) => cola.filter((i) => i.clave !== clave));
  }
  actualizarCola(transformar) {
    const nueva = transformar(this._cola());
    this._cola.set(nueva);
    try {
      localStorage.setItem(CLAVE_COLA, JSON.stringify(nueva));
    } catch (error) {
      console.warn("[OfflineSync] No se pudo persistir la cola:", error);
    }
  }
  registrarRechazo(clave, mensaje) {
    const siguiente = new Map(this._rechazos());
    siguiente.set(clave, mensaje);
    this._rechazos.set(siguiente);
  }
  quitarRechazo(clave) {
    if (!this._rechazos().has(clave))
      return;
    const siguiente = new Map(this._rechazos());
    siguiente.delete(clave);
    this._rechazos.set(siguiente);
  }
  leerColaPersistida() {
    try {
      const crudo = localStorage.getItem(CLAVE_COLA);
      const lista = crudo ? JSON.parse(crudo) : [];
      if (!Array.isArray(lista))
        return [];
      return lista.filter((item) => typeof item === "object" && item !== null && typeof item.clave === "string" && typeof item.ficha?.sesionId === "string");
    } catch {
      return [];
    }
  }
};
_OfflineSyncService.\u0275fac = function OfflineSyncService_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _OfflineSyncService)();
};
_OfflineSyncService.\u0275prov = /* @__PURE__ */ \u0275\u0275defineInjectable({ token: _OfflineSyncService, factory: _OfflineSyncService.\u0275fac, providedIn: "root" });
var OfflineSyncService = _OfflineSyncService;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(OfflineSyncService, [{
    type: Injectable,
    args: [{ providedIn: "root" }]
  }], () => [], null);
})();

// src/app/core/cva/base-cata-form.ts
var ATRIBUTOS_HEDONICOS = /* @__PURE__ */ new Set([
  "fragancia",
  "aroma",
  "sabor",
  "saborResidual",
  "acidez",
  "dulzor",
  "sensacionEnBoca"
]);
var _BaseCataForm = class _BaseCataForm {
  constructor() {
    this.route = inject(ActivatedRoute);
    this.navCtrl = inject(NavController);
    this.toastCtrl = inject(ToastController);
    this.saveAlertCtrl = inject(AlertController);
    this.authService = inject(AuthService);
    this.sesionService = inject(SesionService);
    this.offlineSync = inject(OfflineSyncService);
    this.realtimeService = inject(RealtimeService);
    this.cdr = inject(ChangeDetectorRef);
    this.totalMuestras = signal(
      1,
      ...ngDevMode ? [{ debugName: "totalMuestras" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.muestraActual = signal(
      1,
      ...ngDevMode ? [{ debugName: "muestraActual" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.guardando = signal(
      false,
      ...ngDevMode ? [{ debugName: "guardando" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.error = signal(
      null,
      ...ngDevMode ? [{ debugName: "error" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.cargando = signal(
      true,
      ...ngDevMode ? [{ debugName: "cargando" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.muestrasCerradas = signal(
      /* @__PURE__ */ new Set(),
      ...ngDevMode ? [{ debugName: "muestrasCerradas" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.muestrasEnviadas = signal(
      /* @__PURE__ */ new Set(),
      ...ngDevMode ? [{ debugName: "muestrasEnviadas" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.esperandoSincronizacion = signal(
      false,
      ...ngDevMode ? [{ debugName: "esperandoSincronizacion" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.sesionIdActual = signal(
      "",
      ...ngDevMode ? [{ debugName: "sesionIdActual" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.enLinea = this.offlineSync.enLinea;
    this.pendientesLocales = computed(
      () => {
        const sesionId = this.sesionIdActual();
        return this.offlineSync.cola().filter((item) => item.ficha.sesionId === sesionId).length;
      },
      ...ngDevMode ? [{ debugName: "pendientesLocales" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.muestraActualCerrada = computed(
      () => this.muestrasCerradas().has(this.muestraActual()),
      ...ngDevMode ? [{ debugName: "muestraActualCerrada" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.rechazoActual = computed(
      () => {
        const usuarioId = this.authService.usuario()?.id;
        if (!usuarioId)
          return null;
        return this.offlineSync.rechazos().get(`${this.sesionIdActual()}:${usuarioId}:${this.muestraActual()}`) ?? null;
      },
      ...ngDevMode ? [{ debugName: "rechazoActual" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.respuestas = [];
    this.sesionId = "";
    this.sala = null;
    this.destruido = false;
    this.navegandoFuera = false;
  }
  esRespuestaCompleta(_respuesta) {
    return true;
  }
  calcularPuntajeFinal(_respuesta) {
    return null;
  }
  // ---------------------------------------------------------------------------
  // Autoguardado: cualquier interacción dentro del formulario guarda borrador.
  // Los listeners de ngModel y (click) del elemento corren antes que el burbujeo
  // hasta el host, así que el modelo ya está actualizado aquí.
  // ---------------------------------------------------------------------------
  alInteractuar() {
    queueMicrotask(() => this.guardarBorradorActual());
  }
  async ngOnInit() {
    this.respuestas = [this.formulario];
    this.sesionId = this.route.snapshot.paramMap.get("sesionId")?.trim() ?? "";
    this.sesionIdActual.set(this.sesionId);
    if (!this.sesionId) {
      this.error.set("No se encontr\xF3 el ID de la sesi\xF3n.");
      this.cargando.set(false);
      return;
    }
    try {
      await this.authService.asegurarInicializado();
      const usuario = this.authService.usuario();
      if (!usuario)
        throw new Error("Debes iniciar sesi\xF3n para evaluar.");
      const sesion = await this.sesionService.obtenerSesionPorId(this.sesionId);
      if (!sesion)
        throw new Error("No se encontr\xF3 la sesi\xF3n de cata.");
      const esExtrinseco = getFormatoById(sesion.formato).id === "extrinseca";
      if (!esExtrinseco && sesion.estado === EstadoSesion.EN_ESPERA) {
        await this.salirA(`/session/waiting/${this.sesionId}`);
        return;
      }
      if (sesion.estado === EstadoSesion.FINALIZADA || sesion.estado === EstadoSesion.CANCELADA) {
        await this.salirA(`/session/${this.sesionId}/evaluation-complete`);
        return;
      }
      const total = Math.max(1, sesion.numeroMuestras);
      const [cerradas, enviadas] = await Promise.all([
        this.sesionService.obtenerMuestrasCerradas(this.sesionId),
        this.offlineSync.obtenerFichasEnviadas(this.sesionId).catch((error) => {
          console.warn("[CVA] No se pudieron leer las fichas enviadas:", error);
          return [];
        })
      ]);
      if (this.destruido)
        return;
      const notasPorMuestra = new Map(enviadas.map((f) => [f.numeroMuestra, f.notas]));
      this.totalMuestras.set(total);
      this.muestrasCerradas.set(new Set(cerradas));
      this.muestrasEnviadas.set(new Set(enviadas.map((f) => f.numeroMuestra)));
      this.respuestas = Array.from({ length: total }, (_, indice) => this.restaurarRespuesta(indice + 1, notasPorMuestra.get(indice + 1) ?? null));
      const primeraAbierta = Array.from({ length: total }, (_, i) => i + 1).find((n) => !this.muestrasEnviadas().has(n) && !this.muestrasCerradas().has(n)) ?? 1;
      this.mostrarMuestra(primeraAbierta);
      this.conectarTiempoReal(usuario.id, usuario.nombre);
    } catch (error) {
      this.error.set(mensajeDeError(error, "No se pudo cargar la sesi\xF3n."));
      console.error("Error al cargar la sesi\xF3n para la evaluaci\xF3n:", error);
      await this.mostrarToast(this.error() ?? "No se pudo cargar la sesi\xF3n.", "danger");
    } finally {
      this.cargando.set(false);
      this.cdr.markForCheck();
    }
  }
  ngOnDestroy() {
    this.destruido = true;
    this.guardarBorradorActual();
    this.eventosSub?.unsubscribe();
    this.sincronizadasSub?.unsubscribe();
    if (this.sala)
      this.realtimeService.liberarSala(this.sala);
    this.sala = null;
  }
  // ---------------------------------------------------------------------------
  // Navegación entre muestras
  // ---------------------------------------------------------------------------
  async irAMuestraSiguiente() {
    if (this.guardando())
      return;
    const actual = this.muestraActual();
    if (!this.muestrasCerradas().has(actual)) {
      if (!this.esRespuestaCompleta(this.formulario)) {
        await this.mostrarAvisoCalificacionIncompleta();
        return;
      }
      this.guardando.set(true);
      try {
        const resultado = await this.enviarMuestra(actual);
        if (resultado === "rechazada")
          return;
      } finally {
        this.guardando.set(false);
      }
    }
    const siguiente = this.siguienteMuestraAbierta(actual);
    if (siguiente === null) {
      await this.finalizarCata();
      return;
    }
    this.mostrarMuestra(siguiente);
  }
  irAMuestraAnterior() {
    const actual = this.muestraActual();
    if (actual <= 1)
      return;
    this.guardarBorradorActual();
    this.mostrarMuestra(actual - 1);
  }
  async finalizarCata() {
    if (this.guardando())
      return;
    this.guardarBorradorActual();
    const abiertas = Array.from({ length: this.totalMuestras() }, (_, i) => i + 1).filter((n) => !this.muestrasCerradas().has(n));
    const incompleta = abiertas.find((n) => !this.esRespuestaCompleta(this.respuestas[n - 1]));
    if (incompleta !== void 0) {
      this.mostrarMuestra(incompleta);
      await this.mostrarAvisoCalificacionIncompleta();
      return;
    }
    this.guardando.set(true);
    this.error.set(null);
    try {
      const resultados = await Promise.all(abiertas.map((n) => this.enviarMuestra(n)));
      if (resultados.includes("rechazada"))
        return;
      if (resultados.includes("pendiente") || this.offlineSync.pendientesDeSesion(this.sesionId).length > 0) {
        this.esperandoSincronizacion.set(true);
        await this.mostrarToast("Guardado localmente. Reintentando\u2026 Te avisaremos al sincronizar.", "warning");
        return;
      }
      await this.irAPantallaFinalizacion();
    } finally {
      this.guardando.set(false);
    }
  }
  /** Sale del formulario aunque queden fichas en cola (se enviarán al reconectar). */
  async salirConPendientes() {
    this.offlineSync.reintentarAhora();
    await this.irAPantallaFinalizacion();
  }
  reintentarSincronizacion() {
    this.offlineSync.reintentarAhora();
  }
  volver() {
    this.guardarBorradorActual();
    void this.navCtrl.back();
  }
  // ---------------------------------------------------------------------------
  // Envío de fichas
  // ---------------------------------------------------------------------------
  async enviarMuestra(numeroMuestra) {
    const usuarioId = this.authService.usuario()?.id;
    if (!usuarioId) {
      this.error.set("Tu sesi\xF3n expir\xF3. Inicia sesi\xF3n de nuevo; tus respuestas quedaron guardadas en este dispositivo.");
      return "rechazada";
    }
    const respuesta = this.respuestas[numeroMuestra - 1];
    this.offlineSync.guardarBorrador(this.sesionId, numeroMuestra, respuesta);
    const resultado = await this.offlineSync.enviar(this.construirFicha(usuarioId, numeroMuestra, respuesta));
    if (resultado.estado === "rechazada") {
      const mensaje = resultado.mensaje ?? "El servidor rechaz\xF3 la ficha.";
      if (/cerrada|terminó/i.test(mensaje)) {
        this.marcarCerrada(numeroMuestra);
      }
      const alerta = await this.saveAlertCtrl.create({
        header: `Muestra ${numeroMuestra} no guardada`,
        message: mensaje,
        buttons: ["Entendido"]
      });
      await alerta.present();
    }
    return resultado.estado;
  }
  construirFicha(usuarioId, numeroMuestra, respuesta) {
    const formulario = this.comoRegistro(respuesta);
    const defectos = this.comoRegistro(formulario["defectos"]);
    const tiposDefecto = Array.isArray(formulario["tiposDefecto"]) ? formulario["tiposDefecto"] : [];
    return {
      sesionId: this.sesionId,
      catadorId: usuarioId,
      numeroMuestra,
      impresionGlobal: this.numeroONulo(formulario["impresionGlobal"]),
      tazasNoUniformes: this.numeroO(defectos["tazasNoUniformes"]),
      tazasDefectuosas: Math.max(this.numeroO(defectos["tazasDefectuosas"]), tiposDefecto.length > 0 ? 1 : 0),
      puntajeFinal: this.calcularPuntajeFinal(respuesta),
      notas: JSON.stringify(respuesta),
      atributos: this.extraerAtributos(formulario)
    };
  }
  async irAPantallaFinalizacion() {
    if (!this.sesionId)
      return;
    try {
      const usuarioId = this.authService.usuario()?.id;
      const esOrganizador = usuarioId ? await this.sesionService.esOrganizadorDeSesion(this.sesionId, usuarioId) : false;
      await this.salirA(`/session/${this.sesionId}/evaluation-complete?organizador=${esOrganizador ? "1" : "0"}`);
    } catch {
      await this.salirA(`/session/${this.sesionId}/evaluation-complete`);
    }
  }
  // ---------------------------------------------------------------------------
  // Tiempo real
  // ---------------------------------------------------------------------------
  conectarTiempoReal(usuarioId, nombre) {
    if (this.destruido)
      return;
    this.sala = this.realtimeService.abrirSala({ sesionId: this.sesionId, usuarioId, nombre, rol: "catador" });
    this.eventosSub = this.sala.eventos$.subscribe((evento) => void this.manejarEvento(evento, usuarioId));
    this.sincronizadasSub = this.offlineSync.sincronizadas$.pipe(filter((ficha) => ficha.sesionId === this.sesionId && ficha.catadorId === usuarioId)).subscribe((ficha) => {
      const enviadas = new Set(this.muestrasEnviadas());
      enviadas.add(ficha.numeroMuestra);
      this.muestrasEnviadas.set(enviadas);
      void this.sala?.enviar({ tipo: "EVALUACION_ENVIADA", usuarioId, numeroMuestra: ficha.numeroMuestra });
      if (this.esperandoSincronizacion() && this.offlineSync.pendientesDeSesion(this.sesionId).length === 0) {
        this.esperandoSincronizacion.set(false);
        void this.mostrarToast("Fichas sincronizadas.", "success");
        void this.irAPantallaFinalizacion();
      }
    });
  }
  async manejarEvento(evento, usuarioId) {
    switch (evento.tipo) {
      case "CAMBIAR_MUESTRA":
        if (evento.numeroMuestra <= this.totalMuestras() && evento.numeroMuestra !== this.muestraActual()) {
          this.guardarBorradorActual();
          this.mostrarMuestra(evento.numeroMuestra);
          await this.mostrarToast(`El organizador llev\xF3 el panel a la muestra ${evento.numeroMuestra}.`, "dark");
        }
        break;
      case "MUESTRA_CERRADA":
        this.marcarCerrada(evento.numeroMuestra);
        if (evento.numeroMuestra === this.muestraActual()) {
          await this.mostrarToast(`La muestra ${evento.numeroMuestra} fue cerrada por el organizador.`, "warning");
          const siguiente = this.siguienteMuestraAbierta(evento.numeroMuestra);
          if (siguiente !== null)
            this.mostrarMuestra(siguiente);
        }
        break;
      case "PARTICIPANTE_RETIRADO":
        if (evento.usuarioId === usuarioId) {
          await this.mostrarToast("Fuiste retirado de la sesi\xF3n por desconexi\xF3n prolongada.", "warning");
          await this.salirA("/dashboard");
        }
        break;
      case "SESION_FINALIZADA":
      case "RESYNC":
        await this.resincronizar();
        break;
      default:
        break;
    }
  }
  async resincronizar() {
    try {
      const [sesion, cerradas] = await Promise.all([
        this.sesionService.obtenerSesionPorId(this.sesionId),
        this.sesionService.obtenerMuestrasCerradas(this.sesionId)
      ]);
      if (this.destruido)
        return;
      this.muestrasCerradas.set(new Set(cerradas));
      if (!sesion || sesion.estado === EstadoSesion.FINALIZADA || sesion.estado === EstadoSesion.CANCELADA) {
        this.guardarBorradorActual();
        await this.mostrarToast("El organizador cerr\xF3 el panel.", "dark");
        await this.irAPantallaFinalizacion();
      }
    } catch (error) {
      console.warn("[CVA] Resincronizaci\xF3n fallida:", error);
    }
  }
  // ---------------------------------------------------------------------------
  // Estado local
  // ---------------------------------------------------------------------------
  mostrarMuestra(numeroMuestra) {
    const indice = Math.min(Math.max(1, numeroMuestra), this.totalMuestras()) - 1;
    this.muestraActual.set(indice + 1);
    this.formulario = this.respuestas[indice];
    this.cdr.markForCheck();
  }
  siguienteMuestraAbierta(desde) {
    for (let n = desde + 1; n <= this.totalMuestras(); n++) {
      if (!this.muestrasCerradas().has(n))
        return n;
    }
    return null;
  }
  marcarCerrada(numeroMuestra) {
    const cerradas = new Set(this.muestrasCerradas());
    cerradas.add(numeroMuestra);
    this.muestrasCerradas.set(cerradas);
  }
  guardarBorradorActual() {
    if (!this.sesionId || this.cargando() || this.muestrasCerradas().has(this.muestraActual()))
      return;
    this.offlineSync.guardarBorrador(this.sesionId, this.muestraActual(), this.formulario);
  }
  restaurarRespuesta(numeroMuestra, notasServidor) {
    const vacio = this.crearFormularioVacio();
    const borrador = this.offlineSync.leerBorrador(this.sesionId, numeroMuestra);
    if (borrador && typeof borrador === "object")
      return __spreadValues(__spreadValues({}, vacio), borrador);
    if (notasServidor) {
      try {
        const desdeServidor = JSON.parse(notasServidor);
        if (this.esRegistro(desdeServidor))
          return __spreadValues(__spreadValues({}, vacio), desdeServidor);
      } catch {
      }
    }
    return vacio;
  }
  async salirA(url) {
    if (this.navegandoFuera)
      return;
    this.navegandoFuera = true;
    await this.navCtrl.navigateRoot(url);
  }
  async mostrarAvisoCalificacionIncompleta() {
    await this.mostrarToast("Por favor completa los atributos obligatorios.", "warning");
  }
  async mostrarToast(message, color) {
    const toast = await this.toastCtrl.create({ message, duration: 3e3, color });
    await toast.present();
  }
  // ---------------------------------------------------------------------------
  // Extracción de atributos (estructura genérica de los 4 formularios)
  // ---------------------------------------------------------------------------
  extraerAtributos(formulario) {
    const atributos = [];
    const recorrer = (valor, ruta) => {
      if (!this.esRegistro(valor))
        return;
      const intensidad = this.numeroONulo(valor["intensidad"]);
      const calidad = this.numeroONulo(valor["calidad"]);
      if (intensidad !== null || calidad !== null) {
        const atributo = ruta.replace(/^atributos\./, "");
        if (atributo) {
          atributos.push(__spreadValues(__spreadValues({
            atributo
          }, intensidad !== null ? { intensidad } : {}), calidad !== null ? { calidad } : {}));
        }
        return;
      }
      for (const [clave, hijo] of Object.entries(valor)) {
        if (clave === "defectos" || clave === "tiposDefecto" || clave === "mouthfeel")
          continue;
        if (!ruta && ATRIBUTOS_HEDONICOS.has(clave) && typeof hijo === "number" && Number.isFinite(hijo)) {
          atributos.push({ atributo: clave, calidad: hijo });
          continue;
        }
        if (this.esRegistro(hijo))
          recorrer(hijo, ruta ? `${ruta}.${clave}` : clave);
      }
    };
    recorrer(formulario, "");
    return atributos;
  }
  comoRegistro(valor) {
    return this.esRegistro(valor) ? valor : {};
  }
  esRegistro(valor) {
    return typeof valor === "object" && valor !== null && !Array.isArray(valor);
  }
  numeroO(valor) {
    return this.numeroONulo(valor) ?? 0;
  }
  numeroONulo(valor) {
    return typeof valor === "number" && Number.isFinite(valor) ? valor : null;
  }
};
_BaseCataForm.\u0275fac = function BaseCataForm_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _BaseCataForm)();
};
_BaseCataForm.\u0275dir = /* @__PURE__ */ \u0275\u0275defineDirective({ type: _BaseCataForm, hostBindings: function BaseCataForm_HostBindings(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275listener("input", function BaseCataForm_input_HostBindingHandler() {
      return ctx.alInteractuar();
    })("change", function BaseCataForm_change_HostBindingHandler() {
      return ctx.alInteractuar();
    })("click", function BaseCataForm_click_HostBindingHandler() {
      return ctx.alInteractuar();
    })("ionInput", function BaseCataForm_ionInput_HostBindingHandler() {
      return ctx.alInteractuar();
    })("ionChange", function BaseCataForm_ionChange_HostBindingHandler() {
      return ctx.alInteractuar();
    });
  }
} });
var BaseCataForm = _BaseCataForm;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(BaseCataForm, [{
    type: Directive
  }], null, { alInteractuar: [{
    type: HostListener,
    args: ["input"]
  }, {
    type: HostListener,
    args: ["change"]
  }, {
    type: HostListener,
    args: ["click"]
  }, {
    type: HostListener,
    args: ["ionInput"]
  }, {
    type: HostListener,
    args: ["ionChange"]
  }] });
})();

// src/app/shared/components/estado-ficha/estado-ficha.component.ts
function EstadoFichaComponent_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275domElementStart(0, "div", 0);
    \u0275\u0275text(1, " Esta muestra fue cerrada por el organizador: ya no se aceptan cambios. ");
    \u0275\u0275domElementEnd();
  }
}
function EstadoFichaComponent_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = \u0275\u0275getCurrentView();
    \u0275\u0275domElementStart(0, "div", 1)(1, "span");
    \u0275\u0275text(2);
    \u0275\u0275domElementEnd();
    \u0275\u0275domElementStart(3, "button", 3);
    \u0275\u0275domListener("click", function EstadoFichaComponent_Conditional_1_Template_button_click_3_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.reintentar.emit());
    });
    \u0275\u0275text(4, "Reintentar ahora");
    \u0275\u0275domElementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate3(" Guardado localmente. Reintentando\u2026 (", ctx_r1.pendientes(), " ficha", ctx_r1.pendientes() === 1 ? "" : "s", "", ctx_r1.enLinea() ? "" : " \xB7 sin conexi\xF3n", ") ");
  }
}
function EstadoFichaComponent_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = \u0275\u0275getCurrentView();
    \u0275\u0275domElementStart(0, "div", 1)(1, "span");
    \u0275\u0275text(2, "Terminaste la cata. Las fichas se enviar\xE1n solas al recuperar la conexi\xF3n.");
    \u0275\u0275domElementEnd();
    \u0275\u0275domElementStart(3, "button", 3);
    \u0275\u0275domListener("click", function EstadoFichaComponent_Conditional_2_Template_button_click_3_listener() {
      \u0275\u0275restoreView(_r3);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.salir.emit());
    });
    \u0275\u0275text(4, "Salir ahora");
    \u0275\u0275domElementEnd()();
  }
}
function EstadoFichaComponent_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275domElementStart(0, "div", 2);
    \u0275\u0275text(1);
    \u0275\u0275domElementEnd();
  }
  if (rf & 2) {
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx);
  }
}
var _EstadoFichaComponent = class _EstadoFichaComponent {
  constructor() {
    this.pendientes = input(
      0,
      ...ngDevMode ? [{ debugName: "pendientes" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.enLinea = input(
      true,
      ...ngDevMode ? [{ debugName: "enLinea" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.muestraCerrada = input(
      false,
      ...ngDevMode ? [{ debugName: "muestraCerrada" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.rechazo = input(
      null,
      ...ngDevMode ? [{ debugName: "rechazo" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.esperandoFinalizar = input(
      false,
      ...ngDevMode ? [{ debugName: "esperandoFinalizar" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.reintentar = output();
    this.salir = output();
  }
};
_EstadoFichaComponent.\u0275fac = function EstadoFichaComponent_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _EstadoFichaComponent)();
};
_EstadoFichaComponent.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _EstadoFichaComponent, selectors: [["app-estado-ficha"]], inputs: { pendientes: [1, "pendientes"], enLinea: [1, "enLinea"], muestraCerrada: [1, "muestraCerrada"], rechazo: [1, "rechazo"], esperandoFinalizar: [1, "esperandoFinalizar"] }, outputs: { reintentar: "reintentar", salir: "salir" }, decls: 4, vars: 4, consts: [["role", "status", 1, "estado-ficha", "estado-ficha--cerrada"], ["role", "status", 1, "estado-ficha", "estado-ficha--pendiente"], ["role", "alert", 1, "estado-ficha", "estado-ficha--error"], ["type", "button", 3, "click"]], template: function EstadoFichaComponent_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275conditionalCreate(0, EstadoFichaComponent_Conditional_0_Template, 2, 0, "div", 0);
    \u0275\u0275conditionalCreate(1, EstadoFichaComponent_Conditional_1_Template, 5, 3, "div", 1);
    \u0275\u0275conditionalCreate(2, EstadoFichaComponent_Conditional_2_Template, 5, 0, "div", 1);
    \u0275\u0275conditionalCreate(3, EstadoFichaComponent_Conditional_3_Template, 2, 1, "div", 2);
  }
  if (rf & 2) {
    let tmp_3_0;
    \u0275\u0275conditional(ctx.muestraCerrada() ? 0 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx.pendientes() > 0 ? 1 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx.esperandoFinalizar() ? 2 : -1);
    \u0275\u0275advance();
    \u0275\u0275conditional((tmp_3_0 = ctx.rechazo()) ? 3 : -1, tmp_3_0);
  }
}, styles: ["\n[_nghost-%COMP%] {\n  display: block;\n}\n.estado-ficha[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  gap: 12px;\n  margin: 8px 12px;\n  padding: 10px 12px;\n  border-radius: 8px;\n  font-size: 12px;\n  line-height: 1.4;\n}\n.estado-ficha--pendiente[_ngcontent-%COMP%] {\n  background: #fef9c3;\n  color: #854d0e;\n}\n.estado-ficha--cerrada[_ngcontent-%COMP%] {\n  background: var(--%NS%app-bg-subtle);\n  color: var(--%NS%app-text-muted);\n}\n.estado-ficha--error[_ngcontent-%COMP%] {\n  background: var(--%NS%app-error-bg);\n  color: var(--%NS%app-error-text);\n}\nbutton[_ngcontent-%COMP%] {\n  flex: none;\n  padding: 4px 10px;\n  border: 1px solid currentColor;\n  border-radius: 6px;\n  background: transparent;\n  color: inherit;\n  font: inherit;\n  font-weight: 600;\n  cursor: pointer;\n}\n/*# sourceMappingURL=estado-ficha.component.css.map */"] });
var EstadoFichaComponent = _EstadoFichaComponent;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(EstadoFichaComponent, [{
    type: Component,
    args: [{ selector: "app-estado-ficha", standalone: true, template: `
    @if (muestraCerrada()) {
      <div class="estado-ficha estado-ficha--cerrada" role="status">
        Esta muestra fue cerrada por el organizador: ya no se aceptan cambios.
      </div>
    }
    @if (pendientes() > 0) {
      <div class="estado-ficha estado-ficha--pendiente" role="status">
        <span>
          Guardado localmente. Reintentando\u2026
          ({{ pendientes() }} ficha{{ pendientes() === 1 ? '' : 's' }}{{ enLinea() ? '' : ' \xB7 sin conexi\xF3n' }})
        </span>
        <button type="button" (click)="reintentar.emit()">Reintentar ahora</button>
      </div>
    }
    @if (esperandoFinalizar()) {
      <div class="estado-ficha estado-ficha--pendiente" role="status">
        <span>Terminaste la cata. Las fichas se enviar\xE1n solas al recuperar la conexi\xF3n.</span>
        <button type="button" (click)="salir.emit()">Salir ahora</button>
      </div>
    }
    @if (rechazo(); as mensaje) {
      <div class="estado-ficha estado-ficha--error" role="alert">{{ mensaje }}</div>
    }
  `, styles: ["/* angular:styles/component:scss;78e959490d477b33cedc43a7727ee98c9e7d90453590bbd6fb907cdf9e11f76e;/sessions/rcw-011ru3dfsk6aau4iyw2ynni7/mnt/PacamaraQS/src/app/shared/components/estado-ficha/estado-ficha.component.ts */\n:host {\n  display: block;\n}\n.estado-ficha {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  gap: 12px;\n  margin: 8px 12px;\n  padding: 10px 12px;\n  border-radius: 8px;\n  font-size: 12px;\n  line-height: 1.4;\n}\n.estado-ficha--pendiente {\n  background: #fef9c3;\n  color: #854d0e;\n}\n.estado-ficha--cerrada {\n  background: var(--app-bg-subtle);\n  color: var(--app-text-muted);\n}\n.estado-ficha--error {\n  background: var(--app-error-bg);\n  color: var(--app-error-text);\n}\nbutton {\n  flex: none;\n  padding: 4px 10px;\n  border: 1px solid currentColor;\n  border-radius: 6px;\n  background: transparent;\n  color: inherit;\n  font: inherit;\n  font-weight: 600;\n  cursor: pointer;\n}\n/*# sourceMappingURL=estado-ficha.component.css.map */\n"] }]
  }], null, { pendientes: [{ type: Input, args: [{ isSignal: true, alias: "pendientes", required: false }] }], enLinea: [{ type: Input, args: [{ isSignal: true, alias: "enLinea", required: false }] }], muestraCerrada: [{ type: Input, args: [{ isSignal: true, alias: "muestraCerrada", required: false }] }], rechazo: [{ type: Input, args: [{ isSignal: true, alias: "rechazo", required: false }] }], esperandoFinalizar: [{ type: Input, args: [{ isSignal: true, alias: "esperandoFinalizar", required: false }] }], reintentar: [{ type: Output, args: ["reintentar"] }], salir: [{ type: Output, args: ["salir"] }] });
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(EstadoFichaComponent, { className: "EstadoFichaComponent", filePath: "src/app/shared/components/estado-ficha/estado-ficha.component.ts", lineNumber: 64 });
})();

export {
  BaseCataForm,
  EstadoFichaComponent
};
//# debugId=e676f5ea-d0c2-5628-ae27-7391e90448d6
//# sourceMappingURL=chunk-RZUIYIJO.js.map
