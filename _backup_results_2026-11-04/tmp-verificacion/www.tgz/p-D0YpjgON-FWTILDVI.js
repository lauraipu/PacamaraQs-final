import {
  h,
  n
} from "./chunk-XTVSKRH4.js";
import "./chunk-PAXKX5KU.js";
export {
  h as GESTURE_CONTROLLER,
  n as createGesture
};
//# debugId=63937638-d6a4-59b6-8ed2-3b91ede6aecb
//# sourceMappingURL=p-D0YpjgON-FWTILDVI.js.map
