import {
  BaseCataForm,
  EstadoFichaComponent
} from "./chunk-NSTJCVOE.js";
import "./chunk-NM5KBNCZ.js";
import {
  ETIQUETAS_HEDONICAS
} from "./chunk-ECLBRM7C.js";
import "./chunk-DLWN5DPS.js";
import "./chunk-BHVR7Z6N.js";
import {
  arrowBackOutline
} from "./chunk-IN4O4X7H.js";
import "./chunk-OFWJO6PD.js";
import {
  addIcons
} from "./chunk-4JFQPQWK.js";
import "./chunk-JH4CNQSM.js";
import {
  CommonModule,
  Component,
  DecimalPipe,
  DefaultValueAccessor,
  FormsModule,
  IonContent,
  IonIcon,
  NgControlStatus,
  NgForOf,
  NgIf,
  NgModel,
  setClassMetadata,
  ɵsetClassDebugInfo,
  ɵɵInheritDefinitionFeature,
  ɵɵadvance,
  ɵɵattribute,
  ɵɵclassProp,
  ɵɵcontrol,
  ɵɵcontrolCreate,
  ɵɵdefineComponent,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵgetInheritedFactory,
  ɵɵlistener,
  ɵɵnextContext,
  ɵɵpipe,
  ɵɵpipeBind2,
  ɵɵproperty,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵstyleProp,
  ɵɵtemplate,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1,
  ɵɵtextInterpolate2,
  ɵɵtwoWayBindingSet,
  ɵɵtwoWayListener,
  ɵɵtwoWayProperty
} from "./chunk-DEQWXDMW.js";
import "./chunk-BMQUG2PJ.js";
import "./chunk-3OZZMUVI.js";
import "./chunk-3GAB7GSC.js";
import "./chunk-B7Y4FMY7.js";
import "./chunk-NQCL7WZ3.js";
import "./chunk-4BTEZGN2.js";
import "./chunk-XTVSKRH4.js";
import "./chunk-ETZFPO3Y.js";
import "./chunk-LLS636HS.js";
import "./chunk-KQQH3YTO.js";
import "./chunk-DI3VEDFV.js";
import "./chunk-PAXKX5KU.js";

// src/app/pages/evaluation/affective-form/affective-form.page.ts
function AffectiveFormPage_article_27_button_10_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 53);
    \u0275\u0275listener("click", function AffectiveFormPage_article_27_button_10_Template_button_click_0_listener() {
      const valor_r2 = \u0275\u0275restoreView(_r1).$implicit;
      const atributo_r3 = \u0275\u0275nextContext().$implicit;
      const ctx_r3 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r3.formulario[atributo_r3.key] = valor_r2);
    });
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const valor_r2 = ctx.$implicit;
    const atributo_r3 = \u0275\u0275nextContext().$implicit;
    const ctx_r3 = \u0275\u0275nextContext();
    \u0275\u0275classProp("hedonic-buttons__btn--active", ctx_r3.formulario[atributo_r3.key] === valor_r2);
    \u0275\u0275attribute("aria-pressed", ctx_r3.formulario[atributo_r3.key] === valor_r2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", valor_r2, " ");
  }
}
function AffectiveFormPage_article_27_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "article", 21)(1, "h3", 22);
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "div", 23)(4, "div", 24)(5, "span", 25);
    \u0275\u0275text(6, "Calidad hed\xF3nica");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "span", 26);
    \u0275\u0275text(8);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(9, "div", 27);
    \u0275\u0275template(10, AffectiveFormPage_article_27_button_10_Template, 2, 4, "button", 28);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const atributo_r3 = ctx.$implicit;
    const ctx_r3 = \u0275\u0275nextContext();
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(atributo_r3.label);
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate2(" ", ctx_r3.formulario[atributo_r3.key], " \u2014 ", ctx_r3.etiquetas[ctx_r3.formulario[atributo_r3.key]], " ");
    \u0275\u0275advance(2);
    \u0275\u0275property("ngForOf", ctx_r3.escalaHedonica);
  }
}
function AffectiveFormPage_button_38_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 53);
    \u0275\u0275listener("click", function AffectiveFormPage_button_38_Template_button_click_0_listener() {
      const valor_r6 = \u0275\u0275restoreView(_r5).$implicit;
      const ctx_r3 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r3.formulario.impresionGlobal = valor_r6);
    });
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const valor_r6 = ctx.$implicit;
    const ctx_r3 = \u0275\u0275nextContext();
    \u0275\u0275classProp("hedonic-buttons__btn--active", ctx_r3.formulario.impresionGlobal === valor_r6);
    \u0275\u0275attribute("aria-pressed", ctx_r3.formulario.impresionGlobal === valor_r6);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", valor_r6, " ");
  }
}
function AffectiveFormPage_button_82_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 54);
    \u0275\u0275listener("click", function AffectiveFormPage_button_82_Template_button_click_0_listener() {
      \u0275\u0275restoreView(_r7);
      const ctx_r3 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r3.irAMuestraAnterior());
    });
    \u0275\u0275text(1, " \u2190 Anterior ");
    \u0275\u0275elementEnd();
  }
}
addIcons({ arrowBackOutline });
var _AffectiveFormPage = class _AffectiveFormPage extends BaseCataForm {
  constructor() {
    super(...arguments);
    this.formulario = this.crearFormularioVacio();
    this.atributos = [
      { key: "fragancia", label: "Fragancia" },
      { key: "aroma", label: "Aroma" },
      { key: "sabor", label: "Sabor" },
      { key: "saborResidual", label: "Sabor Residual (Posgusto)" },
      { key: "acidez", label: "Acidez" },
      { key: "dulzor", label: "Dulzor" },
      { key: "sensacionEnBoca", label: "Sensaci\xF3n en Boca" }
    ];
    this.escalaHedonica = [1, 2, 3, 4, 5, 6, 7, 8, 9];
    this.etiquetas = ETIQUETAS_HEDONICAS;
  }
  crearFormularioVacio() {
    return {
      fragancia: 5,
      aroma: 5,
      sabor: 5,
      saborResidual: 5,
      acidez: 5,
      dulzor: 5,
      sensacionEnBoca: 5,
      impresionGlobal: 5,
      defectos: { tazasNoUniformes: 0, tazasDefectuosas: 0 },
      notas: ""
    };
  }
  esRespuestaCompleta(respuesta) {
    const valores = [
      respuesta.fragancia,
      respuesta.aroma,
      respuesta.sabor,
      respuesta.saborResidual,
      respuesta.acidez,
      respuesta.dulzor,
      respuesta.sensacionEnBoca,
      respuesta.impresionGlobal
    ];
    return valores.every((valor) => Number.isInteger(valor) && valor >= 1 && valor <= 9);
  }
  get puntaje() {
    const f = this.formulario;
    const suma = f.fragancia + f.aroma + f.sabor + f.saborResidual + f.acidez + f.dulzor + f.sensacionEnBoca + f.impresionGlobal;
    const penalizacion = 2 * f.defectos.tazasNoUniformes + 4 * f.defectos.tazasDefectuosas;
    const calculo = 0.65625 * suma + 52.75 - penalizacion;
    return Math.max(0, Math.min(100, Math.round(calculo * 4) / 4));
  }
  calcularPuntajeFinal(respuesta) {
    const suma = respuesta.fragancia + respuesta.aroma + respuesta.sabor + respuesta.saborResidual + respuesta.acidez + respuesta.dulzor + respuesta.sensacionEnBoca + respuesta.impresionGlobal;
    const penalizacion = 2 * respuesta.defectos.tazasNoUniformes + 4 * respuesta.defectos.tazasDefectuosas;
    const calculo = 0.65625 * suma + 52.75 - penalizacion;
    return Math.max(0, Math.min(100, Math.round(calculo * 4) / 4));
  }
  get clasificacion() {
    const p = this.puntaje;
    if (p >= 90)
      return { label: "Excepcional", color: "#15803d", bg: "#f0fdf4" };
    if (p >= 85)
      return { label: "Excelente", color: "#1d4ed8", bg: "#eff6ff" };
    if (p >= 80)
      return { label: "Muy bueno", color: "#a16207", bg: "#fefce8" };
    if (p >= 75)
      return { label: "Bueno", color: "#c2410c", bg: "#fff7ed" };
    return { label: "Regular", color: "#6c757d", bg: "#f8f9fa" };
  }
  ajustarDefecto(tipo, operacion) {
    const propiedad = tipo === "uniformes" ? "tazasNoUniformes" : "tazasDefectuosas";
    const valorActual = this.formulario.defectos[propiedad];
    this.formulario.defectos[propiedad] = operacion === "sumar" ? Math.min(5, valorActual + 1) : Math.max(0, valorActual - 1);
  }
};
_AffectiveFormPage.\u0275fac = /* @__PURE__ */ (() => {
  let \u0275AffectiveFormPage_BaseFactory;
  return function AffectiveFormPage_Factory(__ngFactoryType__) {
    return (\u0275AffectiveFormPage_BaseFactory || (\u0275AffectiveFormPage_BaseFactory = \u0275\u0275getInheritedFactory(_AffectiveFormPage)))(__ngFactoryType__ || _AffectiveFormPage);
  };
})();
_AffectiveFormPage.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _AffectiveFormPage, selectors: [["app-affective-form"]], features: [\u0275\u0275InheritDefinitionFeature], decls: 85, vars: 39, consts: [[1, "cva-combined", 3, "scrollY"], [3, "reintentar", "salir", "pendientes", "enLinea", "muestraCerrada", "rechazo", "esperandoFinalizar"], [1, "cva-header"], [1, "cva-header__inner"], [1, "cva-header__left"], ["type", "button", "aria-label", "Volver", 1, "cva-header__back-btn", 3, "click"], ["name", "arrow-back-outline"], [1, "cva-header__meta"], [1, "cva-header__session-name"], [1, "cva-header__sample-label"], [1, "cva-header__right"], [1, "cva-header__live-score"], [1, "cva-header__live-score-label"], [1, "cva-header__live-score-value"], [1, "cva-header__progress-bar-wrap"], [1, "cva-header__progress-bar"], [1, "cva-header__progress-bar-fill"], [1, "cva-main"], [1, "cva-main__grid"], [1, "cva-main__column"], ["class", "attr-card", 4, "ngFor", "ngForOf"], [1, "attr-card"], [1, "attr-card__title"], [1, "hedonic-buttons"], [1, "hedonic-buttons__header"], [1, "hedonic-buttons__label"], [1, "hedonic-buttons__descriptor"], [1, "hedonic-buttons__grid"], ["type", "button", "class", "hedonic-buttons__btn", 3, "hedonic-buttons__btn--active", "click", 4, "ngFor", "ngForOf"], [1, "cva-main__sidebar"], [1, "score-panel"], [1, "score-panel__label"], [1, "score-panel__value"], [1, "score-panel__classification"], [1, "defect-panel"], [1, "label-micro", 2, "display", "block", "margin-bottom", "16px"], [1, "defect-counter"], [1, "defect-counter__info"], [1, "defect-counter__label"], [1, "defect-counter__sublabel"], [1, "defect-counter__controls"], ["type", "button", "aria-label", "Restar taza no uniforme", 1, "defect-counter__btn", 3, "click"], [1, "defect-counter__value"], ["type", "button", "aria-label", "Sumar taza no uniforme", 1, "defect-counter__btn", 3, "click"], [1, "defect-counter", 2, "margin-top", "16px"], ["type", "button", "aria-label", "Restar taza defectuosa", 1, "defect-counter__btn", 3, "click"], ["type", "button", "aria-label", "Sumar taza defectuosa", 1, "defect-counter__btn", 3, "click"], [1, "notes-panel"], [1, "notes-panel__header"], ["rows", "4", "placeholder", "Observaciones...", 1, "notes-panel__textarea", 3, "ngModelChange", "ngModel"], [1, "sample-navigation"], ["type", "button", "class", "submit-btn sample-navigation__previous", 3, "click", 4, "ngIf"], ["type", "button", 1, "submit-btn", 3, "click", "disabled"], ["type", "button", 1, "hedonic-buttons__btn", 3, "click"], ["type", "button", 1, "submit-btn", "sample-navigation__previous", 3, "click"]], template: function AffectiveFormPage_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-content", 0)(1, "app-estado-ficha", 1);
    \u0275\u0275listener("reintentar", function AffectiveFormPage_Template_app_estado_ficha_reintentar_1_listener() {
      return ctx.reintentarSincronizacion();
    })("salir", function AffectiveFormPage_Template_app_estado_ficha_salir_1_listener() {
      return ctx.salirConPendientes();
    });
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(2, "header", 2)(3, "div", 3)(4, "div", 4)(5, "button", 5);
    \u0275\u0275listener("click", function AffectiveFormPage_Template_button_click_5_listener() {
      return ctx.volver();
    });
    \u0275\u0275element(6, "ion-icon", 6);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "div", 7)(8, "p", 8);
    \u0275\u0275text(9, "Evaluaci\xF3n Afectiva");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(10, "p", 9);
    \u0275\u0275text(11);
    \u0275\u0275elementStart(12, "span");
    \u0275\u0275text(13);
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(14, "div", 10)(15, "div", 11)(16, "span", 12);
    \u0275\u0275text(17, "CVA");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(18, "span", 13);
    \u0275\u0275text(19);
    \u0275\u0275pipe(20, "number");
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(21, "div", 14)(22, "div", 15);
    \u0275\u0275element(23, "div", 16);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(24, "main", 17)(25, "div", 18)(26, "div", 19);
    \u0275\u0275template(27, AffectiveFormPage_article_27_Template, 11, 4, "article", 20);
    \u0275\u0275elementStart(28, "article", 21)(29, "h3", 22);
    \u0275\u0275text(30, "Impresi\xF3n Global");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(31, "div", 23)(32, "div", 24)(33, "span", 25);
    \u0275\u0275text(34, "Calidad hed\xF3nica");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(35, "span", 26);
    \u0275\u0275text(36);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(37, "div", 27);
    \u0275\u0275template(38, AffectiveFormPage_button_38_Template, 2, 4, "button", 28);
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(39, "aside", 29)(40, "div", 30)(41, "span", 31);
    \u0275\u0275text(42, "Puntaje CVA");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(43, "span", 32);
    \u0275\u0275text(44);
    \u0275\u0275pipe(45, "number");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(46, "span", 33);
    \u0275\u0275text(47);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(48, "div", 34)(49, "span", 35);
    \u0275\u0275text(50, "Defectos");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(51, "div", 36)(52, "div", 37)(53, "span", 38);
    \u0275\u0275text(54, "Tazas no uniformes");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(55, "span", 39);
    \u0275\u0275text(56, "\u22122 pts por taza");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(57, "div", 40)(58, "button", 41);
    \u0275\u0275listener("click", function AffectiveFormPage_Template_button_click_58_listener() {
      return ctx.ajustarDefecto("uniformes", "restar");
    });
    \u0275\u0275text(59, "\u2212");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(60, "span", 42);
    \u0275\u0275text(61);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(62, "button", 43);
    \u0275\u0275listener("click", function AffectiveFormPage_Template_button_click_62_listener() {
      return ctx.ajustarDefecto("uniformes", "sumar");
    });
    \u0275\u0275text(63, "+");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(64, "div", 44)(65, "div", 37)(66, "span", 38);
    \u0275\u0275text(67, "Tazas defectuosas");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(68, "span", 39);
    \u0275\u0275text(69, "\u22124 pts por taza");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(70, "div", 40)(71, "button", 45);
    \u0275\u0275listener("click", function AffectiveFormPage_Template_button_click_71_listener() {
      return ctx.ajustarDefecto("defectuosas", "restar");
    });
    \u0275\u0275text(72, "\u2212");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(73, "span", 42);
    \u0275\u0275text(74);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(75, "button", 46);
    \u0275\u0275listener("click", function AffectiveFormPage_Template_button_click_75_listener() {
      return ctx.ajustarDefecto("defectuosas", "sumar");
    });
    \u0275\u0275text(76, "+");
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(77, "div", 47)(78, "div", 48);
    \u0275\u0275text(79, "Notas adicionales");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(80, "textarea", 49);
    \u0275\u0275twoWayListener("ngModelChange", function AffectiveFormPage_Template_textarea_ngModelChange_80_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.formulario.notas, $event) || (ctx.formulario.notas = $event);
      return $event;
    });
    \u0275\u0275elementEnd();
    \u0275\u0275controlCreate();
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(81, "div", 50);
    \u0275\u0275template(82, AffectiveFormPage_button_82_Template, 2, 0, "button", 51);
    \u0275\u0275elementStart(83, "button", 52);
    \u0275\u0275listener("click", function AffectiveFormPage_Template_button_click_83_listener() {
      return ctx.irAMuestraSiguiente();
    });
    \u0275\u0275text(84);
    \u0275\u0275elementEnd()()()()()();
  }
  if (rf & 2) {
    \u0275\u0275property("scrollY", true);
    \u0275\u0275advance();
    \u0275\u0275property("pendientes", ctx.pendientesLocales())("enLinea", ctx.enLinea())("muestraCerrada", ctx.muestraActualCerrada())("rechazo", ctx.rechazoActual())("esperandoFinalizar", ctx.esperandoSincronizacion());
    \u0275\u0275advance(10);
    \u0275\u0275textInterpolate1("Muestra ", ctx.muestraActual(), " ");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1("de ", ctx.totalMuestras());
    \u0275\u0275advance(2);
    \u0275\u0275styleProp("background", ctx.clasificacion.bg);
    \u0275\u0275advance(3);
    \u0275\u0275styleProp("color", ctx.clasificacion.color);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", \u0275\u0275pipeBind2(20, 33, ctx.puntaje, "1.2-2"), " ");
    \u0275\u0275advance(4);
    \u0275\u0275styleProp("width", ctx.muestraActual() / ctx.totalMuestras() * 100 + "%");
    \u0275\u0275advance(4);
    \u0275\u0275property("ngForOf", ctx.atributos);
    \u0275\u0275advance(9);
    \u0275\u0275textInterpolate2(" ", ctx.formulario.impresionGlobal, " \u2014 ", ctx.etiquetas[ctx.formulario.impresionGlobal], " ");
    \u0275\u0275advance(2);
    \u0275\u0275property("ngForOf", ctx.escalaHedonica);
    \u0275\u0275advance(2);
    \u0275\u0275styleProp("background", ctx.clasificacion.bg);
    \u0275\u0275advance(3);
    \u0275\u0275styleProp("color", ctx.clasificacion.color);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", \u0275\u0275pipeBind2(45, 36, ctx.puntaje, "1.2-2"), " ");
    \u0275\u0275advance(2);
    \u0275\u0275styleProp("color", ctx.clasificacion.color);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", ctx.clasificacion.label, " ");
    \u0275\u0275advance(14);
    \u0275\u0275textInterpolate(ctx.formulario.defectos.tazasNoUniformes);
    \u0275\u0275advance(13);
    \u0275\u0275textInterpolate(ctx.formulario.defectos.tazasDefectuosas);
    \u0275\u0275advance(6);
    \u0275\u0275twoWayProperty("ngModel", ctx.formulario.notas);
    \u0275\u0275control();
    \u0275\u0275advance(2);
    \u0275\u0275property("ngIf", ctx.muestraActual() > 1);
    \u0275\u0275advance();
    \u0275\u0275property("disabled", ctx.guardando());
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", ctx.guardando() ? "Guardando\u2026" : ctx.muestraActual() === ctx.totalMuestras() ? "Terminar cata" : "Siguiente muestra \u2192", " ");
  }
}, dependencies: [IonContent, IonIcon, CommonModule, NgForOf, NgIf, FormsModule, DefaultValueAccessor, NgControlStatus, NgModel, EstadoFichaComponent, DecimalPipe], encapsulation: 2 });
var AffectiveFormPage = _AffectiveFormPage;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(AffectiveFormPage, [{
    type: Component,
    args: [{ selector: "app-affective-form", standalone: true, imports: [IonContent, IonIcon, CommonModule, FormsModule, EstadoFichaComponent], template: `<ion-content class="cva-combined" [scrollY]="true">
  <app-estado-ficha
    [pendientes]="pendientesLocales()"
    [enLinea]="enLinea()"
    [muestraCerrada]="muestraActualCerrada()"
    [rechazo]="rechazoActual()"
    [esperandoFinalizar]="esperandoSincronizacion()"
    (reintentar)="reintentarSincronizacion()"
    (salir)="salirConPendientes()">
  </app-estado-ficha>
  <header class="cva-header">
    <div class="cva-header__inner">
      <div class="cva-header__left">
        <button type="button" class="cva-header__back-btn" aria-label="Volver" (click)="volver()">
          <ion-icon name="arrow-back-outline"></ion-icon>
        </button>
        <div class="cva-header__meta">
          <p class="cva-header__session-name">Evaluaci\xF3n Afectiva</p>
          <p class="cva-header__sample-label">Muestra {{ muestraActual() }} <span>de {{ totalMuestras() }}</span></p>
        </div>
      </div>
      <div class="cva-header__right">
        <div class="cva-header__live-score" [style.background]="clasificacion.bg">
          <span class="cva-header__live-score-label">CVA</span>
          <span class="cva-header__live-score-value" [style.color]="clasificacion.color">
            {{ puntaje | number:'1.2-2' }}
          </span>
        </div>
      </div>
    </div>
    <div class="cva-header__progress-bar-wrap">
      <div class="cva-header__progress-bar">
        <div class="cva-header__progress-bar-fill" [style.width]="(muestraActual() / totalMuestras()) * 100 + '%'"></div>
      </div>
    </div>
  </header>

  <main class="cva-main">
    <div class="cva-main__grid">
      <div class="cva-main__column">
        <article class="attr-card" *ngFor="let atributo of atributos">
          <h3 class="attr-card__title">{{ atributo.label }}</h3>
          <div class="hedonic-buttons">
            <div class="hedonic-buttons__header">
              <span class="hedonic-buttons__label">Calidad hed\xF3nica</span>
              <span class="hedonic-buttons__descriptor">
                {{ formulario[atributo.key] }} \u2014 {{ etiquetas[formulario[atributo.key]] }}
              </span>
            </div>
            <div class="hedonic-buttons__grid">
              <button
                type="button"
                *ngFor="let valor of escalaHedonica"
                class="hedonic-buttons__btn"
                [class.hedonic-buttons__btn--active]="formulario[atributo.key] === valor"
                [attr.aria-pressed]="formulario[atributo.key] === valor"
                (click)="formulario[atributo.key] = valor">
                {{ valor }}
              </button>
            </div>
          </div>
        </article>

        <article class="attr-card">
          <h3 class="attr-card__title">Impresi\xF3n Global</h3>
          <div class="hedonic-buttons">
            <div class="hedonic-buttons__header">
              <span class="hedonic-buttons__label">Calidad hed\xF3nica</span>
              <span class="hedonic-buttons__descriptor">
                {{ formulario.impresionGlobal }} \u2014 {{ etiquetas[formulario.impresionGlobal] }}
              </span>
            </div>
            <div class="hedonic-buttons__grid">
              <button
                type="button"
                *ngFor="let valor of escalaHedonica"
                class="hedonic-buttons__btn"
                [class.hedonic-buttons__btn--active]="formulario.impresionGlobal === valor"
                [attr.aria-pressed]="formulario.impresionGlobal === valor"
                (click)="formulario.impresionGlobal = valor">
                {{ valor }}
              </button>
            </div>
          </div>
        </article>
      </div>

      <aside class="cva-main__sidebar">
        <div class="score-panel" [style.background]="clasificacion.bg">
          <span class="score-panel__label">Puntaje CVA</span>
          <span class="score-panel__value" [style.color]="clasificacion.color">
            {{ puntaje | number:'1.2-2' }}
          </span>
          <span class="score-panel__classification" [style.color]="clasificacion.color">
            {{ clasificacion.label }}
          </span>
        </div>

        <div class="defect-panel">
          <span class="label-micro" style="display:block; margin-bottom:16px;">Defectos</span>
          <div class="defect-counter">
            <div class="defect-counter__info">
              <span class="defect-counter__label">Tazas no uniformes</span>
              <span class="defect-counter__sublabel">\u22122 pts por taza</span>
            </div>
            <div class="defect-counter__controls">
              <button type="button" class="defect-counter__btn" aria-label="Restar taza no uniforme" (click)="ajustarDefecto('uniformes', 'restar')">\u2212</button>
              <span class="defect-counter__value">{{ formulario.defectos.tazasNoUniformes }}</span>
              <button type="button" class="defect-counter__btn" aria-label="Sumar taza no uniforme" (click)="ajustarDefecto('uniformes', 'sumar')">+</button>
            </div>
          </div>
          <div class="defect-counter" style="margin-top:16px;">
            <div class="defect-counter__info">
              <span class="defect-counter__label">Tazas defectuosas</span>
              <span class="defect-counter__sublabel">\u22124 pts por taza</span>
            </div>
            <div class="defect-counter__controls">
              <button type="button" class="defect-counter__btn" aria-label="Restar taza defectuosa" (click)="ajustarDefecto('defectuosas', 'restar')">\u2212</button>
              <span class="defect-counter__value">{{ formulario.defectos.tazasDefectuosas }}</span>
              <button type="button" class="defect-counter__btn" aria-label="Sumar taza defectuosa" (click)="ajustarDefecto('defectuosas', 'sumar')">+</button>
            </div>
          </div>
        </div>

        <div class="notes-panel">
          <div class="notes-panel__header">Notas adicionales</div>
          <textarea class="notes-panel__textarea" rows="4" [(ngModel)]="formulario.notas" placeholder="Observaciones..."></textarea>
        </div>
        <div class="sample-navigation">
          <button
            *ngIf="muestraActual() > 1"
            type="button"
            class="submit-btn sample-navigation__previous"
            (click)="irAMuestraAnterior()">
            \u2190 Anterior
          </button>
          <button type="button" class="submit-btn" (click)="irAMuestraSiguiente()" [disabled]="guardando()">
            {{ guardando() ? 'Guardando\u2026' : (muestraActual() === totalMuestras() ? 'Terminar cata' : 'Siguiente muestra \u2192') }}
          </button>
        </div>
      </aside>
    </div>
  </main>
</ion-content>
` }]
  }], null, null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(AffectiveFormPage, { className: "AffectiveFormPage", filePath: "src/app/pages/evaluation/affective-form/affective-form.page.ts", lineNumber: 33 });
})();
export {
  AffectiveFormPage
};
//# debugId=5c95887e-048d-59a3-8659-969962a56244
//# sourceMappingURL=affective-form.page-5KKYKHIB.js.map
