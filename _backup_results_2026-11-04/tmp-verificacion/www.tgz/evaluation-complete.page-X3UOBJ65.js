import {
  SesionService
} from "./chunk-KN5DCTIK.js";
import {
  checkmarkCircleOutline,
  lockClosedOutline
} from "./chunk-ISYXHPYK.js";
import {
  addIcons
} from "./chunk-4JFQPQWK.js";
import {
  AuthService
} from "./chunk-SYUCMH2K.js";
import {
  ActivatedRoute,
  CommonModule,
  Component,
  IonButton,
  IonContent,
  IonIcon,
  NavController,
  Router,
  inject,
  setClassMetadata,
  signal,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵconditional,
  ɵɵconditionalCreate,
  ɵɵdefineComponent,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵlistener,
  ɵɵnextContext,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵtext,
  ɵɵtextInterpolate
} from "./chunk-ELFI4Z7L.js";
import "./chunk-BMQUG2PJ.js";
import "./chunk-3OZZMUVI.js";
import "./chunk-3GAB7GSC.js";
import "./chunk-B7Y4FMY7.js";
import "./chunk-NQCL7WZ3.js";
import "./chunk-4BTEZGN2.js";
import "./chunk-XTVSKRH4.js";
import "./chunk-ETZFPO3Y.js";
import "./chunk-LLS636HS.js";
import "./chunk-KQQH3YTO.js";
import "./chunk-DI3VEDFV.js";
import "./chunk-PAXKX5KU.js";

// src/app/pages/session/evaluation-complete/evaluation-complete.page.ts
function EvaluationCompletePage_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p", 6);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx);
  }
}
function EvaluationCompletePage_Conditional_15_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 8)(1, "span", 9);
    \u0275\u0275text(2, "C\xF3digo");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "span", 10);
    \u0275\u0275text(4);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance(4);
    \u0275\u0275textInterpolate(ctx_r0.codigoSesion());
  }
}
function EvaluationCompletePage_Conditional_23_Template(rf, ctx) {
  if (rf & 1) {
    const _r2 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "ion-button", 15);
    \u0275\u0275listener("click", function EvaluationCompletePage_Conditional_23_Template_ion_button_click_0_listener() {
      \u0275\u0275restoreView(_r2);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.irAResultados());
    });
    \u0275\u0275text(1, " Ver resultados del panel \u2192 ");
    \u0275\u0275elementEnd();
  }
}
addIcons({ checkmarkCircleOutline, lockClosedOutline });
var _EvaluationCompletePage = class _EvaluationCompletePage {
  constructor() {
    this.route = inject(ActivatedRoute);
    this.router = inject(Router);
    this.navCtrl = inject(NavController);
    this.authService = inject(AuthService);
    this.sesionService = inject(SesionService);
    this.esOrganizador = signal(
      false,
      ...ngDevMode ? [{ debugName: "esOrganizador" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.nombreSesion = signal(
      "",
      ...ngDevMode ? [{ debugName: "nombreSesion" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.codigoSesion = signal(
      "",
      ...ngDevMode ? [{ debugName: "codigoSesion" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.error = signal(
      null,
      ...ngDevMode ? [{ debugName: "error" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.cargando = signal(
      true,
      ...ngDevMode ? [{ debugName: "cargando" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.sesionId = "";
  }
  async ngOnInit() {
    this.sesionId = this.route.snapshot.paramMap.get("id")?.trim() ?? "";
    if (!this.sesionId) {
      this.error.set("No se encontr\xF3 el ID de la sesi\xF3n.");
      this.cargando.set(false);
      return;
    }
    try {
      const { session } = await this.authService.getSession();
      const user = session?.user;
      if (!user) {
        await this.router.navigateByUrl("/login", { replaceUrl: true });
        return;
      }
      const sesion = await this.sesionService.obtenerSesionPorId(this.sesionId);
      if (!sesion)
        throw new Error("No se encontr\xF3 la sesi\xF3n.");
      this.nombreSesion.set(sesion.nombre);
      const esOrganizador = sesion.organizadorId === user.id;
      this.esOrganizador.set(esOrganizador);
      this.codigoSesion.set(esOrganizador ? sesion.codigoAcceso : "");
    } catch (error) {
      this.error.set(error instanceof Error ? error.message : "No se pudo cargar la sesi\xF3n.");
    } finally {
      this.cargando.set(false);
    }
  }
  async irAResultados() {
    if (!this.esOrganizador() || !this.sesionId)
      return;
    await this.router.navigateByUrl(`/session/${this.sesionId}/results`);
  }
  volverAlPanel() {
    void this.navCtrl.navigateRoot("/dashboard");
  }
};
_EvaluationCompletePage.\u0275fac = function EvaluationCompletePage_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _EvaluationCompletePage)();
};
_EvaluationCompletePage.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _EvaluationCompletePage, selectors: [["app-evaluation-complete"]], decls: 26, vars: 4, consts: [[1, "ion-padding", 2, "--background", "#F8FAFC"], [1, "complete-container"], [1, "icon-wrapper"], ["name", "checkmark-circle-outline"], [1, "title"], [1, "subtitle"], ["role", "alert", 1, "subtitle"], [1, "info-card"], [1, "info-row"], [1, "info-label"], [1, "info-value"], [1, "privacy-card"], ["name", "lock-closed-outline"], ["expand", "block", 1, "primary-btn"], ["expand", "block", "fill", "outline", 2, "--border-color", "#E2E8F0", "--color", "#0F172B", 3, "click"], ["expand", "block", 1, "primary-btn", 3, "click"]], template: function EvaluationCompletePage_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-content", 0)(1, "div", 1)(2, "div", 2);
    \u0275\u0275element(3, "ion-icon", 3);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "h1", 4);
    \u0275\u0275text(5, "Cata finalizada");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "p", 5);
    \u0275\u0275text(7, "Gracias por completar la sesi\xF3n. Consulta al organizador si necesitas confirmar el registro de tu evaluaci\xF3n.");
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(8, EvaluationCompletePage_Conditional_8_Template, 2, 1, "p", 6);
    \u0275\u0275elementStart(9, "div", 7)(10, "div", 8)(11, "span", 9);
    \u0275\u0275text(12, "Sesi\xF3n");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(13, "span", 10);
    \u0275\u0275text(14);
    \u0275\u0275elementEnd()();
    \u0275\u0275conditionalCreate(15, EvaluationCompletePage_Conditional_15_Template, 5, 1, "div", 8);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(16, "div", 11);
    \u0275\u0275element(17, "ion-icon", 12);
    \u0275\u0275elementStart(18, "div")(19, "h4");
    \u0275\u0275text(20, "Los resultados permanecen reservados");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(21, "p");
    \u0275\u0275text(22, "Para proteger la evaluaci\xF3n ciega, los catadores no tienen acceso a los puntajes hasta que el organizador consolide el panel.");
    \u0275\u0275elementEnd()()();
    \u0275\u0275conditionalCreate(23, EvaluationCompletePage_Conditional_23_Template, 2, 0, "ion-button", 13);
    \u0275\u0275elementStart(24, "ion-button", 14);
    \u0275\u0275listener("click", function EvaluationCompletePage_Template_ion_button_click_24_listener() {
      return ctx.volverAlPanel();
    });
    \u0275\u0275text(25, " Volver al panel principal ");
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    let tmp_0_0;
    \u0275\u0275advance(8);
    \u0275\u0275conditional((tmp_0_0 = ctx.error()) ? 8 : -1, tmp_0_0);
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate(ctx.nombreSesion());
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx.esOrganizador() && ctx.codigoSesion() ? 15 : -1);
    \u0275\u0275advance(8);
    \u0275\u0275conditional(ctx.esOrganizador() ? 23 : -1);
  }
}, dependencies: [CommonModule, IonContent, IonIcon, IonButton], styles: ["\n.complete-container[_ngcontent-%COMP%] {\n  max-width: 500px;\n  margin: 0 auto;\n  padding-top: 40px;\n  text-align: center;\n}\n.icon-wrapper[_ngcontent-%COMP%] {\n  width: 64px;\n  height: 64px;\n  background: #F1F5F9;\n  border-radius: 50%;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  margin: 0 auto 16px;\n}\n.icon-wrapper[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 32px;\n  color: #2F3E46;\n}\n.title[_ngcontent-%COMP%] {\n  font-size: 22px;\n  font-weight: 700;\n  color: #0F172B;\n  margin-bottom: 8px;\n}\n.subtitle[_ngcontent-%COMP%] {\n  font-size: 14px;\n  color: #62748E;\n  margin-bottom: 24px;\n  line-height: 1.5;\n}\n.info-card[_ngcontent-%COMP%] {\n  background: #FFFFFF;\n  border: 1px solid #E2E8F0;\n  border-radius: 12px;\n  padding: 16px;\n  margin-bottom: 16px;\n  text-align: left;\n}\n.info-row[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  margin-bottom: 8px;\n  font-size: 13px;\n}\n.info-row[_ngcontent-%COMP%]:last-child {\n  margin-bottom: 0;\n}\n.info-label[_ngcontent-%COMP%] {\n  color: #62748E;\n}\n.info-value[_ngcontent-%COMP%] {\n  font-weight: 600;\n  color: #0F172B;\n}\n.privacy-card[_ngcontent-%COMP%] {\n  background: #FFFFFF;\n  border: 1px solid #E2E8F0;\n  border-radius: 12px;\n  padding: 16px;\n  display: flex;\n  gap: 12px;\n  text-align: left;\n  margin-bottom: 24px;\n}\n.privacy-card[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 20px;\n  color: #2F3E46;\n  flex-shrink: 0;\n}\n.privacy-card[_ngcontent-%COMP%]   h4[_ngcontent-%COMP%] {\n  margin: 0 0 4px;\n  font-size: 13px;\n  font-weight: 700;\n  color: #0F172B;\n}\n.privacy-card[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 11px;\n  color: #62748E;\n  line-height: 1.4;\n}\n.primary-btn[_ngcontent-%COMP%] {\n  --%NS%background: #2F3E46;\n  --%NS%color: #FFF;\n  --%NS%border-radius: 8px;\n  height: 48px;\n  font-weight: 600;\n  text-transform: none;\n  margin-bottom: 12px;\n}\n/*# sourceMappingURL=evaluation-complete.page.css.map */"] });
var EvaluationCompletePage = _EvaluationCompletePage;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(EvaluationCompletePage, [{
    type: Component,
    args: [{ selector: "app-evaluation-complete", standalone: true, imports: [CommonModule, IonContent, IonIcon, IonButton], template: '<ion-content class="ion-padding" style="--background: #F8FAFC;">\n  <div class="complete-container">\n\n    <div class="icon-wrapper">\n      <ion-icon name="checkmark-circle-outline"></ion-icon>\n    </div>\n\n    <h1 class="title">Cata finalizada</h1>\n    <p class="subtitle">Gracias por completar la sesi\xF3n. Consulta al organizador si necesitas confirmar el registro de tu evaluaci\xF3n.</p>\n\n    @if (error(); as mensaje) {\n      <p class="subtitle" role="alert">{{ mensaje }}</p>\n    }\n\n    <div class="info-card">\n      <div class="info-row">\n        <span class="info-label">Sesi\xF3n</span>\n        <span class="info-value">{{ nombreSesion() }}</span>\n      </div>\n      @if (esOrganizador() && codigoSesion()) {\n        <div class="info-row">\n          <span class="info-label">C\xF3digo</span>\n          <span class="info-value">{{ codigoSesion() }}</span>\n        </div>\n      }\n    </div>\n\n    <div class="privacy-card">\n      <ion-icon name="lock-closed-outline"></ion-icon>\n      <div>\n        <h4>Los resultados permanecen reservados</h4>\n        <p>Para proteger la evaluaci\xF3n ciega, los catadores no tienen acceso a los puntajes hasta que el organizador consolide el panel.</p>\n      </div>\n    </div>\n\n    @if (esOrganizador()) {\n      <ion-button expand="block" class="primary-btn" (click)="irAResultados()">\n        Ver resultados del panel \u2192\n      </ion-button>\n    }\n\n    <ion-button expand="block" fill="outline" style="--border-color: #E2E8F0; --color: #0F172B;" (click)="volverAlPanel()">\n      Volver al panel principal\n    </ion-button>\n\n  </div>\n</ion-content>', styles: ["/* src/app/pages/session/evaluation-complete/evaluation-complete.page.scss */\n.complete-container {\n  max-width: 500px;\n  margin: 0 auto;\n  padding-top: 40px;\n  text-align: center;\n}\n.icon-wrapper {\n  width: 64px;\n  height: 64px;\n  background: #F1F5F9;\n  border-radius: 50%;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  margin: 0 auto 16px;\n}\n.icon-wrapper ion-icon {\n  font-size: 32px;\n  color: #2F3E46;\n}\n.title {\n  font-size: 22px;\n  font-weight: 700;\n  color: #0F172B;\n  margin-bottom: 8px;\n}\n.subtitle {\n  font-size: 14px;\n  color: #62748E;\n  margin-bottom: 24px;\n  line-height: 1.5;\n}\n.info-card {\n  background: #FFFFFF;\n  border: 1px solid #E2E8F0;\n  border-radius: 12px;\n  padding: 16px;\n  margin-bottom: 16px;\n  text-align: left;\n}\n.info-row {\n  display: flex;\n  justify-content: space-between;\n  margin-bottom: 8px;\n  font-size: 13px;\n}\n.info-row:last-child {\n  margin-bottom: 0;\n}\n.info-label {\n  color: #62748E;\n}\n.info-value {\n  font-weight: 600;\n  color: #0F172B;\n}\n.privacy-card {\n  background: #FFFFFF;\n  border: 1px solid #E2E8F0;\n  border-radius: 12px;\n  padding: 16px;\n  display: flex;\n  gap: 12px;\n  text-align: left;\n  margin-bottom: 24px;\n}\n.privacy-card ion-icon {\n  font-size: 20px;\n  color: #2F3E46;\n  flex-shrink: 0;\n}\n.privacy-card h4 {\n  margin: 0 0 4px;\n  font-size: 13px;\n  font-weight: 700;\n  color: #0F172B;\n}\n.privacy-card p {\n  margin: 0;\n  font-size: 11px;\n  color: #62748E;\n  line-height: 1.4;\n}\n.primary-btn {\n  --background: #2F3E46;\n  --color: #FFF;\n  --border-radius: 8px;\n  height: 48px;\n  font-weight: 600;\n  text-transform: none;\n  margin-bottom: 12px;\n}\n/*# sourceMappingURL=evaluation-complete.page.css.map */\n"] }]
  }], null, null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(EvaluationCompletePage, { className: "EvaluationCompletePage", filePath: "src/app/pages/session/evaluation-complete/evaluation-complete.page.ts", lineNumber: 24 });
})();
export {
  EvaluationCompletePage
};
//# debugId=2b546e75-6b85-5c79-ade4-fe757961eae5
//# sourceMappingURL=evaluation-complete.page-X3UOBJ65.js.map
