import {
  SesionService
} from "./chunk-KN5DCTIK.js";
import {
  AuthService
} from "./chunk-SYUCMH2K.js";
import {
  Injectable,
  REALTIME_SUBSCRIBE_STATES,
  Subject,
  SupabaseService,
  effect,
  inject,
  setClassMetadata,
  signal,
  ɵɵdefineInjectable
} from "./chunk-ELFI4Z7L.js";
import {
  __objRest,
  __spreadProps,
  __spreadValues
} from "./chunk-PAXKX5KU.js";

// src/app/core/services/realtime.ts
var GRACE_PERIOD_MS = 45e3;
var RETARDO_CIERRE_CANAL_MS = 1500;
var RETARDO_RESYNC_MS = 400;
var EVENTOS_BROADCAST = [
  "LISTO",
  "INICIAR_CATA",
  "CAMBIAR_MUESTRA",
  "MUESTRA_CERRADA",
  "SESION_FINALIZADA",
  "PARTICIPANTE_RETIRADO",
  "EVALUACION_ENVIADA"
];
var SalaRealtime = class {
  constructor(cliente, sesionService, opciones) {
    this.cliente = cliente;
    this.sesionService = sesionService;
    this.opciones = opciones;
    this._presencia = signal(
      /* @__PURE__ */ new Map(),
      ...ngDevMode ? [{ debugName: "_presencia" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this._estadoConexion = signal(
      "conectando",
      ...ngDevMode ? [{ debugName: "_estadoConexion" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.eventosSubject = new Subject();
    this.presencia = this._presencia.asReadonly();
    this.estadoConexion = this._estadoConexion.asReadonly();
    this.eventos$ = this.eventosSubject.asObservable();
    this.canal = null;
    this.cerrada = false;
    this.huboDesconexion = false;
    this.temporizadoresGracia = /* @__PURE__ */ new Map();
    this.alPerderRed = () => {
      if (!this.cerrada)
        this._estadoConexion.set("reconectando");
    };
    this.alRecuperarRed = () => {
      if (!this.cerrada)
        this.emitir({ tipo: "RESYNC", motivo: "red_restaurada" });
    };
    this.gracePeriodMs = opciones.gracePeriodMs ?? GRACE_PERIOD_MS;
  }
  get sesionId() {
    return this.opciones.sesionId;
  }
  async conectar() {
    window.addEventListener("offline", this.alPerderRed);
    window.addEventListener("online", this.alRecuperarRed);
    try {
      await this.cliente.realtime.setAuth();
    } catch (error) {
      console.warn("[Realtime] No se pudo propagar el token al socket:", error);
    }
    if (this.cerrada)
      return;
    const { sesionId, usuarioId } = this.opciones;
    const canal = this.cliente.channel(`sesion:${sesionId}`, {
      config: {
        private: true,
        broadcast: { self: false, ack: true },
        presence: { key: usuarioId, enabled: true }
      }
    });
    canal.on("presence", { event: "sync" }, () => this.procesarPresencia());
    for (const evento of EVENTOS_BROADCAST) {
      canal.on("broadcast", { event: evento }, (mensaje) => {
        const parseado = this.parsearBroadcast(evento, mensaje["payload"]);
        if (parseado)
          this.emitir(parseado);
      });
    }
    canal.on("postgres_changes", { event: "*", schema: "public", table: "participantes", filter: `sesion_id=eq.${sesionId}` }, () => this.programarResync());
    canal.on("postgres_changes", { event: "UPDATE", schema: "public", table: "sesiones", filter: `id=eq.${sesionId}` }, () => this.programarResync());
    this.canal = canal;
    canal.subscribe((estado, error) => {
      if (this.cerrada)
        return;
      switch (estado) {
        case REALTIME_SUBSCRIBE_STATES.SUBSCRIBED:
          this._estadoConexion.set("conectado");
          void this.anunciarPresencia();
          if (this.huboDesconexion) {
            this.huboDesconexion = false;
            this.emitir({ tipo: "RESYNC", motivo: "reconexion" });
          }
          break;
        case REALTIME_SUBSCRIBE_STATES.CHANNEL_ERROR:
        case REALTIME_SUBSCRIBE_STATES.TIMED_OUT:
          console.warn(`[Realtime] Canal sesion:${sesionId} \u2192 ${estado}`, error);
          this.huboDesconexion = true;
          this._estadoConexion.set("reconectando");
          break;
        case REALTIME_SUBSCRIBE_STATES.CLOSED:
          this.huboDesconexion = true;
          this._estadoConexion.set("desconectado");
          break;
      }
    });
  }
  /** Envía un evento efímero. Devuelve true si el servidor lo confirmó. */
  async enviar(evento) {
    if (!this.canal || this.cerrada)
      return false;
    const _a = evento, { tipo } = _a, payload = __objRest(_a, ["tipo"]);
    try {
      if (this._estadoConexion() === "conectado") {
        const respuesta2 = await this.canal.send({ type: "broadcast", event: tipo, payload });
        return respuesta2 === "ok";
      }
      const respuesta = await this.canal.httpSend(tipo, payload);
      return respuesta.success;
    } catch (error) {
      console.warn(`[Realtime] No se pudo enviar ${tipo}:`, error);
      return false;
    }
  }
  async cerrar() {
    if (this.cerrada)
      return;
    this.cerrada = true;
    window.removeEventListener("offline", this.alPerderRed);
    window.removeEventListener("online", this.alRecuperarRed);
    clearTimeout(this.temporizadorResync);
    for (const temporizador of this.temporizadoresGracia.values())
      clearTimeout(temporizador);
    this.temporizadoresGracia.clear();
    const canal = this.canal;
    this.canal = null;
    if (canal) {
      try {
        await canal.untrack();
      } catch {
      }
      await this.cliente.removeChannel(canal);
    }
    this._presencia.set(/* @__PURE__ */ new Map());
    this._estadoConexion.set("desconectado");
    this.eventosSubject.complete();
  }
  async anunciarPresencia() {
    if (!this.canal)
      return;
    const payload = {
      usuarioId: this.opciones.usuarioId,
      nombre: this.opciones.nombre,
      rol: this.opciones.rol,
      conectadoEn: (/* @__PURE__ */ new Date()).toISOString()
    };
    const respuesta = await this.canal.track(payload);
    if (respuesta !== "ok")
      console.warn("[Realtime] track() respondi\xF3:", respuesta);
  }
  /**
   * Se usa solo el evento 'sync' (estado consolidado) en vez de join/leave:
   * con varias pestañas del mismo usuario, un 'leave' de una pestaña no
   * significa que el usuario se haya ido.
   */
  procesarPresencia() {
    if (!this.canal)
      return;
    const estado = this.canal.presenceState();
    const ahora = Date.now();
    const siguiente = new Map(this._presencia());
    for (const [clave, metas] of Object.entries(estado)) {
      const meta = metas[0];
      if (!meta)
        continue;
      this.cancelarGracia(clave);
      const previo = siguiente.get(clave);
      siguiente.set(clave, {
        usuarioId: clave,
        nombre: typeof meta.nombre === "string" && meta.nombre ? meta.nombre : previo?.nombre ?? "Catador",
        rol: meta.rol === "organizador" ? "organizador" : "catador",
        estado: "en_linea",
        desde: previo?.estado === "en_linea" ? previo.desde : ahora
      });
    }
    for (const [clave, previo] of siguiente) {
      if (clave in estado || clave === this.opciones.usuarioId)
        continue;
      if (previo.estado === "en_linea") {
        siguiente.set(clave, __spreadProps(__spreadValues({}, previo), { estado: "inestable", desde: ahora }));
        this.iniciarGracia(clave);
      }
    }
    this._presencia.set(siguiente);
  }
  iniciarGracia(usuarioId) {
    if (this.temporizadoresGracia.has(usuarioId))
      return;
    const temporizador = setTimeout(() => {
      this.temporizadoresGracia.delete(usuarioId);
      void this.vencerGracia(usuarioId);
    }, this.gracePeriodMs);
    this.temporizadoresGracia.set(usuarioId, temporizador);
  }
  cancelarGracia(usuarioId) {
    const temporizador = this.temporizadoresGracia.get(usuarioId);
    if (temporizador) {
      clearTimeout(temporizador);
      this.temporizadoresGracia.delete(usuarioId);
    }
  }
  async vencerGracia(usuarioId) {
    if (this.cerrada)
      return;
    const actual = this._presencia().get(usuarioId);
    if (!actual || actual.estado !== "inestable")
      return;
    const siguiente = new Map(this._presencia());
    siguiente.delete(usuarioId);
    this._presencia.set(siguiente);
    if (this.opciones.rol !== "organizador" || actual.rol === "organizador")
      return;
    try {
      await this.sesionService.abandonarSesion(this.opciones.sesionId, usuarioId);
      this.emitir({ tipo: "PARTICIPANTE_RETIRADO", usuarioId });
      await this.enviar({ tipo: "PARTICIPANTE_RETIRADO", usuarioId });
    } catch (error) {
      console.warn(`[Realtime] No se retir\xF3 a ${usuarioId} tras el Grace Period:`, error);
    }
  }
  programarResync() {
    clearTimeout(this.temporizadorResync);
    this.temporizadorResync = setTimeout(() => {
      this.emitir({ tipo: "RESYNC", motivo: "cambio_bd" });
    }, RETARDO_RESYNC_MS);
  }
  emitir(evento) {
    if (!this.cerrada)
      this.eventosSubject.next(evento);
  }
  parsearBroadcast(tipo, payload) {
    const datos = typeof payload === "object" && payload !== null ? payload : {};
    const texto = (clave) => typeof datos[clave] === "string" ? datos[clave] : "";
    const entero = (clave) => {
      const valor = Number(datos[clave]);
      return Number.isInteger(valor) && valor >= 1 ? valor : null;
    };
    switch (tipo) {
      case "LISTO":
        return texto("usuarioId") ? { tipo, usuarioId: texto("usuarioId"), listo: datos["listo"] === true } : null;
      case "INICIAR_CATA":
      case "SESION_FINALIZADA":
        return { tipo };
      case "CAMBIAR_MUESTRA":
      case "MUESTRA_CERRADA": {
        const numeroMuestra = entero("numeroMuestra");
        return numeroMuestra ? { tipo, numeroMuestra } : null;
      }
      case "PARTICIPANTE_RETIRADO":
        return texto("usuarioId") ? { tipo, usuarioId: texto("usuarioId") } : null;
      case "EVALUACION_ENVIADA": {
        const numeroMuestra = entero("numeroMuestra");
        return texto("usuarioId") && numeroMuestra ? { tipo, usuarioId: texto("usuarioId"), numeroMuestra } : null;
      }
    }
  }
};
var _RealtimeService = class _RealtimeService {
  constructor() {
    this.supabase = inject(SupabaseService);
    this.sesionService = inject(SesionService);
    this.authService = inject(AuthService);
    this.salas = /* @__PURE__ */ new Map();
    effect(() => {
      if (!this.authService.usuario() && this.salas.size > 0)
        void this.cerrarTodas();
    });
  }
  abrirSala(opciones) {
    const existente = this.salas.get(opciones.sesionId);
    if (existente && existente.sala.opciones.usuarioId === opciones.usuarioId) {
      clearTimeout(existente.cierrePendiente);
      existente.cierrePendiente = void 0;
      existente.consumidores++;
      return existente.sala;
    }
    if (existente) {
      clearTimeout(existente.cierrePendiente);
      void existente.sala.cerrar();
      this.salas.delete(opciones.sesionId);
    }
    const sala = new SalaRealtime(this.supabase.client, this.sesionService, opciones);
    this.salas.set(opciones.sesionId, { sala, consumidores: 1 });
    void sala.conectar();
    return sala;
  }
  liberarSala(sala) {
    const registro = this.salas.get(sala.sesionId);
    if (!registro || registro.sala !== sala)
      return;
    registro.consumidores = Math.max(0, registro.consumidores - 1);
    if (registro.consumidores > 0 || registro.cierrePendiente)
      return;
    registro.cierrePendiente = setTimeout(() => {
      if (registro.consumidores === 0 && this.salas.get(sala.sesionId) === registro) {
        this.salas.delete(sala.sesionId);
        void sala.cerrar();
      }
    }, RETARDO_CIERRE_CANAL_MS);
  }
  /** Cierra todas las salas (p. ej. al cerrar sesión). */
  async cerrarTodas() {
    const registros = [...this.salas.values()];
    this.salas.clear();
    await Promise.all(registros.map((registro) => {
      clearTimeout(registro.cierrePendiente);
      return registro.sala.cerrar();
    }));
  }
};
_RealtimeService.\u0275fac = function RealtimeService_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _RealtimeService)();
};
_RealtimeService.\u0275prov = /* @__PURE__ */ \u0275\u0275defineInjectable({ token: _RealtimeService, factory: _RealtimeService.\u0275fac, providedIn: "root" });
var RealtimeService = _RealtimeService;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(RealtimeService, [{
    type: Injectable,
    args: [{ providedIn: "root" }]
  }], () => [], null);
})();

export {
  GRACE_PERIOD_MS,
  RealtimeService
};
//# debugId=a0065a47-1cc6-5152-abe8-823199d53535
//# sourceMappingURL=chunk-7SA6TBRT.js.map
