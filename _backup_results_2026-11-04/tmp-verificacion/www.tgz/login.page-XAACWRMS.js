import {
  mensajeDeError
} from "./chunk-OFWJO6PD.js";
import {
  AuthService
} from "./chunk-SYUCMH2K.js";
import {
  ActivatedRoute,
  CommonModule,
  Component,
  FormsModule,
  IonButton,
  IonContent,
  IonInput,
  IonSpinner,
  NgControlStatus,
  NgControlStatusGroup,
  NgForm,
  NgModel,
  RequiredValidator,
  Router,
  RouterLink,
  ToastController,
  inject,
  setClassMetadata,
  signal,
  ɵNgNoValidate,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵconditional,
  ɵɵconditionalCreate,
  ɵɵcontrol,
  ɵɵcontrolCreate,
  ɵɵdefineComponent,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵlistener,
  ɵɵnextContext,
  ɵɵproperty,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵtext,
  ɵɵtwoWayBindingSet,
  ɵɵtwoWayListener,
  ɵɵtwoWayProperty
} from "./chunk-ELFI4Z7L.js";
import "./chunk-BMQUG2PJ.js";
import "./chunk-3OZZMUVI.js";
import "./chunk-3GAB7GSC.js";
import "./chunk-B7Y4FMY7.js";
import "./chunk-NQCL7WZ3.js";
import "./chunk-4BTEZGN2.js";
import "./chunk-XTVSKRH4.js";
import "./chunk-ETZFPO3Y.js";
import "./chunk-LLS636HS.js";
import "./chunk-KQQH3YTO.js";
import "./chunk-DI3VEDFV.js";
import "./chunk-PAXKX5KU.js";

// src/app/pages/auth/login/login.page.ts
function LoginPage_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 6);
    \u0275\u0275element(1, "ion-spinner", 8);
    \u0275\u0275elementEnd();
  }
}
function LoginPage_Conditional_9_Conditional_10_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-spinner", 8);
  }
}
function LoginPage_Conditional_9_Conditional_11_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span");
    \u0275\u0275text(1, "Iniciar sesi\xF3n");
    \u0275\u0275elementEnd();
  }
}
function LoginPage_Conditional_9_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "form", 9);
    \u0275\u0275listener("ngSubmit", function LoginPage_Conditional_9_Template_form_ngSubmit_0_listener() {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r1.login());
    });
    \u0275\u0275elementStart(1, "div", 10)(2, "label", 11);
    \u0275\u0275text(3, "Usuario");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "ion-input", 12);
    \u0275\u0275twoWayListener("ngModelChange", function LoginPage_Conditional_9_Template_ion_input_ngModelChange_4_listener($event) {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.email, $event) || (ctx_r1.email = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd();
    \u0275\u0275controlCreate();
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "div", 10)(6, "label", 13);
    \u0275\u0275text(7, "Contrase\xF1a");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "ion-input", 14);
    \u0275\u0275twoWayListener("ngModelChange", function LoginPage_Conditional_9_Template_ion_input_ngModelChange_8_listener($event) {
      \u0275\u0275restoreView(_r1);
      const ctx_r1 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r1.password, $event) || (ctx_r1.password = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd();
    \u0275\u0275controlCreate();
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(9, "ion-button", 15);
    \u0275\u0275conditionalCreate(10, LoginPage_Conditional_9_Conditional_10_Template, 1, 0, "ion-spinner", 8)(11, LoginPage_Conditional_9_Conditional_11_Template, 2, 0, "span");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(12, "p", 16);
    \u0275\u0275text(13, " \xBFNo tienes cuenta? ");
    \u0275\u0275elementStart(14, "a", 17);
    \u0275\u0275text(15, "Reg\xEDstrate");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r1 = \u0275\u0275nextContext();
    \u0275\u0275advance(4);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.email);
    \u0275\u0275control();
    \u0275\u0275advance(4);
    \u0275\u0275twoWayProperty("ngModel", ctx_r1.password);
    \u0275\u0275control();
    \u0275\u0275advance();
    \u0275\u0275property("disabled", ctx_r1.isLoading());
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r1.isLoading() ? 10 : 11);
  }
}
var _LoginPage = class _LoginPage {
  constructor() {
    this.email = "";
    this.password = "";
    this.isLoading = signal(
      false,
      ...ngDevMode ? [{ debugName: "isLoading" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.verificandoSesion = signal(
      true,
      ...ngDevMode ? [{ debugName: "verificandoSesion" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.authService = inject(AuthService);
    this.router = inject(Router);
    this.route = inject(ActivatedRoute);
    this.toastController = inject(ToastController);
  }
  ngOnInit() {
    const authError = this.route.snapshot.queryParamMap.get("authError");
    if (authError === "role") {
      void this.mostrarToast("No se pudo verificar tu rol. Intenta de nuevo o contacta al administrador.");
    } else if (authError === "session") {
      void this.mostrarToast("No se pudo validar la sesi\xF3n. Inicia sesi\xF3n nuevamente.");
    }
    void this.redirigirSiYaAutenticado(authError === null);
  }
  async login() {
    if (this.isLoading())
      return;
    if (!this.email.trim() || !this.password) {
      await this.mostrarToast("Ingresa tu correo y contrase\xF1a.");
      return;
    }
    this.isLoading.set(true);
    try {
      const rol = await this.authService.login(this.email, this.password);
      const returnUrl = this.route.snapshot.queryParamMap.get("returnUrl");
      const esRutaInterna = !!returnUrl && returnUrl.startsWith("/") && !returnUrl.startsWith("//");
      const destino = rol === "catador" && esRutaInterna ? returnUrl : this.authService.rutaInicioPorRol(rol);
      this.password = "";
      await this.router.navigateByUrl(destino, { replaceUrl: true });
    } catch (error) {
      await this.mostrarToast(this.traducirError(error));
    } finally {
      this.isLoading.set(false);
    }
  }
  async irARegistro() {
    await this.router.navigateByUrl("/registro");
  }
  /** Con sesión válida, /login no se muestra: se va directo al panel del rol. */
  async redirigirSiYaAutenticado(permitido) {
    try {
      if (!permitido)
        return;
      const destino = await this.authService.obtenerRutaInicio();
      if (destino && destino !== "/login") {
        await this.router.navigateByUrl(destino, { replaceUrl: true });
      }
    } catch {
    } finally {
      this.verificandoSesion.set(false);
    }
  }
  traducirError(error) {
    const mensaje = mensajeDeError(error, "Error al iniciar sesi\xF3n.");
    if (/invalid login credentials/i.test(mensaje))
      return "Correo o contrase\xF1a incorrectos.";
    if (/email not confirmed/i.test(mensaje))
      return "Confirma tu correo antes de iniciar sesi\xF3n.";
    if (/failed to fetch|network/i.test(mensaje))
      return "Sin conexi\xF3n. Revisa tu red e intenta de nuevo.";
    return mensaje;
  }
  async mostrarToast(message) {
    const toast = await this.toastController.create({
      message,
      duration: 3e3,
      position: "bottom",
      color: "danger"
    });
    await toast.present();
  }
};
_LoginPage.\u0275fac = function LoginPage_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _LoginPage)();
};
_LoginPage.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _LoginPage, selectors: [["app-login"]], decls: 12, vars: 1, consts: [[1, "ion-padding", "login-content"], [1, "login-container"], [1, "logo-box"], ["src", "assets/icon/logopacamara.png", "alt", "Logo de Pacamara"], [1, "title"], [1, "subtitle"], ["role", "status", 1, "session-check"], [1, "login-footer"], ["name", "crescent"], [1, "login-form", 3, "ngSubmit"], [1, "form-group"], ["for", "login-email", 1, "field-label"], ["id", "login-email", "name", "email", "aria-label", "Correo electr\xF3nico", "placeholder", "nombre@lab.com", "type", "email", "autocomplete", "email", "inputmode", "email", "fill", "outline", "required", "", 1, "custom-input", 3, "ngModelChange", "ngModel"], ["for", "login-password", 1, "field-label"], ["id", "login-password", "name", "password", "aria-label", "Contrase\xF1a", "placeholder", "\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022", "type", "password", "autocomplete", "current-password", "fill", "outline", "required", "", 1, "custom-input", 3, "ngModelChange", "ngModel"], ["expand", "block", "type", "submit", 1, "btn-login", 3, "disabled"], [1, "register-link"], ["routerLink", "/registro"]], template: function LoginPage_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-content", 0)(1, "main", 1)(2, "div", 2);
    \u0275\u0275element(3, "img", 3);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(4, "h1", 4);
    \u0275\u0275text(5, "PacamaraSQ");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(6, "p", 5);
    \u0275\u0275text(7, "Sistema de Evaluaci\xF3n CVA \xB7 SCA");
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(8, LoginPage_Conditional_8_Template, 2, 0, "div", 6)(9, LoginPage_Conditional_9_Template, 16, 4);
    \u0275\u0275elementStart(10, "p", 7);
    \u0275\u0275text(11, "Plataforma profesional para paneles de cataci\xF3n de caf\xE9 de especialidad");
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    \u0275\u0275advance(8);
    \u0275\u0275conditional(ctx.verificandoSesion() ? 8 : 9);
  }
}, dependencies: [IonContent, IonInput, IonButton, IonSpinner, CommonModule, FormsModule, \u0275NgNoValidate, NgControlStatus, NgControlStatusGroup, RequiredValidator, NgModel, NgForm, RouterLink], styles: ["\n[_nghost-%COMP%] {\n  display: block;\n}\n.login-content[_ngcontent-%COMP%] {\n  --%NS%background: var(--%NS%app-bg-screen);\n}\n.login-container[_ngcontent-%COMP%] {\n  width: min(100%, 420px);\n  min-height: 100%;\n  margin: 0 auto;\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n  padding: 32px 8px;\n}\n.logo-box[_ngcontent-%COMP%] {\n  display: grid;\n  width: 68px;\n  height: 68px;\n  place-items: center;\n  margin: 0 auto 12px;\n  border-radius: 20px;\n  background: var(--%NS%app-primary-dark);\n  overflow: hidden;\n}\n.logo-box[_ngcontent-%COMP%]   img[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 100%;\n  object-fit: cover;\n}\n.title[_ngcontent-%COMP%], \n.subtitle[_ngcontent-%COMP%] {\n  text-align: center;\n}\n.title[_ngcontent-%COMP%] {\n  margin: 0;\n  color: var(--%NS%app-text-main);\n  font-size: 28px;\n}\n.subtitle[_ngcontent-%COMP%] {\n  margin: 8px 0 32px;\n  color: var(--%NS%app-text-muted);\n}\n.login-form[_ngcontent-%COMP%] {\n  display: grid;\n  gap: 18px;\n}\n.form-group[_ngcontent-%COMP%] {\n  display: grid;\n  gap: 8px;\n}\n.register-link[_ngcontent-%COMP%] {\n  margin-top: 24px;\n  color: var(--%NS%app-text-muted);\n  text-align: center;\n}\n.register-link[_ngcontent-%COMP%]   a[_ngcontent-%COMP%] {\n  color: var(--%NS%app-primary-dark);\n  font-weight: 600;\n}\n.field-label[_ngcontent-%COMP%] {\n  color: var(--%NS%app-text-muted);\n  font-size: 11px;\n  font-weight: 600;\n  letter-spacing: 0.06em;\n  text-transform: uppercase;\n}\n.session-check[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: center;\n  padding: 24px 0;\n}\n.login-footer[_ngcontent-%COMP%] {\n  margin: 32px auto 0;\n  max-width: 260px;\n  color: var(--%NS%app-text-faint);\n  font-size: 11px;\n  line-height: 1.5;\n  text-align: center;\n}\n/*# sourceMappingURL=login.page.css.map */"] });
var LoginPage = _LoginPage;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(LoginPage, [{
    type: Component,
    args: [{ selector: "app-login", standalone: true, imports: [IonContent, IonInput, IonButton, IonSpinner, CommonModule, FormsModule, RouterLink], template: '<ion-content class="ion-padding login-content">\n  <main class="login-container">\n    <div class="logo-box">\n      <img src="assets/icon/logopacamara.png" alt="Logo de Pacamara">\n    </div>\n    <h1 class="title">PacamaraSQ</h1>\n    <p class="subtitle">Sistema de Evaluaci\xF3n CVA \xB7 SCA</p>\n\n    @if (verificandoSesion()) {\n      <div class="session-check" role="status">\n        <ion-spinner name="crescent"></ion-spinner>\n      </div>\n    } @else {\n      <form class="login-form" (ngSubmit)="login()">\n        <div class="form-group">\n          <label class="field-label" for="login-email">Usuario</label>\n          <ion-input\n            id="login-email"\n            [(ngModel)]="email"\n            name="email"\n            aria-label="Correo electr\xF3nico"\n            placeholder="nombre@lab.com"\n            type="email"\n            autocomplete="email"\n            inputmode="email"\n            fill="outline"\n            class="custom-input"\n            required\n          ></ion-input>\n        </div>\n\n        <div class="form-group">\n          <label class="field-label" for="login-password">Contrase\xF1a</label>\n          <ion-input\n            id="login-password"\n            [(ngModel)]="password"\n            name="password"\n            aria-label="Contrase\xF1a"\n            placeholder="\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022"\n            type="password"\n            autocomplete="current-password"\n            fill="outline"\n            class="custom-input"\n            required\n          ></ion-input>\n        </div>\n\n        <ion-button expand="block" type="submit" class="btn-login" [disabled]="isLoading()">\n          @if (isLoading()) {\n            <ion-spinner name="crescent"></ion-spinner>\n          } @else {\n            <span>Iniciar sesi\xF3n</span>\n          }\n        </ion-button>\n      </form>\n\n      <p class="register-link">\n        \xBFNo tienes cuenta?\n        <a routerLink="/registro">Reg\xEDstrate</a>\n      </p>\n    }\n\n    <p class="login-footer">Plataforma profesional para paneles de cataci\xF3n de caf\xE9 de especialidad</p>\n  </main>\n</ion-content>\n', styles: ["/* src/app/pages/auth/login/login.page.scss */\n:host {\n  display: block;\n}\n.login-content {\n  --background: var(--app-bg-screen);\n}\n.login-container {\n  width: min(100%, 420px);\n  min-height: 100%;\n  margin: 0 auto;\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n  padding: 32px 8px;\n}\n.logo-box {\n  display: grid;\n  width: 68px;\n  height: 68px;\n  place-items: center;\n  margin: 0 auto 12px;\n  border-radius: 20px;\n  background: var(--app-primary-dark);\n  overflow: hidden;\n}\n.logo-box img {\n  width: 100%;\n  height: 100%;\n  object-fit: cover;\n}\n.title,\n.subtitle {\n  text-align: center;\n}\n.title {\n  margin: 0;\n  color: var(--app-text-main);\n  font-size: 28px;\n}\n.subtitle {\n  margin: 8px 0 32px;\n  color: var(--app-text-muted);\n}\n.login-form {\n  display: grid;\n  gap: 18px;\n}\n.form-group {\n  display: grid;\n  gap: 8px;\n}\n.register-link {\n  margin-top: 24px;\n  color: var(--app-text-muted);\n  text-align: center;\n}\n.register-link a {\n  color: var(--app-primary-dark);\n  font-weight: 600;\n}\n.field-label {\n  color: var(--app-text-muted);\n  font-size: 11px;\n  font-weight: 600;\n  letter-spacing: 0.06em;\n  text-transform: uppercase;\n}\n.session-check {\n  display: flex;\n  justify-content: center;\n  padding: 24px 0;\n}\n.login-footer {\n  margin: 32px auto 0;\n  max-width: 260px;\n  color: var(--app-text-faint);\n  font-size: 11px;\n  line-height: 1.5;\n  text-align: center;\n}\n/*# sourceMappingURL=login.page.css.map */\n"] }]
  }], null, null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(LoginPage, { className: "LoginPage", filePath: "src/app/pages/auth/login/login.page.ts", lineNumber: 16 });
})();
export {
  LoginPage
};
//# debugId=85bf3cf1-ea09-561e-a0be-249a3f079416
//# sourceMappingURL=login.page-XAACWRMS.js.map
