import {
  AuthService
} from "./chunk-SYUCMH2K.js";
import {
  Component,
  IonButton,
  IonContent,
  IonHeader,
  IonTitle,
  IonToolbar,
  Router,
  ToastController,
  inject,
  setClassMetadata,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵdefineComponent,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵlistener,
  ɵɵproperty,
  ɵɵtext
} from "./chunk-ELFI4Z7L.js";
import "./chunk-BMQUG2PJ.js";
import "./chunk-3OZZMUVI.js";
import "./chunk-3GAB7GSC.js";
import "./chunk-B7Y4FMY7.js";
import "./chunk-NQCL7WZ3.js";
import "./chunk-4BTEZGN2.js";
import "./chunk-XTVSKRH4.js";
import "./chunk-ETZFPO3Y.js";
import "./chunk-LLS636HS.js";
import "./chunk-KQQH3YTO.js";
import "./chunk-DI3VEDFV.js";
import "./chunk-PAXKX5KU.js";

// src/app/pages/admin-dashboard/admin-dashboard.page.ts
var _AdminDashboardPage = class _AdminDashboardPage {
  constructor() {
    this.authService = inject(AuthService);
    this.router = inject(Router);
    this.toastController = inject(ToastController);
    this.cerrandoSesion = false;
  }
  async cerrarSesion() {
    if (this.cerrandoSesion)
      return;
    this.cerrandoSesion = true;
    try {
      await this.authService.signOut();
      await this.router.navigateByUrl("/login", { replaceUrl: true });
    } catch (error) {
      const toast = await this.toastController.create({
        message: error instanceof Error ? error.message : "No se pudo cerrar la sesi\xF3n.",
        duration: 3e3,
        color: "danger"
      });
      await toast.present();
    } finally {
      this.cerrandoSesion = false;
    }
  }
};
_AdminDashboardPage.\u0275fac = function AdminDashboardPage_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _AdminDashboardPage)();
};
_AdminDashboardPage.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _AdminDashboardPage, selectors: [["app-admin-dashboard"]], decls: 11, vars: 1, consts: [[1, "ion-padding"], ["expand", "block", "fill", "outline", 3, "click", "disabled"]], template: function AdminDashboardPage_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-header")(1, "ion-toolbar")(2, "ion-title");
    \u0275\u0275text(3, "Panel administrador");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(4, "ion-content", 0)(5, "h1");
    \u0275\u0275text(6, "Administraci\xF3n");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "p");
    \u0275\u0275text(8, "Tu cuenta tiene el rol de administrador.");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(9, "ion-button", 1);
    \u0275\u0275listener("click", function AdminDashboardPage_Template_ion_button_click_9_listener() {
      return ctx.cerrarSesion();
    });
    \u0275\u0275text(10, " Cerrar sesi\xF3n ");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    \u0275\u0275advance(9);
    \u0275\u0275property("disabled", ctx.cerrandoSesion);
  }
}, dependencies: [IonButton, IonContent, IonHeader, IonTitle, IonToolbar], encapsulation: 2 });
var AdminDashboardPage = _AdminDashboardPage;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(AdminDashboardPage, [{
    type: Component,
    args: [{
      selector: "app-admin-dashboard",
      standalone: true,
      imports: [IonButton, IonContent, IonHeader, IonTitle, IonToolbar],
      template: `
    <ion-header>
      <ion-toolbar>
        <ion-title>Panel administrador</ion-title>
      </ion-toolbar>
    </ion-header>
    <ion-content class="ion-padding">
      <h1>Administraci\xF3n</h1>
      <p>Tu cuenta tiene el rol de administrador.</p>
      <ion-button expand="block" fill="outline" (click)="cerrarSesion()" [disabled]="cerrandoSesion">
        Cerrar sesi\xF3n
      </ion-button>
    </ion-content>
  `
    }]
  }], null, null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(AdminDashboardPage, { className: "AdminDashboardPage", filePath: "src/app/pages/admin-dashboard/admin-dashboard.page.ts", lineNumber: 27 });
})();
export {
  AdminDashboardPage
};
//# debugId=089173c4-1f76-514f-9a40-fc3f6bb87fcc
//# sourceMappingURL=admin-dashboard.page-6GD2MWBM.js.map
