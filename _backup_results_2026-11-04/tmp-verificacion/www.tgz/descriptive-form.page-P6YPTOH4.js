import {
  BaseCataForm,
  EstadoFichaComponent
} from "./chunk-NSTJCVOE.js";
import "./chunk-NM5KBNCZ.js";
import {
  RUEDA_SABORES
} from "./chunk-ECLBRM7C.js";
import "./chunk-DLWN5DPS.js";
import "./chunk-BHVR7Z6N.js";
import {
  arrowBackOutline,
  chevronDownOutline,
  chevronForwardOutline
} from "./chunk-IN4O4X7H.js";
import "./chunk-OFWJO6PD.js";
import {
  addIcons
} from "./chunk-4JFQPQWK.js";
import "./chunk-JH4CNQSM.js";
import {
  CommonModule,
  Component,
  DecimalPipe,
  DefaultValueAccessor,
  FormsModule,
  IonContent,
  IonIcon,
  NgControlStatus,
  NgForOf,
  NgIf,
  NgModel,
  RangeValueAccessor,
  setClassMetadata,
  ɵsetClassDebugInfo,
  ɵɵInheritDefinitionFeature,
  ɵɵadvance,
  ɵɵattribute,
  ɵɵclassProp,
  ɵɵcontrol,
  ɵɵcontrolCreate,
  ɵɵdefineComponent,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵgetInheritedFactory,
  ɵɵlistener,
  ɵɵnextContext,
  ɵɵpipe,
  ɵɵpipeBind2,
  ɵɵproperty,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵstyleProp,
  ɵɵtemplate,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1,
  ɵɵtwoWayBindingSet,
  ɵɵtwoWayListener,
  ɵɵtwoWayProperty
} from "./chunk-DEQWXDMW.js";
import "./chunk-BMQUG2PJ.js";
import "./chunk-3OZZMUVI.js";
import "./chunk-3GAB7GSC.js";
import "./chunk-B7Y4FMY7.js";
import "./chunk-NQCL7WZ3.js";
import "./chunk-4BTEZGN2.js";
import "./chunk-XTVSKRH4.js";
import "./chunk-ETZFPO3Y.js";
import "./chunk-LLS636HS.js";
import "./chunk-KQQH3YTO.js";
import "./chunk-DI3VEDFV.js";
import "./chunk-PAXKX5KU.js";

// src/app/pages/evaluation/descriptive-form/descriptive-form.page.ts
function DescriptiveFormPage_article_23_div_19_div_6_button_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r6 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 52);
    \u0275\u0275listener("click", function DescriptiveFormPage_article_23_div_19_div_6_button_1_Template_button_click_0_listener() {
      const descriptor_r7 = \u0275\u0275restoreView(_r6).$implicit;
      const atributo_r2 = \u0275\u0275nextContext(3).$implicit;
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.toggleDescriptor(atributo_r2.key, descriptor_r7));
    });
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const descriptor_r7 = ctx.$implicit;
    const categoria_r5 = \u0275\u0275nextContext(2).$implicit;
    const atributo_r2 = \u0275\u0275nextContext().$implicit;
    const ctx_r2 = \u0275\u0275nextContext();
    \u0275\u0275styleProp("background", ctx_r2.isDescriptorSelected(atributo_r2.key, descriptor_r7) ? ctx_r2.ruedaSabores[categoria_r5].color : "")("color", ctx_r2.isDescriptorSelected(atributo_r2.key, descriptor_r7) ? "white" : "");
    \u0275\u0275classProp("flavor-tree__descriptor-btn--selected", ctx_r2.isDescriptorSelected(atributo_r2.key, descriptor_r7));
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", descriptor_r7, " ");
  }
}
function DescriptiveFormPage_article_23_div_19_div_6_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 50);
    \u0275\u0275template(1, DescriptiveFormPage_article_23_div_19_div_6_button_1_Template, 2, 7, "button", 51);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const categoria_r5 = \u0275\u0275nextContext().$implicit;
    const ctx_r2 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275property("ngForOf", ctx_r2.ruedaSabores[categoria_r5].subdescriptores);
  }
}
function DescriptiveFormPage_article_23_div_19_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 44)(1, "button", 45);
    \u0275\u0275listener("click", function DescriptiveFormPage_article_23_div_19_Template_button_click_1_listener() {
      const categoria_r5 = \u0275\u0275restoreView(_r4).$implicit;
      const ctx_r2 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r2.toggleCategoria(categoria_r5));
    });
    \u0275\u0275elementStart(2, "span", 46);
    \u0275\u0275element(3, "ion-icon", 47)(4, "span", 48);
    \u0275\u0275text(5);
    \u0275\u0275elementEnd()();
    \u0275\u0275template(6, DescriptiveFormPage_article_23_div_19_div_6_Template, 2, 1, "div", 49);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const categoria_r5 = ctx.$implicit;
    const ctx_r2 = \u0275\u0275nextContext(2);
    \u0275\u0275advance(3);
    \u0275\u0275property("name", ctx_r2.categoriasAbiertas[categoria_r5] ? "chevron-down-outline" : "chevron-forward-outline");
    \u0275\u0275advance();
    \u0275\u0275styleProp("background", ctx_r2.ruedaSabores[categoria_r5].color);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", categoria_r5, " ");
    \u0275\u0275advance();
    \u0275\u0275property("ngIf", ctx_r2.categoriasAbiertas[categoria_r5]);
  }
}
function DescriptiveFormPage_article_23_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "article", 19)(1, "h3", 20);
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "div", 21)(4, "div", 22)(5, "span", 23);
    \u0275\u0275text(6, "Intensidad f\xEDsica (0-15)");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "span", 24);
    \u0275\u0275text(8);
    \u0275\u0275pipe(9, "number");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(10, "div", 25)(11, "span", 26);
    \u0275\u0275text(12, "Baja");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(13, "input", 27);
    \u0275\u0275twoWayListener("ngModelChange", function DescriptiveFormPage_article_23_Template_input_ngModelChange_13_listener($event) {
      const atributo_r2 = \u0275\u0275restoreView(_r1).$implicit;
      const ctx_r2 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r2.formulario[atributo_r2.key].intensidad, $event) || (ctx_r2.formulario[atributo_r2.key].intensidad = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd();
    \u0275\u0275controlCreate();
    \u0275\u0275elementStart(14, "span", 26);
    \u0275\u0275text(15, "Alta");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(16, "div", 41)(17, "p", 32);
    \u0275\u0275text(18, "Descriptores arom\xE1ticos");
    \u0275\u0275elementEnd();
    \u0275\u0275template(19, DescriptiveFormPage_article_23_div_19_Template, 7, 5, "div", 42);
    \u0275\u0275elementStart(20, "input", 43);
    \u0275\u0275twoWayListener("ngModelChange", function DescriptiveFormPage_article_23_Template_input_ngModelChange_20_listener($event) {
      const atributo_r2 = \u0275\u0275restoreView(_r1).$implicit;
      const ctx_r2 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r2.formulario[atributo_r2.key].extra, $event) || (ctx_r2.formulario[atributo_r2.key].extra = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd();
    \u0275\u0275controlCreate();
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const atributo_r2 = ctx.$implicit;
    const ctx_r2 = \u0275\u0275nextContext();
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(atributo_r2.label);
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind2(9, 6, ctx_r2.formulario[atributo_r2.key].intensidad, "1.1-1"));
    \u0275\u0275advance(5);
    \u0275\u0275twoWayProperty("ngModel", ctx_r2.formulario[atributo_r2.key].intensidad);
    \u0275\u0275control();
    \u0275\u0275advance(6);
    \u0275\u0275property("ngForOf", ctx_r2.ruedaKeys);
    \u0275\u0275advance();
    \u0275\u0275twoWayProperty("ngModel", ctx_r2.formulario[atributo_r2.key].extra);
    \u0275\u0275attribute("aria-label", "Descriptor personalizado para " + atributo_r2.label);
    \u0275\u0275control();
  }
}
function DescriptiveFormPage_label_80_Template(rf, ctx) {
  if (rf & 1) {
    const _r8 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "label", 53)(1, "input", 54);
    \u0275\u0275listener("change", function DescriptiveFormPage_label_80_Template_input_change_1_listener() {
      const textura_r9 = \u0275\u0275restoreView(_r8).$implicit;
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.toggleTextura(textura_r9));
    });
    \u0275\u0275elementEnd();
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const textura_r9 = ctx.$implicit;
    const ctx_r2 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275property("checked", ctx_r2.formulario.sensacionEnBoca.textura.includes(textura_r9));
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", textura_r9, " ");
  }
}
function DescriptiveFormPage_button_87_Template(rf, ctx) {
  if (rf & 1) {
    const _r10 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 55);
    \u0275\u0275listener("click", function DescriptiveFormPage_button_87_Template_button_click_0_listener() {
      \u0275\u0275restoreView(_r10);
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.irAMuestraAnterior());
    });
    \u0275\u0275text(1, " \u2190 Anterior ");
    \u0275\u0275elementEnd();
  }
}
addIcons({ arrowBackOutline, chevronDownOutline, chevronForwardOutline });
var _DescriptiveFormPage = class _DescriptiveFormPage extends BaseCataForm {
  constructor() {
    super(...arguments);
    this.formulario = this.crearFormularioVacio();
    this.atributosAromaticos = [
      { key: "fragancia", label: "Fragancia" },
      { key: "aroma", label: "Aroma (en taza)" },
      { key: "sabor", label: "Sabor" },
      { key: "saborResidual", label: "Sabor Residual" }
    ];
    this.escalaIntensidad = { min: 0, max: 15, step: 0.5 };
    this.ruedaKeys = Object.keys(RUEDA_SABORES);
    this.ruedaSabores = RUEDA_SABORES;
    this.texturas = ["\xC1spero", "Aceitoso", "Suave", "Astringente", "Met\xE1lico"];
    this.categoriasAbiertas = { Floral: true };
  }
  crearFormularioVacio() {
    const atributoVacio = () => ({ intensidad: 0, descriptores: [], extra: "" });
    return {
      fragancia: atributoVacio(),
      aroma: atributoVacio(),
      sabor: atributoVacio(),
      saborResidual: atributoVacio(),
      acidez: { intensidad: 0, nota: "" },
      dulzor: { intensidad: 0, nota: "" },
      sensacionEnBoca: { intensidad: 0, textura: [] },
      notas: ""
    };
  }
  toggleCategoria(categoria) {
    this.categoriasAbiertas[categoria] = !this.categoriasAbiertas[categoria];
  }
  toggleDescriptor(atributo, descriptor) {
    const lista = this.formulario[atributo].descriptores;
    this.formulario[atributo].descriptores = lista.includes(descriptor) ? lista.filter((item) => item !== descriptor) : [...lista, descriptor];
  }
  isDescriptorSelected(atributo, descriptor) {
    return this.formulario[atributo].descriptores.includes(descriptor);
  }
  toggleTextura(textura) {
    const lista = this.formulario.sensacionEnBoca.textura;
    this.formulario.sensacionEnBoca.textura = lista.includes(textura) ? lista.filter((item) => item !== textura) : [...lista, textura];
  }
};
_DescriptiveFormPage.\u0275fac = /* @__PURE__ */ (() => {
  let \u0275DescriptiveFormPage_BaseFactory;
  return function DescriptiveFormPage_Factory(__ngFactoryType__) {
    return (\u0275DescriptiveFormPage_BaseFactory || (\u0275DescriptiveFormPage_BaseFactory = \u0275\u0275getInheritedFactory(_DescriptiveFormPage)))(__ngFactoryType__ || _DescriptiveFormPage);
  };
})();
_DescriptiveFormPage.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _DescriptiveFormPage, selectors: [["app-descriptive-form"]], features: [\u0275\u0275InheritDefinitionFeature], decls: 90, vars: 32, consts: [[1, "cva-combined", 3, "scrollY"], [3, "reintentar", "salir", "pendientes", "enLinea", "muestraCerrada", "rechazo", "esperandoFinalizar"], [1, "cva-header"], [1, "cva-header__inner"], [1, "cva-header__left"], ["type", "button", "aria-label", "Volver", 1, "cva-header__back-btn", 3, "click"], ["name", "arrow-back-outline"], [1, "cva-header__meta"], [1, "cva-header__session-name"], [1, "cva-header__sample-label"], [1, "cva-header__right"], [1, "cva-header__format-badge"], [1, "cva-header__progress-bar-wrap"], [1, "cva-header__progress-bar"], [1, "cva-header__progress-bar-fill"], [1, "cva-main"], [1, "cva-main__grid"], [1, "cva-main__column"], ["class", "attr-card", 4, "ngFor", "ngForOf"], [1, "attr-card"], [1, "attr-card__title"], [1, "intensity-slider"], [1, "intensity-slider__header"], [1, "intensity-slider__label"], [1, "intensity-slider__value"], [1, "intensity-slider__track"], [1, "intensity-slider__endpoint"], ["type", "range", "min", "0", "max", "15", "step", "0.5", 1, "intensity-slider__input", 3, "ngModelChange", "ngModel"], [1, "notes-panel", 2, "margin-top", "16px"], [1, "notes-panel__header"], ["rows", "2", 1, "notes-panel__textarea", 3, "ngModelChange", "ngModel"], [1, "mouthfeel"], [1, "flavor-tree__section-label"], [1, "mouthfeel__list"], ["class", "mouthfeel__item", 4, "ngFor", "ngForOf"], [1, "cva-main__sidebar"], [1, "notes-panel"], ["rows", "5", "placeholder", "Observaciones descriptivas...", 1, "notes-panel__textarea", 3, "ngModelChange", "ngModel"], [1, "sample-navigation"], ["type", "button", "class", "submit-btn sample-navigation__previous", 3, "click", 4, "ngIf"], ["type", "button", 1, "submit-btn", 3, "click", "disabled"], [1, "flavor-tree"], ["class", "flavor-tree__category", 4, "ngFor", "ngForOf"], ["type", "text", "placeholder", "Agregar descriptor personalizado...", 1, "extra-descriptor", 3, "ngModelChange", "ngModel"], [1, "flavor-tree__category"], ["type", "button", 1, "flavor-tree__category-btn", 3, "click"], [1, "flavor-tree__category-left"], [1, "flavor-tree__chevron", 3, "name"], [1, "flavor-tree__swatch"], ["class", "flavor-tree__sub-list", 4, "ngIf"], [1, "flavor-tree__sub-list"], ["type", "button", "class", "flavor-tree__descriptor-btn", 3, "flavor-tree__descriptor-btn--selected", "background", "color", "click", 4, "ngFor", "ngForOf"], ["type", "button", 1, "flavor-tree__descriptor-btn", 3, "click"], [1, "mouthfeel__item"], ["type", "checkbox", 3, "change", "checked"], ["type", "button", 1, "submit-btn", "sample-navigation__previous", 3, "click"]], template: function DescriptiveFormPage_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-content", 0)(1, "app-estado-ficha", 1);
    \u0275\u0275listener("reintentar", function DescriptiveFormPage_Template_app_estado_ficha_reintentar_1_listener() {
      return ctx.reintentarSincronizacion();
    })("salir", function DescriptiveFormPage_Template_app_estado_ficha_salir_1_listener() {
      return ctx.salirConPendientes();
    });
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(2, "header", 2)(3, "div", 3)(4, "div", 4)(5, "button", 5);
    \u0275\u0275listener("click", function DescriptiveFormPage_Template_button_click_5_listener() {
      return ctx.volver();
    });
    \u0275\u0275element(6, "ion-icon", 6);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(7, "div", 7)(8, "p", 8);
    \u0275\u0275text(9, "Evaluaci\xF3n Descriptiva");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(10, "p", 9);
    \u0275\u0275text(11);
    \u0275\u0275elementStart(12, "span");
    \u0275\u0275text(13);
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(14, "div", 10)(15, "span", 11);
    \u0275\u0275text(16, "Descriptivo");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(17, "div", 12)(18, "div", 13);
    \u0275\u0275element(19, "div", 14);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(20, "main", 15)(21, "div", 16)(22, "div", 17);
    \u0275\u0275template(23, DescriptiveFormPage_article_23_Template, 21, 9, "article", 18);
    \u0275\u0275elementStart(24, "article", 19)(25, "h3", 20);
    \u0275\u0275text(26, "Acidez");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(27, "div", 21)(28, "div", 22)(29, "span", 23);
    \u0275\u0275text(30, "Intensidad f\xEDsica (0-15)");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(31, "span", 24);
    \u0275\u0275text(32);
    \u0275\u0275pipe(33, "number");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(34, "div", 25)(35, "span", 26);
    \u0275\u0275text(36, "Baja");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(37, "input", 27);
    \u0275\u0275twoWayListener("ngModelChange", function DescriptiveFormPage_Template_input_ngModelChange_37_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.formulario.acidez.intensidad, $event) || (ctx.formulario.acidez.intensidad = $event);
      return $event;
    });
    \u0275\u0275elementEnd();
    \u0275\u0275controlCreate();
    \u0275\u0275elementStart(38, "span", 26);
    \u0275\u0275text(39, "Alta");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(40, "div", 28)(41, "div", 29);
    \u0275\u0275text(42, "Notas de acidez (ej. c\xEDtrica, m\xE1lica)");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(43, "textarea", 30);
    \u0275\u0275twoWayListener("ngModelChange", function DescriptiveFormPage_Template_textarea_ngModelChange_43_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.formulario.acidez.nota, $event) || (ctx.formulario.acidez.nota = $event);
      return $event;
    });
    \u0275\u0275elementEnd();
    \u0275\u0275controlCreate();
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(44, "article", 19)(45, "h3", 20);
    \u0275\u0275text(46, "Dulzor");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(47, "div", 21)(48, "div", 22)(49, "span", 23);
    \u0275\u0275text(50, "Intensidad f\xEDsica (0-15)");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(51, "span", 24);
    \u0275\u0275text(52);
    \u0275\u0275pipe(53, "number");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(54, "div", 25)(55, "span", 26);
    \u0275\u0275text(56, "Baja");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(57, "input", 27);
    \u0275\u0275twoWayListener("ngModelChange", function DescriptiveFormPage_Template_input_ngModelChange_57_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.formulario.dulzor.intensidad, $event) || (ctx.formulario.dulzor.intensidad = $event);
      return $event;
    });
    \u0275\u0275elementEnd();
    \u0275\u0275controlCreate();
    \u0275\u0275elementStart(58, "span", 26);
    \u0275\u0275text(59, "Alta");
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(60, "article", 19)(61, "h3", 20);
    \u0275\u0275text(62, "Sensaci\xF3n en Boca");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(63, "div", 21)(64, "div", 22)(65, "span", 23);
    \u0275\u0275text(66, "Intensidad f\xEDsica (0-15)");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(67, "span", 24);
    \u0275\u0275text(68);
    \u0275\u0275pipe(69, "number");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(70, "div", 25)(71, "span", 26);
    \u0275\u0275text(72, "Baja");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(73, "input", 27);
    \u0275\u0275twoWayListener("ngModelChange", function DescriptiveFormPage_Template_input_ngModelChange_73_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.formulario.sensacionEnBoca.intensidad, $event) || (ctx.formulario.sensacionEnBoca.intensidad = $event);
      return $event;
    });
    \u0275\u0275elementEnd();
    \u0275\u0275controlCreate();
    \u0275\u0275elementStart(74, "span", 26);
    \u0275\u0275text(75, "Alta");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(76, "div", 31)(77, "p", 32);
    \u0275\u0275text(78, "Texturas t\xE1ctiles");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(79, "div", 33);
    \u0275\u0275template(80, DescriptiveFormPage_label_80_Template, 3, 2, "label", 34);
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(81, "aside", 35)(82, "div", 36)(83, "div", 29);
    \u0275\u0275text(84, "Notas adicionales");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(85, "textarea", 37);
    \u0275\u0275twoWayListener("ngModelChange", function DescriptiveFormPage_Template_textarea_ngModelChange_85_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.formulario.notas, $event) || (ctx.formulario.notas = $event);
      return $event;
    });
    \u0275\u0275elementEnd();
    \u0275\u0275controlCreate();
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(86, "div", 38);
    \u0275\u0275template(87, DescriptiveFormPage_button_87_Template, 2, 0, "button", 39);
    \u0275\u0275elementStart(88, "button", 40);
    \u0275\u0275listener("click", function DescriptiveFormPage_Template_button_click_88_listener() {
      return ctx.irAMuestraSiguiente();
    });
    \u0275\u0275text(89);
    \u0275\u0275elementEnd()()()()()();
  }
  if (rf & 2) {
    \u0275\u0275property("scrollY", true);
    \u0275\u0275advance();
    \u0275\u0275property("pendientes", ctx.pendientesLocales())("enLinea", ctx.enLinea())("muestraCerrada", ctx.muestraActualCerrada())("rechazo", ctx.rechazoActual())("esperandoFinalizar", ctx.esperandoSincronizacion());
    \u0275\u0275advance(10);
    \u0275\u0275textInterpolate1("Muestra ", ctx.muestraActual(), " ");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1("de ", ctx.totalMuestras());
    \u0275\u0275advance(6);
    \u0275\u0275styleProp("width", ctx.muestraActual() / ctx.totalMuestras() * 100 + "%");
    \u0275\u0275advance(4);
    \u0275\u0275property("ngForOf", ctx.atributosAromaticos);
    \u0275\u0275advance(9);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind2(33, 23, ctx.formulario.acidez.intensidad, "1.1-1"));
    \u0275\u0275advance(5);
    \u0275\u0275twoWayProperty("ngModel", ctx.formulario.acidez.intensidad);
    \u0275\u0275control();
    \u0275\u0275advance(6);
    \u0275\u0275twoWayProperty("ngModel", ctx.formulario.acidez.nota);
    \u0275\u0275control();
    \u0275\u0275advance(9);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind2(53, 26, ctx.formulario.dulzor.intensidad, "1.1-1"));
    \u0275\u0275advance(5);
    \u0275\u0275twoWayProperty("ngModel", ctx.formulario.dulzor.intensidad);
    \u0275\u0275control();
    \u0275\u0275advance(11);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind2(69, 29, ctx.formulario.sensacionEnBoca.intensidad, "1.1-1"));
    \u0275\u0275advance(5);
    \u0275\u0275twoWayProperty("ngModel", ctx.formulario.sensacionEnBoca.intensidad);
    \u0275\u0275control();
    \u0275\u0275advance(7);
    \u0275\u0275property("ngForOf", ctx.texturas);
    \u0275\u0275advance(5);
    \u0275\u0275twoWayProperty("ngModel", ctx.formulario.notas);
    \u0275\u0275control();
    \u0275\u0275advance(2);
    \u0275\u0275property("ngIf", ctx.muestraActual() > 1);
    \u0275\u0275advance();
    \u0275\u0275property("disabled", ctx.guardando());
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", ctx.guardando() ? "Guardando\u2026" : ctx.muestraActual() === ctx.totalMuestras() ? "Terminar cata" : "Siguiente muestra \u2192", " ");
  }
}, dependencies: [IonContent, IonIcon, CommonModule, NgForOf, NgIf, FormsModule, DefaultValueAccessor, RangeValueAccessor, NgControlStatus, NgModel, EstadoFichaComponent, DecimalPipe], encapsulation: 2 });
var DescriptiveFormPage = _DescriptiveFormPage;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(DescriptiveFormPage, [{
    type: Component,
    args: [{ selector: "app-descriptive-form", standalone: true, imports: [IonContent, IonIcon, CommonModule, FormsModule, EstadoFichaComponent], template: `<ion-content class="cva-combined" [scrollY]="true">
  <app-estado-ficha
    [pendientes]="pendientesLocales()"
    [enLinea]="enLinea()"
    [muestraCerrada]="muestraActualCerrada()"
    [rechazo]="rechazoActual()"
    [esperandoFinalizar]="esperandoSincronizacion()"
    (reintentar)="reintentarSincronizacion()"
    (salir)="salirConPendientes()">
  </app-estado-ficha>
  <header class="cva-header">
    <div class="cva-header__inner">
      <div class="cva-header__left">
        <button type="button" class="cva-header__back-btn" aria-label="Volver" (click)="volver()">
          <ion-icon name="arrow-back-outline"></ion-icon>
        </button>
        <div class="cva-header__meta">
          <p class="cva-header__session-name">Evaluaci\xF3n Descriptiva</p>
          <p class="cva-header__sample-label">Muestra {{ muestraActual() }} <span>de {{ totalMuestras() }}</span></p>
        </div>
      </div>
      <div class="cva-header__right">
        <span class="cva-header__format-badge">Descriptivo</span>
      </div>
    </div>
    <div class="cva-header__progress-bar-wrap">
      <div class="cva-header__progress-bar">
        <div class="cva-header__progress-bar-fill" [style.width]="(muestraActual() / totalMuestras()) * 100 + '%'"></div>
      </div>
    </div>
  </header>

  <main class="cva-main">
    <div class="cva-main__grid">
      <div class="cva-main__column">
        <article class="attr-card" *ngFor="let atributo of atributosAromaticos">
          <h3 class="attr-card__title">{{ atributo.label }}</h3>
          <div class="intensity-slider">
            <div class="intensity-slider__header">
              <span class="intensity-slider__label">Intensidad f\xEDsica (0-15)</span>
              <span class="intensity-slider__value">{{ formulario[atributo.key].intensidad | number:'1.1-1' }}</span>
            </div>
            <div class="intensity-slider__track">
              <span class="intensity-slider__endpoint">Baja</span>
              <input class="intensity-slider__input" type="range" min="0" max="15" step="0.5" [(ngModel)]="formulario[atributo.key].intensidad">
              <span class="intensity-slider__endpoint">Alta</span>
            </div>
          </div>

          <div class="flavor-tree">
            <p class="flavor-tree__section-label">Descriptores arom\xE1ticos</p>
            <div class="flavor-tree__category" *ngFor="let categoria of ruedaKeys">
              <button type="button" class="flavor-tree__category-btn" (click)="toggleCategoria(categoria)">
                <span class="flavor-tree__category-left">
                  <ion-icon
                    [name]="categoriasAbiertas[categoria] ? 'chevron-down-outline' : 'chevron-forward-outline'"
                    class="flavor-tree__chevron">
                  </ion-icon>
                  <span class="flavor-tree__swatch" [style.background]="ruedaSabores[categoria].color"></span>
                  {{ categoria }}
                </span>
              </button>
              <div class="flavor-tree__sub-list" *ngIf="categoriasAbiertas[categoria]">
                <button
                  type="button"
                  *ngFor="let descriptor of ruedaSabores[categoria].subdescriptores"
                  class="flavor-tree__descriptor-btn"
                  [class.flavor-tree__descriptor-btn--selected]="isDescriptorSelected(atributo.key, descriptor)"
                  [style.background]="isDescriptorSelected(atributo.key, descriptor) ? ruedaSabores[categoria].color : ''"
                  [style.color]="isDescriptorSelected(atributo.key, descriptor) ? 'white' : ''"
                  (click)="toggleDescriptor(atributo.key, descriptor)">
                  {{ descriptor }}
                </button>
              </div>
            </div>
            <input
              type="text"
              class="extra-descriptor"
              [attr.aria-label]="'Descriptor personalizado para ' + atributo.label"
              placeholder="Agregar descriptor personalizado..."
              [(ngModel)]="formulario[atributo.key].extra">
          </div>
        </article>

        <article class="attr-card">
          <h3 class="attr-card__title">Acidez</h3>
          <div class="intensity-slider">
            <div class="intensity-slider__header">
              <span class="intensity-slider__label">Intensidad f\xEDsica (0-15)</span>
              <span class="intensity-slider__value">{{ formulario.acidez.intensidad | number:'1.1-1' }}</span>
            </div>
            <div class="intensity-slider__track">
              <span class="intensity-slider__endpoint">Baja</span>
              <input class="intensity-slider__input" type="range" min="0" max="15" step="0.5" [(ngModel)]="formulario.acidez.intensidad">
              <span class="intensity-slider__endpoint">Alta</span>
            </div>
          </div>
          <div class="notes-panel" style="margin-top:16px;">
            <div class="notes-panel__header">Notas de acidez (ej. c\xEDtrica, m\xE1lica)</div>
            <textarea class="notes-panel__textarea" rows="2" [(ngModel)]="formulario.acidez.nota"></textarea>
          </div>
        </article>

        <article class="attr-card">
          <h3 class="attr-card__title">Dulzor</h3>
          <div class="intensity-slider">
            <div class="intensity-slider__header">
              <span class="intensity-slider__label">Intensidad f\xEDsica (0-15)</span>
              <span class="intensity-slider__value">{{ formulario.dulzor.intensidad | number:'1.1-1' }}</span>
            </div>
            <div class="intensity-slider__track">
              <span class="intensity-slider__endpoint">Baja</span>
              <input class="intensity-slider__input" type="range" min="0" max="15" step="0.5" [(ngModel)]="formulario.dulzor.intensidad">
              <span class="intensity-slider__endpoint">Alta</span>
            </div>
          </div>
        </article>

        <article class="attr-card">
          <h3 class="attr-card__title">Sensaci\xF3n en Boca</h3>
          <div class="intensity-slider">
            <div class="intensity-slider__header">
              <span class="intensity-slider__label">Intensidad f\xEDsica (0-15)</span>
              <span class="intensity-slider__value">{{ formulario.sensacionEnBoca.intensidad | number:'1.1-1' }}</span>
            </div>
            <div class="intensity-slider__track">
              <span class="intensity-slider__endpoint">Baja</span>
              <input class="intensity-slider__input" type="range" min="0" max="15" step="0.5" [(ngModel)]="formulario.sensacionEnBoca.intensidad">
              <span class="intensity-slider__endpoint">Alta</span>
            </div>
          </div>
          <div class="mouthfeel">
            <p class="flavor-tree__section-label">Texturas t\xE1ctiles</p>
            <div class="mouthfeel__list">
              <label class="mouthfeel__item" *ngFor="let textura of texturas">
                <input type="checkbox" [checked]="formulario.sensacionEnBoca.textura.includes(textura)" (change)="toggleTextura(textura)">
                {{ textura }}
              </label>
            </div>
          </div>
        </article>
      </div>

      <aside class="cva-main__sidebar">
        <div class="notes-panel">
          <div class="notes-panel__header">Notas adicionales</div>
          <textarea class="notes-panel__textarea" rows="5" [(ngModel)]="formulario.notas" placeholder="Observaciones descriptivas..."></textarea>
        </div>
        <div class="sample-navigation">
          <button
            *ngIf="muestraActual() > 1"
            type="button"
            class="submit-btn sample-navigation__previous"
            (click)="irAMuestraAnterior()">
            \u2190 Anterior
          </button>
          <button type="button" class="submit-btn" (click)="irAMuestraSiguiente()" [disabled]="guardando()">
            {{ guardando() ? 'Guardando\u2026' : (muestraActual() === totalMuestras() ? 'Terminar cata' : 'Siguiente muestra \u2192') }}
          </button>
        </div>
      </aside>
    </div>
  </main>
</ion-content>
` }]
  }], null, null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(DescriptiveFormPage, { className: "DescriptiveFormPage", filePath: "src/app/pages/evaluation/descriptive-form/descriptive-form.page.ts", lineNumber: 38 });
})();
export {
  DescriptiveFormPage
};
//# debugId=86519f1d-2e61-5ca1-b3dc-68537dfcf21f
//# sourceMappingURL=descriptive-form.page-P6YPTOH4.js.map
