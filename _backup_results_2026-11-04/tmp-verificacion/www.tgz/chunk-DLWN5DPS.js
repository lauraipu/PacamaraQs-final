import {
  esErrorPermanente,
  mensajeDeError
} from "./chunk-OFWJO6PD.js";
import {
  AuthService
} from "./chunk-JH4CNQSM.js";
import {
  DestroyRef,
  Injectable,
  Subject,
  SupabaseService,
  computed,
  effect,
  inject,
  setClassMetadata,
  signal,
  untracked,
  ɵɵdefineInjectable
} from "./chunk-DEQWXDMW.js";
import {
  __spreadProps,
  __spreadValues
} from "./chunk-PAXKX5KU.js";

// src/app/core/services/offline-sync.ts
var CLAVE_COLA = "pacamara_cola_sync_v1";
var BACKOFF_BASE_MS = 2e3;
var BACKOFF_MAX_MS = 6e4;
var ATRIBUTO_DB = {
  fragancia: "fragancia",
  aroma: "aroma",
  sabor: "sabor",
  saborResidual: "sabor_residual",
  sabor_residual: "sabor_residual",
  acidez: "acidez",
  dulzor: "dulzor",
  sensacionEnBoca: "sensacion_boca",
  sensacion_boca: "sensacion_boca"
};
function claveBorrador(sesionId, numeroMuestra) {
  return `borrador_sesion_${sesionId}_${numeroMuestra}`;
}
function claveFicha(ficha) {
  return `${ficha.sesionId}:${ficha.catadorId}:${ficha.numeroMuestra}`;
}
var _OfflineSyncService = class _OfflineSyncService {
  constructor() {
    this.supabase = inject(SupabaseService);
    this.authService = inject(AuthService);
    this._enLinea = signal(
      typeof navigator === "undefined" ? true : navigator.onLine,
      ...ngDevMode ? [{ debugName: "_enLinea" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this._cola = signal(
      this.leerColaPersistida(),
      ...ngDevMode ? [{ debugName: "_cola" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this._rechazos = signal(
      /* @__PURE__ */ new Map(),
      ...ngDevMode ? [{ debugName: "_rechazos" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this._sincronizando = signal(
      false,
      ...ngDevMode ? [{ debugName: "_sincronizando" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.sincronizadasSubject = new Subject();
    this.enLinea = this._enLinea.asReadonly();
    this.cola = this._cola.asReadonly();
    this.rechazos = this._rechazos.asReadonly();
    this.sincronizando = this._sincronizando.asReadonly();
    this.cantidadPendientes = computed(
      () => this._cola().length,
      ...ngDevMode ? [{ debugName: "cantidadPendientes" }] : (
        /* istanbul ignore next */
        []
      )
    );
    this.sincronizadas$ = this.sincronizadasSubject.asObservable();
    this.procesando = false;
    this.enVuelo = /* @__PURE__ */ new Map();
    const alConectar = () => {
      this._enLinea.set(true);
      this.adelantarReintentos();
    };
    const alDesconectar = () => this._enLinea.set(false);
    const alVolverPrimerPlano = () => {
      if (document.visibilityState === "visible")
        this.adelantarReintentos();
    };
    window.addEventListener("online", alConectar);
    window.addEventListener("offline", alDesconectar);
    document.addEventListener("visibilitychange", alVolverPrimerPlano);
    inject(DestroyRef).onDestroy(() => {
      window.removeEventListener("online", alConectar);
      window.removeEventListener("offline", alDesconectar);
      document.removeEventListener("visibilitychange", alVolverPrimerPlano);
      clearTimeout(this.temporizador);
    });
    effect(() => {
      const usuario = this.authService.usuario();
      if (usuario && untracked(() => this._cola().length) > 0) {
        queueMicrotask(() => void this.procesarCola());
      }
    });
  }
  /** Fichas pendientes de una sesión concreta. */
  pendientesDeSesion(sesionId) {
    return this._cola().filter((item) => item.ficha.sesionId === sesionId);
  }
  /**
   * Fichas que el servidor ya tiene del catador actual (RLS: solo las propias).
   * `notas` guarda el formulario serializado y permite retomar en otro dispositivo.
   */
  async obtenerFichasEnviadas(sesionId) {
    const usuarioId = this.authService.usuario()?.id;
    if (!usuarioId)
      return [];
    const { data, error } = await this.supabase.client.from("evaluaciones").select("numero_muestra, notas").eq("sesion_id", sesionId).eq("catador_id", usuarioId);
    if (error)
      throw error;
    return (data ?? []).map((fila) => ({
      numeroMuestra: Number(fila.numero_muestra),
      notas: typeof fila.notas === "string" ? fila.notas : null
    }));
  }
  // ---------------------------------------------------------------------------
  // Borradores
  // ---------------------------------------------------------------------------
  guardarBorrador(sesionId, numeroMuestra, datos) {
    const usuarioId = this.authService.usuario()?.id;
    if (!usuarioId)
      return;
    const registro = { usuarioId, actualizadoEn: Date.now(), datos };
    try {
      localStorage.setItem(claveBorrador(sesionId, numeroMuestra), JSON.stringify(registro));
    } catch (error) {
      console.warn("[OfflineSync] No se pudo guardar el borrador:", error);
    }
  }
  /** Devuelve el borrador SOLO si pertenece al usuario actual (dispositivos compartidos). */
  leerBorrador(sesionId, numeroMuestra) {
    const usuarioId = this.authService.usuario()?.id;
    if (!usuarioId)
      return null;
    try {
      const crudo = localStorage.getItem(claveBorrador(sesionId, numeroMuestra));
      if (!crudo)
        return null;
      const registro = JSON.parse(crudo);
      return registro.usuarioId === usuarioId && registro.datos !== void 0 ? registro.datos : null;
    } catch {
      return null;
    }
  }
  eliminarBorrador(sesionId, numeroMuestra) {
    try {
      localStorage.removeItem(claveBorrador(sesionId, numeroMuestra));
    } catch {
    }
  }
  // ---------------------------------------------------------------------------
  // Envío
  // ---------------------------------------------------------------------------
  /**
   * Encola la ficha y la intenta enviar de inmediato.
   * - 'sincronizada': confirmada por el servidor.
   * - 'pendiente': sin red o error transitorio; queda en cola con backoff.
   * - 'rechazada': el servidor la rechazó (p. ej. muestra cerrada). No se reintenta.
   */
  async enviar(ficha) {
    const clave = claveFicha(ficha);
    this.quitarRechazo(clave);
    this.ponerEnCola({ clave, ficha, intentos: 0, proximoIntentoEn: Date.now(), encoladaEn: Date.now() });
    if (!this._enLinea()) {
      return { estado: "pendiente", mensaje: "Guardado localmente. Reintentando\u2026" };
    }
    await this.enVuelo.get(clave)?.catch(() => void 0);
    const item = this._cola().find((i) => i.clave === clave);
    if (!item)
      return { estado: "sincronizada" };
    const resultado = await this.intentar(item);
    this.programarSiguiente();
    if (resultado === "ok")
      return { estado: "sincronizada" };
    if (resultado === "rechazado") {
      return { estado: "rechazada", mensaje: this._rechazos().get(clave) };
    }
    return { estado: "pendiente", mensaje: "Guardado localmente. Reintentando\u2026" };
  }
  /** Fuerza un reintento inmediato de toda la cola (botón "Reintentar"). */
  reintentarAhora() {
    this.adelantarReintentos();
  }
  async procesarCola() {
    if (this.procesando || !this._enLinea()) {
      this.programarSiguiente();
      return;
    }
    this.procesando = true;
    this._sincronizando.set(true);
    try {
      const ahora = Date.now();
      const vencidos = this._cola().filter((item) => item.proximoIntentoEn <= ahora);
      for (const item of vencidos) {
        if (!this._enLinea())
          break;
        const vigente = this._cola().find((i) => i.clave === item.clave);
        if (vigente)
          await this.intentar(vigente);
      }
    } finally {
      this.procesando = false;
      this._sincronizando.set(false);
      this.programarSiguiente();
    }
  }
  intentar(item) {
    const existente = this.enVuelo.get(item.clave);
    if (existente)
      return existente;
    const intento = this.ejecutarIntento(item).finally(() => this.enVuelo.delete(item.clave));
    this.enVuelo.set(item.clave, intento);
    return intento;
  }
  async ejecutarIntento(item) {
    const usuarioId = this.authService.usuario()?.id;
    if (!usuarioId || usuarioId !== item.ficha.catadorId) {
      this.reprogramar(item, "Esperando la sesi\xF3n del catador.");
      return "reintentar";
    }
    try {
      await this.persistir(item.ficha);
      const reemplazada = this._cola().some((i) => i.clave === item.clave && i.encoladaEn !== item.encoladaEn);
      if (!reemplazada) {
        this.quitarDeCola(item.clave);
        this.eliminarBorrador(item.ficha.sesionId, item.ficha.numeroMuestra);
      }
      this.sincronizadasSubject.next(item.ficha);
      return "ok";
    } catch (error) {
      if (esErrorPermanente(error)) {
        this.actualizarCola((cola) => cola.filter((i) => !(i.clave === item.clave && i.encoladaEn === item.encoladaEn)));
        this.registrarRechazo(item.clave, this.mensajeRechazo(error));
        return "rechazado";
      }
      this.reprogramar(item, mensajeDeError(error, "Error de red."));
      return "reintentar";
    }
  }
  async persistir(ficha) {
    const { data, error } = await this.supabase.client.from("evaluaciones").upsert({
      sesion_id: ficha.sesionId,
      catador_id: ficha.catadorId,
      numero_muestra: ficha.numeroMuestra,
      impresion_global: ficha.impresionGlobal,
      tazas_no_uniformes: ficha.tazasNoUniformes,
      tazas_defectuosas: ficha.tazasDefectuosas,
      puntaje_final: ficha.puntajeFinal,
      notas: ficha.notas
    }, { onConflict: "sesion_id,catador_id,numero_muestra" }).select("id").single();
    if (error)
      throw error;
    const evaluacionId = data?.id;
    if (!evaluacionId)
      throw new Error("Supabase no devolvi\xF3 el ID de la evaluaci\xF3n.");
    const filas = ficha.atributos.map((atributo) => this.normalizarAtributo(atributo)).filter((fila) => fila !== null).map((fila) => __spreadValues({ evaluacion_id: evaluacionId }, fila));
    if (filas.length === 0)
      return;
    const { error: errorAtributos } = await this.supabase.client.from("evaluacion_atributos").upsert(filas, { onConflict: "evaluacion_id,atributo" });
    if (errorAtributos)
      throw errorAtributos;
  }
  normalizarAtributo(atributo) {
    const nombreDb = ATRIBUTO_DB[atributo.atributo];
    if (!nombreDb)
      return null;
    const intensidad = this.enRango(atributo.intensidad, 0, 15);
    const calidad = this.enRango(atributo.calidad, 1, 9);
    if (intensidad === null && calidad === null)
      return null;
    return { atributo: nombreDb, intensidad, calidad };
  }
  enRango(valor, min, max) {
    return typeof valor === "number" && Number.isFinite(valor) && valor >= min && valor <= max ? valor : null;
  }
  mensajeRechazo(error) {
    const texto = mensajeDeError(error, "");
    if (/row-level security/i.test(texto)) {
      return "El servidor ya no acepta esta ficha: la muestra fue cerrada o la sesi\xF3n termin\xF3.";
    }
    return texto || "El servidor rechaz\xF3 la ficha.";
  }
  // ---------------------------------------------------------------------------
  // Cola y backoff
  // ---------------------------------------------------------------------------
  calcularEspera(intentos) {
    const base = Math.min(BACKOFF_MAX_MS, BACKOFF_BASE_MS * 2 ** Math.max(0, intentos - 1));
    const jitter = base * 0.2 * (Math.random() * 2 - 1);
    return Math.round(base + jitter);
  }
  reprogramar(item, mensaje) {
    const intentos = item.intentos + 1;
    this.actualizarCola((cola) => cola.map((i) => i.clave === item.clave ? __spreadProps(__spreadValues({}, i), { intentos, ultimoError: mensaje, proximoIntentoEn: Date.now() + this.calcularEspera(intentos) }) : i));
  }
  adelantarReintentos() {
    const ahora = Date.now();
    this.actualizarCola((cola) => cola.map((i) => __spreadProps(__spreadValues({}, i), { proximoIntentoEn: Math.min(i.proximoIntentoEn, ahora) })));
    void this.procesarCola();
  }
  programarSiguiente() {
    clearTimeout(this.temporizador);
    const cola = this._cola();
    if (cola.length === 0 || !this._enLinea())
      return;
    const proximo = Math.min(...cola.map((i) => i.proximoIntentoEn));
    const espera = Math.max(250, proximo - Date.now());
    this.temporizador = setTimeout(() => void this.procesarCola(), espera);
  }
  /** Una ficha nueva reemplaza a la pendiente de la misma (sesión, catador, muestra). */
  ponerEnCola(item) {
    this.actualizarCola((cola) => [...cola.filter((i) => i.clave !== item.clave), item]);
  }
  quitarDeCola(clave) {
    this.actualizarCola((cola) => cola.filter((i) => i.clave !== clave));
  }
  actualizarCola(transformar) {
    const nueva = transformar(this._cola());
    this._cola.set(nueva);
    try {
      localStorage.setItem(CLAVE_COLA, JSON.stringify(nueva));
    } catch (error) {
      console.warn("[OfflineSync] No se pudo persistir la cola:", error);
    }
  }
  registrarRechazo(clave, mensaje) {
    const siguiente = new Map(this._rechazos());
    siguiente.set(clave, mensaje);
    this._rechazos.set(siguiente);
  }
  quitarRechazo(clave) {
    if (!this._rechazos().has(clave))
      return;
    const siguiente = new Map(this._rechazos());
    siguiente.delete(clave);
    this._rechazos.set(siguiente);
  }
  leerColaPersistida() {
    try {
      const crudo = localStorage.getItem(CLAVE_COLA);
      const lista = crudo ? JSON.parse(crudo) : [];
      if (!Array.isArray(lista))
        return [];
      return lista.filter((item) => typeof item === "object" && item !== null && typeof item.clave === "string" && typeof item.ficha?.sesionId === "string");
    } catch {
      return [];
    }
  }
};
_OfflineSyncService.\u0275fac = function OfflineSyncService_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _OfflineSyncService)();
};
_OfflineSyncService.\u0275prov = /* @__PURE__ */ \u0275\u0275defineInjectable({ token: _OfflineSyncService, factory: _OfflineSyncService.\u0275fac, providedIn: "root" });
var OfflineSyncService = _OfflineSyncService;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(OfflineSyncService, [{
    type: Injectable,
    args: [{ providedIn: "root" }]
  }], () => [], null);
})();

export {
  OfflineSyncService
};
//# debugId=684ceae4-d6d2-5807-a1bd-d65f4d667e3e
//# sourceMappingURL=chunk-DLWN5DPS.js.map
