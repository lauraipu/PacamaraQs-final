import {
  c,
  d,
  i,
  l,
  n,
  s,
  u
} from "./chunk-NQCL7WZ3.js";
import "./chunk-ETZFPO3Y.js";
import "./chunk-DI3VEDFV.js";
import "./chunk-PAXKX5KU.js";
export {
  u as MENU_BACK_BUTTON_PRIORITY,
  d as OVERLAY_BACK_BUTTON_PRIORITY,
  c as addCloseWatcherCondition,
  i as blockHardwareBackButton,
  n as shouldUseCloseWatcher,
  l as startHardwareBackButton,
  s as updateCloseWatcher
};
//# debugId=63937638-d6a4-59b6-8ed2-3b91ede6aecb
//# sourceMappingURL=p-CohRJRIu-CV2MXZ33.js.map
