// src/app/core/cva/cva.ts
var RUEDA_SABORES = {
  Floral: { color: "#F4B8C8", subdescriptores: ["Flor de t\xE9", "Jazm\xEDn", "Rosa", "Lavanda"] },
  Afrutado: { color: "#F4A636", subdescriptores: ["Bayas", "Frutas deshidratadas", "C\xEDtricos", "Fruta de hueso", "Coco", "Mel\xF3n"] },
  "\xC1cido / Fermentado": { color: "#EDD84A", subdescriptores: ["\xC1cido ac\xE9tico", "Fermentado", "Vinoso", "Agrio"] },
  "Verde / Vegetal": { color: "#72B74A", subdescriptores: ["Oliva", "Pepino", "Hierba", "Heno", "Crudo"] },
  Otro: { color: "#A08060", subdescriptores: ["Madera", "Tinta", "Caucho"] },
  Tostado: { color: "#7B4F2E", subdescriptores: ["Cereal", "Quemado", "Tabaco", "Pipa"] },
  "Nueces / Cacao": { color: "#C47A30", subdescriptores: ["Nueces", "Cacao", "Chocolate", "Almendra"] },
  Especias: { color: "#E06040", subdescriptores: ["An\xEDs", "Pimienta", "Canela", "Clavo"] },
  Dulce: { color: "#D49AB8", subdescriptores: ["Vainilla", "Az\xFAcar morena", "Miel", "Caramelo"] }
};
var DESCRIPTORES_MOUTHFEEL = [
  "\xC1spero (arenoso, rugoso)",
  "Aceitoso",
  "Suave (aterciopelado, sedoso)",
  "Astringente (deja seca la boca)",
  "Met\xE1lico"
];
var TIPOS_DEFECTO = ["Mohoso / Terroso", "Fen\xF3lico", "Papa", "Papel / Mohoso", "Qu\xEDmico"];
var ETIQUETAS_HEDONICAS = {
  1: "Extremadamente baja",
  2: "Muy baja",
  3: "Moderadamente baja",
  4: "Ligeramente baja",
  5: "Ni alto ni bajo",
  6: "Ligeramente alta",
  7: "Moderadamente alta",
  8: "Muy alta",
  9: "Extremadamente alta"
};

export {
  RUEDA_SABORES,
  DESCRIPTORES_MOUTHFEEL,
  TIPOS_DEFECTO,
  ETIQUETAS_HEDONICAS
};
//# debugId=718a5d57-48b1-5dc5-8721-0d2092ffd7c2
//# sourceMappingURL=chunk-ECLBRM7C.js.map
