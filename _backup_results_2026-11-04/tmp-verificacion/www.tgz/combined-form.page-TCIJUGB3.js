import {
  BaseCataForm,
  EstadoFichaComponent
} from "./chunk-NSTJCVOE.js";
import "./chunk-NM5KBNCZ.js";
import {
  DESCRIPTORES_MOUTHFEEL,
  ETIQUETAS_HEDONICAS,
  RUEDA_SABORES,
  TIPOS_DEFECTO
} from "./chunk-ECLBRM7C.js";
import "./chunk-DLWN5DPS.js";
import "./chunk-BHVR7Z6N.js";
import {
  arrowBackOutline,
  chevronDownOutline,
  chevronForwardOutline,
  documentTextOutline,
  lockClosedOutline
} from "./chunk-IN4O4X7H.js";
import "./chunk-OFWJO6PD.js";
import {
  addIcons
} from "./chunk-4JFQPQWK.js";
import "./chunk-JH4CNQSM.js";
import {
  AlertController,
  CommonModule,
  Component,
  DecimalPipe,
  DefaultValueAccessor,
  FormsModule,
  IonContent,
  IonIcon,
  NgClass,
  NgControlStatus,
  NgForOf,
  NgIf,
  NgModel,
  RangeValueAccessor,
  inject,
  setClassMetadata,
  ɵsetClassDebugInfo,
  ɵɵInheritDefinitionFeature,
  ɵɵadvance,
  ɵɵconditional,
  ɵɵconditionalCreate,
  ɵɵcontrol,
  ɵɵcontrolCreate,
  ɵɵdefineComponent,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵgetInheritedFactory,
  ɵɵlistener,
  ɵɵnextContext,
  ɵɵpipe,
  ɵɵpipeBind2,
  ɵɵproperty,
  ɵɵpureFunction0,
  ɵɵpureFunction1,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵstyleProp,
  ɵɵtemplate,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1,
  ɵɵtwoWayBindingSet,
  ɵɵtwoWayListener,
  ɵɵtwoWayProperty
} from "./chunk-DEQWXDMW.js";
import "./chunk-BMQUG2PJ.js";
import "./chunk-3OZZMUVI.js";
import "./chunk-3GAB7GSC.js";
import "./chunk-B7Y4FMY7.js";
import "./chunk-NQCL7WZ3.js";
import "./chunk-4BTEZGN2.js";
import "./chunk-XTVSKRH4.js";
import "./chunk-ETZFPO3Y.js";
import "./chunk-LLS636HS.js";
import "./chunk-KQQH3YTO.js";
import "./chunk-DI3VEDFV.js";
import "./chunk-PAXKX5KU.js";

// src/app/pages/evaluation/combined-form/combined-form.page.ts
var _c0 = () => [1, 2, 3, 4, 5, 6, 7, 8, 9];
var _c1 = (a0) => ({ "hedonic-buttons__btn--active": a0 });
var _c2 = (a0) => ({ "flavor-tree__descriptor-btn--selected": a0 });
function CombinedFormPage_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 2);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx);
  }
}
function CombinedFormPage_button_56_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 77);
    \u0275\u0275listener("click", function CombinedFormPage_button_56_Template_button_click_0_listener() {
      const i_r2 = \u0275\u0275restoreView(_r1).$implicit;
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.seleccionarCalidad("fragancia", i_r2));
    });
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const i_r2 = ctx.$implicit;
    const ctx_r2 = \u0275\u0275nextContext();
    \u0275\u0275property("ngClass", \u0275\u0275pureFunction1(2, _c1, ctx_r2.formulario.atributos.fragancia.calidad === i_r2));
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", i_r2, " ");
  }
}
function CombinedFormPage_div_60_span_6_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "span", 85);
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r2 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", ctx_r2.formulario.atributos.fragancia.descriptores.length, " ");
  }
}
function CombinedFormPage_div_60_div_7_button_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r6 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 88);
    \u0275\u0275listener("click", function CombinedFormPage_div_60_div_7_button_1_Template_button_click_0_listener() {
      const sub_r7 = \u0275\u0275restoreView(_r6).$implicit;
      const ctx_r2 = \u0275\u0275nextContext(3);
      return \u0275\u0275resetView(ctx_r2.toggleDescriptor("fragancia", sub_r7));
    });
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const sub_r7 = ctx.$implicit;
    const cat_r5 = \u0275\u0275nextContext(2).$implicit;
    const ctx_r2 = \u0275\u0275nextContext();
    \u0275\u0275styleProp("background", ctx_r2.isDescriptorSelected("fragancia", sub_r7) ? ctx_r2.ruedaSabores[cat_r5].color : "")("color", ctx_r2.isDescriptorSelected("fragancia", sub_r7) ? "white" : "");
    \u0275\u0275property("ngClass", \u0275\u0275pureFunction1(6, _c2, ctx_r2.isDescriptorSelected("fragancia", sub_r7)));
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", sub_r7, " ");
  }
}
function CombinedFormPage_div_60_div_7_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 86);
    \u0275\u0275template(1, CombinedFormPage_div_60_div_7_button_1_Template, 2, 8, "button", 87);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const cat_r5 = \u0275\u0275nextContext().$implicit;
    const ctx_r2 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275property("ngForOf", ctx_r2.ruedaSabores[cat_r5].subdescriptores);
  }
}
function CombinedFormPage_div_60_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 78)(1, "button", 79);
    \u0275\u0275listener("click", function CombinedFormPage_div_60_Template_button_click_1_listener() {
      const cat_r5 = \u0275\u0275restoreView(_r4).$implicit;
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.toggleCategoria(cat_r5));
    });
    \u0275\u0275elementStart(2, "span", 80);
    \u0275\u0275element(3, "ion-icon", 81)(4, "span", 82);
    \u0275\u0275text(5);
    \u0275\u0275elementEnd();
    \u0275\u0275template(6, CombinedFormPage_div_60_span_6_Template, 2, 1, "span", 83);
    \u0275\u0275elementEnd();
    \u0275\u0275template(7, CombinedFormPage_div_60_div_7_Template, 2, 1, "div", 84);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const cat_r5 = ctx.$implicit;
    const ctx_r2 = \u0275\u0275nextContext();
    \u0275\u0275advance(3);
    \u0275\u0275property("name", ctx_r2.categoriasAbiertas[cat_r5] ? "chevron-down-outline" : "chevron-forward-outline");
    \u0275\u0275advance();
    \u0275\u0275styleProp("background", ctx_r2.ruedaSabores[cat_r5].color);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", cat_r5, " ");
    \u0275\u0275advance();
    \u0275\u0275property("ngIf", ctx_r2.formulario.atributos.fragancia.descriptores.length > 0 && ctx_r2.categoriasAbiertas[cat_r5]);
    \u0275\u0275advance();
    \u0275\u0275property("ngIf", ctx_r2.categoriasAbiertas[cat_r5]);
  }
}
function CombinedFormPage_button_85_Template(rf, ctx) {
  if (rf & 1) {
    const _r8 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 77);
    \u0275\u0275listener("click", function CombinedFormPage_button_85_Template_button_click_0_listener() {
      const i_r9 = \u0275\u0275restoreView(_r8).$implicit;
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.seleccionarCalidad("aroma", i_r9));
    });
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const i_r9 = ctx.$implicit;
    const ctx_r2 = \u0275\u0275nextContext();
    \u0275\u0275property("ngClass", \u0275\u0275pureFunction1(2, _c1, ctx_r2.formulario.atributos.aroma.calidad === i_r9));
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(i_r9);
  }
}
function CombinedFormPage_button_109_Template(rf, ctx) {
  if (rf & 1) {
    const _r10 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 77);
    \u0275\u0275listener("click", function CombinedFormPage_button_109_Template_button_click_0_listener() {
      const i_r11 = \u0275\u0275restoreView(_r10).$implicit;
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.seleccionarCalidad("sabor", i_r11));
    });
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const i_r11 = ctx.$implicit;
    const ctx_r2 = \u0275\u0275nextContext();
    \u0275\u0275property("ngClass", \u0275\u0275pureFunction1(2, _c1, ctx_r2.formulario.atributos.sabor.calidad === i_r11));
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(i_r11);
  }
}
function CombinedFormPage_button_133_Template(rf, ctx) {
  if (rf & 1) {
    const _r12 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 77);
    \u0275\u0275listener("click", function CombinedFormPage_button_133_Template_button_click_0_listener() {
      const i_r13 = \u0275\u0275restoreView(_r12).$implicit;
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.seleccionarCalidad("saborResidual", i_r13));
    });
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const i_r13 = ctx.$implicit;
    const ctx_r2 = \u0275\u0275nextContext();
    \u0275\u0275property("ngClass", \u0275\u0275pureFunction1(2, _c1, ctx_r2.formulario.atributos.saborResidual.calidad === i_r13));
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(i_r13);
  }
}
function CombinedFormPage_button_157_Template(rf, ctx) {
  if (rf & 1) {
    const _r14 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 77);
    \u0275\u0275listener("click", function CombinedFormPage_button_157_Template_button_click_0_listener() {
      const i_r15 = \u0275\u0275restoreView(_r14).$implicit;
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.seleccionarCalidad("acidez", i_r15));
    });
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const i_r15 = ctx.$implicit;
    const ctx_r2 = \u0275\u0275nextContext();
    \u0275\u0275property("ngClass", \u0275\u0275pureFunction1(2, _c1, ctx_r2.formulario.atributos.acidez.calidad === i_r15));
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(i_r15);
  }
}
function CombinedFormPage_button_181_Template(rf, ctx) {
  if (rf & 1) {
    const _r16 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 77);
    \u0275\u0275listener("click", function CombinedFormPage_button_181_Template_button_click_0_listener() {
      const i_r17 = \u0275\u0275restoreView(_r16).$implicit;
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.seleccionarCalidad("dulzor", i_r17));
    });
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const i_r17 = ctx.$implicit;
    const ctx_r2 = \u0275\u0275nextContext();
    \u0275\u0275property("ngClass", \u0275\u0275pureFunction1(2, _c1, ctx_r2.formulario.atributos.dulzor.calidad === i_r17));
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(i_r17);
  }
}
function CombinedFormPage_button_205_Template(rf, ctx) {
  if (rf & 1) {
    const _r18 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 77);
    \u0275\u0275listener("click", function CombinedFormPage_button_205_Template_button_click_0_listener() {
      const i_r19 = \u0275\u0275restoreView(_r18).$implicit;
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.seleccionarCalidad("sensacionEnBoca", i_r19));
    });
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const i_r19 = ctx.$implicit;
    const ctx_r2 = \u0275\u0275nextContext();
    \u0275\u0275property("ngClass", \u0275\u0275pureFunction1(2, _c1, ctx_r2.formulario.atributos.sensacionEnBoca.calidad === i_r19));
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(i_r19);
  }
}
function CombinedFormPage_label_210_Template(rf, ctx) {
  if (rf & 1) {
    const _r20 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "label", 89)(1, "input", 90);
    \u0275\u0275listener("change", function CombinedFormPage_label_210_Template_input_change_1_listener() {
      const opcion_r21 = \u0275\u0275restoreView(_r20).$implicit;
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.toggleMouthfeel(opcion_r21));
    });
    \u0275\u0275elementEnd();
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const opcion_r21 = ctx.$implicit;
    const ctx_r2 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275property("checked", ctx_r2.formulario.mouthfeel.includes(opcion_r21));
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", opcion_r21, " ");
  }
}
function CombinedFormPage_button_223_Template(rf, ctx) {
  if (rf & 1) {
    const _r22 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 77);
    \u0275\u0275listener("click", function CombinedFormPage_button_223_Template_button_click_0_listener() {
      const i_r23 = \u0275\u0275restoreView(_r22).$implicit;
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.seleccionarCalidad("impresionGlobal", i_r23));
    });
    \u0275\u0275text(1);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const i_r23 = ctx.$implicit;
    const ctx_r2 = \u0275\u0275nextContext();
    \u0275\u0275property("ngClass", \u0275\u0275pureFunction1(2, _c1, ctx_r2.formulario.impresionGlobal === i_r23));
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(i_r23);
  }
}
function CombinedFormPage_label_274_Template(rf, ctx) {
  if (rf & 1) {
    const _r24 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "label", 91)(1, "input", 90);
    \u0275\u0275listener("change", function CombinedFormPage_label_274_Template_input_change_1_listener() {
      const tipo_r25 = \u0275\u0275restoreView(_r24).$implicit;
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.toggleTipoDefecto(tipo_r25));
    });
    \u0275\u0275elementEnd();
    \u0275\u0275text(2);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const tipo_r25 = ctx.$implicit;
    const ctx_r2 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275property("checked", ctx_r2.formulario.tiposDefecto.includes(tipo_r25));
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", tipo_r25, " ");
  }
}
function CombinedFormPage_button_281_Template(rf, ctx) {
  if (rf & 1) {
    const _r26 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "button", 92);
    \u0275\u0275listener("click", function CombinedFormPage_button_281_Template_button_click_0_listener() {
      \u0275\u0275restoreView(_r26);
      const ctx_r2 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r2.irAMuestraAnterior());
    });
    \u0275\u0275text(1, " \u2190 Anterior ");
    \u0275\u0275elementEnd();
  }
}
addIcons({
  arrowBackOutline,
  chevronDownOutline,
  chevronForwardOutline,
  documentTextOutline,
  lockClosedOutline
});
var _CombinedFormPage = class _CombinedFormPage extends BaseCataForm {
  constructor() {
    super(...arguments);
    this.categoriasAbiertas = { "Floral": true, "Nueces / Cacao": true };
    this.ruedaKeys = Object.keys(RUEDA_SABORES);
    this.ruedaSabores = RUEDA_SABORES;
    this.mouthfeelOptions = DESCRIPTORES_MOUTHFEEL;
    this.defectosOptions = TIPOS_DEFECTO;
    this.etiquetas = ETIQUETAS_HEDONICAS;
    this.alertCtrl = inject(AlertController);
    this.formulario = this.crearFormularioVacio();
  }
  crearFormularioVacio() {
    return {
      atributos: {
        fragancia: { intensidad: 0, calidad: 0, descriptores: [], extra: "" },
        aroma: { intensidad: 0, calidad: 0, descriptores: [], extra: "" },
        sabor: { intensidad: 0, calidad: 0, descriptores: [], extra: "" },
        saborResidual: { intensidad: 0, calidad: 0, descriptores: [], extra: "" },
        acidez: { intensidad: 0, calidad: 0 },
        dulzor: { intensidad: 0, calidad: 0 },
        sensacionEnBoca: { intensidad: 0, calidad: 0 }
      },
      impresionGlobal: 0,
      mouthfeel: [],
      notasMouthfeel: "",
      defectos: { tazasNoUniformes: 0, tazasDefectuosas: 0 },
      tiposDefecto: [],
      notas: ""
    };
  }
  get puntaje() {
    const a = this.formulario.atributos;
    const calidades = [
      a.fragancia.calidad,
      a.aroma.calidad,
      a.sabor.calidad,
      a.saborResidual.calidad,
      a.acidez.calidad,
      a.dulzor.calidad,
      a.sensacionEnBoca.calidad,
      this.formulario.impresionGlobal
    ];
    if (calidades.some((calidad) => calidad < 1 || calidad > 9))
      return null;
    const sumaHedonicos = a.fragancia.calidad + a.aroma.calidad + a.sabor.calidad + a.saborResidual.calidad + a.acidez.calidad + a.dulzor.calidad + a.sensacionEnBoca.calidad + this.formulario.impresionGlobal;
    const penalizacion = 2 * this.formulario.defectos.tazasNoUniformes + 4 * this.totalTazasDefectuosas;
    const calculo = 0.65625 * sumaHedonicos + 52.75 - penalizacion;
    const redondeado = Math.round(calculo * 4) / 4;
    return Math.max(0, Math.min(100, redondeado));
  }
  get penalizacionTotal() {
    return 2 * this.formulario.defectos.tazasNoUniformes + 4 * this.totalTazasDefectuosas;
  }
  get totalTazasDefectuosas() {
    return Math.max(this.formulario.defectos.tazasDefectuosas, this.formulario.tiposDefecto.length > 0 ? 1 : 0);
  }
  get clasificacion() {
    const p = this.puntaje;
    if (p === null)
      return { label: "Pendiente", color: "#6c757d", bg: "#f8f9fa", border: "#dee2e6" };
    if (p >= 90)
      return { label: "Excepcional", color: "#15803d", bg: "#f0fdf4", border: "#bbf7d0" };
    if (p >= 85)
      return { label: "Excelente", color: "#1d4ed8", bg: "#eff6ff", border: "#bfdbfe" };
    if (p >= 80)
      return { label: "Muy bueno", color: "#a16207", bg: "#fefce8", border: "#fef08a" };
    if (p >= 75)
      return { label: "Bueno", color: "#c2410c", bg: "#fff7ed", border: "#fed7aa" };
    return { label: "Regular", color: "#6c757d", bg: "#f8f9fa", border: "#dee2e6" };
  }
  // --- MÉTODOS DE INTERACCIÓN ---
  seleccionarCalidad(atributo, valor) {
    if (atributo === "impresionGlobal") {
      this.formulario.impresionGlobal = valor;
    } else {
      this.formulario.atributos[atributo].calidad = valor;
    }
  }
  toggleCategoria(cat) {
    this.categoriasAbiertas[cat] = !this.categoriasAbiertas[cat];
  }
  toggleDescriptor(atributo, descriptor) {
    const lista = this.formulario.atributos[atributo].descriptores;
    if (lista.includes(descriptor)) {
      this.formulario.atributos[atributo].descriptores = lista.filter((d) => d !== descriptor);
    } else {
      this.formulario.atributos[atributo].descriptores.push(descriptor);
    }
  }
  isDescriptorSelected(atributo, descriptor) {
    return this.formulario.atributos[atributo].descriptores.includes(descriptor);
  }
  toggleMouthfeel(opcion) {
    if (this.formulario.mouthfeel.includes(opcion)) {
      this.formulario.mouthfeel = this.formulario.mouthfeel.filter((o) => o !== opcion);
    } else {
      this.formulario.mouthfeel.push(opcion);
    }
  }
  toggleTipoDefecto(opcion) {
    if (this.formulario.tiposDefecto.includes(opcion)) {
      this.formulario.tiposDefecto = this.formulario.tiposDefecto.filter((o) => o !== opcion);
    } else {
      this.formulario.tiposDefecto.push(opcion);
    }
  }
  ajustarDefecto(tipo, operacion) {
    if (tipo === "uniformes") {
      let val = this.formulario.defectos.tazasNoUniformes;
      this.formulario.defectos.tazasNoUniformes = operacion === "sumar" ? Math.min(5, val + 1) : Math.max(0, val - 1);
    } else {
      let val = this.formulario.defectos.tazasDefectuosas;
      this.formulario.defectos.tazasDefectuosas = operacion === "sumar" ? Math.min(5, val + 1) : Math.max(0, val - 1);
    }
  }
  async finalizarCata() {
    const incompletas = this.respuestas.filter((respuesta, indice) => !this.muestrasCerradas().has(indice + 1) && !this.esRespuestaCompleta(respuesta)).length;
    if (incompletas > 0) {
      const alert2 = await this.alertCtrl.create({
        header: "Cata incompleta",
        message: `A\xFAn tienes ${incompletas} muestra(s) sin calificar todos los atributos. Revisa todas las muestras antes de terminar.`,
        buttons: ["Entendido"]
      });
      await alert2.present();
      return;
    }
    const alert = await this.alertCtrl.create({
      header: "Finalizar cata",
      message: "Se guardar\xE1n las respuestas de todas las muestras antes de finalizar.",
      buttons: [
        { text: "Seguir evaluando", role: "cancel" },
        {
          text: "Guardar y finalizar",
          handler: () => this.finalizarYGuardar()
        }
      ]
    });
    await alert.present();
  }
  async finalizarYGuardar() {
    await super.finalizarCata();
  }
  calcularPuntajeFinal(respuesta) {
    const atributos = respuesta.atributos;
    const calidades = [
      atributos.fragancia.calidad,
      atributos.aroma.calidad,
      atributos.sabor.calidad,
      atributos.saborResidual.calidad,
      atributos.acidez.calidad,
      atributos.dulzor.calidad,
      atributos.sensacionEnBoca.calidad,
      respuesta.impresionGlobal
    ];
    if (calidades.some((calidad) => !Number.isInteger(calidad) || calidad < 1 || calidad > 9)) {
      return null;
    }
    const suma = calidades.reduce((total, calidad) => total + calidad, 0);
    const tazasDefectuosas = Math.max(respuesta.defectos.tazasDefectuosas, respuesta.tiposDefecto.length > 0 ? 1 : 0);
    const puntaje = 0.65625 * suma + 52.75 - 2 * respuesta.defectos.tazasNoUniformes - 4 * tazasDefectuosas;
    return Math.max(0, Math.min(100, Math.round(puntaje * 4) / 4));
  }
  esRespuestaCompleta(respuesta) {
    const atributos = respuesta.atributos;
    return ![
      atributos.fragancia.calidad,
      atributos.aroma.calidad,
      atributos.sabor.calidad,
      atributos.saborResidual.calidad,
      atributos.acidez.calidad,
      atributos.dulzor.calidad,
      atributos.sensacionEnBoca.calidad,
      respuesta.impresionGlobal
    ].some((calidad) => !Number.isInteger(calidad) || calidad < 1 || calidad > 9);
  }
  async mostrarAvisoCalificacionIncompleta() {
    await this.mostrarToast("Por favor, califica todos los atributos de esta muestra antes de continuar.", "warning");
  }
};
_CombinedFormPage.\u0275fac = /* @__PURE__ */ (() => {
  let \u0275CombinedFormPage_BaseFactory;
  return function CombinedFormPage_Factory(__ngFactoryType__) {
    return (\u0275CombinedFormPage_BaseFactory || (\u0275CombinedFormPage_BaseFactory = \u0275\u0275getInheritedFactory(_CombinedFormPage)))(__ngFactoryType__ || _CombinedFormPage);
  };
})();
_CombinedFormPage.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _CombinedFormPage, selectors: [["app-combined-form"]], features: [\u0275\u0275InheritDefinitionFeature], decls: 284, vars: 104, consts: [[1, "cva-combined", 3, "scrollY"], [3, "reintentar", "salir", "pendientes", "enLinea", "muestraCerrada", "rechazo", "esperandoFinalizar"], ["role", "alert", 1, "evaluation-error"], [1, "cva-header"], [1, "cva-header__inner"], [1, "cva-header__left"], [1, "cva-header__back-btn", 3, "click"], ["name", "arrow-back-outline"], [1, "cva-header__meta"], [1, "cva-header__session-name"], [1, "cva-header__sample-label"], [1, "cva-header__right"], [1, "cva-header__blind-badge"], ["name", "lock-closed-outline"], [1, "cva-header__format-badge"], [1, "cva-header__live-score"], [1, "cva-header__live-score-label"], [1, "cva-header__live-score-value"], [1, "cva-header__progress-bar-wrap"], [1, "cva-header__progress-bar"], [1, "cva-header__progress-bar-fill"], [1, "cva-main"], [1, "cva-main__grid"], [1, "cva-main__column"], [1, "attr-card"], [1, "attr-card__title"], [1, "intensity-slider"], [1, "intensity-slider__header"], [1, "intensity-slider__label"], [1, "intensity-slider__value"], [1, "intensity-slider__track"], [1, "intensity-slider__endpoint"], ["type", "range", "min", "0", "max", "15", "step", "0.5", 1, "intensity-slider__input", 3, "ngModelChange", "ngModel"], [1, "hedonic-buttons"], [1, "hedonic-buttons__header"], [1, "hedonic-buttons__label"], [1, "hedonic-buttons__descriptor"], [1, "hedonic-buttons__grid"], ["class", "hedonic-buttons__btn", 3, "ngClass", "click", 4, "ngFor", "ngForOf"], [1, "flavor-tree"], [1, "flavor-tree__section-label"], ["class", "flavor-tree__category", 4, "ngFor", "ngForOf"], ["type", "text", "aria-label", "Descriptor personalizado para fragancia", "placeholder", "Agregar descriptor personalizado...", 1, "extra-descriptor", 3, "ngModelChange", "ngModel"], [1, "mouthfeel"], [1, "mouthfeel__list"], ["class", "mouthfeel__item", 4, "ngFor", "ngForOf"], [2, "font-size", "12px", "color", "var(--gray-500)", "margin-bottom", "16px"], [1, "cva-main__sidebar"], [1, "score-panel"], [1, "score-panel__label"], [1, "score-panel__value"], [1, "score-panel__classification"], [1, "score-panel__formula"], [1, "defect-panel"], [1, "label-micro", 2, "display", "block", "margin-bottom", "16px"], [1, "defect-counter"], [1, "defect-counter__info"], [1, "defect-counter__label"], [1, "defect-counter__sublabel"], [1, "defect-counter__controls"], [1, "defect-counter__btn", 3, "click"], [1, "defect-counter__value"], [1, "defect-counter", 2, "margin-top", "16px"], [1, "defect-penalty"], [1, "defect-penalty__label"], [1, "defect-penalty__value"], [1, "defect-types"], [1, "defect-types__label"], [1, "defect-types__hint"], ["class", "defect-types__item", 4, "ngFor", "ngForOf"], [1, "notes-panel"], [1, "notes-panel__header"], ["name", "document-text-outline"], ["rows", "5", "placeholder", "Observaciones...", 1, "notes-panel__textarea", 3, "ngModelChange", "ngModel"], [1, "sample-navigation"], ["type", "button", "class", "submit-btn sample-navigation__previous", 3, "click", 4, "ngIf"], ["type", "button", 1, "submit-btn", 3, "click", "disabled"], [1, "hedonic-buttons__btn", 3, "click", "ngClass"], [1, "flavor-tree__category"], [1, "flavor-tree__category-btn", 3, "click"], [1, "flavor-tree__category-left"], [1, "flavor-tree__chevron", 3, "name"], [1, "flavor-tree__swatch"], ["class", "flavor-tree__count-badge", 4, "ngIf"], ["class", "flavor-tree__sub-list", 4, "ngIf"], [1, "flavor-tree__count-badge"], [1, "flavor-tree__sub-list"], ["class", "flavor-tree__descriptor-btn", 3, "ngClass", "background", "color", "click", 4, "ngFor", "ngForOf"], [1, "flavor-tree__descriptor-btn", 3, "click", "ngClass"], [1, "mouthfeel__item"], ["type", "checkbox", 3, "change", "checked"], [1, "defect-types__item"], ["type", "button", 1, "submit-btn", "sample-navigation__previous", 3, "click"]], template: function CombinedFormPage_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-content", 0)(1, "app-estado-ficha", 1);
    \u0275\u0275listener("reintentar", function CombinedFormPage_Template_app_estado_ficha_reintentar_1_listener() {
      return ctx.reintentarSincronizacion();
    })("salir", function CombinedFormPage_Template_app_estado_ficha_salir_1_listener() {
      return ctx.salirConPendientes();
    });
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(2, CombinedFormPage_Conditional_2_Template, 2, 1, "div", 2);
    \u0275\u0275elementStart(3, "header", 3)(4, "div", 4)(5, "div", 5)(6, "button", 6);
    \u0275\u0275listener("click", function CombinedFormPage_Template_button_click_6_listener() {
      return ctx.volver();
    });
    \u0275\u0275element(7, "ion-icon", 7);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "div", 8)(9, "p", 9);
    \u0275\u0275text(10, "Evaluaci\xF3n Combinada");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(11, "p", 10);
    \u0275\u0275text(12);
    \u0275\u0275elementStart(13, "span");
    \u0275\u0275text(14);
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(15, "div", 11)(16, "div", 12);
    \u0275\u0275element(17, "ion-icon", 13);
    \u0275\u0275text(18, " Ciego ");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(19, "span", 14);
    \u0275\u0275text(20, "Combinado");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(21, "div", 15)(22, "span", 16);
    \u0275\u0275text(23, "CVA");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(24, "span", 17);
    \u0275\u0275text(25);
    \u0275\u0275pipe(26, "number");
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(27, "div", 18)(28, "div", 19);
    \u0275\u0275element(29, "div", 20);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(30, "main", 21)(31, "div", 22)(32, "div", 23)(33, "article", 24)(34, "h3", 25);
    \u0275\u0275text(35, "Fragancia");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(36, "div", 26)(37, "div", 27)(38, "span", 28);
    \u0275\u0275text(39, "Intensidad f\xEDsica");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(40, "span", 29);
    \u0275\u0275text(41);
    \u0275\u0275pipe(42, "number");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(43, "div", 30)(44, "span", 31);
    \u0275\u0275text(45, "Baja");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(46, "input", 32);
    \u0275\u0275twoWayListener("ngModelChange", function CombinedFormPage_Template_input_ngModelChange_46_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.formulario.atributos.fragancia.intensidad, $event) || (ctx.formulario.atributos.fragancia.intensidad = $event);
      return $event;
    });
    \u0275\u0275elementEnd();
    \u0275\u0275controlCreate();
    \u0275\u0275elementStart(47, "span", 31);
    \u0275\u0275text(48, "Alta");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(49, "div", 33)(50, "div", 34)(51, "span", 35);
    \u0275\u0275text(52, "Calidad hed\xF3nica");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(53, "span", 36);
    \u0275\u0275text(54);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(55, "div", 37);
    \u0275\u0275template(56, CombinedFormPage_button_56_Template, 2, 4, "button", 38);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(57, "div", 39)(58, "p", 40);
    \u0275\u0275text(59, "Descriptores arom\xE1ticos");
    \u0275\u0275elementEnd();
    \u0275\u0275template(60, CombinedFormPage_div_60_Template, 8, 6, "div", 41);
    \u0275\u0275elementStart(61, "input", 42);
    \u0275\u0275twoWayListener("ngModelChange", function CombinedFormPage_Template_input_ngModelChange_61_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.formulario.atributos.fragancia.extra, $event) || (ctx.formulario.atributos.fragancia.extra = $event);
      return $event;
    });
    \u0275\u0275elementEnd();
    \u0275\u0275controlCreate();
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(62, "article", 24)(63, "h3", 25);
    \u0275\u0275text(64, "Aroma (en taza)");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(65, "div", 26)(66, "div", 27)(67, "span", 28);
    \u0275\u0275text(68, "Intensidad f\xEDsica");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(69, "span", 29);
    \u0275\u0275text(70);
    \u0275\u0275pipe(71, "number");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(72, "div", 30)(73, "span", 31);
    \u0275\u0275text(74, "Baja");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(75, "input", 32);
    \u0275\u0275twoWayListener("ngModelChange", function CombinedFormPage_Template_input_ngModelChange_75_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.formulario.atributos.aroma.intensidad, $event) || (ctx.formulario.atributos.aroma.intensidad = $event);
      return $event;
    });
    \u0275\u0275elementEnd();
    \u0275\u0275controlCreate();
    \u0275\u0275elementStart(76, "span", 31);
    \u0275\u0275text(77, "Alta");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(78, "div", 33)(79, "div", 34)(80, "span", 35);
    \u0275\u0275text(81, "Calidad hed\xF3nica");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(82, "span", 36);
    \u0275\u0275text(83);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(84, "div", 37);
    \u0275\u0275template(85, CombinedFormPage_button_85_Template, 2, 4, "button", 38);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(86, "article", 24)(87, "h3", 25);
    \u0275\u0275text(88, "Sabor");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(89, "div", 26)(90, "div", 27)(91, "span", 28);
    \u0275\u0275text(92, "Intensidad f\xEDsica");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(93, "span", 29);
    \u0275\u0275text(94);
    \u0275\u0275pipe(95, "number");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(96, "div", 30)(97, "span", 31);
    \u0275\u0275text(98, "Baja");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(99, "input", 32);
    \u0275\u0275twoWayListener("ngModelChange", function CombinedFormPage_Template_input_ngModelChange_99_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.formulario.atributos.sabor.intensidad, $event) || (ctx.formulario.atributos.sabor.intensidad = $event);
      return $event;
    });
    \u0275\u0275elementEnd();
    \u0275\u0275controlCreate();
    \u0275\u0275elementStart(100, "span", 31);
    \u0275\u0275text(101, "Alta");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(102, "div", 33)(103, "div", 34)(104, "span", 35);
    \u0275\u0275text(105, "Calidad hed\xF3nica");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(106, "span", 36);
    \u0275\u0275text(107);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(108, "div", 37);
    \u0275\u0275template(109, CombinedFormPage_button_109_Template, 2, 4, "button", 38);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(110, "article", 24)(111, "h3", 25);
    \u0275\u0275text(112, "Sabor Residual");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(113, "div", 26)(114, "div", 27)(115, "span", 28);
    \u0275\u0275text(116, "Intensidad f\xEDsica");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(117, "span", 29);
    \u0275\u0275text(118);
    \u0275\u0275pipe(119, "number");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(120, "div", 30)(121, "span", 31);
    \u0275\u0275text(122, "Baja");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(123, "input", 32);
    \u0275\u0275twoWayListener("ngModelChange", function CombinedFormPage_Template_input_ngModelChange_123_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.formulario.atributos.saborResidual.intensidad, $event) || (ctx.formulario.atributos.saborResidual.intensidad = $event);
      return $event;
    });
    \u0275\u0275elementEnd();
    \u0275\u0275controlCreate();
    \u0275\u0275elementStart(124, "span", 31);
    \u0275\u0275text(125, "Alta");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(126, "div", 33)(127, "div", 34)(128, "span", 35);
    \u0275\u0275text(129, "Calidad hed\xF3nica");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(130, "span", 36);
    \u0275\u0275text(131);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(132, "div", 37);
    \u0275\u0275template(133, CombinedFormPage_button_133_Template, 2, 4, "button", 38);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(134, "article", 24)(135, "h3", 25);
    \u0275\u0275text(136, "Acidez");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(137, "div", 26)(138, "div", 27)(139, "span", 28);
    \u0275\u0275text(140, "Intensidad f\xEDsica");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(141, "span", 29);
    \u0275\u0275text(142);
    \u0275\u0275pipe(143, "number");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(144, "div", 30)(145, "span", 31);
    \u0275\u0275text(146, "Baja");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(147, "input", 32);
    \u0275\u0275twoWayListener("ngModelChange", function CombinedFormPage_Template_input_ngModelChange_147_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.formulario.atributos.acidez.intensidad, $event) || (ctx.formulario.atributos.acidez.intensidad = $event);
      return $event;
    });
    \u0275\u0275elementEnd();
    \u0275\u0275controlCreate();
    \u0275\u0275elementStart(148, "span", 31);
    \u0275\u0275text(149, "Alta");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(150, "div", 33)(151, "div", 34)(152, "span", 35);
    \u0275\u0275text(153, "Calidad hed\xF3nica");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(154, "span", 36);
    \u0275\u0275text(155);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(156, "div", 37);
    \u0275\u0275template(157, CombinedFormPage_button_157_Template, 2, 4, "button", 38);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(158, "article", 24)(159, "h3", 25);
    \u0275\u0275text(160, "Dulzor");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(161, "div", 26)(162, "div", 27)(163, "span", 28);
    \u0275\u0275text(164, "Intensidad f\xEDsica");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(165, "span", 29);
    \u0275\u0275text(166);
    \u0275\u0275pipe(167, "number");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(168, "div", 30)(169, "span", 31);
    \u0275\u0275text(170, "Baja");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(171, "input", 32);
    \u0275\u0275twoWayListener("ngModelChange", function CombinedFormPage_Template_input_ngModelChange_171_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.formulario.atributos.dulzor.intensidad, $event) || (ctx.formulario.atributos.dulzor.intensidad = $event);
      return $event;
    });
    \u0275\u0275elementEnd();
    \u0275\u0275controlCreate();
    \u0275\u0275elementStart(172, "span", 31);
    \u0275\u0275text(173, "Alta");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(174, "div", 33)(175, "div", 34)(176, "span", 35);
    \u0275\u0275text(177, "Calidad hed\xF3nica");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(178, "span", 36);
    \u0275\u0275text(179);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(180, "div", 37);
    \u0275\u0275template(181, CombinedFormPage_button_181_Template, 2, 4, "button", 38);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(182, "article", 24)(183, "h3", 25);
    \u0275\u0275text(184, "Sensaci\xF3n en Boca");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(185, "div", 26)(186, "div", 27)(187, "span", 28);
    \u0275\u0275text(188, "Intensidad f\xEDsica");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(189, "span", 29);
    \u0275\u0275text(190);
    \u0275\u0275pipe(191, "number");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(192, "div", 30)(193, "span", 31);
    \u0275\u0275text(194, "Baja");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(195, "input", 32);
    \u0275\u0275twoWayListener("ngModelChange", function CombinedFormPage_Template_input_ngModelChange_195_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.formulario.atributos.sensacionEnBoca.intensidad, $event) || (ctx.formulario.atributos.sensacionEnBoca.intensidad = $event);
      return $event;
    });
    \u0275\u0275elementEnd();
    \u0275\u0275controlCreate();
    \u0275\u0275elementStart(196, "span", 31);
    \u0275\u0275text(197, "Alta");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(198, "div", 33)(199, "div", 34)(200, "span", 35);
    \u0275\u0275text(201, "Calidad hed\xF3nica");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(202, "span", 36);
    \u0275\u0275text(203);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(204, "div", 37);
    \u0275\u0275template(205, CombinedFormPage_button_205_Template, 2, 4, "button", 38);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(206, "div", 43)(207, "p", 40);
    \u0275\u0275text(208, "Descriptores t\xE1ctiles");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(209, "div", 44);
    \u0275\u0275template(210, CombinedFormPage_label_210_Template, 3, 2, "label", 45);
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(211, "article", 24)(212, "h3", 25);
    \u0275\u0275text(213, "Impresi\xF3n Global");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(214, "p", 46);
    \u0275\u0275text(215, "Evaluaci\xF3n hed\xF3nica general de la muestra");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(216, "div", 33)(217, "div", 34)(218, "span", 35);
    \u0275\u0275text(219, "Calidad hed\xF3nica");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(220, "span", 36);
    \u0275\u0275text(221);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(222, "div", 37);
    \u0275\u0275template(223, CombinedFormPage_button_223_Template, 2, 4, "button", 38);
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(224, "aside", 47)(225, "div", 48)(226, "span", 49);
    \u0275\u0275text(227, "Puntaje CVA");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(228, "span", 50);
    \u0275\u0275text(229);
    \u0275\u0275pipe(230, "number");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(231, "span", 51);
    \u0275\u0275text(232);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(233, "p", 52);
    \u0275\u0275text(234, "S = 0.65625 \xD7 \u03A3h\u1D62 + 52.75 \u2212 2u \u2212 4d");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(235, "div", 53)(236, "span", 54);
    \u0275\u0275text(237, "Defectos");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(238, "div", 55)(239, "div", 56)(240, "span", 57);
    \u0275\u0275text(241, "Tazas no uniformes");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(242, "span", 58);
    \u0275\u0275text(243, "\u22122 pts por taza");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(244, "div", 59)(245, "button", 60);
    \u0275\u0275listener("click", function CombinedFormPage_Template_button_click_245_listener() {
      return ctx.ajustarDefecto("uniformes", "restar");
    });
    \u0275\u0275text(246, "\u2212");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(247, "span", 61);
    \u0275\u0275text(248);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(249, "button", 60);
    \u0275\u0275listener("click", function CombinedFormPage_Template_button_click_249_listener() {
      return ctx.ajustarDefecto("uniformes", "sumar");
    });
    \u0275\u0275text(250, "+");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(251, "div", 62)(252, "div", 56)(253, "span", 57);
    \u0275\u0275text(254, "Tazas defectuosas");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(255, "span", 58);
    \u0275\u0275text(256, "\u22124 pts por taza");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(257, "div", 59)(258, "button", 60);
    \u0275\u0275listener("click", function CombinedFormPage_Template_button_click_258_listener() {
      return ctx.ajustarDefecto("defectuosas", "restar");
    });
    \u0275\u0275text(259, "\u2212");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(260, "span", 61);
    \u0275\u0275text(261);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(262, "button", 60);
    \u0275\u0275listener("click", function CombinedFormPage_Template_button_click_262_listener() {
      return ctx.ajustarDefecto("defectuosas", "sumar");
    });
    \u0275\u0275text(263, "+");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(264, "div", 63)(265, "span", 64);
    \u0275\u0275text(266, "Penalizaci\xF3n total");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(267, "span", 65);
    \u0275\u0275text(268);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(269, "div", 66)(270, "span", 67);
    \u0275\u0275text(271, "Tipo de defecto");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(272, "span", 68);
    \u0275\u0275text(273, "Al marcar un tipo se cuenta al menos una taza defectuosa.");
    \u0275\u0275elementEnd();
    \u0275\u0275template(274, CombinedFormPage_label_274_Template, 3, 2, "label", 69);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(275, "div", 70)(276, "div", 71);
    \u0275\u0275element(277, "ion-icon", 72);
    \u0275\u0275text(278, " Notas adicionales ");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(279, "textarea", 73);
    \u0275\u0275twoWayListener("ngModelChange", function CombinedFormPage_Template_textarea_ngModelChange_279_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.formulario.notas, $event) || (ctx.formulario.notas = $event);
      return $event;
    });
    \u0275\u0275elementEnd();
    \u0275\u0275controlCreate();
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(280, "div", 74);
    \u0275\u0275template(281, CombinedFormPage_button_281_Template, 2, 0, "button", 75);
    \u0275\u0275elementStart(282, "button", 76);
    \u0275\u0275listener("click", function CombinedFormPage_Template_button_click_282_listener() {
      return ctx.irAMuestraSiguiente();
    });
    \u0275\u0275text(283);
    \u0275\u0275elementEnd()()()()()();
  }
  if (rf & 2) {
    let tmp_6_0;
    \u0275\u0275property("scrollY", true);
    \u0275\u0275advance();
    \u0275\u0275property("pendientes", ctx.pendientesLocales())("enLinea", ctx.enLinea())("muestraCerrada", ctx.muestraActualCerrada())("rechazo", ctx.rechazoActual())("esperandoFinalizar", ctx.esperandoSincronizacion());
    \u0275\u0275advance();
    \u0275\u0275conditional((tmp_6_0 = ctx.error()) ? 2 : -1, tmp_6_0);
    \u0275\u0275advance(10);
    \u0275\u0275textInterpolate1("Muestra ", ctx.muestraActual(), " ");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1("de ", ctx.totalMuestras());
    \u0275\u0275advance(7);
    \u0275\u0275styleProp("border-color", ctx.clasificacion.border)("background", ctx.clasificacion.bg);
    \u0275\u0275advance(3);
    \u0275\u0275styleProp("color", ctx.clasificacion.color);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", ctx.puntaje === null ? "Pendiente" : \u0275\u0275pipeBind2(26, 69, ctx.puntaje, "1.2-2"), " ");
    \u0275\u0275advance(4);
    \u0275\u0275styleProp("width", ctx.muestraActual() / ctx.totalMuestras() * 100 + "%");
    \u0275\u0275advance(12);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind2(42, 72, ctx.formulario.atributos.fragancia.intensidad, "1.1-1"));
    \u0275\u0275advance(5);
    \u0275\u0275twoWayProperty("ngModel", ctx.formulario.atributos.fragancia.intensidad);
    \u0275\u0275control();
    \u0275\u0275advance(8);
    \u0275\u0275textInterpolate1(" ", ctx.formulario.atributos.fragancia.calidad ? ctx.etiquetas[ctx.formulario.atributos.fragancia.calidad] : "Selecciona una opci\xF3n", " ");
    \u0275\u0275advance(2);
    \u0275\u0275property("ngForOf", \u0275\u0275pureFunction0(96, _c0));
    \u0275\u0275advance(4);
    \u0275\u0275property("ngForOf", ctx.ruedaKeys);
    \u0275\u0275advance();
    \u0275\u0275twoWayProperty("ngModel", ctx.formulario.atributos.fragancia.extra);
    \u0275\u0275control();
    \u0275\u0275advance(9);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind2(71, 75, ctx.formulario.atributos.aroma.intensidad, "1.1-1"));
    \u0275\u0275advance(5);
    \u0275\u0275twoWayProperty("ngModel", ctx.formulario.atributos.aroma.intensidad);
    \u0275\u0275control();
    \u0275\u0275advance(8);
    \u0275\u0275textInterpolate(ctx.formulario.atributos.aroma.calidad ? ctx.etiquetas[ctx.formulario.atributos.aroma.calidad] : "Selecciona una opci\xF3n");
    \u0275\u0275advance(2);
    \u0275\u0275property("ngForOf", \u0275\u0275pureFunction0(97, _c0));
    \u0275\u0275advance(9);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind2(95, 78, ctx.formulario.atributos.sabor.intensidad, "1.1-1"));
    \u0275\u0275advance(5);
    \u0275\u0275twoWayProperty("ngModel", ctx.formulario.atributos.sabor.intensidad);
    \u0275\u0275control();
    \u0275\u0275advance(8);
    \u0275\u0275textInterpolate(ctx.formulario.atributos.sabor.calidad ? ctx.etiquetas[ctx.formulario.atributos.sabor.calidad] : "Selecciona una opci\xF3n");
    \u0275\u0275advance(2);
    \u0275\u0275property("ngForOf", \u0275\u0275pureFunction0(98, _c0));
    \u0275\u0275advance(9);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind2(119, 81, ctx.formulario.atributos.saborResidual.intensidad, "1.1-1"));
    \u0275\u0275advance(5);
    \u0275\u0275twoWayProperty("ngModel", ctx.formulario.atributos.saborResidual.intensidad);
    \u0275\u0275control();
    \u0275\u0275advance(8);
    \u0275\u0275textInterpolate(ctx.formulario.atributos.saborResidual.calidad ? ctx.etiquetas[ctx.formulario.atributos.saborResidual.calidad] : "Selecciona una opci\xF3n");
    \u0275\u0275advance(2);
    \u0275\u0275property("ngForOf", \u0275\u0275pureFunction0(99, _c0));
    \u0275\u0275advance(9);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind2(143, 84, ctx.formulario.atributos.acidez.intensidad, "1.1-1"));
    \u0275\u0275advance(5);
    \u0275\u0275twoWayProperty("ngModel", ctx.formulario.atributos.acidez.intensidad);
    \u0275\u0275control();
    \u0275\u0275advance(8);
    \u0275\u0275textInterpolate(ctx.formulario.atributos.acidez.calidad ? ctx.etiquetas[ctx.formulario.atributos.acidez.calidad] : "Selecciona una opci\xF3n");
    \u0275\u0275advance(2);
    \u0275\u0275property("ngForOf", \u0275\u0275pureFunction0(100, _c0));
    \u0275\u0275advance(9);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind2(167, 87, ctx.formulario.atributos.dulzor.intensidad, "1.1-1"));
    \u0275\u0275advance(5);
    \u0275\u0275twoWayProperty("ngModel", ctx.formulario.atributos.dulzor.intensidad);
    \u0275\u0275control();
    \u0275\u0275advance(8);
    \u0275\u0275textInterpolate(ctx.formulario.atributos.dulzor.calidad ? ctx.etiquetas[ctx.formulario.atributos.dulzor.calidad] : "Selecciona una opci\xF3n");
    \u0275\u0275advance(2);
    \u0275\u0275property("ngForOf", \u0275\u0275pureFunction0(101, _c0));
    \u0275\u0275advance(9);
    \u0275\u0275textInterpolate(\u0275\u0275pipeBind2(191, 90, ctx.formulario.atributos.sensacionEnBoca.intensidad, "1.1-1"));
    \u0275\u0275advance(5);
    \u0275\u0275twoWayProperty("ngModel", ctx.formulario.atributos.sensacionEnBoca.intensidad);
    \u0275\u0275control();
    \u0275\u0275advance(8);
    \u0275\u0275textInterpolate(ctx.formulario.atributos.sensacionEnBoca.calidad ? ctx.etiquetas[ctx.formulario.atributos.sensacionEnBoca.calidad] : "Selecciona una opci\xF3n");
    \u0275\u0275advance(2);
    \u0275\u0275property("ngForOf", \u0275\u0275pureFunction0(102, _c0));
    \u0275\u0275advance(5);
    \u0275\u0275property("ngForOf", ctx.mouthfeelOptions);
    \u0275\u0275advance(11);
    \u0275\u0275textInterpolate(ctx.formulario.impresionGlobal ? ctx.etiquetas[ctx.formulario.impresionGlobal] : "Selecciona una opci\xF3n");
    \u0275\u0275advance(2);
    \u0275\u0275property("ngForOf", \u0275\u0275pureFunction0(103, _c0));
    \u0275\u0275advance(2);
    \u0275\u0275styleProp("background", ctx.clasificacion.bg)("border-color", ctx.clasificacion.border);
    \u0275\u0275advance(3);
    \u0275\u0275styleProp("color", ctx.clasificacion.color);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", ctx.puntaje === null ? "\u2014" : \u0275\u0275pipeBind2(230, 93, ctx.puntaje, "1.2-2"), " ");
    \u0275\u0275advance(2);
    \u0275\u0275styleProp("color", ctx.clasificacion.color);
    \u0275\u0275advance();
    \u0275\u0275textInterpolate(ctx.clasificacion.label);
    \u0275\u0275advance(16);
    \u0275\u0275textInterpolate(ctx.formulario.defectos.tazasNoUniformes);
    \u0275\u0275advance(13);
    \u0275\u0275textInterpolate(ctx.totalTazasDefectuosas);
    \u0275\u0275advance(7);
    \u0275\u0275textInterpolate1("\u2212", ctx.penalizacionTotal, " pts");
    \u0275\u0275advance(6);
    \u0275\u0275property("ngForOf", ctx.defectosOptions);
    \u0275\u0275advance(5);
    \u0275\u0275twoWayProperty("ngModel", ctx.formulario.notas);
    \u0275\u0275control();
    \u0275\u0275advance(2);
    \u0275\u0275property("ngIf", ctx.muestraActual() > 1);
    \u0275\u0275advance();
    \u0275\u0275property("disabled", ctx.guardando());
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", ctx.guardando() ? "Guardando\u2026" : ctx.muestraActual() === ctx.totalMuestras() ? "Terminar cata" : "Siguiente muestra \u2192", " ");
  }
}, dependencies: [IonContent, IonIcon, CommonModule, NgClass, NgForOf, NgIf, FormsModule, DefaultValueAccessor, RangeValueAccessor, NgControlStatus, NgModel, EstadoFichaComponent, DecimalPipe], encapsulation: 2 });
var CombinedFormPage = _CombinedFormPage;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(CombinedFormPage, [{
    type: Component,
    args: [{ selector: "app-combined-form", standalone: true, imports: [IonContent, IonIcon, CommonModule, FormsModule, EstadoFichaComponent], template: `<ion-content class="cva-combined" [scrollY]="true">
  <app-estado-ficha
    [pendientes]="pendientesLocales()"
    [enLinea]="enLinea()"
    [muestraCerrada]="muestraActualCerrada()"
    [rechazo]="rechazoActual()"
    [esperandoFinalizar]="esperandoSincronizacion()"
    (reintentar)="reintentarSincronizacion()"
    (salir)="salirConPendientes()">
  </app-estado-ficha>
  @if (error(); as mensaje) {
    <div class="evaluation-error" role="alert">{{ mensaje }}</div>
  }
  
  <!-- HEADER -->
  <header class="cva-header">
    <div class="cva-header__inner">
      <div class="cva-header__left">
        <button class="cva-header__back-btn" (click)="volver()">
          <ion-icon name="arrow-back-outline"></ion-icon>
        </button>
        <div class="cva-header__meta">
          <p class="cva-header__session-name">Evaluaci\xF3n Combinada</p>
          <p class="cva-header__sample-label">Muestra {{ muestraActual() }} <span>de {{ totalMuestras() }}</span></p>
        </div>
      </div>
      <div class="cva-header__right">
        <div class="cva-header__blind-badge">
          <ion-icon name="lock-closed-outline"></ion-icon> Ciego
        </div>
        <span class="cva-header__format-badge">Combinado</span>
        
        <!-- Puntaje en vivo -->
        <div class="cva-header__live-score" [style.border-color]="clasificacion.border" [style.background]="clasificacion.bg">
          <span class="cva-header__live-score-label">CVA</span>
          <span class="cva-header__live-score-value" [style.color]="clasificacion.color">
            {{ puntaje === null ? 'Pendiente' : (puntaje | number:'1.2-2') }}
          </span>
        </div>
      </div>
    </div>
    <div class="cva-header__progress-bar-wrap">
      <div class="cva-header__progress-bar">
        <div class="cva-header__progress-bar-fill" [style.width]="(muestraActual() / totalMuestras()) * 100 + '%'"></div>
      </div>
    </div>
  </header>

  <!-- CONTENIDO PRINCIPAL -->
  <main class="cva-main">
    <div class="cva-main__grid">
      
      <!-- COLUMNA IZQUIERDA (ATRIBUTOS) -->
      <div class="cva-main__column">

        <!-- FRAGANCIA -->
        <article class="attr-card">
          <h3 class="attr-card__title">Fragancia</h3>
          <div class="intensity-slider">
            <div class="intensity-slider__header">
              <span class="intensity-slider__label">Intensidad f\xEDsica</span>
              <span class="intensity-slider__value">{{ formulario.atributos.fragancia.intensidad | number:'1.1-1' }}</span>
            </div>
            <div class="intensity-slider__track">
              <span class="intensity-slider__endpoint">Baja</span>
              <input class="intensity-slider__input" type="range" min="0" max="15" step="0.5" [(ngModel)]="formulario.atributos.fragancia.intensidad">
              <span class="intensity-slider__endpoint">Alta</span>
            </div>
          </div>

          <div class="hedonic-buttons">
            <div class="hedonic-buttons__header">
              <span class="hedonic-buttons__label">Calidad hed\xF3nica</span>
              <span class="hedonic-buttons__descriptor">
                {{ formulario.atributos.fragancia.calidad ? etiquetas[formulario.atributos.fragancia.calidad] : 'Selecciona una opci\xF3n' }}
              </span>
            </div>
            <div class="hedonic-buttons__grid">
              <button *ngFor="let i of [1,2,3,4,5,6,7,8,9]" 
                      class="hedonic-buttons__btn" 
                      [ngClass]="{'hedonic-buttons__btn--active': formulario.atributos.fragancia.calidad === i}"
                      (click)="seleccionarCalidad('fragancia', i)">
                {{ i }}
              </button>
            </div>
          </div>

          <!-- Rueda de Sabores -->
          <div class="flavor-tree">
            <p class="flavor-tree__section-label">Descriptores arom\xE1ticos</p>
            <div class="flavor-tree__category" *ngFor="let cat of ruedaKeys">
              <button class="flavor-tree__category-btn" (click)="toggleCategoria(cat)">
                <span class="flavor-tree__category-left">
                  <ion-icon [name]="categoriasAbiertas[cat] ? 'chevron-down-outline' : 'chevron-forward-outline'" class="flavor-tree__chevron"></ion-icon>
                  <span class="flavor-tree__swatch" [style.background]="ruedaSabores[cat].color"></span>
                  {{ cat }}
                </span>
                <span class="flavor-tree__count-badge" *ngIf="formulario.atributos.fragancia.descriptores.length > 0 && categoriasAbiertas[cat]">
                  {{ formulario.atributos.fragancia.descriptores.length }}
                </span>
              </button>
              <div class="flavor-tree__sub-list" *ngIf="categoriasAbiertas[cat]">
                <button *ngFor="let sub of ruedaSabores[cat].subdescriptores" 
                        class="flavor-tree__descriptor-btn"
                        [ngClass]="{'flavor-tree__descriptor-btn--selected': isDescriptorSelected('fragancia', sub)}"
                        [style.background]="isDescriptorSelected('fragancia', sub) ? ruedaSabores[cat].color : ''"
                        [style.color]="isDescriptorSelected('fragancia', sub) ? 'white' : ''"
                        (click)="toggleDescriptor('fragancia', sub)">
                  {{ sub }}
                </button>
              </div>
            </div>
            <input
              type="text"
              class="extra-descriptor"
              aria-label="Descriptor personalizado para fragancia"
              placeholder="Agregar descriptor personalizado..."
              [(ngModel)]="formulario.atributos.fragancia.extra">
          </div>
        </article>

        <!-- AROMA EN TAZA -->
        <article class="attr-card">
          <h3 class="attr-card__title">Aroma (en taza)</h3>
          <div class="intensity-slider">
            <div class="intensity-slider__header">
              <span class="intensity-slider__label">Intensidad f\xEDsica</span>
              <span class="intensity-slider__value">{{ formulario.atributos.aroma.intensidad | number:'1.1-1' }}</span>
            </div>
            <div class="intensity-slider__track">
              <span class="intensity-slider__endpoint">Baja</span>
              <input class="intensity-slider__input" type="range" min="0" max="15" step="0.5" [(ngModel)]="formulario.atributos.aroma.intensidad">
              <span class="intensity-slider__endpoint">Alta</span>
            </div>
          </div>
          <div class="hedonic-buttons">
            <div class="hedonic-buttons__header">
              <span class="hedonic-buttons__label">Calidad hed\xF3nica</span>
              <span class="hedonic-buttons__descriptor">{{ formulario.atributos.aroma.calidad ? etiquetas[formulario.atributos.aroma.calidad] : 'Selecciona una opci\xF3n' }}</span>
            </div>
            <div class="hedonic-buttons__grid">
              <button *ngFor="let i of [1,2,3,4,5,6,7,8,9]" class="hedonic-buttons__btn" [ngClass]="{'hedonic-buttons__btn--active': formulario.atributos.aroma.calidad === i}" (click)="seleccionarCalidad('aroma', i)">{{ i }}</button>
            </div>
          </div>
        </article>

        <!-- SABOR -->
        <article class="attr-card">
          <h3 class="attr-card__title">Sabor</h3>
          <div class="intensity-slider">
            <div class="intensity-slider__header">
              <span class="intensity-slider__label">Intensidad f\xEDsica</span>
              <span class="intensity-slider__value">{{ formulario.atributos.sabor.intensidad | number:'1.1-1' }}</span>
            </div>
            <div class="intensity-slider__track">
              <span class="intensity-slider__endpoint">Baja</span>
              <input class="intensity-slider__input" type="range" min="0" max="15" step="0.5" [(ngModel)]="formulario.atributos.sabor.intensidad">
              <span class="intensity-slider__endpoint">Alta</span>
            </div>
          </div>
          <div class="hedonic-buttons">
            <div class="hedonic-buttons__header">
              <span class="hedonic-buttons__label">Calidad hed\xF3nica</span>
              <span class="hedonic-buttons__descriptor">{{ formulario.atributos.sabor.calidad ? etiquetas[formulario.atributos.sabor.calidad] : 'Selecciona una opci\xF3n' }}</span>
            </div>
            <div class="hedonic-buttons__grid">
              <button *ngFor="let i of [1,2,3,4,5,6,7,8,9]" class="hedonic-buttons__btn" [ngClass]="{'hedonic-buttons__btn--active': formulario.atributos.sabor.calidad === i}" (click)="seleccionarCalidad('sabor', i)">{{ i }}</button>
            </div>
          </div>
        </article>

        <!-- SABOR RESIDUAL -->
        <article class="attr-card">
          <h3 class="attr-card__title">Sabor Residual</h3>
          <div class="intensity-slider">
            <div class="intensity-slider__header">
              <span class="intensity-slider__label">Intensidad f\xEDsica</span>
              <span class="intensity-slider__value">{{ formulario.atributos.saborResidual.intensidad | number:'1.1-1' }}</span>
            </div>
            <div class="intensity-slider__track">
              <span class="intensity-slider__endpoint">Baja</span>
              <input class="intensity-slider__input" type="range" min="0" max="15" step="0.5" [(ngModel)]="formulario.atributos.saborResidual.intensidad">
              <span class="intensity-slider__endpoint">Alta</span>
            </div>
          </div>
          <div class="hedonic-buttons">
            <div class="hedonic-buttons__header">
              <span class="hedonic-buttons__label">Calidad hed\xF3nica</span>
              <span class="hedonic-buttons__descriptor">{{ formulario.atributos.saborResidual.calidad ? etiquetas[formulario.atributos.saborResidual.calidad] : 'Selecciona una opci\xF3n' }}</span>
            </div>
            <div class="hedonic-buttons__grid">
              <button *ngFor="let i of [1,2,3,4,5,6,7,8,9]" class="hedonic-buttons__btn" [ngClass]="{'hedonic-buttons__btn--active': formulario.atributos.saborResidual.calidad === i}" (click)="seleccionarCalidad('saborResidual', i)">{{ i }}</button>
            </div>
          </div>
        </article>

        <!-- ACIDEZ -->
        <article class="attr-card">
          <h3 class="attr-card__title">Acidez</h3>
          <div class="intensity-slider">
            <div class="intensity-slider__header">
              <span class="intensity-slider__label">Intensidad f\xEDsica</span>
              <span class="intensity-slider__value">{{ formulario.atributos.acidez.intensidad | number:'1.1-1' }}</span>
            </div>
            <div class="intensity-slider__track">
              <span class="intensity-slider__endpoint">Baja</span>
              <input class="intensity-slider__input" type="range" min="0" max="15" step="0.5" [(ngModel)]="formulario.atributos.acidez.intensidad">
              <span class="intensity-slider__endpoint">Alta</span>
            </div>
          </div>
          <div class="hedonic-buttons">
            <div class="hedonic-buttons__header">
              <span class="hedonic-buttons__label">Calidad hed\xF3nica</span>
              <span class="hedonic-buttons__descriptor">{{ formulario.atributos.acidez.calidad ? etiquetas[formulario.atributos.acidez.calidad] : 'Selecciona una opci\xF3n' }}</span>
            </div>
            <div class="hedonic-buttons__grid">
              <button *ngFor="let i of [1,2,3,4,5,6,7,8,9]" class="hedonic-buttons__btn" [ngClass]="{'hedonic-buttons__btn--active': formulario.atributos.acidez.calidad === i}" (click)="seleccionarCalidad('acidez', i)">{{ i }}</button>
            </div>
          </div>
        </article>

        <!-- DULZOR -->
        <article class="attr-card">
          <h3 class="attr-card__title">Dulzor</h3>
          <div class="intensity-slider">
            <div class="intensity-slider__header">
              <span class="intensity-slider__label">Intensidad f\xEDsica</span>
              <span class="intensity-slider__value">{{ formulario.atributos.dulzor.intensidad | number:'1.1-1' }}</span>
            </div>
            <div class="intensity-slider__track">
              <span class="intensity-slider__endpoint">Baja</span>
              <input class="intensity-slider__input" type="range" min="0" max="15" step="0.5" [(ngModel)]="formulario.atributos.dulzor.intensidad">
              <span class="intensity-slider__endpoint">Alta</span>
            </div>
          </div>
          <div class="hedonic-buttons">
            <div class="hedonic-buttons__header">
              <span class="hedonic-buttons__label">Calidad hed\xF3nica</span>
              <span class="hedonic-buttons__descriptor">{{ formulario.atributos.dulzor.calidad ? etiquetas[formulario.atributos.dulzor.calidad] : 'Selecciona una opci\xF3n' }}</span>
            </div>
            <div class="hedonic-buttons__grid">
              <button *ngFor="let i of [1,2,3,4,5,6,7,8,9]" class="hedonic-buttons__btn" [ngClass]="{'hedonic-buttons__btn--active': formulario.atributos.dulzor.calidad === i}" (click)="seleccionarCalidad('dulzor', i)">{{ i }}</button>
            </div>
          </div>
        </article>

        <!-- SENSACI\xD3N EN BOCA -->
        <article class="attr-card">
          <h3 class="attr-card__title">Sensaci\xF3n en Boca</h3>
          <div class="intensity-slider">
            <div class="intensity-slider__header">
              <span class="intensity-slider__label">Intensidad f\xEDsica</span>
              <span class="intensity-slider__value">{{ formulario.atributos.sensacionEnBoca.intensidad | number:'1.1-1' }}</span>
            </div>
            <div class="intensity-slider__track">
              <span class="intensity-slider__endpoint">Baja</span>
              <input class="intensity-slider__input" type="range" min="0" max="15" step="0.5" [(ngModel)]="formulario.atributos.sensacionEnBoca.intensidad">
              <span class="intensity-slider__endpoint">Alta</span>
            </div>
          </div>
          <div class="hedonic-buttons">
            <div class="hedonic-buttons__header">
              <span class="hedonic-buttons__label">Calidad hed\xF3nica</span>
              <span class="hedonic-buttons__descriptor">{{ formulario.atributos.sensacionEnBoca.calidad ? etiquetas[formulario.atributos.sensacionEnBoca.calidad] : 'Selecciona una opci\xF3n' }}</span>
            </div>
            <div class="hedonic-buttons__grid">
              <button *ngFor="let i of [1,2,3,4,5,6,7,8,9]" class="hedonic-buttons__btn" [ngClass]="{'hedonic-buttons__btn--active': formulario.atributos.sensacionEnBoca.calidad === i}" (click)="seleccionarCalidad('sensacionEnBoca', i)">{{ i }}</button>
            </div>
          </div>

          <!-- Mouthfeel -->
          <div class="mouthfeel">
            <p class="flavor-tree__section-label">Descriptores t\xE1ctiles</p>
            <div class="mouthfeel__list">
              <label class="mouthfeel__item" *ngFor="let opcion of mouthfeelOptions">
                <input type="checkbox" [checked]="formulario.mouthfeel.includes(opcion)" (change)="toggleMouthfeel(opcion)">
                {{ opcion }}
              </label>
            </div>
          </div>
        </article>

        <!-- IMPRESI\xD3N GLOBAL -->
        <article class="attr-card">
          <h3 class="attr-card__title">Impresi\xF3n Global</h3>
          <p style="font-size:12px; color:var(--gray-500); margin-bottom:16px;">Evaluaci\xF3n hed\xF3nica general de la muestra</p>
          <div class="hedonic-buttons">
            <div class="hedonic-buttons__header">
              <span class="hedonic-buttons__label">Calidad hed\xF3nica</span>
              <span class="hedonic-buttons__descriptor">{{ formulario.impresionGlobal ? etiquetas[formulario.impresionGlobal] : 'Selecciona una opci\xF3n' }}</span>
            </div>
            <div class="hedonic-buttons__grid">
              <button *ngFor="let i of [1,2,3,4,5,6,7,8,9]" class="hedonic-buttons__btn" [ngClass]="{'hedonic-buttons__btn--active': formulario.impresionGlobal === i}" (click)="seleccionarCalidad('impresionGlobal', i)">{{ i }}</button>
            </div>
          </div>
        </article>
      </div>

      <!-- BARRA LATERAL (SIDEBAR) -->
      <aside class="cva-main__sidebar">
        
        <!-- PUNTAJE EN VIVO -->
        <div class="score-panel" [style.background]="clasificacion.bg" [style.border-color]="clasificacion.border">
          <span class="score-panel__label">Puntaje CVA</span>
          <span class="score-panel__value" [style.color]="clasificacion.color">
            {{ puntaje === null ? '\u2014' : (puntaje | number:'1.2-2') }}
          </span>
          <span class="score-panel__classification" [style.color]="clasificacion.color">{{ clasificacion.label }}</span>
          <p class="score-panel__formula">S = 0.65625 \xD7 \u03A3h\u1D62 + 52.75 \u2212 2u \u2212 4d</p>
        </div>

        <!-- DEFECTOS -->
        <div class="defect-panel">
          <span class="label-micro" style="display:block; margin-bottom:16px;">Defectos</span>
          
          <div class="defect-counter">
            <div class="defect-counter__info">
              <span class="defect-counter__label">Tazas no uniformes</span>
              <span class="defect-counter__sublabel">\u22122 pts por taza</span>
            </div>
            <div class="defect-counter__controls">
              <button class="defect-counter__btn" (click)="ajustarDefecto('uniformes', 'restar')">\u2212</button>
              <span class="defect-counter__value">{{ formulario.defectos.tazasNoUniformes }}</span>
              <button class="defect-counter__btn" (click)="ajustarDefecto('uniformes', 'sumar')">+</button>
            </div>
          </div>

          <div class="defect-counter" style="margin-top: 16px;">
            <div class="defect-counter__info">
              <span class="defect-counter__label">Tazas defectuosas</span>
              <span class="defect-counter__sublabel">\u22124 pts por taza</span>
            </div>
            <div class="defect-counter__controls">
              <button class="defect-counter__btn" (click)="ajustarDefecto('defectuosas', 'restar')">\u2212</button>
              <span class="defect-counter__value">{{ totalTazasDefectuosas }}</span>
              <button class="defect-counter__btn" (click)="ajustarDefecto('defectuosas', 'sumar')">+</button>
            </div>
          </div>

          <div class="defect-penalty">
            <span class="defect-penalty__label">Penalizaci\xF3n total</span>
            <span class="defect-penalty__value">\u2212{{ penalizacionTotal }} pts</span>
          </div>

          <div class="defect-types">
            <span class="defect-types__label">Tipo de defecto</span>
            <span class="defect-types__hint">Al marcar un tipo se cuenta al menos una taza defectuosa.</span>
            <label class="defect-types__item" *ngFor="let tipo of defectosOptions">
              <input type="checkbox" [checked]="formulario.tiposDefecto.includes(tipo)" (change)="toggleTipoDefecto(tipo)">
              {{ tipo }}
            </label>
          </div>
        </div>

        <!-- NOTAS -->
        <div class="notes-panel">
          <div class="notes-panel__header">
            <ion-icon name="document-text-outline"></ion-icon> Notas adicionales
          </div>
          <textarea class="notes-panel__textarea" rows="5" [(ngModel)]="formulario.notas" placeholder="Observaciones..."></textarea>
        </div>

        <div class="sample-navigation">
          <button
            *ngIf="muestraActual() > 1"
            type="button"
            class="submit-btn sample-navigation__previous"
            (click)="irAMuestraAnterior()">
            \u2190 Anterior
          </button>
          <button
            type="button"
            class="submit-btn"
            (click)="irAMuestraSiguiente()"
            [disabled]="guardando()">
            {{ guardando() ? 'Guardando\u2026' : (muestraActual() === totalMuestras() ? 'Terminar cata' : 'Siguiente muestra \u2192') }}
          </button>
        </div>
      </aside>
    </div>
  </main>
</ion-content>` }]
  }], null, null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(CombinedFormPage, { className: "CombinedFormPage", filePath: "src/app/pages/evaluation/combined-form/combined-form.page.ts", lineNumber: 75 });
})();
export {
  CombinedFormPage
};
//# debugId=1062af1a-0afe-574a-b576-1d67b04f558d
//# sourceMappingURL=combined-form.page-TCIJUGB3.js.map
