// node_modules/@ionic/core/components/p-ZjP4CjeZ.js
/*!
 * (C) Ionic http://ionicframework.com - MIT License
 */
var d = "undefined" != typeof window ? window : void 0;
var o = "undefined" != typeof document ? document : void 0;

export {
  d,
  o
};
//# debugId=cf8c47aa-70d0-580f-9b2f-c778f5b7b0ca
//# sourceMappingURL=chunk-DI3VEDFV.js.map
