import {
  SesionService
} from "./chunk-KN5DCTIK.js";
import {
  EstadoSesion,
  addOutline,
  arrowForwardOutline,
  getFormatoById,
  keyOutline
} from "./chunk-ISYXHPYK.js";
import {
  addIcons
} from "./chunk-4JFQPQWK.js";
import {
  AuthService
} from "./chunk-SYUCMH2K.js";
import {
  AlertController,
  ChangeDetectorRef,
  CommonModule,
  Component,
  FormsModule,
  IonButton,
  IonButtons,
  IonContent,
  IonFab,
  IonFabButton,
  IonHeader,
  IonIcon,
  IonInput,
  IonLabel,
  IonModal,
  IonSegment,
  IonSegmentButton,
  IonSpinner,
  IonTitle,
  IonToolbar,
  NgControlStatus,
  NgModel,
  Router,
  SupabaseService,
  ToastController,
  inject,
  setClassMetadata,
  ɵsetClassDebugInfo,
  ɵɵadvance,
  ɵɵattribute,
  ɵɵclassProp,
  ɵɵconditional,
  ɵɵconditionalCreate,
  ɵɵcontrol,
  ɵɵcontrolCreate,
  ɵɵdefineComponent,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵlistener,
  ɵɵnextContext,
  ɵɵproperty,
  ɵɵpureFunction0,
  ɵɵrepeater,
  ɵɵrepeaterCreate,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵtemplate,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1,
  ɵɵtwoWayBindingSet,
  ɵɵtwoWayListener,
  ɵɵtwoWayProperty
} from "./chunk-ELFI4Z7L.js";
import "./chunk-BMQUG2PJ.js";
import "./chunk-3OZZMUVI.js";
import "./chunk-3GAB7GSC.js";
import "./chunk-B7Y4FMY7.js";
import "./chunk-NQCL7WZ3.js";
import "./chunk-4BTEZGN2.js";
import "./chunk-XTVSKRH4.js";
import "./chunk-ETZFPO3Y.js";
import "./chunk-LLS636HS.js";
import "./chunk-KQQH3YTO.js";
import "./chunk-DI3VEDFV.js";
import "./chunk-PAXKX5KU.js";

// src/app/pages/dashboard/dashboard/dashboard.page.ts
var _c0 = () => [0, 0.4];
var _forTrack0 = ($index, $item) => $item.id;
function DashboardPage_Conditional_47_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "div", 20);
    \u0275\u0275element(1, "ion-spinner", 26);
    \u0275\u0275elementStart(2, "span");
    \u0275\u0275text(3, "Cargando sesiones\u2026");
    \u0275\u0275elementEnd()();
  }
}
function DashboardPage_Conditional_48_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "h3");
    \u0275\u0275text(1, "A\xFAn no hay sesiones");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(2, "p");
    \u0275\u0275text(3, "Crea una sesi\xF3n o \xFAnete presionando el bot\xF3n flotante con el c\xF3digo del organizador.");
    \u0275\u0275elementEnd();
  }
}
function DashboardPage_Conditional_48_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "p");
    \u0275\u0275text(1, "No tienes sesiones en esta categor\xEDa.");
    \u0275\u0275elementEnd();
  }
}
function DashboardPage_Conditional_48_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "article", 21);
    \u0275\u0275conditionalCreate(1, DashboardPage_Conditional_48_Conditional_1_Template, 4, 0)(2, DashboardPage_Conditional_48_Conditional_2_Template, 2, 0, "p");
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r0.sesiones.length === 0 ? 1 : 2);
  }
}
function DashboardPage_Conditional_49_For_1_Conditional_7_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 38);
    \u0275\u0275listener("click", function DashboardPage_Conditional_49_For_1_Conditional_7_Conditional_3_Template_div_click_0_listener($event) {
      return $event.stopPropagation();
    });
    \u0275\u0275elementStart(1, "button", 39);
    \u0275\u0275listener("click", function DashboardPage_Conditional_49_For_1_Conditional_7_Conditional_3_Template_button_click_1_listener($event) {
      \u0275\u0275restoreView(_r5);
      const sesion_r3 = \u0275\u0275nextContext(2).$implicit;
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.solicitarEliminarSesion(sesion_r3, $event));
    });
    \u0275\u0275text(2, " Eliminar sesi\xF3n ");
    \u0275\u0275elementEnd()();
  }
}
function DashboardPage_Conditional_49_For_1_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 33)(1, "button", 36);
    \u0275\u0275listener("click", function DashboardPage_Conditional_49_For_1_Conditional_7_Template_button_click_1_listener($event) {
      \u0275\u0275restoreView(_r4);
      const sesion_r3 = \u0275\u0275nextContext().$implicit;
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.toggleMenuSesion(sesion_r3.id, $event));
    });
    \u0275\u0275text(2, " \u22EE ");
    \u0275\u0275elementEnd();
    \u0275\u0275conditionalCreate(3, DashboardPage_Conditional_49_For_1_Conditional_7_Conditional_3_Template, 3, 0, "div", 37);
    \u0275\u0275elementEnd();
  }
  if (rf & 2) {
    const sesion_r3 = \u0275\u0275nextContext().$implicit;
    const ctx_r0 = \u0275\u0275nextContext(2);
    \u0275\u0275advance();
    \u0275\u0275property("disabled", ctx_r0.sesionEliminandoId === sesion_r3.id);
    \u0275\u0275attribute("aria-expanded", ctx_r0.menuSesionAbiertoId === sesion_r3.id);
    \u0275\u0275advance(2);
    \u0275\u0275conditional(ctx_r0.menuSesionAbiertoId === sesion_r3.id ? 3 : -1);
  }
}
function DashboardPage_Conditional_49_For_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r2 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "article", 28);
    \u0275\u0275listener("click", function DashboardPage_Conditional_49_For_1_Template_article_click_0_listener() {
      const sesion_r3 = \u0275\u0275restoreView(_r2).$implicit;
      const ctx_r0 = \u0275\u0275nextContext(2);
      return \u0275\u0275resetView(ctx_r0.entrarASesion(sesion_r3));
    });
    \u0275\u0275elementStart(1, "div", 29)(2, "div", 30)(3, "span", 31);
    \u0275\u0275text(4);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "span", 32);
    \u0275\u0275text(6);
    \u0275\u0275elementEnd()();
    \u0275\u0275conditionalCreate(7, DashboardPage_Conditional_49_For_1_Conditional_7_Template, 4, 3, "div", 33);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(8, "div", 34);
    \u0275\u0275text(9);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(10, "h3");
    \u0275\u0275text(11);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(12, "div", 35)(13, "span");
    \u0275\u0275text(14);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(15, "span");
    \u0275\u0275text(16);
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(17, "span");
    \u0275\u0275text(18);
    \u0275\u0275elementEnd()()();
  }
  if (rf & 2) {
    const sesion_r3 = ctx.$implicit;
    \u0275\u0275advance(3);
    \u0275\u0275classProp("chip-active", sesion_r3.estado === "En progreso");
    \u0275\u0275advance();
    \u0275\u0275textInterpolate1(" ", sesion_r3.estado, " ");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(sesion_r3.rol);
    \u0275\u0275advance();
    \u0275\u0275conditional(sesion_r3.esOrganizador ? 7 : -1);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(sesion_r3.tipo);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate(sesion_r3.titulo);
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate(sesion_r3.fecha);
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1("", sesion_r3.cantMuestras, " muestras");
    \u0275\u0275advance(2);
    \u0275\u0275textInterpolate1("", sesion_r3.cantCatadores, " catadores");
  }
}
function DashboardPage_Conditional_49_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275repeaterCreate(0, DashboardPage_Conditional_49_For_1_Template, 19, 10, "article", 27, _forTrack0);
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275repeater(ctx_r0.sesionesFiltradas);
  }
}
function DashboardPage_ng_template_54_Conditional_7_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275element(0, "ion-spinner", 26);
  }
}
function DashboardPage_ng_template_54_Conditional_8_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275text(0, " Unirme ");
    \u0275\u0275element(1, "ion-icon", 44);
  }
}
function DashboardPage_ng_template_54_Template(rf, ctx) {
  if (rf & 1) {
    const _r6 = \u0275\u0275getCurrentView();
    \u0275\u0275elementStart(0, "div", 40)(1, "h3");
    \u0275\u0275text(2, "Unirme a una sesi\xF3n");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(3, "p", 41);
    \u0275\u0275text(4, "Ingresa el c\xF3digo proporcionado por el organizador");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "ion-input", 42);
    \u0275\u0275twoWayListener("ngModelChange", function DashboardPage_ng_template_54_Template_ion_input_ngModelChange_5_listener($event) {
      \u0275\u0275restoreView(_r6);
      const ctx_r0 = \u0275\u0275nextContext();
      \u0275\u0275twoWayBindingSet(ctx_r0.codigoInput, $event) || (ctx_r0.codigoInput = $event);
      return \u0275\u0275resetView($event);
    });
    \u0275\u0275elementEnd();
    \u0275\u0275controlCreate();
    \u0275\u0275elementStart(6, "ion-button", 43);
    \u0275\u0275listener("click", function DashboardPage_ng_template_54_Template_ion_button_click_6_listener() {
      \u0275\u0275restoreView(_r6);
      const ctx_r0 = \u0275\u0275nextContext();
      return \u0275\u0275resetView(ctx_r0.unirseSesion());
    });
    \u0275\u0275conditionalCreate(7, DashboardPage_ng_template_54_Conditional_7_Template, 1, 0, "ion-spinner", 26)(8, DashboardPage_ng_template_54_Conditional_8_Template, 2, 0);
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    const ctx_r0 = \u0275\u0275nextContext();
    \u0275\u0275advance(5);
    \u0275\u0275twoWayProperty("ngModel", ctx_r0.codigoInput);
    \u0275\u0275control();
    \u0275\u0275advance();
    \u0275\u0275property("disabled", ctx_r0.isJoining || ctx_r0.cargandoPerfil || !ctx_r0.codigoInput.trim());
    \u0275\u0275advance();
    \u0275\u0275conditional(ctx_r0.isJoining ? 7 : 8);
  }
}
var _DashboardPage = class _DashboardPage {
  constructor() {
    this.codigoInput = "";
    this.nombreUsuario = "";
    this.isJoining = false;
    this.isSigningOut = false;
    this.cargandoPerfil = true;
    this.isModalOpen = false;
    this.filtroSeleccionado = "todas";
    this.sesiones = [];
    this.cargando = true;
    this.menuSesionAbiertoId = null;
    this.sesionEliminandoId = null;
    this.router = inject(Router);
    this.authService = inject(AuthService);
    this.sesionService = inject(SesionService);
    this.supabaseService = inject(SupabaseService);
    this.toastController = inject(ToastController);
    this.alertController = inject(AlertController);
    this.changeDetector = inject(ChangeDetectorRef);
    this.inicializando = false;
    this.primeraCargaCompleta = false;
    addIcons({ keyOutline, addOutline, arrowForwardOutline });
  }
  ngOnInit() {
    void this.inicializar();
  }
  ionViewWillEnter() {
    if (this.primeraCargaCompleta)
      void this.inicializar();
  }
  get sesionesFiltradas() {
    if (this.filtroSeleccionado === "organizador") {
      return this.sesiones.filter((s) => s.esOrganizador);
    }
    if (this.filtroSeleccionado === "catador") {
      return this.sesiones.filter((s) => !s.esOrganizador);
    }
    return this.sesiones;
  }
  async inicializar() {
    if (this.inicializando)
      return;
    this.inicializando = true;
    try {
      const { data: { user }, error } = await this.supabaseService.client.auth.getUser();
      if (error)
        throw error;
      if (!user)
        throw new Error("Debes iniciar sesi\xF3n para ver tus sesiones.");
      await this.cargarNombreUsuario(user);
      this.cargandoPerfil = false;
      await this.cargarSesionesReales(user);
    } catch (error) {
      this.sesiones = [];
      this.cargando = false;
      this.cargandoPerfil = false;
      await this.mostrarToast(error instanceof Error ? error.message : "No se pudieron cargar tus sesiones.");
    } finally {
      this.primeraCargaCompleta = true;
      this.inicializando = false;
      this.changeDetector.markForCheck();
    }
  }
  async cargarSesionesReales(user) {
    this.cargando = true;
    try {
      const sesiones = await this.sesionService.obtenerMisSesiones(user.id);
      this.sesiones = sesiones.map((sesion) => this.mapearSesion(sesion));
    } catch (error) {
      this.sesiones = [];
      throw error;
    } finally {
      this.cargando = false;
      this.changeDetector.markForCheck();
    }
  }
  abrirModalUnirse() {
    this.isModalOpen = true;
    this.changeDetector.markForCheck();
  }
  cerrarModalUnirse() {
    this.isModalOpen = false;
    this.codigoInput = "";
    this.changeDetector.markForCheck();
  }
  entrarASesion(sesion) {
    this.menuSesionAbiertoId = null;
    if (sesion.estado === "En espera" || sesion.estado === "En progreso") {
      if (sesion.esOrganizador && !sesion.organizadorParticipa) {
        if (sesion.estado === "En progreso") {
          void this.router.navigateByUrl(`/session/${sesion.id}/organizer-dashboard`, { replaceUrl: true });
          return;
        }
      }
      if (sesion.formato.toLowerCase() === "extrinseca") {
        void this.router.navigateByUrl(`/extrinsic-form/${sesion.id}`, { replaceUrl: true });
      } else {
        void this.router.navigateByUrl(`/session/waiting/${sesion.id}`, { replaceUrl: true });
      }
      return;
    }
    if (sesion.estado === "Completada" && sesion.esOrganizador) {
      void this.router.navigateByUrl(`/session/${sesion.id}/results`, { replaceUrl: true });
    } else if (sesion.estado === "Completada") {
      void this.router.navigateByUrl(`/session/${sesion.id}/evaluation-complete`, { replaceUrl: true });
    } else {
      void this.mostrarToast("Esta sesi\xF3n fue cancelada.");
    }
  }
  toggleMenuSesion(sesionId, event) {
    event.stopPropagation();
    this.menuSesionAbiertoId = this.menuSesionAbiertoId === sesionId ? null : sesionId;
  }
  async solicitarEliminarSesion(sesion, event) {
    event.stopPropagation();
    this.menuSesionAbiertoId = null;
    if (!sesion.esOrganizador)
      return;
    const alert = await this.alertController.create({
      header: "Eliminar sesi\xF3n",
      message: `\xBFEliminar \u201C${sesion.titulo}\u201D? Esta acci\xF3n no se puede deshacer.`,
      buttons: [
        { text: "Cancelar", role: "cancel" },
        {
          text: "Eliminar",
          role: "destructive",
          handler: () => {
            void this.eliminarSesion(sesion.id);
          }
        }
      ]
    });
    await alert.present();
  }
  async nuevaSesion() {
    await this.router.navigateByUrl("/session/create", { replaceUrl: true });
  }
  async unirseSesion() {
    const codigoLimpio = this.codigoInput.trim().toUpperCase();
    if (!codigoLimpio) {
      await this.mostrarToast("Ingresa el c\xF3digo de la sesi\xF3n.");
      return;
    }
    this.isJoining = true;
    try {
      const { sesion } = await this.sesionService.unirseASesion(codigoLimpio);
      this.isModalOpen = false;
      this.codigoInput = "";
      const destino = sesion.formato.toLowerCase() === "extrinseca" ? `/extrinsic-form/${sesion.id}` : `/session/waiting/${sesion.id}`;
      await this.router.navigateByUrl(destino, { replaceUrl: true });
    } catch (error) {
      console.error("Error al unirse a la sesi\xF3n:", error);
      await this.mostrarToast(error instanceof Error ? error.message : "No se pudo unir a la sesi\xF3n.");
    } finally {
      this.isJoining = false;
      this.changeDetector.markForCheck();
    }
  }
  async cerrarSesion() {
    this.isSigningOut = true;
    try {
      await this.authService.signOut();
      await this.router.navigateByUrl("/login", { replaceUrl: true });
    } catch (error) {
      await this.mostrarToast(error instanceof Error ? error.message : "No se pudo cerrar la sesi\xF3n.");
    } finally {
      this.isSigningOut = false;
      this.changeDetector.markForCheck();
    }
  }
  async mostrarToast(message, color = "danger") {
    const toast = await this.toastController.create({
      message,
      duration: 3500,
      position: "bottom",
      color
    });
    await toast.present();
  }
  async eliminarSesion(sesionId) {
    this.sesionEliminandoId = sesionId;
    try {
      await this.sesionService.eliminarSesion(sesionId);
      this.sesiones = this.sesiones.filter((sesion) => sesion.id !== sesionId);
      await this.mostrarToast("Sesi\xF3n eliminada.", "success");
    } catch (error) {
      await this.mostrarToast(error instanceof Error ? error.message : "No se pudo eliminar la sesi\xF3n.");
    } finally {
      this.sesionEliminandoId = null;
      this.changeDetector.markForCheck();
    }
  }
  async cargarNombreUsuario(user) {
    try {
      const { data, error } = await this.supabaseService.client.from("usuarios").select("nombre").eq("id", user.id).maybeSingle();
      if (error)
        throw error;
      const nombrePerfil = data?.["nombre"];
      const nombreMetadata = user.user_metadata?.["nombre"];
      this.nombreUsuario = typeof nombrePerfil === "string" && nombrePerfil.trim() ? nombrePerfil.trim() : typeof nombreMetadata === "string" && nombreMetadata.trim() ? nombreMetadata.trim() : user.email?.split("@")[0] ?? "Catador";
    } catch (error) {
      console.warn("[Dashboard] No se pudo cargar el perfil:", error);
      const nombreMetadata = user.user_metadata?.["nombre"];
      this.nombreUsuario = (typeof nombreMetadata === "string" && nombreMetadata.trim() ? nombreMetadata.trim() : "") || user.email?.split("@")[0] || "Catador";
    }
  }
  mapearSesion(sesion) {
    const estado = {
      [EstadoSesion.EN_ESPERA]: "En espera",
      [EstadoSesion.INICIADA]: "En progreso",
      [EstadoSesion.FINALIZADA]: "Completada",
      [EstadoSesion.CANCELADA]: "Cancelada"
    }[sesion.estado];
    return {
      id: sesion.id,
      titulo: sesion.nombre,
      formato: sesion.formato,
      tipo: getFormatoById(sesion.formato).titulo,
      estado,
      rol: sesion.esOrganizador ? "Organizador" : "Catador",
      fecha: sesion.creadaEn ? new Date(sesion.creadaEn).toLocaleDateString() : "\u2014",
      cantMuestras: sesion.numeroMuestras,
      cantCatadores: sesion.catadoresObjetivo,
      esOrganizador: sesion.esOrganizador,
      organizadorParticipa: sesion.organizadorParticipa
    };
  }
};
_DashboardPage.\u0275fac = function DashboardPage_Factory(__ngFactoryType__) {
  return new (__ngFactoryType__ || _DashboardPage)();
};
_DashboardPage.\u0275cmp = /* @__PURE__ */ \u0275\u0275defineComponent({ type: _DashboardPage, selectors: [["app-dashboard"]], decls: 55, vars: 10, consts: [[1, "ion-no-border"], [1, "brand-title"], [1, "brand-subtitle"], ["slot", "end"], ["color", "medium", 3, "click", "disabled"], [1, "ion-padding", "dashboard-content"], [1, "dashboard-container"], ["aria-label", "Resumen", 1, "metrics"], [1, "cupping-card", "metric-card"], [1, "metric-label"], [1, "metric-value"], [1, "filter-container"], ["mode", "ios", 3, "ngModelChange", "ngModel"], ["value", "todas"], ["value", "organizador"], ["value", "catador"], [1, "section-heading"], ["size", "small", 1, "new-session-btn", 3, "click"], ["aria-hidden", "true"], [1, "sessions-list-container"], ["role", "status", 1, "loading-state"], [1, "cupping-card", "empty-state"], ["slot", "fixed", "vertical", "bottom", "horizontal", "end"], ["aria-label", "Unirme a una sesi\xF3n", 1, "join-fab", 3, "click"], ["name", "key-outline"], [3, "didDismiss", "isOpen", "initialBreakpoint", "breakpoints"], ["name", "crescent"], [1, "cupping-card", "session-card"], [1, "cupping-card", "session-card", 3, "click"], [1, "session-card__top"], [1, "session-chips"], [1, "chip"], [1, "chip", "chip-neutral"], [1, "session-card__menu"], [1, "session-type"], [1, "session-meta"], ["type", "button", "aria-label", "Opciones de sesi\xF3n", 1, "session-card__menu-trigger", 3, "click", "disabled"], [1, "session-card__menu-dropdown"], [1, "session-card__menu-dropdown", 3, "click"], ["type", "button", 1, "session-card__menu-item", "session-card__menu-item--danger", 3, "click"], [1, "modal-content", "ion-padding"], [1, "subtitle"], ["placeholder", "Ej: ABC-123", "autocapitalize", "characters", "fill", "outline", 1, "custom-input", "ion-margin-top", 3, "ngModelChange", "ngModel"], ["expand", "block", 1, "join-btn", "primary-btn", 3, "click", "disabled"], ["slot", "end", "name", "arrow-forward-outline"]], template: function DashboardPage_Template(rf, ctx) {
  if (rf & 1) {
    \u0275\u0275elementStart(0, "ion-header", 0)(1, "ion-toolbar")(2, "ion-title")(3, "div", 1);
    \u0275\u0275text(4, "Pacamara");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(5, "div", 2);
    \u0275\u0275text(6);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(7, "ion-buttons", 3)(8, "ion-button", 4);
    \u0275\u0275listener("click", function DashboardPage_Template_ion_button_click_8_listener() {
      return ctx.cerrarSesion();
    });
    \u0275\u0275text(9, " Cerrar sesi\xF3n ");
    \u0275\u0275elementEnd()()()();
    \u0275\u0275elementStart(10, "ion-content", 5)(11, "main", 6)(12, "section", 7)(13, "article", 8)(14, "div", 9);
    \u0275\u0275text(15, "Sesiones");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(16, "div", 10);
    \u0275\u0275text(17);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(18, "article", 8)(19, "div", 9);
    \u0275\u0275text(20, "Muestras");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(21, "div", 10);
    \u0275\u0275text(22, "\u2014");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(23, "article", 8)(24, "div", 9);
    \u0275\u0275text(25, "Prom. personal");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(26, "div", 10);
    \u0275\u0275text(27, "\u2014");
    \u0275\u0275elementEnd()()();
    \u0275\u0275elementStart(28, "div", 11)(29, "ion-segment", 12);
    \u0275\u0275twoWayListener("ngModelChange", function DashboardPage_Template_ion_segment_ngModelChange_29_listener($event) {
      \u0275\u0275twoWayBindingSet(ctx.filtroSeleccionado, $event) || (ctx.filtroSeleccionado = $event);
      return $event;
    });
    \u0275\u0275elementStart(30, "ion-segment-button", 13)(31, "ion-label");
    \u0275\u0275text(32);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(33, "ion-segment-button", 14)(34, "ion-label");
    \u0275\u0275text(35, "Organizador");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(36, "ion-segment-button", 15)(37, "ion-label");
    \u0275\u0275text(38, "Catador");
    \u0275\u0275elementEnd()()();
    \u0275\u0275controlCreate();
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(39, "section", 16)(40, "h2");
    \u0275\u0275text(41, "Mis Sesiones");
    \u0275\u0275elementEnd();
    \u0275\u0275elementStart(42, "ion-button", 17);
    \u0275\u0275listener("click", function DashboardPage_Template_ion_button_click_42_listener() {
      return ctx.nuevaSesion();
    });
    \u0275\u0275elementStart(43, "span", 18);
    \u0275\u0275text(44, "+");
    \u0275\u0275elementEnd();
    \u0275\u0275text(45, " Nueva sesi\xF3n ");
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(46, "div", 19);
    \u0275\u0275conditionalCreate(47, DashboardPage_Conditional_47_Template, 4, 0, "div", 20)(48, DashboardPage_Conditional_48_Template, 3, 1, "article", 21)(49, DashboardPage_Conditional_49_Template, 2, 0);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(50, "ion-fab", 22)(51, "ion-fab-button", 23);
    \u0275\u0275listener("click", function DashboardPage_Template_ion_fab_button_click_51_listener() {
      return ctx.abrirModalUnirse();
    });
    \u0275\u0275element(52, "ion-icon", 24);
    \u0275\u0275elementEnd()();
    \u0275\u0275elementStart(53, "ion-modal", 25);
    \u0275\u0275listener("didDismiss", function DashboardPage_Template_ion_modal_didDismiss_53_listener() {
      return ctx.cerrarModalUnirse();
    });
    \u0275\u0275template(54, DashboardPage_ng_template_54_Template, 9, 3, "ng-template");
    \u0275\u0275elementEnd()();
  }
  if (rf & 2) {
    \u0275\u0275advance(6);
    \u0275\u0275textInterpolate(ctx.nombreUsuario);
    \u0275\u0275advance(2);
    \u0275\u0275property("disabled", ctx.isSigningOut);
    \u0275\u0275advance(9);
    \u0275\u0275textInterpolate(ctx.sesiones.length);
    \u0275\u0275advance(12);
    \u0275\u0275twoWayProperty("ngModel", ctx.filtroSeleccionado);
    \u0275\u0275control();
    \u0275\u0275advance(3);
    \u0275\u0275textInterpolate1("Todas (", ctx.sesiones.length, ")");
    \u0275\u0275advance(15);
    \u0275\u0275conditional(ctx.cargando ? 47 : ctx.sesionesFiltradas.length === 0 ? 48 : 49);
    \u0275\u0275advance(6);
    \u0275\u0275property("isOpen", ctx.isModalOpen)("initialBreakpoint", 0.4)("breakpoints", \u0275\u0275pureFunction0(9, _c0));
  }
}, dependencies: [
  IonContent,
  IonHeader,
  IonToolbar,
  IonTitle,
  IonButtons,
  IonButton,
  IonInput,
  IonSpinner,
  IonSegment,
  IonSegmentButton,
  IonLabel,
  IonFab,
  IonFabButton,
  IonIcon,
  IonModal,
  CommonModule,
  FormsModule,
  NgControlStatus,
  NgModel
], styles: ['@charset "UTF-8";\n\n\nion-toolbar[_ngcontent-%COMP%] {\n  --%NS%background: var(--%NS%app-bg-card, #ffffff);\n}\n.brand-title[_ngcontent-%COMP%] {\n  color: var(--%NS%app-text-main, #111827);\n  font-size: 18px;\n  font-weight: 700;\n}\n.brand-subtitle[_ngcontent-%COMP%] {\n  margin-top: 2px;\n  color: var(--%NS%app-text-muted, #6b7280);\n  font-size: 12px;\n  font-weight: 400;\n}\n.dashboard-content[_ngcontent-%COMP%] {\n  --%NS%background: var(--%NS%app-bg-screen, #f9fafb);\n}\n.dashboard-container[_ngcontent-%COMP%] {\n  width: min(100%, 900px);\n  margin: 0 auto;\n  padding-bottom: 80px;\n}\n.filter-container[_ngcontent-%COMP%] {\n  margin-bottom: 1.25rem;\n}\n.metrics[_ngcontent-%COMP%] {\n  display: grid;\n  grid-template-columns: repeat(3, minmax(0, 1fr));\n  gap: 12px;\n  margin: 8px 0 24px;\n}\n.metric-card[_ngcontent-%COMP%] {\n  margin: 0;\n  padding: 14px 8px;\n  text-align: center;\n}\n.metric-label[_ngcontent-%COMP%] {\n  color: var(--%NS%app-text-muted, #6b7280);\n  font-size: 12px;\n}\n.metric-value[_ngcontent-%COMP%] {\n  margin-top: 6px;\n  color: var(--%NS%app-text-main, #111827);\n  font-size: 20px;\n  font-weight: 700;\n}\n.section-heading[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  gap: 12px;\n  margin-bottom: 14px;\n}\n.section-heading[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n  margin: 0;\n  color: var(--%NS%app-text-main, #111827);\n  font-size: 16px;\n  font-weight: 600;\n}\n.new-session-btn[_ngcontent-%COMP%] {\n  --%NS%background: #ffffff;\n  --%NS%color: #0f344c;\n  --%NS%border-radius: 10px;\n  font-weight: 600;\n  text-transform: none;\n}\n.sessions-list-container[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 12px;\n}\n.session-card[_ngcontent-%COMP%] {\n  position: relative;\n  padding: 16px;\n  border-radius: 12px;\n  cursor: pointer;\n  transition: transform 0.15s ease, box-shadow 0.15s ease;\n}\n.session-card[_ngcontent-%COMP%]:active {\n  transform: scale(0.99);\n}\n.session-card__top[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: flex-start;\n  justify-content: space-between;\n  gap: 12px;\n}\n.session-chips[_ngcontent-%COMP%] {\n  display: flex;\n  flex-wrap: wrap;\n  gap: 8px;\n  margin-bottom: 8px;\n}\n.session-card__menu[_ngcontent-%COMP%] {\n  position: relative;\n  flex: none;\n}\n.session-card__menu-trigger[_ngcontent-%COMP%] {\n  display: grid;\n  width: 32px;\n  height: 32px;\n  place-items: center;\n  border: 1px solid var(--%NS%app-border, #e5e7eb);\n  border-radius: 8px;\n  background: var(--%NS%app-bg-card, #ffffff);\n  color: var(--%NS%app-text-main, #111827);\n  font-size: 20px;\n  line-height: 1;\n  cursor: pointer;\n}\n.session-card__menu-dropdown[_ngcontent-%COMP%] {\n  position: absolute;\n  top: calc(100% + 4px);\n  right: 0;\n  z-index: 5;\n  min-width: 160px;\n  padding: 4px;\n  border: 1px solid var(--%NS%app-border, #e5e7eb);\n  border-radius: 8px;\n  background: var(--%NS%app-bg-card, #ffffff);\n  box-shadow: 0 8px 20px rgba(15, 23, 43, 0.12);\n}\n.session-card__menu-item[_ngcontent-%COMP%] {\n  width: 100%;\n  padding: 9px 10px;\n  border: 0;\n  border-radius: 5px;\n  background: transparent;\n  color: var(--%NS%app-text-main, #111827);\n  font: inherit;\n  font-size: 12px;\n  text-align: left;\n  cursor: pointer;\n}\n.session-card__menu-item--danger[_ngcontent-%COMP%] {\n  color: var(--%NS%app-error, #ef4444);\n}\n.session-card__menu-item[_ngcontent-%COMP%]:hover {\n  background: var(--%NS%app-bg-screen, #f9fafb);\n}\n.chip[_ngcontent-%COMP%] {\n  padding: 4px 9px;\n  border-radius: 999px;\n  background: var(--%NS%app-border, #e5e7eb);\n  color: var(--%NS%app-text-muted, #6b7280);\n  font-size: 11px;\n}\n.chip-active[_ngcontent-%COMP%] {\n  background: #f8fafc;\n  color: var(--%NS%app-primary-dark, #0f344c);\n  font-weight: 600;\n}\n.chip-neutral[_ngcontent-%COMP%] {\n  background: var(--%NS%app-border, #e5e7eb);\n}\n.session-type[_ngcontent-%COMP%] {\n  margin: 4px 0;\n  color: var(--%NS%app-text-muted, #6b7280);\n  font-size: 12px;\n}\n.session-card[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%] {\n  margin: 0;\n  color: var(--%NS%app-text-main, #111827);\n  font-size: 15px;\n}\n.session-meta[_ngcontent-%COMP%] {\n  display: flex;\n  flex-wrap: wrap;\n  gap: 8px 16px;\n  margin-top: 10px;\n  color: var(--%NS%app-text-muted, #6b7280);\n  font-size: 11px;\n}\n.empty-state[_ngcontent-%COMP%] {\n  padding: 3rem 1rem;\n  text-align: center;\n}\n.empty-state[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%] {\n  margin: 0 0 8px;\n  color: var(--%NS%app-text-main, #111827);\n  font-size: 15px;\n}\n.empty-state[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  margin: 0;\n  color: var(--%NS%app-text-muted, #6b7280);\n  font-size: 13px;\n  line-height: 1.5;\n}\n.loading-state[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  gap: 10px;\n  padding: 32px 16px;\n  color: var(--%NS%app-text-muted, #6b7280);\n  font-size: 13px;\n}\nion-modal[_ngcontent-%COMP%] {\n  --%NS%background: var(--%NS%app-bg-card, #ffffff);\n  --%NS%border-radius: 16px;\n}\n.modal-content[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  gap: 4px;\n  padding-top: 20px;\n  color: var(--%NS%app-text-main, #111827);\n}\n.modal-content[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%] {\n  margin: 0;\n  font-size: 16px;\n  font-weight: 600;\n}\n.modal-content[_ngcontent-%COMP%]   .subtitle[_ngcontent-%COMP%] {\n  margin: 0 0 12px;\n  color: var(--%NS%app-text-muted, #6b7280);\n  font-size: 0.875rem;\n}\n.modal-content[_ngcontent-%COMP%]   ion-button.primary-btn[_ngcontent-%COMP%] {\n  margin-top: 16px;\n}\n.modal-content[_ngcontent-%COMP%]   ion-button.primary-btn[disabled][_ngcontent-%COMP%] {\n  opacity: 0.45;\n}\n.join-fab[_ngcontent-%COMP%] {\n  --%NS%background: var(--%NS%app-primary-dark, #0f344c);\n  --%NS%background-hover: var(--%NS%app-primary-hover, #0b2738);\n  --%NS%background-activated: var(--%NS%app-primary-hover, #0b2738);\n  --%NS%color: #ffffff;\n  --%NS%box-shadow: 0 6px 16px rgb(15 52 76 / 28%);\n}\n@media (max-width: 360px) {\n  .metrics[_ngcontent-%COMP%] {\n    gap: 6px;\n  }\n  .metric-card[_ngcontent-%COMP%] {\n    padding: 10px 4px;\n  }\n  .metric-label[_ngcontent-%COMP%] {\n    font-size: 10px;\n  }\n  .metric-value[_ngcontent-%COMP%] {\n    font-size: 16px;\n  }\n}\n/*# sourceMappingURL=dashboard.page.css.map */'] });
var DashboardPage = _DashboardPage;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(DashboardPage, [{
    type: Component,
    args: [{ selector: "app-dashboard", standalone: true, imports: [
      IonContent,
      IonHeader,
      IonToolbar,
      IonTitle,
      IonButtons,
      IonButton,
      IonInput,
      IonSpinner,
      IonSegment,
      IonSegmentButton,
      IonLabel,
      IonFab,
      IonFabButton,
      IonIcon,
      IonModal,
      CommonModule,
      FormsModule
    ], template: `<ion-header class="ion-no-border">
  <ion-toolbar>
    <ion-title>
      <div class="brand-title">Pacamara</div>
      <div class="brand-subtitle">{{ nombreUsuario }}</div>
    </ion-title>
    <ion-buttons slot="end">
      <ion-button color="medium" (click)="cerrarSesion()" [disabled]="isSigningOut">
        Cerrar sesi\xF3n
      </ion-button>
    </ion-buttons>
  </ion-toolbar>
</ion-header>

<ion-content class="ion-padding dashboard-content">
  <main class="dashboard-container">
    
    <!-- RESUMEN DE M\xC9TRICAS -->
    <section class="metrics" aria-label="Resumen">
      <article class="cupping-card metric-card">
        <div class="metric-label">Sesiones</div>
        <div class="metric-value">{{ sesiones.length }}</div>
      </article>
      <article class="cupping-card metric-card">
        <div class="metric-label">Muestras</div>
        <div class="metric-value">\u2014</div>
      </article>
      <article class="cupping-card metric-card">
        <div class="metric-label">Prom. personal</div>
        <div class="metric-value">\u2014</div>
      </article>
    </section>

    <!-- FILTROS POR ROL -->
    <div class="filter-container">
      <ion-segment [(ngModel)]="filtroSeleccionado" mode="ios">
        <ion-segment-button value="todas">
          <ion-label>Todas ({{ sesiones.length }})</ion-label>
        </ion-segment-button>
        <ion-segment-button value="organizador">
          <ion-label>Organizador</ion-label>
        </ion-segment-button>
        <ion-segment-button value="catador">
          <ion-label>Catador</ion-label>
        </ion-segment-button>
      </ion-segment>
    </div>

    <!-- CABECERA DE SECCI\xD3N Y BOT\xD3N NUEVA SESI\xD3N -->
    <section class="section-heading">
      <h2>Mis Sesiones</h2>
      <ion-button size="small" class="new-session-btn" (click)="nuevaSesion()">
        <span aria-hidden="true">+</span>
        Nueva sesi\xF3n
      </ion-button>
    </section>

    <!-- LISTADO DE SESIONES -->
    <div class="sessions-list-container">
      @if (cargando) {
        <div class="loading-state" role="status">
          <ion-spinner name="crescent"></ion-spinner>
          <span>Cargando sesiones\u2026</span>
        </div>
      } @else if (sesionesFiltradas.length === 0) {
        <article class="cupping-card empty-state">
          @if (sesiones.length === 0) {
            <h3>A\xFAn no hay sesiones</h3>
            <p>Crea una sesi\xF3n o \xFAnete presionando el bot\xF3n flotante con el c\xF3digo del organizador.</p>
          } @else {
            <p>No tienes sesiones en esta categor\xEDa.</p>
          }
        </article>
      } @else {
        @for (sesion of sesionesFiltradas; track sesion.id) {
          <article class="cupping-card session-card" (click)="entrarASesion(sesion)">
            <div class="session-card__top">
              <div class="session-chips">
                <span class="chip" [class.chip-active]="sesion.estado === 'En progreso'">
                  {{ sesion.estado }}
                </span>
                <span class="chip chip-neutral">{{ sesion.rol }}</span>
              </div>
              @if (sesion.esOrganizador) {
                <div class="session-card__menu">
                  <button
                    type="button"
                    class="session-card__menu-trigger"
                    aria-label="Opciones de sesi\xF3n"
                    [attr.aria-expanded]="menuSesionAbiertoId === sesion.id"
                    [disabled]="sesionEliminandoId === sesion.id"
                    (click)="toggleMenuSesion(sesion.id, $event)">
                    \u22EE
                  </button>
                  @if (menuSesionAbiertoId === sesion.id) {
                    <div class="session-card__menu-dropdown" (click)="$event.stopPropagation()">
                      <button
                        type="button"
                        class="session-card__menu-item session-card__menu-item--danger"
                        (click)="solicitarEliminarSesion(sesion, $event)">
                        Eliminar sesi\xF3n
                      </button>
                    </div>
                  }
                </div>
              }
            </div>
            <div class="session-type">{{ sesion.tipo }}</div>
            <h3>{{ sesion.titulo }}</h3>
            <div class="session-meta">
              <span>{{ sesion.fecha }}</span>
              <span>{{ sesion.cantMuestras }} muestras</span>
              <span>{{ sesion.cantCatadores }} catadores</span>
            </div>
          </article>
        }
      }
    </div>
  </main>

  <!-- BOT\xD3N FLOTANTE PARA UNIRSE -->
  <ion-fab slot="fixed" vertical="bottom" horizontal="end">
    <ion-fab-button class="join-fab" (click)="abrirModalUnirse()" aria-label="Unirme a una sesi\xF3n">
      <ion-icon name="key-outline"></ion-icon>
    </ion-fab-button>
  </ion-fab>

  <!-- MODAL INFERIOR (BOTTOM SHEET) -->
  <ion-modal
    [isOpen]="isModalOpen"
    (didDismiss)="cerrarModalUnirse()"
    [initialBreakpoint]="0.4"
    [breakpoints]="[0, 0.4]">
    <ng-template>
      <div class="modal-content ion-padding">
        <h3>Unirme a una sesi\xF3n</h3>
        <p class="subtitle">Ingresa el c\xF3digo proporcionado por el organizador</p>

        <ion-input
          [(ngModel)]="codigoInput"
          placeholder="Ej: ABC-123"
          autocapitalize="characters"
          fill="outline"
          class="custom-input ion-margin-top">
        </ion-input>

        <ion-button
          expand="block"
          class="join-btn primary-btn"
          [disabled]="isJoining || cargandoPerfil || !codigoInput.trim()"
          (click)="unirseSesion()">
          @if (isJoining) {
            <ion-spinner name="crescent"></ion-spinner>
          } @else {
            Unirme
            <ion-icon slot="end" name="arrow-forward-outline"></ion-icon>
          }
        </ion-button>
      </div>
    </ng-template>
  </ion-modal>
</ion-content>`, styles: ['@charset "UTF-8";\n\n/* src/app/pages/dashboard/dashboard/dashboard.page.scss */\nion-toolbar {\n  --background: var(--app-bg-card, #ffffff);\n}\n.brand-title {\n  color: var(--app-text-main, #111827);\n  font-size: 18px;\n  font-weight: 700;\n}\n.brand-subtitle {\n  margin-top: 2px;\n  color: var(--app-text-muted, #6b7280);\n  font-size: 12px;\n  font-weight: 400;\n}\n.dashboard-content {\n  --background: var(--app-bg-screen, #f9fafb);\n}\n.dashboard-container {\n  width: min(100%, 900px);\n  margin: 0 auto;\n  padding-bottom: 80px;\n}\n.filter-container {\n  margin-bottom: 1.25rem;\n}\n.metrics {\n  display: grid;\n  grid-template-columns: repeat(3, minmax(0, 1fr));\n  gap: 12px;\n  margin: 8px 0 24px;\n}\n.metric-card {\n  margin: 0;\n  padding: 14px 8px;\n  text-align: center;\n}\n.metric-label {\n  color: var(--app-text-muted, #6b7280);\n  font-size: 12px;\n}\n.metric-value {\n  margin-top: 6px;\n  color: var(--app-text-main, #111827);\n  font-size: 20px;\n  font-weight: 700;\n}\n.section-heading {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  gap: 12px;\n  margin-bottom: 14px;\n}\n.section-heading h2 {\n  margin: 0;\n  color: var(--app-text-main, #111827);\n  font-size: 16px;\n  font-weight: 600;\n}\n.new-session-btn {\n  --background: #ffffff;\n  --color: #0f344c;\n  --border-radius: 10px;\n  font-weight: 600;\n  text-transform: none;\n}\n.sessions-list-container {\n  display: flex;\n  flex-direction: column;\n  gap: 12px;\n}\n.session-card {\n  position: relative;\n  padding: 16px;\n  border-radius: 12px;\n  cursor: pointer;\n  transition: transform 0.15s ease, box-shadow 0.15s ease;\n}\n.session-card:active {\n  transform: scale(0.99);\n}\n.session-card__top {\n  display: flex;\n  align-items: flex-start;\n  justify-content: space-between;\n  gap: 12px;\n}\n.session-chips {\n  display: flex;\n  flex-wrap: wrap;\n  gap: 8px;\n  margin-bottom: 8px;\n}\n.session-card__menu {\n  position: relative;\n  flex: none;\n}\n.session-card__menu-trigger {\n  display: grid;\n  width: 32px;\n  height: 32px;\n  place-items: center;\n  border: 1px solid var(--app-border, #e5e7eb);\n  border-radius: 8px;\n  background: var(--app-bg-card, #ffffff);\n  color: var(--app-text-main, #111827);\n  font-size: 20px;\n  line-height: 1;\n  cursor: pointer;\n}\n.session-card__menu-dropdown {\n  position: absolute;\n  top: calc(100% + 4px);\n  right: 0;\n  z-index: 5;\n  min-width: 160px;\n  padding: 4px;\n  border: 1px solid var(--app-border, #e5e7eb);\n  border-radius: 8px;\n  background: var(--app-bg-card, #ffffff);\n  box-shadow: 0 8px 20px rgba(15, 23, 43, 0.12);\n}\n.session-card__menu-item {\n  width: 100%;\n  padding: 9px 10px;\n  border: 0;\n  border-radius: 5px;\n  background: transparent;\n  color: var(--app-text-main, #111827);\n  font: inherit;\n  font-size: 12px;\n  text-align: left;\n  cursor: pointer;\n}\n.session-card__menu-item--danger {\n  color: var(--app-error, #ef4444);\n}\n.session-card__menu-item:hover {\n  background: var(--app-bg-screen, #f9fafb);\n}\n.chip {\n  padding: 4px 9px;\n  border-radius: 999px;\n  background: var(--app-border, #e5e7eb);\n  color: var(--app-text-muted, #6b7280);\n  font-size: 11px;\n}\n.chip-active {\n  background: #f8fafc;\n  color: var(--app-primary-dark, #0f344c);\n  font-weight: 600;\n}\n.chip-neutral {\n  background: var(--app-border, #e5e7eb);\n}\n.session-type {\n  margin: 4px 0;\n  color: var(--app-text-muted, #6b7280);\n  font-size: 12px;\n}\n.session-card h3 {\n  margin: 0;\n  color: var(--app-text-main, #111827);\n  font-size: 15px;\n}\n.session-meta {\n  display: flex;\n  flex-wrap: wrap;\n  gap: 8px 16px;\n  margin-top: 10px;\n  color: var(--app-text-muted, #6b7280);\n  font-size: 11px;\n}\n.empty-state {\n  padding: 3rem 1rem;\n  text-align: center;\n}\n.empty-state h3 {\n  margin: 0 0 8px;\n  color: var(--app-text-main, #111827);\n  font-size: 15px;\n}\n.empty-state p {\n  margin: 0;\n  color: var(--app-text-muted, #6b7280);\n  font-size: 13px;\n  line-height: 1.5;\n}\n.loading-state {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  gap: 10px;\n  padding: 32px 16px;\n  color: var(--app-text-muted, #6b7280);\n  font-size: 13px;\n}\nion-modal {\n  --background: var(--app-bg-card, #ffffff);\n  --border-radius: 16px;\n}\n.modal-content {\n  display: flex;\n  flex-direction: column;\n  gap: 4px;\n  padding-top: 20px;\n  color: var(--app-text-main, #111827);\n}\n.modal-content h3 {\n  margin: 0;\n  font-size: 16px;\n  font-weight: 600;\n}\n.modal-content .subtitle {\n  margin: 0 0 12px;\n  color: var(--app-text-muted, #6b7280);\n  font-size: 0.875rem;\n}\n.modal-content ion-button.primary-btn {\n  margin-top: 16px;\n}\n.modal-content ion-button.primary-btn[disabled] {\n  opacity: 0.45;\n}\n.join-fab {\n  --background: var(--app-primary-dark, #0f344c);\n  --background-hover: var(--app-primary-hover, #0b2738);\n  --background-activated: var(--app-primary-hover, #0b2738);\n  --color: #ffffff;\n  --box-shadow: 0 6px 16px rgb(15 52 76 / 28%);\n}\n@media (max-width: 360px) {\n  .metrics {\n    gap: 6px;\n  }\n  .metric-card {\n    padding: 10px 4px;\n  }\n  .metric-label {\n    font-size: 10px;\n  }\n  .metric-value {\n    font-size: 16px;\n  }\n}\n/*# sourceMappingURL=dashboard.page.css.map */\n'] }]
  }], () => [], null);
})();
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && \u0275setClassDebugInfo(DashboardPage, { className: "DashboardPage", filePath: "src/app/pages/dashboard/dashboard/dashboard.page.ts", lineNumber: 70 });
})();
export {
  DashboardPage
};
//# debugId=7099cd30-c3db-5ef1-84a3-c0ac119e2ff0
//# sourceMappingURL=dashboard.page-XFDJPW2F.js.map
